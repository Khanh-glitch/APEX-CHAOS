# Forward Drive — product theme authority
Owner-supplied `Forward Drive.mp3`, transcoded to Ogg Opus for repository/runtime payload efficiency. Preserve continuous playhead across product-surface pauses. Do not restart at 0 on ordinary surface changes.

Policy for the upcoming Gold cutover:
- PLAY / continue: Home/navigation, BOT/Local Fighter Pick, result/return and other allowed product surfaces until the actual battle session starts.
- PAUSE with fade-out, preserve currentTime: Lucky Draw, Fighter Upgrade, Mission(s), Fighter Shop.
- BATTLE: fade out and pause only when the actual match starts. Returning to an allowed surface resumes the same playhead with fade-in.
- TAB/WINDOW: `document.hidden` or window blur must silence/pause immediately enough that no music continues in another tab/window; resume same playhead only when visible/focused and policy allows.
- `M`: global music-only mute/unmute. Never use M to switch 1P/2P in production. M must not mute battle SFX.
- No duplicate AudioContext. Keep theme outside battle-audio graph; use the existing menu BGM HTMLMediaElement seam.
