# HUNTER VFX pack
VFX-only authority pack. Production Gold/body/trap rendering already ships in Git and must not be duplicated. Preserve real contact truth, measured trap footprint, no persistent bright movement layer, and the accepted Gold choreography. Existing Hunter SFX already lives under `public/assets/hero-rework/hunter-v10/sfx/` and is not duplicated here.
