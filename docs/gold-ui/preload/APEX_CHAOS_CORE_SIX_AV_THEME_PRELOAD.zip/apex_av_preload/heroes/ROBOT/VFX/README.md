# ROBOT VFX pack
VFX-only authority pack. Production VFX already ships in Git and must not be duplicated. Use the manifest paths at the locked branch/commit, then audit newer accepted deltas before implementation. Existing Robot SFX already lives under `public/assets/hero-rework/robot-final/sfx/` and is not duplicated here.
