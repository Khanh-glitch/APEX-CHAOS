# CRYSTALA SFX — integration map

Goal: Crystala should sound like a small number of **precise crystal/material beats**, not a chime machine. Reflection sounds are rate-limited and structural-hit audio is optional.

## 1) `source/crystala_shard_pulse_source.wav`
**Status:** LOW ACCENT  
**Original:** `2 time for a1 6 time for a2 quickly and short.wav`  
**Source duration:** ~4.719 s  
**Micro-cut:** **0.020 -> 0.200 s**

Do not play the 4.7 s source.

The useful role is a very short shard/count accent.

### A1 Wall use — DEFAULT
At `CrystalConstructCast` for a Wall:
- play the micro-cut twice
- offsets: `+0.000 s`, `+0.090 s`
- each play around -12 to -14 dB

This reads as the two authored Wall shards without adding a long extra sound.

### A2 six-shard use — OPTIONAL
If six-shard activation needs explicit count readability:
- six micro-plays at approximately:
  `+0.000, +0.050, +0.100, +0.150, +0.200, +0.250 s`
- keep them very low, roughly -15 to -17 dB
- do not enable this if `crystala_a2_awaken_source.wav` already reads clearly in OWNER playtest

Never create one long overlapping chord from six full source plays.

---

## 2) `source/crystala_a2_awaken_source.wav`
**Status:** DEFAULT ON  
**Original:** `A2 active.wav`  
**Source duration:** ~3.500 s  
**Use only:** **0.020 -> 1.700 s**

### Trigger
`CrystalAwaken`

### Playback
- one-shot only
- no loop across the whole Awakening window
- relative level about -5 to -7 dB
- if optional six-shard pulses are enabled, they must sit far underneath this cue

---

## 3) `source/crystala_projectile_reflect_source.wav`
**Status:** DEFAULT ON, rate-limited  
**Original:** `reflect bullet.wav`  
**Source duration:** ~3.900 s  
**Use only:** **0.080 -> 0.460 s**

### Trigger
Prefer `CrystalIntercept`.

Do **not** also fire the same sound again for the paired `CrystalReflect` event from that same interception. One projectile event = one audible reflect cue.

### Anti-noise
- max one reflect voice every ~90 ms per Crystala
- max 2 overlapping reflect voices
- a bullet spray should read as a few crystalline redirects, not a machine-gun of glass pings
- relative level about -9 to -12 dB

---

## 4) `source/crystala_wall_construct_source.wav`
**Status:** DEFAULT ON  
**Original:** `wall construct.wav`  
**Source duration:** ~2.333 s  
**Use only:** **0.430 -> 1.300 s**

### Trigger
`CrystalConstructCast` when `kind === "wall"`.

### Playback
- one-shot
- use as the material-growth body of the Wall
- do not layer another dedicated "construct locked" sound unless later playtest proves it necessary
- relative level about -7 to -9 dB

For Prison, leave audio silent for now rather than forcing this Wall sound onto a different construct identity.

---

## 5) `optional/crystala_construct_hit_optional_source.wav`
**Status:** OFF BY DEFAULT / MATERIAL ACCENT  
**Original:** `wall attacked.wav`  
**Source duration:** ~3.188 s  
**Use only:** **0.000 -> 0.160 s**

### Important duplication note
This source is byte-identical to Mirror's canonical `mirror_glass_snap_source.wav`.

Because of that shared sonic fingerprint, this file should **not** be a prominent Crystala identity cue.

### If enabled later
Use only as a quiet structural stress transient:
- trigger on a significant `CrystalConstructHit`
- minimum ~140 ms cooldown per construct
- skip it if the same projectile already produced a stronger Crystala reflect cue
- do not play once per pellet
- relative level about -13 to -16 dB

A good first production mix can leave this completely unwired.
