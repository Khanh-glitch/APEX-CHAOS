# CRYSTALA VFX AUTHORITY

This folder intentionally stores a **pinned authority manifest**, not a second editable copy of the accepted VFX implementation. Duplicating the Gold runtime outside Git would create another source of truth and make drift easier.

## Shipping / authority sources
- **gold_vfx_engine** — `public/game/hero-rework/crystalaGoldV6.js` — blob `f52031fd9baa7d7622ad2134b44a14b656021b8d` — REQUIRED
- **production_presentation_adapter** — `public/game/hero-rework/crystalaPresentationRuntime.js` — blob `3db0a1ca02e0189d9b5a2980b204b20d91a1c41c` — REQUIRED
- **gameplay_event_authority** — `public/game/hero-rework/crystalGameplayRuntime.js` — blob `b0c74f19fc2dc61e5713073062ec21a4b81e0d57` — REQUIRED
- **gold_reference** — `docs/hero-rework/crystala-v1/01_OWNER_APPROVED_GOLD_REFERENCE.html` — blob `349af13c09fdc4199b4fae1fc256ef56813dbe17` — reference only
- **implementation_authority** — `docs/hero-rework/crystala-v1/00_CRYSTALA_IMPLEMENTATION_AUTHORITY.md` — blob `9ce9c38146b4920fa40189242403fce6f58330ab` — reference only

## Raster dependencies
- No separate raster dependency directory is required; canonical material/effects are code-authored/baked by the Gold engine.

## Source lock
`5dc8c8c80f3804a5c363e4af0ab34c726e86e73b`

Run `../MATERIALIZE_VFX_FROM_REPO.py /path/to/APEX-CHAOS` only when a physical copy of the VFX source is actually needed.
