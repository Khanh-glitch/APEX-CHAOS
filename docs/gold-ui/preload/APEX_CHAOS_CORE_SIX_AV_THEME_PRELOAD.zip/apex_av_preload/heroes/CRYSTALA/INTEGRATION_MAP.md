# CRYSTALA — SFX + VFX INTEGRATION MAP

**Repo authority:** `Khanh-glitch/APEX-CHAOS`  
**Pinned commit:** `5dc8c8c80f3804a5c363e4af0ab34c726e86e73b`  
**Branch label at audit:** `arena/01a1025a-apex-chaos`

## Identity
Ancient crystal guardian; six living shards, refraction, material-grown constructs.

## Binding rule
VFX is already accepted in Git and is **not** to be redesigned from this pack. SFX files are the OWNER-curated sources. Do not play every file merely because it exists.

| AV beat | Runtime trigger | VFX truth | SFX source | Exact source slice | Mix policy |
|---|---|---|---|---|---|
| `A2_AWAKEN` | `CrystalAwaken` | Awaken spring, eye/pendant charge, six-shard energy lift. | `crystala_a2_awaken_source.wav` | 0.020–1.700 s | **DEFAULT ON** |
| `SHARD_RESERVE_OUTBOUND` | `CrystalReserve` | A shard claims the threat, peels from orbit and commits to intercept. | `crystala_shard_pulse_source.wav` | 0.020–0.200 s micro-cut | **LOW ACCENT; do not sound every sub-step** |
| `INTERCEPT_REFRACTION` | `CrystalIntercept` | Real shard contact, internal refraction and redirect beat. | `crystala_projectile_reflect_source.wav` | 0.080–0.460 s | **DEFAULT ON; 90 ms rate limit; max 2 voices** |
| `RELEASE_RECOIL_RETURN` | `CrystalRelease / CrystalDock` | Projectile exits; shard recoils and returns. | `—` | — | **SILENT; do not invent extra dock audio** |
| `A1_WALL_GROW` | `CrystalConstructCast kind=wall` | Two blade shards sweep to anchors; 13-cell material wall grows from both ends and locks. | `crystala_wall_construct_source.wav` | 0.430–1.300 s | **DEFAULT ON** |
| `WALL_HIT_CRACK` | `CrystalConstructHit` | Stress light, cracks, chips and debris. | `crystala_construct_hit_optional_source.wav` | 0.000–0.160 s | **OFF BY DEFAULT; >=140 ms per construct** |
| `WALL_BREAK_COLLAPSE` | `CrystalConstructBreak` | Support-failure cascade, debris and shard detach/return. | `—` | — | **SILENT in first mix** |
| `PRISON_ENCIRCLE` | `CrystalConstructCast kind=prison` | Six-shard burst, encircle, index, chain-grow and closure. | `—` | — | **SILENT; never reuse Wall sound** |

## Audio hierarchy
1. Normal Arsenal firearm/equip/body-hit audio keeps authority.
2. Hero SFX marks only mechanic identity the shared combat mix cannot express.
3. `OFF BY DEFAULT`, `LOW ACCENT`, and `SILENT` are binding first-mix decisions.
4. Trigger audio from the semantic event seam above, never from render frames or simulation ticks.
5. Compatibility/alias events for one semantic action must still produce only one audible cue.

## VFX drift guard
Read `VFX/VFX_AUTHORITY_MANIFEST.json`. If a physical copy is required, run `MATERIALIZE_VFX_FROM_REPO.py` against the checkout. It verifies pinned Git blob hashes before copying required files.
