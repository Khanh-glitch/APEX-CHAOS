# FROST — SFX + VFX INTEGRATION MAP

**Repo authority:** `Khanh-glitch/APEX-CHAOS`  
**Pinned commit:** `5dc8c8c80f3804a5c363e4af0ab34c726e86e73b`  
**Branch label at audit:** `arena/01a1025a-apex-chaos`

## Identity
Create ice, control movement, convert firearms to Frozen Gun, apply Frozen Bullet freeze.

## Binding rule
VFX is already accepted in Git and is **not** to be redesigned from this pack. SFX files are the OWNER-curated sources. Do not play every file merely because it exists.

| AV beat | Runtime trigger | VFX truth | SFX source | Exact source slice | Mix policy |
|---|---|---|---|---|---|
| `A1_CHARGE_RELEASE` | `FrostBreathCast` | 0.00–0.25 compression/jaw load; release ~+0.25; breath/core/front; authored recovery to 0.80. | `frost_a1_breath_source.mp3` | 1.340–2.140 s | **DEFAULT ON; source peak lands ~+0.24 s** |
| `A1_ICE_FRONT` | `FrostFloorBuilt` | Near-to-far crystallization front and floor material growth. | `—` | — | **No second release sound** |
| `GUN_FREEZE` | `FrostSlotFrozen / FrostGunFrozen` | Frost material grows over floor or held firearm. | `frost_weapon_freeze_source.mp3` | A 0.780–1.260; B 4.880–5.380; C 9.080–9.580 | **DEFAULT ON; one slice per conversion; cap 2 voices/frame** |
| `A2_HUNT` | `FrostHuntStart / FrostHuntEnd` | Eye/crest ignition, real-path ice trail, carve and movement energy. | `—` | — | **INTENTIONALLY SILENT in curated mix** |
| `A2_COLD_SHOCK_STEAL` | `FrostColdShock / FrostSteal` | Physical reaction plus same-holder 0.44 s transfer arc into Frost hand. | `—` | — | **INTENTIONALLY SILENT; shared collision sound may remain** |
| `FROZEN_BULLET` | `real Frozen Bullet projectile tags` | Cold projectile/muzzle overlay; firearm sound remains Arsenal authority. | `—` | — | **NO replacement gunshot** |
| `ENEMY_FREEZE` | `FrostFreezeStart` | Target shell/crust/seize VFX lasting ~0.90 s. | `frost_enemy_freeze_source.mp3` | 0.040–0.940 s | **DEFAULT ON; never replay on FrostFreezeRefresh** |
| `THAW` | `FrostThaw / slot thaw` | Ice visually releases. | `—` | — | **SILENT in curated mix** |
| `FLOOR_ENTRY` | `off-surface -> on-Frost-surface` | Optional tactile entry accent only. | `frost_floor_contact_optional_source.mp3` | 0.720–0.920 or 1.000–1.180 or 1.980–2.180 | **OFF BY DEFAULT; >=250 ms/fighter** |

## Audio hierarchy
1. Normal Arsenal firearm/equip/body-hit audio keeps authority.
2. Hero SFX marks only mechanic identity the shared combat mix cannot express.
3. `OFF BY DEFAULT`, `LOW ACCENT`, and `SILENT` are binding first-mix decisions.
4. Trigger audio from the semantic event seam above, never from render frames or simulation ticks.
5. Compatibility/alias events for one semantic action must still produce only one audible cue.

## VFX drift guard
Read `VFX/VFX_AUTHORITY_MANIFEST.json`. If a physical copy is required, run `MATERIALIZE_VFX_FROM_REPO.py` against the checkout. It verifies pinned Git blob hashes before copying required files.
