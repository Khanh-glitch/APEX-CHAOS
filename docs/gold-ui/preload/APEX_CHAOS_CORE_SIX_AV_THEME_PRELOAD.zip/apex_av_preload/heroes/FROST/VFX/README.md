# FROST VFX AUTHORITY

This folder intentionally stores a **pinned authority manifest**, not a second editable copy of the accepted VFX implementation. Duplicating the Gold runtime outside Git would create another source of truth and make drift easier.

## Shipping / authority sources
- **gold_vfx_engine** — `public/game/hero-rework/frostGoldV1.js` — blob `8982e9774072b2d51d679ca9aed47c25c465e92d` — REQUIRED
- **production_presentation_adapter** — `public/game/hero-rework/frostPresentationRuntime.js` — blob `cce79f259cf73487b915e84271782f193e97ddb4` — REQUIRED
- **gameplay_event_authority** — `public/game/hero-rework/frostGameplayRuntime.js` — blob `ce64316a6d7da2f601f92ecf800772a138542d3c` — REQUIRED
- **gold_reference** — `docs/hero-rework/frost-v1/gold/FROST_GOLD_APEX_PHYSICS_ACCURATE_V2_FIXED.html` — blob `6874c37e15aba2df0bd2ee6ba3392c2a8625e3f5` — reference only
- **implementation_authority** — `docs/hero-rework/frost-v1/00_FROST_IMPLEMENTATION_AUTHORITY.md` — blob `ca03dbf9a06dcfd33ea33f68d6c43363d1aa32b0` — reference only

## Raster dependencies
- `public/assets/hero-rework/frost-v1/` — Frost identity layers consumed by the canonical Gold VFX engine; not legacy ICE art (9 files; 636440 bytes at pinned commit).

## Source lock
`5dc8c8c80f3804a5c363e4af0ab34c726e86e73b`

Run `../MATERIALIZE_VFX_FROM_REPO.py /path/to/APEX-CHAOS` only when a physical copy of the VFX source is actually needed.
