# FROST SFX — integration map

Goal: Frost remains readable without turning the arena into constant ice ambience. The first mix uses **A1 breath, freeze conversion, and enemy freeze**. Floor-contact audio is optional.

## 1) `source/frost_a1_breath_source.mp3`
**Status:** DEFAULT ON  
**Original:** `a1 action.mp3`  
**Source duration:** ~4.704 s  
**Use only:** **1.340 -> 2.140 s** (0.800 s final window)

### Trigger
`FrostBreathCast`

### Timing
Play the cut from cast acceptance, not from the source's original beginning.

The strongest energy in this selected section occurs around original **1.58 s**, which becomes roughly **+0.24 s after playback starts**. That intentionally lands almost exactly on Frost's gameplay release at **+0.25 s**.

So the resulting timing is:

- +0.00: compression/load
- ~+0.24/+0.25: main release accent
- +0.25–0.70: breath/front body
- by +0.80: tail is gone

### Playback
- one-shot
- 5–10 ms fade-in
- 35–50 ms fade-out
- no second A1 release sound on top
- relative level about -5 to -7 dB

---

## 2) `source/frost_weapon_freeze_source.mp3`
**Status:** DEFAULT ON, choose ONE slice per event  
**Original:** `weapon freeze.mp3`  
**Source duration:** ~10.632 s

This file contains several separated sound regions. Do **not** play the whole 10.6 s file.

### Recommended short variants
- **Variant A:** `0.780 -> 1.260 s`
- **Variant B:** `4.880 -> 5.380 s`
- **Variant C:** `9.080 -> 9.580 s`

Use one variant only.

### Trigger
- `FrostSlotFrozen`
- `FrostGunFrozen`

### Anti-noise rules
- do not replay while the same slot/holder remains continuously frozen
- one freeze-conversion voice per semantic conversion
- if several guns freeze on the same frame, cap to 2 voices total
- relative level about -9 to -11 dB

Variant A is the safest default. B/C can be introduced later as random alternatives if repetition becomes noticeable.

---

## 3) `source/frost_enemy_freeze_source.mp3`
**Status:** DEFAULT ON  
**Original:** `enemy freeze.mp3`  
**Source duration:** ~8.040 s  
**Use only:** **0.040 -> 0.940 s**

### Trigger
`FrostFreezeStart`

### Do NOT trigger on
`FrostFreezeRefresh`

A refresh extends/resets an already readable freeze state; replaying the full sound every refresh would become noisy and would reward rapid Frozen Bullet hits with audio clutter.

### Timing
The chosen window is ~0.90 s, matching the authored Frost freeze duration closely enough to read as one coherent freeze event.

### Playback
- one-shot
- fade last 30–50 ms
- relative level about -7 to -9 dB

---

## 4) `optional/frost_floor_contact_optional_source.mp3`
**Status:** OFF BY DEFAULT  
**Original:** `replay when ice on floor.mp3`  
**Source duration:** ~2.736 s

Do not loop this file while a fighter is on ice.

If later playtest proves floor contact needs more tactile feedback, use a **single short entry accent**, randomly selecting one of:

- `0.720 -> 0.920 s`
- `1.000 -> 1.180 s`
- `1.980 -> 2.180 s`

### Trigger
Only on **off-surface -> on-Frost-surface transition**, not every movement tick.

### Rate limit
At least ~250 ms between floor accents for the same fighter.

### Why OFF by default
The ice already has strong visual/movement feedback. Continuous replay is the fastest way to make Frost dominate the whole combat mix.

## Explicitly not present
The accidentally nested `magnet sfx.zip` from the uploaded Frost archive was removed.
