# MAGNET VFX AUTHORITY

This folder intentionally stores a **pinned authority manifest**, not a second editable copy of the accepted VFX implementation. Duplicating the Gold runtime outside Git would create another source of truth and make drift easier.

## Shipping / authority sources
- **gold_vfx_engine** — `public/game/hero-rework/magnetGoldV1.js` — blob `da4bc7e3036d47bac3cb7936d5d3fc077f157599` — REQUIRED
- **production_presentation_adapter** — `public/game/hero-rework/magnetPresentationRuntime.js` — blob `59f70e0a58914bb7b559f739159cfa09d607a57f` — REQUIRED
- **gameplay_event_authority** — `public/game/hero-rework/magnetGameplayRuntime.js` — blob `9547e4e020909939c6aa2ceff200964c920430a8` — REQUIRED
- **gold_reference** — `docs/hero-rework/magnet-v1/gold/MAGNET_FINAL_DONOR_MAX.html` — blob `276d63ae5fb86e9f420dd49d82f29dd545b65f2f` — reference only
- **implementation_authority** — `docs/hero-rework/magnet-v1/00_MAGNET_IMPLEMENTATION_AUTHORITY.md` — blob `1ad6595ee442902804a4b8e9d8ffd0c4e52ff47c` — reference only

## Raster dependencies
- `public/assets/magnet_v1/gold/` — Gold six-part actor/channel raster dependencies consumed by magnetGoldV1.js (55 files; 868455 bytes at pinned commit).

## Source lock
`5dc8c8c80f3804a5c363e4af0ab34c726e86e73b`

Run `../MATERIALIZE_VFX_FROM_REPO.py /path/to/APEX-CHAOS` only when a physical copy of the VFX source is actually needed.
