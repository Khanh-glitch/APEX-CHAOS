# MAGNET SFX — integration map

Goal: Magnet should communicate **inward pull**, **outward repulsion**, and **bullet deflection** with only three sounds. Do not add continuous electrical ambience.

## 1) `source/magnet_a1_attraction_source.wav`
**Status:** DEFAULT ON  
**Original:** `magnet a1 active.wav`  
**Source duration:** ~1.023 s  
**Use only:** **0.000 -> 0.520 s**

### Trigger
`MagnetA1Start`

### Playback
- one-shot only
- no loop
- fade-out 25–35 ms at the cut end
- target relative level: about -5 to -7 dB vs normal gunfire

### Why this cut
The meaningful authored activity is concentrated in the first ~0.50 s; the rest of the source is effectively dead tail. Keeping the whole 1.023 s adds no useful identity.

---

## 2) `source/magnet_a2_repulsion_source.wav`
**Status:** DEFAULT ON  
**Original:** `magnet a2 acitve.wav`  
**Source duration:** ~3.111 s  
**Use only:** **0.080 -> 1.620 s**

### Trigger
`MagnetA2Start`

### Playback
- one-shot; **do not loop for the entire 1.80 s field**
- the natural tail may end before gameplay A2 ends
- if the skill is forcibly torn down, stop/fade the voice rather than leaving it detached
- target relative level: about -6 to -8 dB

### Why this cut
The source carries its useful energy through roughly 0.10–1.60 s. The remaining tail is unnecessary and would make the field feel like constant ambience.

---

## 3) `source/magnet_a2_bullet_deflect_source.mp3`
**Status:** DEFAULT ON, heavily rate-limited  
**Original:** `bullet touch reflect magnet.mp3`  
**Source duration:** ~1.872 s  
**Use only:** **0.620 -> 0.960 s**

### Trigger
Use the real A2 bullet-capture/deflection seam already consumed by Magnet presentation (`inspect().captureEvents` / Gold `a2capture`).  
Do **not** trigger just because a bullet is somewhere inside A2.

### Important cut rule
This cut is intentionally the **bullet-whizz / directional movement portion**.

**Stop before ~1.03 s of the original source**, where a stronger transient appears. We do not want that impact-like transient because the gameplay beat is magnetic redirection, not a bullet striking a solid wall.

### Anti-noise rules
- max one deflect voice every ~80–100 ms per Magnet
- max 2 overlapping voices
- if many pellets cross together, represent the burst with 1–2 whizzes, not N sounds
- target relative level: about -10 to -12 dB
- 5 ms fade-in / 20 ms fade-out

## Do not add
- body-collision Magnet SFX
- separate A1 gun-by-gun pull sounds
- field hum loops
- a sound every simulation tick
