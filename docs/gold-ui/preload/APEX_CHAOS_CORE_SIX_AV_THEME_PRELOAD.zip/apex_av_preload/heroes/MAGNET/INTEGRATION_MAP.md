# MAGNET — SFX + VFX INTEGRATION MAP

**Repo authority:** `Khanh-glitch/APEX-CHAOS`  
**Pinned commit:** `5dc8c8c80f3804a5c363e4af0ab34c726e86e73b`  
**Branch label at audit:** `arena/01a1025a-apex-chaos`

## Identity
Trajectory controller; inward acquisition and outward nonlinear magnetic pressure.

## Binding rule
VFX is already accepted in Git and is **not** to be redesigned from this pack. SFX files are the OWNER-curated sources. Do not play every file merely because it exists.

| AV beat | Runtime trigger | VFX truth | SFX source | Exact source slice | Mix policy |
|---|---|---|---|---|---|
| `A1_ATTRACTION` | `MagnetA1Start` | Inward pole choreography, curved filaments, target rings, object histories and pressure fronts. | `magnet_a1_attraction_source.wav` | 0.000–0.520 s | **DEFAULT ON; one-shot only** |
| `A1_OBJECT_RESPONSE` | `real A1 object influence` | VFX reacts per object; audio intentionally does not. | `—` | — | **SILENT; no gun-by-gun pull sound** |
| `A2_REPULSION` | `MagnetA2Start` | Outward pole spread, reactive R225 pressure field and object-pressure arcs. | `magnet_a2_repulsion_source.wav` | 0.080–1.620 s | **DEFAULT ON; no loop** |
| `A2_BULLET_DEFLECT` | `real captureEvents / Gold a2capture` | Short field-boundary catch/bend arc at the real redirection seam. | `magnet_a2_bullet_deflect_source.mp3` | 0.620–0.960 s | **DEFAULT ON; 80–100 ms rate limit; max 2 voices** |
| `PASSIVE_ACCELERATION` | `MagnetPassiveEmission` | Gold corridor/pole pulse for Magnet-fired velocity bonus. | `—` | — | **SILENT in curated first mix** |
| `IMPACT_RESPONSE` | `RealizedDamageEvent / BodyCollision` | Actor VFX reaction only; shared combat SFX stays authority. | `—` | — | **NO hero-specific impact audio** |

## Audio hierarchy
1. Normal Arsenal firearm/equip/body-hit audio keeps authority.
2. Hero SFX marks only mechanic identity the shared combat mix cannot express.
3. `OFF BY DEFAULT`, `LOW ACCENT`, and `SILENT` are binding first-mix decisions.
4. Trigger audio from the semantic event seam above, never from render frames or simulation ticks.
5. Compatibility/alias events for one semantic action must still produce only one audible cue.

## VFX drift guard
Read `VFX/VFX_AUTHORITY_MANIFEST.json`. If a physical copy is required, run `MATERIALIZE_VFX_FROM_REPO.py` against the checkout. It verifies pinned Git blob hashes before copying required files.
