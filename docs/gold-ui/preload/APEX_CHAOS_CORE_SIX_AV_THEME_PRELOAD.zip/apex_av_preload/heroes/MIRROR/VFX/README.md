# MIRROR VFX AUTHORITY

This folder intentionally stores a **pinned authority manifest**, not a second editable copy of the accepted VFX implementation. Duplicating the Gold runtime outside Git would create another source of truth and make drift easier.

## Shipping / authority sources
- **gold_vfx_engine** — `public/game/hero-rework/mirrorGoldV1.js` — blob `debf781083a441e8512389d52910629c7b7fdeb5` — REQUIRED
- **production_presentation_adapter** — `public/game/hero-rework/mirrorPresentationRuntime.js` — blob `a022ef0ff4aacb3df568191175679494528b086d` — REQUIRED
- **active_skill_gameplay_events** — `public/game/hero-rework/heroMechanicsRuntime.js` — blob `c3ff8f68e00320125d66d4bee2278b2c0f4c4431` — REQUIRED
- **passive_routing_gameplay_events** — `public/game/hero-rework/heroReworkRuntime.js` — blob `eaa4708e0af3f0c4702fdbc0b830e0e4e6e52c37` — REQUIRED
- **gold_reference** — `docs/hero-rework/mirror-v1/gold/MIRROR_GOLD_FUSION_12.html` — blob `d955d96cdc162aa046fa386b617b90745b6495ee` — reference only
- **implementation_authority** — `docs/hero-rework/mirror-v1/00_MIRROR_IMPLEMENTATION_AUTHORITY.md` — blob `ffeaf0c636f0fff598e64ff88d76b9e0132d2742` — reference only

## Raster dependencies
- No separate raster dependency directory is required; canonical material/effects are code-authored/baked by the Gold engine.

## Source lock
`5dc8c8c80f3804a5c363e4af0ab34c726e86e73b`

Run `../MATERIALIZE_VFX_FROM_REPO.py /path/to/APEX-CHAOS` only when a physical copy of the VFX source is actually needed.
