# MIRROR SFX — integration map

Goal: Mirror gets one clear sound per **semantic transformation**, not one sound for every visual sub-step.

Important cleanup: the uploaded `a1 when already have gun.wav` and `a2.wav` are **byte-identical**. The duplicate was collapsed into one canonical source:
`source/mirror_glass_snap_source.wav`.

## 1) `source/mirror_a1_cast_source.wav`
**Status:** DEFAULT ON  
**Original:** `a1 active mirror.wav`  
**Source duration:** ~1.250 s  
**Use only:** **0.050 -> 1.150 s**

### Trigger
`MirrorA1Cast`

### Playback
- one-shot
- no separate full-volume sound at A1 OWN by default
- this source already carries the A1 transformation motion through the important ~0.93 s OWN timing
- relative level about -6 to -8 dB

---

## 2) `source/mirror_glass_snap_source.wav`
**Status:** DEFAULT ON for A2; A1 OWN use is OPTIONAL  
**Original kept:** `a2.wav`  
**Duplicate removed:** `a1 when already have gun.wav`  
**Source duration:** ~3.188 s

### Primary use — A2 exchange
**Cut:** `0.000 -> 0.320 s`  
**Trigger:** `MirrorExchange`

Trigger at the actual atomic exchange event, **not `MirrorA2Cast`**. That keeps the sonic snap exactly on the gameplay position swap (~0.258 s after cast).

Relative level: about -7 to -9 dB.

### Optional secondary use — A1 OWN
**OFF BY DEFAULT**  
If playtest says A1 materialization is not readable enough:

- cut `0.000 -> 0.180 s`
- trigger `MirrorA1Own`
- keep it very quiet: roughly -13 to -15 dB

Do not enable this on the first mix; `mirror_a1_cast_source.wav` should carry A1 by itself unless OWNER playtest asks for a second tactile edge.

---

## 3) `source/mirror_passive_shard_drop_source.wav`
**Status:** LOW ACCENT  
**Original:** `piece of mirror drop passive.wav`  
**Source duration:** ~3.125 s

The source contains three useful separated takes. Use one random slice per realized passive proc:

- **A:** `0.400 -> 0.700 s`
- **B:** `1.020 -> 1.280 s`
- **C:** `2.340 -> 2.660 s`

### Trigger
Once per realized Mirror damage event **when the passive actually creates one or more shards**.

### Critical anti-noise rule
If one hit creates 5 shards, play **ONE** shard-drop sound, not five.

### Mix
- relative level about -12 to -15 dB
- max one passive drop voice per ~100 ms
- do not stack A/B/C simultaneously

---

## 4) `source/mirror_passive_node_form_source.wav`
**Status:** DEFAULT ON, quiet  
**Original:** `mirro passvie appear.wav`  
**Source duration:** ~5.844 s  
**Use only:** **1.160 -> 2.050 s**

### Trigger
`MirrorNodeForming`

Use this as the single formation-to-lock sound. Do **not** add a second full-volume sound at `MirrorNodeActive`; the visual lock is enough.

### Mix
- relative level about -10 to -12 dB
- max one node-form voice per Mirror at a time

---

## 5) `optional/mirror_passive_node_fold_optional_source.wav`
**Status:** OFF BY DEFAULT  
**Original:** `mirror passive disapear.wav`  
**Source duration:** ~3.701 s  
**Use only:** **2.840 -> 3.420 s**

This ~0.58 s window is close to Mirror's authored ~0.55 s fold envelope.

### Preferred trigger
Start when the node enters its FOLD state.

### Do not
If integration only exposes `MirrorNodeOff` at the **end** of folding, do not play this late just to use the file. Leave it silent until a fold-start seam is available.

### Why optional
Multiple node expiries can otherwise create unnecessary glassy clutter during normal gun combat.
