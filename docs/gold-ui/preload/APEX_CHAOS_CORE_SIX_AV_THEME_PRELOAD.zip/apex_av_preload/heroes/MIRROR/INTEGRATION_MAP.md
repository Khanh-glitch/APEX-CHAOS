# MIRROR — SFX + VFX INTEGRATION MAP

**Repo authority:** `Khanh-glitch/APEX-CHAOS`  
**Pinned commit:** `5dc8c8c80f3804a5c363e4af0ab34c726e86e73b`  
**Branch label at audit:** `arena/01a1025a-apex-chaos`

## Identity
Two-face living mirror; opponent reflection manipulation, atomic exchange, damage-born shard/node routing.

## Binding rule
VFX is already accepted in Git and is **not** to be redesigned from this pack. SFX files are the OWNER-curated sources. Do not play every file merely because it exists.

| AV beat | Runtime trigger | VFX truth | SFX source | Exact source slice | Mix policy |
|---|---|---|---|---|---|
| `A1_REFLECTION_PEEL` | `MirrorA1Cast` | Opponent weapon reflection/image attaches, peels and reforms toward Mirror. | `mirror_a1_cast_source.wav` | 0.050–1.150 s | **DEFAULT ON** |
| `A1_OWN_EDGE` | `MirrorA1Own ~0.933 s` | Gameplay copy materializes at canonical OWN edge. | `mirror_glass_snap_source.wav` | 0.000–0.180 s | **OFF BY DEFAULT; only if OWNER asks for more tactile read** |
| `A1_WHIFF` | `MirrorA1Whiff` | Gold whiff choreography only. | `—` | — | **No extra sound selected** |
| `A2_PRE_SNAP_EXCHANGE` | `MirrorA2Cast -> MirrorExchange ~0.258 s` | Mixed-identity pre-snap band/ghost then atomic position swap and residue. | `mirror_glass_snap_source.wav` | 0.000–0.320 s | **DEFAULT ON at MirrorExchange, NOT cast** |
| `PASSIVE_SHARD_DROP` | `realized Mirror damage event that creates shards` | Free shard scatter seeded from real impact provenance. | `mirror_passive_shard_drop_source.wav` | A 0.400–0.700; B 1.020–1.280; C 2.340–2.660 | **LOW ACCENT; ONE sound per proc, never per shard** |
| `PASSIVE_NODE_FORM` | `MirrorNodeForming` | Five-shard assembly, fill and lock choreography. | `mirror_passive_node_form_source.wav` | 1.160–2.050 s | **DEFAULT ON quiet; max one node-form voice/Mirror** |
| `PASSIVE_NODE_ACTIVE` | `MirrorNodeActive` | Node visual lock/readability. | `—` | — | **No second full-volume lock sound** |
| `PASSIVE_NODE_FOLD` | `fold start -> MirrorNodeOff` | Authored ~0.55 s fold/off envelope. | `mirror_passive_node_fold_optional_source.wav` | 2.840–3.420 s | **OFF BY DEFAULT; only if fold-start seam exists** |
| `PROJECTILE_CAPTURE` | `MirrorRouteCapture` | Projectile image is captured into active node. | `—` | — | **SILENT in current curated mix** |
| `DESTINATION_IMAGE` | `MirrorEscrowImage` | Destination image appears before emergence. | `—` | — | **SILENT; no preview leak** |
| `PROJECTILE_EMERGE` | `MirrorRouteEmerge` | Projectile emerges from destination/fallback with retained identity. | `—` | — | **SILENT in current curated mix** |

## Audio hierarchy
1. Normal Arsenal firearm/equip/body-hit audio keeps authority.
2. Hero SFX marks only mechanic identity the shared combat mix cannot express.
3. `OFF BY DEFAULT`, `LOW ACCENT`, and `SILENT` are binding first-mix decisions.
4. Trigger audio from the semantic event seam above, never from render frames or simulation ticks.
5. Compatibility/alias events for one semantic action must still produce only one audible cue.

## VFX drift guard
Read `VFX/VFX_AUTHORITY_MANIFEST.json`. If a physical copy is required, run `MATERIALIZE_VFX_FROM_REPO.py` against the checkout. It verifies pinned Git blob hashes before copying required files.
