# APEX CHAOS — Core Six AV + Theme preload
This archive is an implementation preload, not a second VFX source of truth.

Heroes:
- ROBOT: VFX authority manifest; existing production SFX remains in repo.
- HUNTER: VFX authority manifest; existing production SFX remains in repo.
- CRYSTALA / MAGNET / FROST / MIRROR: VFX authority manifest + curated production-ready SFX cuts.

VFX law: materialize/reuse the locked Git shipping authority. Do not fork Gold/presentation code merely because this is called an asset pack.
SFX law: wire only semantic runtime events listed by each integration/cut authority. Optional clips stay OFF BY DEFAULT until owner playtest asks for them.
Theme law: see `music/README.md`.
