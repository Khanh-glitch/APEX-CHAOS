# APEX-CHAOS GitHub Actions storage audit

Snapshot: artifact API pagination completed 2026-11-01 UTC; repository checkout c7a04f0b57f08093a783fa6080b536b9754c83a8 (main base). Private repository verified. This is read-only: no artifacts downloaded or deleted.

## Inventory and interpretation
- Artifact API: 5,730 records across 58 pages; total_count values [5730]; unique IDs 5,730; expired=false for 5,730. Total 231,662,321,660 bytes (231.662322 decimal GB; 215.752350 GiB). API list is a time-varying snapshot, not an atomic transaction; revalidate before action.
- Oldest/newest created: 2026-09-23T15:59:25Z / 2026-10-29T01:53:52Z. Earliest/latest expiry: 2026-11-02T07:11:46Z / 2027-01-27T00:35:10Z. Expirations as returned, not assumed retroactively shortened.
- Separate cache API: 27 entries, 2,362,231,541 bytes; usage endpoint reports 27 and 2,362,231,541 bytes. See cache-inventory.csv. No cache deletion proposed; cache use is not artifact storage. These are point-in-time logical size figures, not a reconstruction of billed storage.
- User-supplied billing: 369.06 APEX GB-hours, 158.21 Soul-of-Hero, total 530.21, $0; not independently verified. GB-hours are a time-integral, not current GB; a point-in-time inventory cannot establish exact historical drivers or convert these figures to current gigabytes. Deletion can reduce future accrual, not undo already accrued GB-hours. The apparent magnitude disparity needs billing-period, accounting and reporting-lag verification; do not infer fraud or exact cost savings.
- Run metadata was separately paginated: snapshot includes 12,400 runs (API reported 13,523 at last complete page); 841 artifacts / 73,881,432,363 bytes could not be joined to a run in that snapshot. Unknown is explicitly grouped, never inferred from names. See workflow-totals.csv. Run URL and SHA are provided from artifact metadata even when workflow cannot be resolved. The separate workflow-run pagination exceeded the 180-second command wait and was still in progress at the snapshot; this does not affect full artifact pagination.

## Age distribution (approximate, at 2026-11-01 05:08 UTC)

- 0–7 days: 976 artifacts, 27,072,434,606 bytes.
- 7–14 days: 941 artifacts, 48,681,447,728 bytes.
- 14–30 days: 3,138 artifacts, 93,354,500,307 bytes.
- 30+ days: 675 artifacts, 62,553,939,019 bytes.

## Categories and conservative savings
- KEEP: 0 artifacts, 0 bytes.
- ARCHIVE_THEN_DELETE: 0 artifacts, 0 bytes.
- DELETE_CANDIDATE: 1 artifacts, 7,929 bytes.
- NEEDS_REVIEW: 5,729 artifacts, 231,662,313,731 bytes.
- Proposed candidate only: delete ID 12741023054 **after explicit approval** and after checking ID 12741543396 still exists with matching digest, size and SHA. Reclaimable 7,929 bytes (0.007929 MB); estimated remaining artifact bytes 231,662,313,731, assuming no other changes. Preserving the archive does not preserve the deleted artifact ID or run linkage; record both before deletion. This is a conservative upper estimate of immediate candidate savings, not billed GB-hours.
- No current inventory item is positively proven to be accepted release evidence, nor verified as durably archived; accordingly no KEEP or ARCHIVE_THEN_DELETE designation is asserted. NEEDS_REVIEW is a preservation hold, not permission to discard. GOLD, release, exact-SHA and irreplaceable evidence must be protected, including all uncertain candidates.

## Top 20 largest artifacts (decimal MB)

| Rank | ID | Artifact | Bytes | MB | Workflow / run |
|---:|---:|---|---:|---:|---|
| 1 | 12513060678 | arsenal-product-acceptance | 260,292,216 | 260.292 | Arsenal Product Acceptance [run 39973763390](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/39973763390) |
| 2 | 12520768343 | arsenal-product-acceptance | 260,217,854 | 260.218 | Arsenal Product Acceptance [run 39995883878](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/39995883878) |
| 3 | 12509186377 | arsenal-product-acceptance | 259,926,389 | 259.926 | Arsenal Product Acceptance [run 39967396229](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/39967396229) |
| 4 | 12515250827 | arsenal-product-acceptance | 259,470,160 | 259.470 | Arsenal Product Acceptance [run 39981156898](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/39981156898) |
| 5 | 12516736299 | arsenal-product-acceptance | 259,443,697 | 259.444 | Arsenal Product Acceptance [run 39985486750](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/39985486750) |
| 6 | 12578176982 | arsenal-product-acceptance | 259,258,770 | 259.259 | Arsenal Product Acceptance [run 40135719110](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/40135719110) |
| 7 | 12607155064 | arsenal-product-acceptance | 258,439,897 | 258.440 | Arsenal Product Acceptance [run 40210602192](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/40210602192) |
| 8 | 11297951727 | arsenal-product-acceptance | 257,146,702 | 257.147 | Unknown [run 37187455343](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/37187455343) |
| 9 | 11297540907 | arsenal-product-acceptance | 256,778,264 | 256.778 | Unknown [run 37186996646](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/37186996646) |
| 10 | 11298597571 | arsenal-product-acceptance | 256,635,045 | 256.635 | Unknown [run 37190561193](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/37190561193) |
| 11 | 11298805451 | arsenal-product-acceptance | 256,461,110 | 256.461 | Unknown [run 37189632094](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/37189632094) |
| 12 | 11298357350 | arsenal-product-acceptance | 256,443,080 | 256.443 | Unknown [run 37188454327](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/37188454327) |
| 13 | 11298372080 | arsenal-product-acceptance | 256,368,240 | 256.368 | Unknown [run 37188386232](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/37188386232) |
| 14 | 11292983580 | arsenal-product-acceptance | 256,342,519 | 256.343 | Unknown [run 37176853988](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/37176853988) |
| 15 | 11292649893 | arsenal-product-acceptance | 256,328,145 | 256.328 | Unknown [run 37175302014](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/37175302014) |
| 16 | 11299175443 | arsenal-product-acceptance | 256,304,850 | 256.305 | Unknown [run 37190277813](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/37190277813) |
| 17 | 11293711171 | arsenal-product-acceptance | 256,259,505 | 256.260 | Unknown [run 37176261894](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/37176261894) |
| 18 | 11297845667 | arsenal-product-acceptance | 256,246,436 | 256.246 | Unknown [run 37186859684](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/37186859684) |
| 19 | 11295357287 | arsenal-product-acceptance | 256,068,199 | 256.068 | Unknown [run 37181949924](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/37181949924) |
| 20 | 11297224223 | arsenal-product-acceptance | 255,973,159 | 255.973 | Unknown [run 37188633164](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/37188633164) |

## Largest repeated artifact names (not evidence of identical content)

| Name | Count | Bytes |
|---|---:|---:|
| arsenal-product-acceptance | 1,877 | 105,959,432,755 |
| arsenal-quest-production-build | 206 | 47,565,587,624 |
| localization-chrome-visual-evidence | 426 | 25,504,844,860 |
| arsenal-quest-qa-evidence | 278 | 12,216,494,990 |
| arsenal-quest-browser-evidence | 220 | 5,628,317,012 |
| b8-gold-mobile | 185 | 4,088,922,717 |
| quest-q2-real-n-actors-and-browser | 134 | 3,701,006,932 |
| r89-gold-browser-evidence | 27 | 3,086,209,331 |
| b8-gold-desktop | 183 | 2,349,303,186 |
| apex-bot-wave-metal-hardware-trace | 21 | 1,672,191,816 |
| a1-skill-details-browser | 177 | 1,292,196,229 |
| v43-owner-chrome-visual-proof | 95 | 993,973,412 |
| cp16-cold-return-chrome | 151 | 821,791,821 |
| apex-chaos-itch-owner-gold-html5 | 11 | 812,155,850 |
| bot-wave-f1-browser | 104 | 716,829,975 |
| cp8-owner-gold-real-chrome-frames | 155 | 692,807,723 |
| apex-chaos-itch-guest-200ac-rc | 9 | 657,482,300 |
| story-lock-f2-browser | 90 | 593,942,681 |
| b6n-gold-mobile | 20 | 591,867,104 |
| b6n-gold-desktop | 20 | 333,135,189 |

## Storage by workflow

Full workflow grouping is in workflow-totals.csv; includes an explicit unknown bucket. Largest groups:

| Workflow / path | Count | Bytes |
|---|---:|---:|
| Arsenal Product Acceptance [.github/workflows/arsenal-product-acceptance.yml] | 1,764 | 97,497,359,019 |
| UNKNOWN / run not in snapshot [?] | 841 | 73,881,432,363 |
| VIE ENG Localization Gates [.github/workflows/localization-gates.yml] | 426 | 25,504,844,860 |
| B8 E08 Last Choice Native Gold [.github/workflows/quest-b8-e08-last-choice-gold.yml] | 368 | 6,438,225,903 |
| R89 Gold Responsive Resolver [.github/workflows/r89-gold-responsive.yml] | 27 | 3,086,209,331 |
| BOT WAVE Apple Silicon GPU availability probe [.github/workflows/bot-wave-apple-gpu-probe.yml] | 43 | 1,672,236,801 |
| BOT WAVE WASM candidate playtest acceptance [.github/workflows/bot-wave-wasm-playtest.yml] | 25 | 1,601,548,017 |
| RA-2 Exact-SHA Isolated Preview [.github/workflows/ra2-exact-sha-preview.yml] | 11 | 1,484,754,779 |
| Owner five-session swipe + wallet + HUD itch acceptance [.github/workflows/owner-five-session-swipe-itch.yml] | 16 | 1,408,474,549 |
| A1 Account Economy Gates [.github/workflows/a1-account-economy-gates.yml] | 177 | 1,292,196,229 |
| itch CDN subpath white-screen acceptance [.github/workflows/itch-subpath-acceptance.yml] | 17 | 1,285,950,917 |
| Owner Gold Direct-Port Acceptance [.github/workflows/gold-direct-port-acceptance.yml] | 91 | 1,229,471,927 |
| Quest Q3 Presentation isolated acceptance [.github/workflows/quest-q3-presentation.yml] | 44 | 1,032,778,685 |
| V43 Owner Real Browser Reproduction [.github/workflows/v43-owner-real-browser.yml] | 95 | 993,973,412 |
| Package Owner Gold for itch.io [.github/workflows/owner-gold-itch-package.yml] | 18 | 993,039,409 |

## Waste investigation and evidence
- Arsenal Product Acceptance is a major repeated family. The checked-in workflow uploads `dist/`, a Windows package whose `app/` is populated by copying `dist/`, browser captures, and logs together with `if: always()` and no explicit retention. This shows repeated upload and an apparent duplicated payload inside a successful artifact; exact archive content, byte savings and historical workflow versions have not been verified. It also triggers on all pull requests and pushes to main, development/v43, arena/** and one integration branch; an open PR from a matching branch can produce both push and PR runs. Trigger overlap is possible, not proof any two distinct runs are redundant.
- Production builds, localization Chrome evidence, QA/browser evidence and GOLD screenshots are large repeated families; run-specific outputs and failures can be historically valuable. No digest match is assumed from a common name. Check failed runs and report supersession against issue/PR ownership before disposal.
- API digest comparison found exactly one equal-digest pair: 12741023054 and 12741543396, each 7,929 bytes, same name and head SHA. Digest is archive-level evidence; the distinct run IDs remain distinct provenance. All other returned artifact digests differ; this does not rule out substantially identical individual files within different ZIPs.
- R90 `r90-r52-r81-chromium-evidence`: three records (11594788940, 11594549460, 11594303604), about 4.08 MB each, distinct digests; other R90-named reports also exist. Do not delete based on labels. V43 `v43-owner-chrome-visual-proof`: 95 records totaling 993,973,412 bytes; its active workflow explicitly calls it exact-SHA browser reproduction and screenshots. Protect pending owner review. V43 gold preflight has 581 records; avoid automatic deletion of historical certification outcomes.
- Builds can potentially be rerun from available commits and locked dependencies, but exact original environment, generated assets, signatures, deployment and acceptance state may not be reproducible. Screenshots, logs, failure state, exact-SHA proof and original artifact/run associations can be irreplaceable.

## Workflow prevention proposal (not implemented)
- Current checkout: 82 workflow files; 60 contain 63 upload-artifact steps; 13 retention-days declarations found in upload-bearing files (manual scan, not historical workflow evidence). GitHub retention setting API returned HTTP 403 Resource not accessible by integration; the user-reported 30-day setting is not independently verified. Existing expiry timestamps extend to 2027-01-27. Do not assume lowering the setting retroactively changes old artifacts.
- Assign explicit 3–7 days to genuinely temporary routine CI captures/logs, up to 14 days for integration evidence; obtain owner approval for the classification and check each downstream download consumer. Keep 30-day repository default; per-upload retention must conform to repository limits.
- Separate temporary CI reports/builds from accepted GOLD/release evidence. Publish final accepted exact-SHA proofs, manifests, source/run links and checksums to an owner-approved durable archive independent of Actions expiry, with restore verification. Preserve original IDs and run metadata. Avoid storing production dist twice in a single upload where functionally equivalent; confirm consumers and inspect contents before removing paths.
- Audit open-PR push/pull_request overlap per workflow and event, SHA, ref and required checks. Consolidate only equivalent uploads or share immutable artifacts after verification; keep the tests and branch-protection gates intact. Keep native/runtime, Chromium, visual and release gates unchanged. Failures may need longer retention during incident investigation.
- Explicit examples: R89 preview dist uses 7 days; BOXE candidate and C04 evidence use 14 days. R90 and V43 owner captures and Arsenal product upload have no explicit retention in the inspected revision. Historical runs may use other definitions.

## Approved execution sequence for Control Tower
1. Before expiry, review NEEDS_REVIEW prioritized by size and imminent expiry. Determine accepted release/GOLD status, owner, SHA, original run, decision and archive destination. Rerun inventory and capture API metadata; snapshots race expiration and newly-created artifacts.
2. For valuable items selected for archival, with authorization download individually to approved durable storage, retain repository/run/commit/artifact IDs and SHA-256 digest, compare the downloaded ZIP to the API digest, verify independent durable copy and restoration, record custodian and retention policy. Only then reclassify ARCHIVE_THEN_DELETE; never treat GitHub release assets as automatically verified copies.
3. Obtain explicit approval for an exact ID list. For candidate 12741023054, fetch both artifact metadata records and confirm survivor exists, unexpired and has same SHA-256 digest, size and head SHA; preserve both run URLs, names, timestamps and IDs in the external record. If any check fails, stop. With separate delete permissions and approval, execute `gh api --method DELETE repos/Khanh-glitch/APEX-CHAOS/actions/artifacts/12741023054`; do not run this command during the audit. No bulk or wildcard deletion.
4. Verify candidate deletion by re-querying and verify survivor remains downloadable and digest-matching, then compare refreshed inventory. Do not delete caches without a separate review/approval; cache scope/ref and last access affect rebuilds. Monitor future billing over time.

## Risks, blockers and confidence
- High confidence in paginated artifact record count, byte sum and reported metadata at query time, subject to non-atomic pagination and service-reported sizes/digests. High confidence in duplicate archive digest as API metadata, not independently downloaded/hashed. Medium confidence in present-checkout workflow diagnosis; historical definitions and exact archive contents are unverified.
- Low confidence in acceptance, ownership, recreation and supersession for individual records: no content downloads, releases/owner decisions or archive verification. Retention settings endpoint denied (HTTP 403); the claimed 30 days remains user-supplied. Different ZIP digests do not prove distinct underlying screenshots. Workflow run API enrichment may be incomplete as noted; unknown grouping is explicit.
- Artifact-by-artifact manifest includes exact reason, timestamps, SHA, digest, run link and classification; workflow grouping and cache metadata are separate CSVs. Sorting the CSV by bytes, creation or name supports size, age and repetition prioritization.

## Control Tower handoff
**May delete only after explicit approval and the checks above:** 12741023054 (7,929 bytes), retaining matching 12741543396 and recording provenance. **Must preserve:** all exact-SHA GOLD, accepted releases, unique visual evidence, run records and anything without verified archive or review. **Human approval required:** all other 5,729 artifacts, any archiving/deletion, all caches, and workflow policy changes. No destructive action has been performed.
