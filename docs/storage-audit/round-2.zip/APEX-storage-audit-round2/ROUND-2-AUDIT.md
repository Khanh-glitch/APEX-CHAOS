# APEX-CHAOS storage recovery — round 2

**Read-only, versioned follow-up.** The prior report and its manifest remain unchanged. This report distinguishes measured metadata, proposed decisions, and hypothetical projections. No archive was downloaded; no destructive or repository operation occurred.

## 1. Live revalidation
- Artifact pagination began 2026-11-01T05:11:21Z and completed 2026-11-01T05:11:47Z. 58 pages, each reported total_count 5,730; 5,730 records and 5,730 unique IDs; all expired=false. Count and total match round 1. All 5,730 prior IDs remain; no new IDs. Per-ID name, bytes, creation, expiration, expired status and digest changes: none. The list is paginated and not atomic; recheck immediately before action.
- Current retained API size **231,662,321,660 bytes**, 231.662322 GB decimal or 215.752350 GiB. Expiry range 2026-11-02T07:11:46Z to 2027-01-27T00:35:10Z. GitHub reported 27 caches / 2,362,231,541 bytes separately; do not add caches to artifacts or treat either as GB-hours. Packages storage was not inventoried.
- The separate repository run listing completed 2026-11-01T05:16:07Z: 136 pages; 13,523 reported and enumerated unique runs. All 5,730 artifact run IDs now resolve. The prior 841 unknown workflow mappings represented 73,881,432,363 bytes; all 841 are now resolved, leaving 0 unmatched and 0 unmatched bytes. This is mapping completeness, not acceptance-state completeness.
- Repository retention API again returned HTTP 403. The 30-day setting remains user-reported; actual expiry timestamps show older artifacts retaining dates in December and January. Workflow evidence remains independently inspectable.

## 2. Billing reconciliation
- The user supplied 369.06 APEX GB-hours for November and $0 billed; the timestamp, billing timezone, SKU, detailed usage rows, and accounting delay were not supplied or independently accessible. A point-in-time 215.752 GiB cannot be directly compared to a month-to-date GB-hour integral. GitHub defines its storage GB as 2^30 bytes, and documentation says usage can update within 6–12 hours ([GitHub billing documentation](https://docs.github.com/en/billing/concepts/product-billing/github-actions)).
- Diagnostic only: every retained artifact was created before November 1 UTC. If API bytes equaled billed storage continuously since 00:00 UTC and the dashboard were fully current at 05:11:47 UTC, the artifact-only integral would be about 1,121.13 binary GB-hours, not 369.06. Conversely 369.06 / current 215.752 GiB is about 1.71 equivalent hours. These are conditional illustrations, not billing reconstructions; usage reporting lag, different reporting as-of times, SKU/accounting scope, units and possible API-versus-billing measurement differences could explain the mismatch, but none is proven. A dashboard lag of several hours is plausible under GitHub’s documented update window, not verified. User’s local timezone does not establish the billing cycle timezone.
- Packages and artifact storage share an allowance according to GitHub; Packages storage is not measured here. Cache allowance and accounting are separate; the inventory does not establish billed cache usage. Request timestamped hourly billing/export, SKU labels, billing cycle timezone and GitHub support clarification before claiming a reconciliation or cost savings. Deletion cannot reverse accrued GB-hours.

## 3. Pareto: what dominates
| Largest artifacts | Cumulative bytes | Share |
|---:|---:|---:|
| 20 | 5,150,404,237 | 2.223% |
| 50 | 12,615,459,372 | 5.446% |
| 100 | 24,903,944,662 | 10.750% |

The four largest name families account for **191,246,360,229 bytes (82.55%)**; a name family is a prioritization device, not a content duplicate. Full family, workflow, age, daily expiry and per-run-conclusion breakdowns are in the accompanying CSVs. The 100 largest individual records are in top-100.csv.

| Family | Artifacts | Bytes | Share |
|---|---:|---:|---:|
| arsenal-product-acceptance | 1,877 | 105,959,432,755 | 45.74% |
| arsenal-quest-production-build | 206 | 47,565,587,624 | 20.53% |
| localization-chrome-visual-evidence | 426 | 25,504,844,860 | 11.01% |
| arsenal-quest-qa-evidence | 278 | 12,216,494,990 | 5.27% |
| arsenal-quest-browser-evidence | 220 | 5,628,317,012 | 2.43% |
| b8-gold-mobile | 185 | 4,088,922,717 | 1.77% |
| quest-q2-real-n-actors-and-browser | 134 | 3,701,006,932 | 1.60% |
| r89-gold-browser-evidence | 27 | 3,086,209,331 | 1.33% |
| b8-gold-desktop | 183 | 2,349,303,186 | 1.01% |
| apex-bot-wave-metal-hardware-trace | 21 | 1,672,191,816 | 0.72% |
| a1-skill-details-browser | 177 | 1,292,196,229 | 0.56% |
| v43-owner-chrome-visual-proof | 95 | 993,973,412 | 0.43% |
| cp16-cold-return-chrome | 151 | 821,791,821 | 0.35% |
| apex-chaos-itch-owner-gold-html5 | 11 | 812,155,850 | 0.35% |
| bot-wave-f1-browser | 104 | 716,829,975 | 0.31% |

### Workflow association and disposition evidence
- **Arsenal Product Acceptance:** 1,877 artifacts / 105,959,432,755 bytes; 60,766,241,386 bytes from successful runs, 26,666,952,423 from failed runs and 18,526,238,946 from cancelled runs. Current workflow builds dist, copies it into a Windows launcher app, and always uploads both plus browser evidence and logs together. That shows a repeated structural payload, not ZIP-level byte identity or automatic disposability. V43 backlog cites artifact 11673294462, exact commit and digest, and labels its captures evidence-only, not certification; this is concrete traceability to preserve.
- **Arsenal Quest Stabilization:** 206 `arsenal-quest-production-build` artifacts / 47,565,587,624 bytes (116 success / 26,709,515,631 bytes; 90 later-failed runs / 20,856,071,993 bytes). At commit 912835bc1aec2b8a7ef1ad711917c4bd0e3376f5, historical workflow `.github/workflows/arsenal-stabilize.yml` uploads dist after build, before subsequent browser tests; an overall failed run does not mean the build is worthless. Same workflow also produces 278 QA evidence artifacts / 12,216,494,990 bytes and 220 browser artifacts / 5,628,317,012 bytes. Project report explicitly cites artifacts 10789831037 and 10789008837 as successful production and browser evidence. KEEP these pending owner decision.
- **Localization:** 426 visual artifacts / 25,504,844,860 bytes; 411 successful runs / 25,029,864,333 bytes. Current path uploads localization screenshots on all outcomes, no explicit retention. Whether each is owner-accepted, superseded, or duplicated at file level is unknown.
- **QA failure evidence:** 276 failed-run QA artifacts total 12,095,822,614 bytes. Potential review priority, not proven redundant: failed runs may contain unique regressions. Intermediate/failure labels do not resolve incident or legal retention requirements.
- **R90/V43:** R90 three Chromium records remain distinct by digest; 95 V43 owner visual proofs total 993,973,412 bytes; the workflow explicitly says exact-SHA browser reproduction. Protect until reviewed, not forever by name alone.
- API comparison yields one equal-digest pair: 12741023054 and 12741543396, 7,929 bytes each. Different digests do not rule out common files across ZIPs; without authorized content inspection, file-level similarity, supersession, external copy, and acceptance are unverified. Metadata of six GitHub releases is visible, but no release asset was verified equivalent to the relevant artifacts and none proves independent archive preservation.

### Run conclusions are not owner acceptance

| Run conclusion | Artifacts | Bytes |
|---|---:|---:|
| success | 2,825 | 137,790,549,952 |
| failure | 1,873 | 71,850,963,772 |
| cancelled | 1,032 | 22,020,807,936 |

Run conclusion is a CI result, not evidence of owner acceptance, supersession, or durability. Accepted GOLD/release total is **unknown**; no reliable project-wide owner-acceptance registry was verified. Exact one cited V43 candidate was explicitly **not certification**. Failure/cancelled totals include artifacts from later-failed runs and must not be equated to obsolete output.

## 4. Classifications and ranked actions

| Classification | Count | Bytes |
|---|---:|---:|
| KEEP | 2 | 233,794,157 |
| ARCHIVE_THEN_DELETE | 21 | 5,282,299,975 |
| DELETE_CANDIDATE | 1 | 7,929 |
| NEEDS_REVIEW | 5,706 | 226,146,219,599 |

`ARCHIVE_THEN_DELETE` is a **proposal, not permission**: all original archives, metadata and run links must be copied intact and independently verified in a durable destination the owner approves; then explicit owner approval must authorize removal of each GitHub copy. No such archive is known to exist. The classification does not assert the artifact is accepted or superseded. KEEP and NEEDS_REVIEW are holds. All 5,730 artifacts have exact reasons, conditions and provenance in ranked-manifest.csv.

### Twenty highest-impact proposed archive-first actions

| Rank | Artifact ID | Bytes | Run (conclusion) | SHA | Required action |
|---:|---:|---:|---|---|---|
| 1 | 12513060678 | 260,292,216 | [39973763390](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/39973763390) (failure) | `eaefdce0800e0bca78064f1de4478e2150a43232` | Owner-approved archive, checksum and restore verification; then specific deletion approval |
| 2 | 12520768343 | 260,217,854 | [39995883878](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/39995883878) (success) | `63cc83544f8ec92e2437e9944f41f14a4561a88b` | Owner-approved archive, checksum and restore verification; then specific deletion approval |
| 3 | 12509186377 | 259,926,389 | [39967396229](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/39967396229) (failure) | `0b382316e20f68eae8cd6733f0a7e673f4b5158c` | Owner-approved archive, checksum and restore verification; then specific deletion approval |
| 4 | 12515250827 | 259,470,160 | [39981156898](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/39981156898) (failure) | `1f98ba1d5958b1df2907bce0b1f9a20f7fd1e5eb` | Owner-approved archive, checksum and restore verification; then specific deletion approval |
| 5 | 12516736299 | 259,443,697 | [39985486750](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/39985486750) (success) | `33dbc31f4446bb9f752d980f26205f0d89c98918` | Owner-approved archive, checksum and restore verification; then specific deletion approval |
| 6 | 12578176982 | 259,258,770 | [40135719110](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/40135719110) (success) | `7ef2dc0ff37ba49fba00e7f1eb3d1722bb00146a` | Owner-approved archive, checksum and restore verification; then specific deletion approval |
| 7 | 12607155064 | 258,439,897 | [40210602192](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/40210602192) (success) | `6f7003956702f5094497cfd0dd2b12118272cd38` | Owner-approved archive, checksum and restore verification; then specific deletion approval |
| 8 | 11297951727 | 257,146,702 | [37187455343](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/37187455343) (success) | `bc46330135821848415d7450cb9a80039f2ce638` | Owner-approved archive, checksum and restore verification; then specific deletion approval |
| 9 | 11297540907 | 256,778,264 | [37186996646](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/37186996646) (success) | `a1f846c998d4c9bda8e5b075321a3dcfbd40a671` | Owner-approved archive, checksum and restore verification; then specific deletion approval |
| 10 | 11298597571 | 256,635,045 | [37190561193](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/37190561193) (success) | `02982a664963ef7be9c6bf0837f5841e8ec1a176` | Owner-approved archive, checksum and restore verification; then specific deletion approval |
| 11 | 11298805451 | 256,461,110 | [37189632094](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/37189632094) (success) | `2d42bc70de8a911dd3b91e939646a5df1010da0e` | Owner-approved archive, checksum and restore verification; then specific deletion approval |
| 12 | 11298357350 | 256,443,080 | [37188454327](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/37188454327) (success) | `bc46330135821848415d7450cb9a80039f2ce638` | Owner-approved archive, checksum and restore verification; then specific deletion approval |
| 13 | 11298372080 | 256,368,240 | [37188386232](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/37188386232) (success) | `44167225863346755999c377229b3c417ccfbdd6` | Owner-approved archive, checksum and restore verification; then specific deletion approval |
| 14 | 11292983580 | 256,342,519 | [37176853988](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/37176853988) (failure) | `e506be3f1592adb8d264f0ad645ea50868dc7590` | Owner-approved archive, checksum and restore verification; then specific deletion approval |
| 15 | 11292649893 | 256,328,145 | [37175302014](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/37175302014) (failure) | `98540981932bc85f718a3b884322316e40356280` | Owner-approved archive, checksum and restore verification; then specific deletion approval |
| 16 | 11299175443 | 256,304,850 | [37190277813](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/37190277813) (success) | `02982a664963ef7be9c6bf0837f5841e8ec1a176` | Owner-approved archive, checksum and restore verification; then specific deletion approval |
| 17 | 11293711171 | 256,259,505 | [37176261894](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/37176261894) (failure) | `b5ad24194d30f98d97eb0ec3811f1306a1410021` | Owner-approved archive, checksum and restore verification; then specific deletion approval |
| 18 | 11297845667 | 256,246,436 | [37186859684](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/37186859684) (success) | `58027e5624b6264349617d9c3fefc75890b14a61` | Owner-approved archive, checksum and restore verification; then specific deletion approval |
| 19 | 11295357287 | 256,068,199 | [37181949924](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/37181949924) (success) | `b28048201ba5054ce557472d6ed0a5cd7cd8928b` | Owner-approved archive, checksum and restore verification; then specific deletion approval |
| 20 | 11297224223 | 255,973,159 | [37188633164](https://github.com/Khanh-glitch/APEX-CHAOS/actions/runs/37188633164) (success) | `44167225863346755999c377229b3c417ccfbdd6` | Owner-approved archive, checksum and restore verification; then specific deletion approval |

All 20 are `arsenal-product-acceptance` mixed acceptance evidence. Full dates, digest, SHA, evidence and preconditions are in the CSV. An additional archive-first item, 11673294462, is prioritized because a project document cites its exact SHA and digest. Each Action is deliberately conditional; a CI success/failure alone does not decide retention.

## 5. Three decisions and quantitative scenarios

**A — ZERO-LOSS proposed**: one API-digest-matched duplicate (12741023054), 7,929 bytes. Immediate deletion now: **0**, because no authorization or external provenance record exists. After approval, preserve the run metadata and survivor 12741543396 and verify both; theoretical reclaimed 7,929 bytes; remaining 231,662,313,731 bytes. No artifact archive required if survivor retained and provenance separately recorded. Earliest relief is after approval and GitHub processing. Risk: distinct run association cannot be recreated natively; byte-equivalence is API-reported and not independently downloaded. Future artifact accrual reduction if billed in the same binary units: approximately 0.000007384 GB-hours per hour, not a retroactive credit.

**B — ARCHIVE-FIRST proposed batch**: 20 largest plus documented V43 item 11673294462: **21 artifacts / 5,282,299,975 bytes**. Immediate deletion now: **0**. Archive prerequisite: original archive bytes 5,282,299,975, plus metadata/overhead; approved independent destination and verified complete restoration are not present. After owner approvals and successful verification for every item, potential GitHub bytes removed 5,282,299,975, remaining 226,380,021,685; earliest relief is only after that work and deletion processing. Approximate future rate reduction if billing size is equal: 4.919525 GB-hours per hour while those artifacts would otherwise remain. This is a conditional plan, not a claim of existing approved safe deletions or total cost savings. Distinct metadata and original run associations must be carried into the archive; GitHub UI links will not preserve deleted artifact blobs.

**Material opportunity beyond the batch, not an executable deletion list:** the four dominant families occupy 191,246,360,229 bytes (82.55%). If every one were individually authorized for archival and complete original copies were verified, moving all could theoretically remove at most 191,246,360,229 GitHub bytes, leave 40,415,961,431, and require at least 191,246,360,229 destination bytes plus metadata. This is an upper-bound thought experiment, overlaps the batch, and must not be added to it; accepted items may have to stay and copy/transfer costs are unknown. It is not a safe reclaim estimate.

**C — EXPIRATION ONLY:** immediately reclaimed 0; archive prerequisite 0 only if owner accepts the permanent loss of expired evidence. Without new uploads, retention changes or early deletion, the currently listed snapshot would decline as follows (by end of UTC date, subject to GitHub cleanup timing):

| Through UTC date | Cumulative bytes scheduled to expire | Remaining from this snapshot |
|---|---:|---:|
| 2026-11-02 | 186,726,828 | 231,475,594,832 |
| 2026-11-30 | 9,387,452,415 | 222,274,869,245 |
| 2026-12-31 | 72,817,715,657 | 158,844,606,003 |
| 2027-01-27 | 231,662,321,660 | 0 |

Earliest scheduled expiry is 2026-11-02T07:11:46Z; release of storage and billing dashboards can lag. The last listed expiry is 2027-01-27T00:35:10Z. These are not actual future totals: new uploads add bytes, deletions accelerate declines, retention changes may alter dates, and physical/billing processing may lag. Expiration removes evidence, potentially including accepted or irreplaceable captures; archive any required items **before** their expiry. Past storage accrual remains billed; future accumulation changes hour by hour as files expire.

## 6. Prevention without reducing coverage
- Current checkout `.github/workflows/arsenal-product-acceptance.yml`: `push` on main, development/v43, arena/** and an integration branch plus all PRs; shared acceptance workflow uploads dist, Windows package, browser evidence and logs with `if: always()` and no explicit retention. Matching branch push and PR triggers can overlap; verify event/SHA/ref and required checks before any deduplication. Preserve all CI gates, visual/native/runtime and release acceptance.
- Split temporary logs/reports/builds from accepted proof; set 3–7 days for routine CI and up to 14 for integration on an owner-approved basis. Preserve durable exact-SHA evidence with signed manifests, provenance and restore tests. Avoid duplicating `dist` inside the Windows package and as a separate upload only after confirming consumers and actual archive contents. Do not infer exact savings from path overlap. Keep user-reported 30-day repository default unless justified; explicit durations govern future uploads, not old expiry timestamps.
- Current localization and R90/V43 evidence uploads have no explicit retention; R89 preview uses 7 days, BOXE integration artifacts 14 days. Historical Arsenal Stabilization at 912835bc1aec2b8a7ef1ad711917c4bd0e3376f5 used no explicit retention on build or browser evidence. Full current workflow sweep from round 1: 63 upload steps, 13 retention-days declarations, with historical versions potentially different.

## 7. Exact Control Tower handoff
1. **No immediate deletion is authorized.** For zero-loss, approve only ID 12741023054 after requerying the survivor 12741543396 and recording both original run IDs, SHA, digest, timestamps and traceability. Estimated savings 7,929 bytes.
2. **Material controlled option:** decide whether to approve moving the 21 archive-first records (5,282,299,975 bytes) to a named independent durable archive, specifying retention, access, custodian, metadata, checksum and restore testing. Only approve deletion individually after preservation is proven. If an item must remain on GitHub, exclude it and recalculate.
3. **Largest decision backlog:** four families (191,246,360,229 bytes) require owners to decide which historical builds, screenshots, failure investigations and release evidence are still required, and whether an external archive is acceptable. Same name, failure, age or success is not a deletion proof. Top 100 and every ID are in the manifest.
4. **Expiration risk:** prioritize evidence with the earliest timestamps; do not assume 30-day settings shorten existing artifacts. If owner chooses expiration-only, accept evidence-loss risk explicitly and account for continued uploads.
5. **Unresolved blockers:** acceptance/supersession registry, authorized durable archive and verification, independent file-level duplication, complete billing time series and timezone, retention-settings access, and deletion authorization. No source, branch, setting, workflow, run, release, cache or artifact was modified.
