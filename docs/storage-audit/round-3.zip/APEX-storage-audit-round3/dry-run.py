#!/usr/bin/env python3
"""Offline-only review scope, stdout CSV. No API, download, mutation, or deletion."""
import csv,sys,os
source=os.path.join(os.path.dirname(os.path.abspath(__file__)), 'four-family-snapshot.csv')
protect={'11673294462':'Documented exact-SHA V43 capture; preserve in GitHub pending explicit owner decision.', '10789831037':'Documented successful production build; preserve in GitHub pending explicit owner decision.'}
families={'arsenal-product-acceptance','arsenal-quest-production-build','localization-chrome-visual-evidence','arsenal-quest-qa-evidence'}
with open(source,newline='',encoding='utf-8') as f: rows=list(csv.DictReader(f))
if len(rows)!=2787 or len({r['artifact_id'] for r in rows})!=2787 or sum(int(r['size_bytes']) for r in rows)!=191246360229 or any(r['name'] not in families for r in rows):
 sys.exit('STOP: snapshot integrity mismatch; do not act.')
fields=['artifact_id','name','size_bytes','run_id','commit_sha','created_at','expires_at','digest','run_conclusion','r2_classification','scope','required_precondition']
w=csv.DictWriter(sys.stdout,fieldnames=fields,lineterminator='\n');w.writeheader()
for r in rows:
 hold=r['artifact_id'] in protect
 w.writerow({'artifact_id':r['artifact_id'],'name':r['name'],'size_bytes':r['size_bytes'],'run_id':r['run_id'],'commit_sha':r['commit_sha'],'created_at':r['created_at'],'expires_at':r['expires_at'],'digest':r['digest'],'run_conclusion':r['run_conclusion'],'r2_classification':r['classification'],'scope':'HOLD' if hold else 'REVIEW_ONLY_NOT_APPROVED','required_precondition':protect.get(r['artifact_id'],'Owner selects item; verify availability, independent archive integrity and restore, record provenance, and separately authorize any deletion.')})
print('DRY RUN ONLY: 2787 records; 2 explicit holds; 2785 review-only; review-only snapshot total 190883762498 bytes; no live verification; NO actions taken.',file=sys.stderr)
