# QA GATE

Any future change to this engine/lab must pass:

- HTML closes correctly (`</script></body></html>`)
- JS syntax passes
- all shaders compile in a real browser
- canvas is non-empty
- IDENTITY OPEN renders
- A1 CAPTURE renders
- A1 RELEASE renders
- A2 ABSORB renders
- A2 RETURN renders
- PASSIVE growth renders
- manual sliders visibly affect the engine
- no page errors
- at least IDLE + one active screenshot are inspected

If runtime cannot be executed, the result is **UNVERIFIED**, not complete.
