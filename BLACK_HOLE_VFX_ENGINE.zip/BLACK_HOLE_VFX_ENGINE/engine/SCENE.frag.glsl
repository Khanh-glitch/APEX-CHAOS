#version 300 es
${COMMON}
out vec4 fragColor;
uniform vec2 uRes, uCenter, uSway;
uniform float uScale, uTime, uSwayR, uBreath;
uniform float uBandPhase, uSwirlPhase, uInflow, uFall, uStarSpin;
uniform float uSuck, uTension, uStress, uBlink, uEye, uSquint, uTwist;
uniform vec4 uShardA[16];
uniform vec4 uShardB[16];

const vec2 SC = vec2(0.0, 0.17);   // forehead singularity seat
float PX;

// egg metric: wide cranium, tapered chin (face void boundary at E = 0.5)
float eggE(vec2 p){
  float sx = 1.0 + 0.30*smoothstep(0.25, -0.85, p.y);
  float sy = mix(0.73, 0.84, smoothstep(-0.15, 0.15, p.y));
  return length(vec2(p.x*sx, p.y*sy));
}

float starLayer(vec2 uv, float pxs, float seed){
  vec2 id = floor(uv), gv = fract(uv) - 0.5;
  float n = hash12(id + seed*17.3);
  if(n < 0.62) return 0.0;
  vec2 off = (hash22(id + seed*3.1) - 0.5)*0.76;
  vec2 dd = gv - off;
  float n2 = fract(n*37.17);
  float sz = max(pxs*0.75, 1e-4)*(1.0 + 1.3*pow(n2, 8.0));
  float b = exp(-dot(dd,dd)/(sz*sz));
  float tw = 0.72 + 0.28*sin(uTime*(0.5 + n2*1.6) + n*60.0);
  return b*tw*(0.12 + 1.4*pow(n2, 3.0));
}

vec2 vor2(vec2 x){
  vec2 i=floor(x), f=fract(x); float f1=8., f2=8.;
  for(int yy=-1;yy<=1;yy++) for(int xx=-1;xx<=1;xx++){
    vec2 g=vec2(float(xx),float(yy)); vec2 o=hash22(i+g); vec2 r=g+o-f; float d=dot(r,r);
    if(d<f1){ f2=f1; f1=d; } else if(d<f2){ f2=d; }
  }
  return vec2(sqrt(f1), sqrt(f2));
}

/* ---------- inner universe ---------- */
float nebField(vec2 q, float seed){
  float tt = uTime*0.01;
  vec2 w = vec2(fbm(q*1.1 + vec2(seed, tt), 3), fbm(q*1.1 + vec2(5.2 - tt, 1.3 + seed), 3));
  return fbm(q*1.8 + w*1.8 + seed, 5);
}

vec3 cosmos(vec2 hp, float fE){
  vec2 d = hp - SC; float r = length(d);

  // nebula volume: two depth slices flowing in scale-space toward/away from the
  // singularity seat. two-phase crossfade (Vlachos) + variance-preserving blend.
  float ph = uFall*0.5;
  float fa = fract(ph), fb = fract(ph + 0.5);
  float wa = 1.0 - abs(2.0*fa - 1.0), wb = 1.0 - wa;
  vec2 dn = rot(uStarSpin*0.3)*d;
  float na = nebField(dn*exp2(fa) + uSway*1.5, floor(ph)*7.31);
  float nb = nebField(dn*exp2(fb) + uSway*1.5, floor(ph + 0.5)*7.31 + 3.7);
  float n = (wa*na + wb*nb)/sqrt(wa*wa + wb*wb);

  vec3 col = vec3(0.0);
  float dens = smoothstep(-0.2, 0.5, n);
  col += L(vec3(0.15,0.07,0.36))*dens*0.7;
  col += L(vec3(0.42,0.14,0.72))*pow(smoothstep(0.1, 0.55, n), 2.0)*0.8;
  col += L(vec3(0.95,0.6,1.0))*pow(smoothstep(0.38, 0.75, n), 4.0)*0.9;
  float lowC = smoothstep(0.1, -0.55, hp.y)*smoothstep(0.42, 0.05, abs(hp.x));
  float m = mix(0.22, 0.85, smoothstep(0.35, 1.0, fE))*(1.0 - 0.75*lowC);
  m *= 1.0 - 0.7*smoothstep(0.28, 0.0, r);
  col *= m;

  // stars with real depth: 4 layers cycling in depth (BigWings layering), zoom centred on the seat
  vec3 st = vec3(0.0);
  for(int i=0;i<4;i++){
    float fi = float(i);
    float z = fi*0.25 + uFall*0.5;
    float dep = fract(z);
    float sc = 8.0*exp2(dep*2.4);
    float fade = smoothstep(0.0, 0.18, dep)*smoothstep(1.0, 0.72, dep);
    vec2 sq = rot(uStarSpin*(0.5 + dep))*d + uSway*(1.0 - dep)*2.5;
    vec2 uv = sq*sc + vec2(fi*37.7, fi*11.3) + floor(z)*vec2(13.1, 7.7);
    float s = starLayer(uv, PX*sc, fi + floor(z));
    vec3 sCol = mix(vec3(0.75,0.8,1.0), vec3(1.0,0.8,1.0), hash12(floor(uv)+3.0));
    st += sCol*s*fade;
  }
  col += st*(0.65 + 0.35*smoothstep(0.2, 0.9, fE));

  // distant galaxies — scale cue that this is a universe, not a texture
  for(int g=0; g<2; g++){
    vec2 gp = g==0 ? vec2(-0.26, 0.05) : vec2(0.29, 0.24);
    vec2 gq = rot(g==0 ? 0.6 : -0.9)*(hp - gp + uSway*1.5);
    gq.y *= 2.6;
    float gr = length(gq);
    float ga = atan(gq.y, gq.x);
    float arms = 0.6 + 0.4*sin(2.0*ga + log(gr + 1e-3)*6.0 - uTime*0.02);
    col += L(vec3(0.8,0.65,1.0))*exp(-gr*95.0)*0.8 + L(vec3(0.5,0.3,0.9))*exp(-gr*38.0)*arms*0.1;
  }

  // forehead vortex: brush-stroke strata in log-polar space (translation in log-polar
  // = rigid rotation + self-similar inflow, never winds up)
  float lr = log(max(r, 1e-3));
  float a = atan(d.y, d.x)/TAU;
  float tw = 0.14 + 0.2*uTwist;
  float su = (a - tw*lr + uSwirlPhase)*5.0;
  float sv = lr*6.5 + uInflow;
  float s1 = pfbm(vec2(su, sv), 5.0, 4);
  float s2 = pnoise(vec2(su*4.0, sv*0.6 + 3.0), 20.0);
  float strokes = smoothstep(-0.02, 0.42, s1 + s2*0.12);
  float vm = smoothstep(0.66, 0.2, r)*smoothstep(0.03, 0.16, r)*smoothstep(-0.28, 0.05, hp.y);
  col += mix(L(vec3(0.09,0.06,0.28)), L(vec3(0.3,0.2,0.72)), strokes*strokes)*strokes*vm*(0.9 + 1.8*uSuck + 1.2*uTension);
  return col;
}

/* ---------- eyes: ruptures in the shell exposing the hot layer behind ---------- */
vec3 eyeShade(vec2 hp, float side, out float spill, out float dOut){
  vec2 q = vec2(hp.x*side, hp.y);
  const vec2 I = vec2(0.112, -0.372);
  const vec2 O = vec2(0.36, -0.172);
  vec2 ax = O - I; float Ln = length(ax); vec2 ad = ax/Ln; vec2 nd = vec2(-ad.y, ad.x);
  vec2 rel = q - I;
  float u = dot(rel, ad), v = dot(rel, nd);
  float un = u/Ln, unc = clamp(un, 0.0, 1.0);
  v -= 0.016*sin(PI*unc);                                 // slight arch in the hard lid line
  float prof = pow(unc, 0.45)*pow(1.0 - unc, 1.1)/0.393;  // fat near the bridge, long blade outward
  float H = 0.074*(1.0 - 0.5*uSquint);
  float h = H*prof;
  float top = -h*uBlink*0.97;                             // lid descends from the flat top edge
  float bot = -h*(1.0 + 0.04*sin(uTime*0.9 + side));
  float dv = max(v - top, bot - v);
  float du = max(-u, u - Ln);
  float d = max(dv, du*0.8);
  d += gnoise(q*42.0 + vec2(side*7.1, uTime*0.12))*0.0042 + gnoise(q*110.0 + side*3.3)*0.0018; // torn rim
  dOut = d;

  float Ie = uEye*(0.93 + 0.07*sin(uTime*1.1 + side*0.7));
  float aa = PX*1.3;
  float inside = smoothstep(aa, -aa, d);
  float T = max(top - bot, 1e-4);
  float depth = clamp(-d/(0.5*T), 0.0, 1.0);
  float pl = fbm(vec2(u*22.0 - uTime*0.5, v*38.0 + side*4.0), 3);
  float bias = mix(1.0, 0.5, smoothstep(0.22 + 0.08*sin(uTime*0.31 + side), 1.0, unc));
  float core = pow(depth, 1.1)*bias + pl*0.3;
  vec3 cV = L(vec3(0.64,0.2,1.0)), cM = L(vec3(0.86,0.42,1.0));
  vec3 inC = mix(cV*2.4, vec3(1.0,0.95,1.0)*6.0, smoothstep(0.18, 0.78, core));
  vec3 col = inC*inside*Ie;
  float rim = exp(-abs(d)/(PX*1.4 + 0.0011));
  col += cM*rim*2.2*Ie;
  float dd = max(d, 0.0);
  float dirB = 1.0 + 0.9*smoothstep(0.2, 1.3, un);
  col += cV*(exp(-dd*40.0) + exp(-dd*10.0)*0.3)*dirB*(1.0 - 0.45*uBlink)*Ie*0.9;

  // outer tail: the tear continues as a hairline fracture toward the temple
  float ut = u - Ln;
  if(ut > -0.02 && ut < 0.12){
    float utp = max(ut, 0.0);
    float vt = v - 2.2*utp*utp;
    float wdt = 0.0032*(1.0 - utp/0.12) + 0.0004;
    col += cM*exp(-abs(vt)/wdt)*smoothstep(0.12, 0.02, utp)*step(-0.005, ut)*1.8*Ie;
  }
  // inner hook: sharp predatory point dropping toward the bridge
  {
    vec2 hd = normalize(vec2(-0.42, -1.0));
    float hh; float dh = sdSeg(q, I + vec2(0.004, 0.004), I + hd*0.052, hh);
    float wdt = 0.0036*(1.0 - hh) + 0.0004;
    col += mix(cM*2.0, vec3(3.0), 0.25)*exp(-dh/wdt)*Ie*(1.0 - 0.6*uBlink);
  }
  // fracture veins in the surrounding shell
  if(dd < 0.085){
    vec2 f = vor2(q*24.0 + side*5.3);
    float cr = exp(-(f.y - f.x)*26.0);
    float cm = smoothstep(0.085, 0.0, dd)*smoothstep(0.1, 0.45, gnoise(q*8.0 + side*2.0) + 0.25);
    col += cV*cr*cm*0.4*Ie;
  }
  spill = exp(-dd*7.0)*0.55*Ie*(1.0 - 0.55*uBlink);
  return col;
}

float browRidge(vec2 hp, float fE){
  vec2 q = vec2(abs(hp.x), hp.y);
  float ang = atan(q.y, q.x);
  float m = smoothstep(-0.72, -0.48, ang)*smoothstep(0.62, -0.05, ang);
  return (exp(-abs(fE - 0.975)*80.0) + exp(-abs(fE - 0.96)*16.0)*0.22)*m;
}

// eye energy drawn up into the forehead
vec3 eyeStreams(vec2 hp){
  if(uSuck < 0.01) return vec3(0.0);
  vec3 acc = vec3(0.0);
  for(int e=0;e<2;e++){
    float sd = e==0 ? 1.0 : -1.0;
    vec2 P0 = vec2(0.175*sd, -0.3), P1 = vec2(0.25*sd, -0.03), P2 = SC;
    float best = 1e3, bt = 0.0;
    vec2 prev = P0;
    for(int i=1;i<=12;i++){
      float t1 = float(i)/12.0;
      vec2 cur = mix(mix(P0,P1,t1), mix(P1,P2,t1), t1);
      float h; float dd = sdSeg(hp, prev, cur, h);
      if(dd < best){ best = dd; bt = (float(i-1) + h)/12.0; }
      prev = cur;
    }
    float reach = uSuck*1.25;
    float grow = smoothstep(reach, reach - 0.15, bt);
    float wdt = mix(0.010, 0.0025, bt);
    float core = exp(-pow(best/wdt, 2.0));
    float glow = exp(-best/0.035)*0.22;
    float nz = clamp(0.55 + 1.3*fbm(vec2(bt*10.0 - uTime*3.2, sd*4.0 + uTime*0.2), 3), 0.0, 1.6);
    float fadeEnds = smoothstep(0.0, 0.06, bt)*smoothstep(1.0, 0.82, bt);
    vec3 c = mix(L(vec3(0.62,0.25,1.0)), vec3(1.0,0.93,1.0), core*0.7);
    acc += c*(core*2.0 + glow)*nz*grow*fadeEnds;
  }
  return acc*uSuck*uEye;
}

/* ---------- orbiting matter: stacked sheets of torn, perforated substance ---------- */
float holesF(vec2 x, float P){
  vec2 i = floor(x), f = fract(x);
  float res = 0.0;
  for(int yy=-1; yy<=1; yy++){
    for(int xx=-1; xx<=1; xx++){
      vec2 g = vec2(float(xx), float(yy));
      vec2 id = i + g; id.x = mod(id.x, P);
      vec2 hh = hash22(id + 17.0);
      vec2 o = 0.5 + (hh - 0.5)*0.7;
      vec2 dv = (g + o - f)*vec2(1.0, 1.2);
      float rad = 0.2 + 0.24*hh.y;
      float on = step(0.4, fract(hh.x*7.13 + hh.y*3.1));
      res = max(res, on*smoothstep(rad, rad*0.45, length(dv)));
    }
  }
  return res;
}

vec4 bandSheet(vec2 bp, float rB, float s, float phase, float swirlK, float freq, float thr,
               float ridgeW, float seed, bool holes, float bright, vec3 eyeL){
  // rigid orbit + trailing shear (outer lags, Keplerian feel) + bounded tidal breathing
  float sw = -swirlK*rB*rB + 0.2*sin(uTime*0.09 + seed*1.7)*(rB - 0.72);
  vec2 q = rot(phase + sw)*bp;
  float tt = uTime*0.03;
  vec2 w = vec2(fbm(q*freq*0.6 + vec2(seed, tt), 3), fbm(q*freq*0.6 + vec2(tt*0.8 + 5.2, seed + 1.3), 3));
  float n = fbm(q*freq + w*1.25 + seed*2.0, 5);
  float rdg = ridgeW > 0.0 ? 1.0 - 2.0*abs(fbm(q*freq*1.7 + w*1.8 + seed + 11.0, 3)) : 0.66;
  float env = smoothstep(-0.02, 0.14, s)*smoothstep(1.06, 0.58, s);
  float D = n + (rdg - 0.66)*ridgeW + env*0.72 - 0.37 + thr;
  float aq = atan(q.y, q.x)/TAU + 0.5;
  if(holes){
    vec2 cc = vec2(aq*26.0, rB*10.0) + w*vec2(2.0, 0.9);
    D -= holesF(cc, 26.0)*0.75;
  }
  float aa = fwidth(D) + 1e-4;
  float alpha = smoothstep(-aa, aa*0.6, D);
  float hgt = smoothstep(0.0, 0.2, D);
  vec2 g = vec2(dFdx(hgt), dFdy(hgt))/PX;
  vec3 N = normalize(vec3(-g*0.016, 1.0));
  vec3 Lk = normalize(vec3(-0.45, 0.62, 0.64));
  float dif = max(dot(N, Lk), 0.0);
  float spec = pow(max(dot(N, normalize(Lk + vec3(0.0,0.0,1.0))), 0.0), 26.0);
  float rim = pow(1.0 - hgt, 2.2);
  float stri = pnoise(vec2(aq*40.0, rB*70.0), 40.0);
  float fold = smoothstep(-0.15, 0.5, n*1.4 + stri*0.28 + w.x*0.6);
  vec3 cDeep = L(vec3(0.075,0.045,0.13)), cMid = L(vec3(0.38,0.26,0.58)), cLav = L(vec3(0.84,0.7,1.0)), cVio = L(vec3(0.62,0.28,1.0));
  vec3 col = mix(cDeep, cMid, fold*(0.3 + 0.7*dif));
  col = mix(col, cLav, pow(fold, 3.0)*dif*0.55);
  col += cLav*rim*(0.3 + 1.1*dif + 0.9*spec);
  col += vec3(1.0,0.95,1.0)*spec*0.8*(0.25 + rim);
  float eT = eyeL.z*(0.3 + 1.6*max(dot(N.xy, eyeL.xy), 0.0));
  col += cVio*eT*(0.4 + 1.6*rim);
  vec2 toC = SC - bp; float dC = length(toC);
  float cT = uSuck*exp(-dC*2.4)*(0.25 + 1.8*max(dot(N.xy, toC/max(dC,1e-3)), 0.0));
  col += mix(cVio, vec3(1.0,0.9,1.0), 0.35)*cT*(0.35 + 1.6*rim);
  col += cVio*uStress*rim*(0.6 + 1.6*smoothstep(0.35, 0.95, s));
  float spk = starLayer(q*55.0 + seed*9.0, PX*55.0, seed + 5.0);
  col += vec3(0.85,0.8,1.0)*spk*hgt*0.6;
  return vec4(col*bright, alpha);
}

/* ---------- detached shards (driven by CPU orbital sim, spaghettify when captured) ---------- */
float sdVesica(vec2 p, float r, float d){
  p = abs(p); float b = sqrt(r*r - d*d);
  return ((p.y - b)*d > p.x*b) ? length(p - vec2(0.0, b)) : length(p - vec2(-d, 0.0)) - r;
}
vec3 shards(vec2 hp, vec3 col){
  vec3 cDeep=L(vec3(0.07,0.04,0.12)), cMid=L(vec3(0.42,0.3,0.66)), cLav=L(vec3(0.85,0.72,1.0)), cVio=L(vec3(0.62,0.28,1.0));
  for(int i=0;i<16;i++){
    vec4 A = uShardA[i], B = uShardB[i];
    if(B.y < 0.004) continue;
    vec2 lp = hp - A.xy;
    float ext = A.w*B.x*0.75 + 0.02;
    if(dot(lp,lp) > ext*ext) continue;
    lp = rot(-A.z)*lp/A.w;
    lp.y /= B.x; lp.x *= sqrt(B.x);
    lp.x -= 0.3*lp.y*lp.y - 0.06;
    float ds = sdVesica(lp, 1.0, 0.8)*A.w;
    float al = smoothstep(PX, -PX, ds)*B.y;
    if(al < 0.001) continue;
    float inr = clamp(-ds/(0.2*A.w), 0.0, 1.0);
    float side = smoothstep(-0.2, 0.2, lp.x + 0.1*lp.y);
    vec3 sc = mix(cMid*(0.55 + 0.6*side), cDeep, smoothstep(0.3, 0.85, inr)*step(0.35, B.z));
    sc += cLav*exp(-(-ds)/(0.03*A.w + PX))*(0.6 + 1.2*side);
    sc += cVio*B.w*(0.8 + 1.5*(1.0 - inr));
    col = mix(col, sc, al);
  }
  return col;
}

void main(){
  PX = 1.0/uScale;
  vec2 p = (gl_FragCoord.xy - uCenter)/uScale;
  vec2 hp = rot(uSwayR)*(p - uSway)/uBreath;
  float rC = length(hp);
  vec3 col = vec3(0.0);
  col += vec3(0.7,0.72,1.0)*starLayer(p*22.0 + 91.0, PX*22.0, 9.0)*0.16;

  if(rC < 1.3){
    float E = eggE(hp); float fE = E/0.5;
    vec3 cs = cosmos(hp, fE);
    float faceM = 1.0 - smoothstep(0.97, 1.1, fE);
    float headM = 1.0 - smoothstep(0.84, 0.97, length(hp*vec2(1.05,0.97)));
    vec3 inner = cs*mix(0.3, 1.0, faceM);
    inner *= mix(1.0, 0.55, smoothstep(0.78, 1.0, fE)*faceM);
    inner += L(vec3(0.3,0.14,0.62))*exp(-abs(fE - 1.0)*14.0)*0.05*faceM;
    col = mix(col, inner, headM);

    float spR, spL, dR, dL;
    vec3 eR = eyeShade(hp, 1.0, spR, dR);
    vec3 eL = eyeShade(hp, -1.0, spL, dL);
    col += eR + eL;
    col += cs*(spR + spL)*3.0*faceM;
    col += L(vec3(0.68,0.28,1.0))*browRidge(hp, fE)*uEye*(1.0 - 0.6*uBlink)*1.3;
    col += eyeStreams(hp);
    float dc = length(hp - SC);
    col += L(vec3(0.55,0.3,1.0))*uTension*exp(-dc*9.0)*0.25;

    if(rC > 0.33){
      vec2 bp = SC + (hp - SC)*(1.0 + uSuck*0.32*exp(-length(hp - SC)*2.2)); // tidal reach toward the forehead
      float rB = length(bp);
      float rI = 0.5*rB/max(eggE(bp), 1e-3);
      float rO = 0.9*rB/max(length(bp*vec2(1.05,0.97)), 1e-3);
      float s = (rB - rI)/max(rO - rI, 1e-3);
      s += 0.025*sin(uTime*0.37 + atan(bp.y, bp.x)*2.0);
      vec2 E0 = vec2(sign(bp.x)*0.22, -0.29);
      vec2 te = E0 - bp; float de = length(te);
      vec3 eyeL = vec3(te/max(de,1e-3), uEye*exp(-de*4.2)*0.9*(1.0 - 0.5*uBlink));
      vec4 bk = bandSheet(bp, rB, s, uBandPhase*0.62, 0.9 + uSuck*0.8, 2.1, -0.08, 0.0, 3.0, false, 0.34, eyeL);
      col = mix(col, bk.rgb, bk.a*0.94);
      vec4 md = bandSheet(bp, rB, s, uBandPhase, 1.4 + uSuck*1.6, 2.7, 0.0, 0.22, 0.0, true, 1.0, eyeL);
      col = mix(col, md.rgb, md.a);
      vec4 fr = bandSheet(bp, rB, s + 0.07, uBandPhase*1.45, 2.0 + uSuck*2.2, 3.3, -0.6, 0.38, 7.0, false, 1.15, eyeL);
      col = mix(col, fr.rgb, fr.a);
      // edge stress: violet pressure waves travelling up both flanks into the singularity
      float angTop = abs(atan(hp.x, hp.y));
      float wave = 0.55 + 0.45*sin(angTop*6.0 + uTime*2.2);
      float halo = exp(-max(rC - 0.84, 0.0)*7.0)*smoothstep(0.62, 0.86, rC);
      col += L(vec3(0.6,0.22,1.0))*halo*uStress*wave*0.55;
    }
    col += L(vec3(0.6,0.22,1.0))*exp(-abs(fE - 1.0)*26.0)*uStress*0.35;
    col = shards(hp, col);
  }
  fragColor = vec4(col, 1.0);
}