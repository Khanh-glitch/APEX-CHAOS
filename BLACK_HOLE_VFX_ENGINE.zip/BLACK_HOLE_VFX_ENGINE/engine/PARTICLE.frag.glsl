#version 300 es
precision highp float;
in vec3 vData; uniform float uPoint; out vec4 o;
void main(){
  float a = 1.0;
  if(uPoint > 0.5){ vec2 c = gl_PointCoord*2.0 - 1.0; float d = dot(c,c); a = exp(-d*3.5)*step(d, 1.0); }
  vec3 col = mix(vec3(0.42,0.22,1.0), vec3(1.0,0.93,1.0), vData.z);
  o = vec4(col*vData.y*a, 1.0);
}