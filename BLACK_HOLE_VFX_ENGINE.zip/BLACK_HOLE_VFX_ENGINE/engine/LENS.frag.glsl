#version 300 es
${COMMON}
out vec4 o;
uniform sampler2D uScene;
uniform vec2 uRes, uCenter, uC;
uniform float uScale, uRs, uK, uSpin, uSuck, uTime, uShockR, uShockA, uFlash, uAccPhase, uAccIn, uTension;
vec3 samp(vec2 hp){ return texture(uScene, (hp*uScale + uCenter)/uRes).rgb; }
void main(){
  float PX = 1.0/uScale;
  vec2 p = (gl_FragCoord.xy - uCenter)/uScale;
  vec2 d = p - uC; float r = length(d) + 1e-6; vec2 dir = d/r;
  float K2 = uK*abs(uK);                    // signed: negative = elastic rebound bulge
  float rsrc = sqrt(max(r*r + K2, 0.0));    // face-space collapses into the seat
  float rs = uRs;
  float drag = uSpin*(max(K2,0.0) + 0.35*rs*rs)/(r*r + 0.35*abs(K2) + 0.25*rs*rs + 1e-4);
  float x = (r - uShockR)/0.07;
  rsrc += uShockA*x*exp(-x*x)*0.035;        // refractive shock front
  vec3 base = samp(uC + rot(drag)*dir*rsrc);
  vec3 col = base;
  float streak = uSuck*smoothstep(1.05, 0.12, r);
  if(streak > 0.002){
    vec3 tr = vec3(0.0), av = base; float ws = 0.0, wa = 1.0;
    for(int i=1;i<10;i++){
      float fi = float(i)/9.0;
      float k = fi*streak;
      float ang = drag + k*0.5*(0.1/(r + 0.06));
      vec3 s = samp(uC + rot(ang)*dir*rsrc*(1.0 + k*0.22));
      float w = exp(-fi*2.2);
      tr += max(s - 0.12, 0.0)*w; ws += w;
      av += s*w; wa += w;
    }
    col = mix(col, av/wa, 0.3*streak);
    col += tr/ws*streak*1.1;
  }
  if(rs > 0.0008){
    float lr = log(r/rs);
    col *= mix(1.0, smoothstep(0.0, 0.55, lr), 0.6);
    float a = atan(d.y, d.x)/TAU;
    float su = (a - 0.32*lr + uAccPhase)*6.0;
    float sv = lr*4.5 + uAccIn;
    float n = pfbm(vec2(su, sv), 6.0, 4);
    float n2 = pnoise(vec2(su*2.0 + 3.0, sv*2.2), 12.0);
    float prof = smoothstep(-0.02, 0.18, lr)*exp(-max(lr, 0.0)*1.7);
    float heat = exp(-max(lr, 0.0)*2.4);
    vec3 accC = mix(L(vec3(0.45,0.16,0.95)), vec3(1.0,0.9,1.0), heat*0.85);
    float dens = smoothstep(-0.2, 0.45, n + n2*0.25);
    float open01 = smoothstep(0.0, 0.5, rs/0.125);
    col += accC*prof*dens*(0.5 + 2.2*heat)*(0.25 + 0.95*uSuck)*open01;
    float w1 = rs*0.028 + PX*0.9;
    float x1 = (r - rs*1.075)/w1;
    float x2 = (r - rs*1.2)/(rs*0.07);
    float pr = exp(-x1*x1);
    float pr2 = exp(-x2*x2);
    float beam = 0.7 + 0.5*cos(TAU*a + 1.2 - uTime*0.5);
    col += vec3(1.0,0.9,1.0)*pr*2.6*beam*open01 + L(vec3(0.7,0.4,1.0))*pr2*0.5*open01;
    col *= smoothstep(rs - PX*1.2, rs + PX*1.2, r);
  }
  float rr = r*r;
  col += vec3(1.0,0.9,1.0)*uFlash*exp(-rr/0.0012)*6.0;
  col += L(vec3(0.62,0.25,1.0))*uFlash*exp(-r*7.0)*0.9;
  col += L(vec3(0.8,0.5,1.0))*uTension*(1.0 - smoothstep(0.0, 0.01, rs))*exp(-rr/0.0005)*2.2;
  o = vec4(col, 1.0);
}