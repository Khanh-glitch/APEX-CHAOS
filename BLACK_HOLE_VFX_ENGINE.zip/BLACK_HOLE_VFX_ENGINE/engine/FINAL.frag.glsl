#version 300 es
precision highp float;
uniform sampler2D uLens, uB0, uB1, uB2, uB3;
uniform vec2 uRes, uCuv; uniform float uCA, uTime, uBloom, uExposure;
out vec4 o;
float h12(vec2 p){ vec3 p3=fract(vec3(p.xyx)*.1031); p3+=dot(p3,p3.yzx+33.33); return fract((p3.x+p3.y)*p3.z); }
vec3 aces(vec3 x){ return clamp((x*(2.51*x + 0.03))/(x*(2.43*x + 0.59) + 0.14), 0.0, 1.0); }
void main(){
  vec2 uv = gl_FragCoord.xy/uRes;
  float asp = uRes.x/uRes.y;
  vec2 dv = uv - uCuv;
  float dl = length(dv*vec2(asp, 1.0));
  float ca = 0.0012 + uCA*exp(-dl*5.0)*0.02;
  vec2 off = dv*ca;
  vec3 col;
  col.r = texture(uLens, uv - off).r;
  col.g = texture(uLens, uv).g;
  col.b = texture(uLens, uv + off).b;
  vec3 b = texture(uB0, uv).rgb*0.55 + texture(uB1, uv).rgb*0.6 + texture(uB2, uv).rgb*0.7 + texture(uB3, uv).rgb*0.8;
  col += b*uBloom;
  col *= uExposure;
  col = aces(col);
  vec2 q = (uv - 0.5)*vec2(asp, 1.0);
  col *= 1.0 - dot(q, q)*0.3;
  col = pow(col, vec3(1.0/2.2));
  col += (h12(gl_FragCoord.xy + fract(uTime*7.13)*97.0) - 0.5)*0.016;
  o = vec4(col, 1.0);
}