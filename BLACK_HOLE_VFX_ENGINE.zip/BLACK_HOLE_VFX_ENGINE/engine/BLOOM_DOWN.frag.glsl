#version 300 es
precision highp float;
uniform sampler2D uSrc; uniform vec2 uSrcTexel, uDstRes; uniform float uThresh;
out vec4 o;
void main(){
  vec2 uv = gl_FragCoord.xy/uDstRes;
  vec3 c = texture(uSrc, uv + uSrcTexel*vec2(-1.0,-1.0)).rgb + texture(uSrc, uv + uSrcTexel*vec2(1.0,-1.0)).rgb
         + texture(uSrc, uv + uSrcTexel*vec2(-1.0, 1.0)).rgb + texture(uSrc, uv + uSrcTexel*vec2(1.0, 1.0)).rgb;
  c *= 0.25;
  if(uThresh > 0.0){
    float l = max(c.r, max(c.g, c.b));
    float knee = 0.5;
    float soft = clamp(l - uThresh + knee, 0.0, 2.0*knee);
    soft = soft*soft/(4.0*knee + 1e-5);
    c *= max(soft, l - uThresh)/max(l, 1e-5);
  }
  o = vec4(c, 1.0);
}