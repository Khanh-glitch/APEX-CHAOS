#version 300 es
precision highp float;
uniform sampler2D uSrc; uniform vec2 uDir, uDstRes;
out vec4 o;
void main(){
  vec2 uv = gl_FragCoord.xy/uDstRes;
  vec3 c = texture(uSrc, uv).rgb*0.2270270270;
  c += (texture(uSrc, uv + uDir*1.3846153846).rgb + texture(uSrc, uv - uDir*1.3846153846).rgb)*0.3162162162;
  c += (texture(uSrc, uv + uDir*3.2307692308).rgb + texture(uSrc, uv - uDir*3.2307692308).rgb)*0.0702702703;
  o = vec4(c, 1.0);
}