#version 300 es
layout(location=0) in vec2 aPos;
layout(location=1) in vec3 aData;
uniform vec2 uRes, uCenter, uSway; uniform float uScale, uSwayR, uBreath;
out vec3 vData;
void main(){
  float c = cos(-uSwayR), s = sin(-uSwayR);
  vec2 hp = aPos*uBreath;
  vec2 p = vec2(c*hp.x - s*hp.y, s*hp.x + c*hp.y) + uSway;
  vec2 px = p*uScale + uCenter;
  gl_Position = vec4(px/uRes*2.0 - 1.0, 0.0, 1.0);
  gl_PointSize = aData.x;
  vData = aData;
}