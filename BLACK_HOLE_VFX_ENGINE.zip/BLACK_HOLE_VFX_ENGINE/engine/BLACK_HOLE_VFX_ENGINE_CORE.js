// BLACK_HOLE Golden Motion Core
// Reusable choreography extracted from the approved Opus baseline.
export class Spring {
  constructor(v,w,z){ this.v=v; this.t=v; this.vel=0; this.w=w; this.z=z; this.w0=w; this.z0=z; }
  step(dt){ const n=4,h=dt/n; for(let i=0;i<n;i++){ const a=this.w*this.w*(this.t-this.v)-2*this.z*this.w*this.vel; this.vel+=a*h; this.v+=this.vel*h; } }
  snap(v){ this.v=this.t=v; this.vel=0; }
}

export const GOLDEN_DEFAULTS = Object.freeze({
  tension:0, K:0.025, rs:0, suck:0, stress:0,
  band:1, swirl:1, twist:0, eye:1, squint:0,
  spin:0, fall:-0.006, growth:0, seatX:0, seatY:0.17
});

export function createGoldenSpringBank(){
  return {
    tension:new Spring(0,6,1), K:new Spring(.025,3.2,1), rs:new Spring(0,4.8,.52),
    suck:new Spring(0,3.2,1), stress:new Spring(0,2.6,1), band:new Spring(1,1.6,1),
    swirl:new Spring(1,1.8,1), twist:new Spring(0,1.6,1), eye:new Spring(1,7,.75),
    squint:new Spring(0,8,.85), spin:new Spring(0,2.4,1), fall:new Spring(-.006,1.2,1),
    growth:new Spring(0,2.2,.82)
  };
}

export const GOLDEN_PRESETS = Object.freeze({
  IDLE:{...GOLDEN_DEFAULTS},
  A1_CAPTURE:{tension:.34,K:.265,rs:1,suck:1,stress:.88,band:2.8,swirl:7,twist:1.7,eye:1.25,squint:.12,spin:1.25,fall:.22,growth:0},
  A1_RELEASE:{tension:.05,K:-.055,rs:0,suck:0,stress:.12,band:1.15,swirl:1,twist:0,eye:1.05,squint:0,spin:0,fall:-.006,growth:0},
  A2_ABSORB:{tension:.52,K:.105,rs:.46,suck:.36,stress:.76,band:1.35,swirl:2.35,twist:.52,eye:1.18,squint:.18,spin:.38,fall:.035,growth:0},
  A2_RETURN:{tension:.18,K:-.085,rs:.10,suck:0,stress:1.0,band:1.55,swirl:1.4,twist:.18,eye:1.42,squint:.04,spin:.16,fall:-.015,growth:0},
  PASSIVE_50:{...GOLDEN_DEFAULTS,growth:.5,stress:.12},
  PASSIVE_100:{...GOLDEN_DEFAULTS,growth:1,stress:.20}
});

export class GoldenPhaseClock {
  constructor(){ this.band=0;this.swirl=0;this.inflow=0;this.fall=0;this.starSpin=0;this.acc=0;this.accIn=0; }
  step(dt,s){
    const suck=Math.max(0,s.suck.v);
    this.band += dt*.045*s.band.v;
    this.swirl = (this.swirl + dt*.02*s.swirl.v)%1;
    this.inflow += dt*(.05+.9*suck);
    this.fall += dt*s.fall.v;
    this.starSpin += dt*(.003+.09*suck);
    this.acc = (this.acc + dt*(.18+.35*suck))%1;
    this.accIn += dt*(.25+.6*suck);
  }
}
