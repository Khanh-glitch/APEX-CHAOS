
precision highp float;
#define PI 3.14159265359
#define TAU 6.28318530718
mat2 rot(float a){ float c=cos(a), s=sin(a); return mat2(c,s,-s,c); }
float hash12(vec2 p){ vec3 p3=fract(vec3(p.xyx)*.1031); p3+=dot(p3,p3.yzx+33.33); return fract((p3.x+p3.y)*p3.z); }
vec2 hash22(vec2 p){ vec3 p3=fract(vec3(p.xyx)*vec3(.1031,.1030,.0973)); p3+=dot(p3,p3.yzx+33.33); return fract((p3.xx+p3.yz)*p3.zy); }
float gnoise(vec2 p){
  vec2 i=floor(p), f=fract(p);
  vec2 u=f*f*f*(f*(f*6.-15.)+10.);
  float a=dot(hash22(i)*2.-1., f);
  float b=dot(hash22(i+vec2(1,0))*2.-1., f-vec2(1,0));
  float c=dot(hash22(i+vec2(0,1))*2.-1., f-vec2(0,1));
  float d=dot(hash22(i+vec2(1,1))*2.-1., f-vec2(1,1));
  return a+(b-a)*u.x+(c-a)*u.y+(a-b-c+d)*u.x*u.y;
}
float pnoise(vec2 p, float P){
  vec2 i=floor(p), f=fract(p);
  vec2 u=f*f*f*(f*(f*6.-15.)+10.);
  float x0=mod(i.x,P), x1=mod(i.x+1.,P);
  float a=dot(hash22(vec2(x0,i.y))*2.-1., f);
  float b=dot(hash22(vec2(x1,i.y))*2.-1., f-vec2(1,0));
  float c=dot(hash22(vec2(x0,i.y+1.))*2.-1., f-vec2(0,1));
  float d=dot(hash22(vec2(x1,i.y+1.))*2.-1., f-vec2(1,1));
  return a+(b-a)*u.x+(c-a)*u.y+(a-b-c+d)*u.x*u.y;
}
float fbm(vec2 p, int oct){
  float s=0., a=.5;
  for(int i=0;i<6;i++){ if(i>=oct) break; s+=a*gnoise(p); p=mat2(1.6,1.2,-1.2,1.6)*p+vec2(3.1,1.7); a*=.5; }
  return s;
}
float pfbm(vec2 p, float P, int oct){
  float s=0., a=.5;
  for(int i=0;i<5;i++){ if(i>=oct) break; s+=a*pnoise(p,P); p=p*2.+vec2(0.,1.37); P*=2.; a*=.5; }
  return s;
}
vec3 L(vec3 c){ return pow(c, vec3(2.2)); }
float sdSeg(vec2 p, vec2 a, vec2 b, out float h){ vec2 pa=p-a, ba=b-a; h=clamp(dot(pa,ba)/dot(ba,ba),0.,1.); return length(pa-ba*h); }
