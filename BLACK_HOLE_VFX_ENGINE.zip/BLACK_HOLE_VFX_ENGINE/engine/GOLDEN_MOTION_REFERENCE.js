// Exact source excerpts from 01_GOLDEN_BASELINE.html; line numbers preserved for audit.

0715: /* =====================================================================
0716:    Motion system: springs (critically / under-damped) driven by a
0717:    scripted event timeline. Speeds are integrated into phases so that
0718:    any change of speed never produces a jump.
0719:    ===================================================================== */
0720: const clamp01 = x => Math.min(1, Math.max(0, x));
0721: const ease = x => { x = clamp01(x); return x * x * (3 - 2 * x); };
0722: const easeOut = x => { x = clamp01(x); return 1 - Math.pow(1 - x, 3); };
0723: const easeIn = x => { x = clamp01(x); return x * x * x; };
0724: const lerp = (a, b, t) => a + (b - a) * t;
0725: const sstep = (e0, e1, x) => ease((x - e0) / (e1 - e0));
0726: const rnd = (a = 0, b = 1) => a + Math.random() * (b - a);
0727: 
0728: class Spring {
0729:   constructor(v, w, z){ this.v = v; this.t = v; this.vel = 0; this.w = w; this.z = z; this.w0 = w; this.z0 = z; }
0730:   step(dt){ const n = 4, h = dt / n; for (let i = 0; i < n; i++) { const a = this.w * this.w * (this.t - this.v) - 2 * this.z * this.w * this.vel; this.vel += a * h; this.v += this.vel * h; } }
0731:   snap(v){ this.v = this.t = v; this.vel = 0; }
0732: }
0733: const SP = {
0734:   tension: new Spring(0, 6, 1),
0735:   K:       new Spring(0.025, 3.2, 1),
0736:   rs:      new Spring(0, 4.8, 0.52),
0737:   suck:    new Spring(0, 3.2, 1),
0738:   stress:  new Spring(0.0, 2.6, 1),
0739:   band:    new Spring(1, 1.6, 1),
0740:   swirl:   new Spring(1, 1.8, 1),
0741:   twist:   new Spring(0, 1.6, 1),
0742:   eye:     new Spring(1, 7, 0.75),
0743:   squint:  new Spring(0, 8, 0.85),
0744:   spin:    new Spring(0, 2.4, 1),
0745:   fall:    new Spring(-0.006, 1.2, 1),
0746: };
0747: const IDLE_T = { tension:0, K:0.025, rs:0, suck:0, stress:0, band:1, swirl:1, twist:0, eye:1, squint:0, spin:0, fall:-0.006 };
0748: function setTargets(o){ for (const k in o) SP[k].t = o[k]; }
0749: 
0750: const S = { state:'idle', tau:0, fired:{}, shockT:99, shockAmp:0, flash:0 };
0751: let T = 0;              // shader time (scaled by slow-mo)
0752: let timeScale = 1;
0753: const PH = { band:0, swirl:0, inflow:0, fall:0, starSpin:0, acc:0, accIn:0 };
0754: 
0755: function setState(s){
0756:   S.state = s; S.tau = 0; S.fired = {};
0757:   if (s === 'closing') { SP.rs.w = 9; SP.rs.z = 0.95; SP.K.w = 5.2; SP.K.z = 0.3; SP.band.w = 1.2; }
0758:   else if (s === 'opening') { SP.rs.w = 4.8; SP.rs.z = 0.52; SP.K.w = 3.2; SP.K.z = 1; SP.band.w = 1.6; }
0759:   else if (s === 'idle') { SP.rs.w = 4.8; SP.rs.z = 0.52; SP.K.w = 2.2; SP.K.z = 1; SP.band.w = 1.6; }
0760:   $('stName').textContent = s.toUpperCase();
0761:   $('bOpen').innerHTML = (s === 'opening' || s === 'active') ? '<kbd>J</kbd>CLOSE' : '<kbd>J</kbd>OPEN';
0762: }
0763: function fireShock(a){ S.shockT = 0; S.shockAmp = a; }
0764: 
0765: function updateTimeline(dt){
0766:   S.tau += dt;
0767:   const t = S.tau, st = S.state;
0768:   if (st === 'idle') {
0769:     setTargets(IDLE_T);
0770:   } else if (st === 'opening') {
0771:     const B = 1.05; // singularity birth
0772:     setTargets({
0773:       tension: t < B ? easeIn(t / B) * 0.6 + ease(t / B) * 0.4 : 0.3,
0774:       squint:  t < B ? 0.5 * ease(t / 0.9) : 0.12,
0775:       eye:     t < B ? 1 + 0.6 * ease(t / B) : 1.3,
0776:       K:       t < 0.45 ? 0.025 : t < B ? 0.025 + 0.06 * ease((t - 0.45) / 0.6) : 0.085 + 0.19 * easeOut((t - B) / 1.8),
0777:       rs:      t < B ? 0 : 1,
0778:       suck:    t < B ? 0.12 * ease(t / B) : 0.12 + 0.88 * ease((t - B) / 1.5),
0779:       stress:  t < 0.7 ? 0.1 * ease(t / 0.7) : 0.1 + 0.9 * ease((t - 0.7) / 1.8),
0780:       band:    t < B ? 1 - 0.7 * ease(t / B) : 2.8,
0781:       swirl:   t < B ? 1 + 3 * ease(t / B) : 7,
0782:       twist:   t < B ? 0.8 * ease(t / B) : 1.7,
0783:       spin:    t < 0.45 ? 0 : t < B ? 0.6 * ease((t - 0.45) / 0.6) : 1.25,
0784:       fall:    t < B ? 0.0 : 0.22,
0785:     });
0786:     if (t >= B && !S.fired.birth) { S.fired.birth = 1; fireShock(1.0); S.flash = 1.0; }
0787:     if (t > 3.8) setState('active');
0788:   } else if (st === 'active') {
0789:     const hb = Math.sin(T * 1.25);
0790:     setTargets({ tension:0.28, K:0.275 + 0.012 * hb, rs:1 + 0.035 * hb, suck:1, stress:0.86 + 0.14 * Math.sin(T * 1.25 - 0.7),
0791:                  band:2.8, swirl:7, twist:1.7, eye:1.28, squint:0.14, spin:1.25, fall:0.22 });
0792:   } else if (st === 'closing') {
0793:     const C1 = 0.7; // horizon collapse
0794:     setTargets({
0795:       suck: 0,
0796:       rs:   t < C1 ? 1 - easeIn(t / C1) : 0,
0797:       K:    t < C1 ? 0.275 * (1 - 0.3 * ease(t / C1)) : 0.0,
0798:       tension: t < C1 ? 0.5 : 0,
0799:       eye:  t < C1 ? 1.1 : t < C1 + 0.3 ? 1.9 : 1,
0800:       squint: t < C1 ? 0.3 : 0,
0801:       stress: 0, band: t < C1 ? 1.5 : 1, swirl: 1, twist: 0,
0802:       spin: t < C1 ? 1.25 : 0, fall: -0.006,
0803:     });
0804:     if (t >= C1 && !S.fired.col) { S.fired.col = 1; fireShock(-0.85); S.flash = 0.85; releaseAll(); }
0805:     if (t > 3.4) setState('idle');
0806:   }
0807:   for (const k in SP) SP[k].step(dt);
0808: 
0809:   const suck = Math.max(0, SP.suck.v);
0810:   PH.band += dt * 0.045 * SP.band.v;
0811:   PH.swirl = (PH.swirl + dt * 0.02 * SP.swirl.v) % 1;
0812:   PH.inflow += dt * (0.05 + 0.9 * suck);
0813:   PH.fall += dt * SP.fall.v;
0814:   PH.starSpin += dt * (0.003 + 0.09 * suck);
0815:   PH.acc = (PH.acc + dt * (0.18 + 0.35 * suck)) % 1;
0816:   PH.accIn += dt * (0.25 + 0.6 * suck);
0817:   S.shockT += dt;
0818:   S.flash *= Math.exp(-dt * 5);
0819: }
0820: 
0821: /* ---------- blink: fast close, brief hold, slower open (eyelid timing) ---------- */
0822: let blinkT = 99, nextBlink = rnd(3, 6), blinkQueue = 0;
0823: function startBlink(){ blinkT = 0; }
0824: function blinkValue(){
0825:   const t = blinkT;
0826:   if (t < 0.075) return 1 - Math.pow(1 - t / 0.075, 2);
0827:   if (t < 0.115) return 1;
0828:   if (t < 0.33) return 1 - easeOut((t - 0.115) / 0.215);
0829:   return 0;
0830: }
0831: function updateBlink(dt){
0832:   blinkT += dt;
0833:   if (blinkQueue > 0 && blinkT > 0.45) { blinkQueue--; startBlink(); }
0834:   const preBirth = S.state === 'opening' && S.tau < 1.6;
0835:   nextBlink -= dt;
0836:   if (nextBlink <= 0 && !preBirth) { startBlink(); if (Math.random() < 0.22) blinkQueue = 1; nextBlink = rnd(3.5, 8.5); }
0837: }
0838: 

// Particle / debris simulation
0839: /* =====================================================================
0840:    Orbiting debris & inner motes — CPU orbital sim.
0841:    Idle: Keplerian-ish orbits around the head. Captured: angular speed
0842:    ~ rho^-1.5 around the forehead seat with decaying radius (spiral infall),
0843:    heating as they fall. Release: elastic outward kick on collapse.
0844:    ===================================================================== */
0845: const SCX = 0, SCY = 0.17;
0846: function eggE(x, y){ const sx = 1 + 0.30 * sstep(0.25, -0.85, y); const sy = lerp(0.73, 0.84, sstep(-0.15, 0.15, y)); return Math.hypot(x * sx, y * sy); }
0847: const ND = 1100, NM = 380, NP = ND + NM;
0848: const parts = [];
0849: function spawnDust(p, fresh){
0850:   p.kind = 0; p.mode = 0;
0851:   p.a = rnd(0, Math.PI * 2);
0852:   p.rad0 = 0.6 + Math.pow(Math.random(), 0.8) * 0.46; p.rad = p.rad0; p.vr = 0;
0853:   p.spd = 0.055 * Math.pow(0.8 / p.rad0, 1.5) * rnd(0.75, 1.25);
0854:   p.size = rnd(1.0, 2.1) * (Math.random() < 0.06 ? 1.8 : 1);
0855:   p.b = Math.random() < 0.07 ? rnd(0.5, 1.1) : rnd(0.05, 0.28);
0856:   p.fade = fresh ? 0 : 1; p.heat = 0; p.wob = rnd(0, 6.28);
0857:   p.x = Math.cos(p.a) * p.rad; p.y = Math.sin(p.a) * p.rad * 0.97; p.px = p.x; p.py = p.y;
0858: }
0859: function spawnMote(p, fresh){
0860:   p.kind = 1; p.mode = 0;
0861:   do { p.x = rnd(-0.45, 0.45); p.y = rnd(-0.66, 0.6); } while (eggE(p.x, p.y) > 0.45);
0862:   p.bvx = rnd(-1, 1) * 0.004; p.bvy = rnd(-1, 1) * 0.004; p.vx = p.bvx; p.vy = p.bvy;
0863:   p.size = rnd(0.8, 1.6); p.b = rnd(0.05, 0.24) * (Math.random() < 0.05 ? 3 : 1);
0864:   p.fade = fresh ? 0 : 1; p.heat = 0; p.px = p.x; p.py = p.y; p.wob = rnd(0, 6.28);
0865: }
0866: for (let i = 0; i < NP; i++) { const p = {}; if (i < ND) spawnDust(p, false); else spawnMote(p, false); parts.push(p); }
0867: 
0868: const NS = 16, shards = [];
0869: function spawnShard(s, fresh){
0870:   s.mode = 0; s.a = rnd(0, Math.PI * 2); s.rad0 = rnd(0.93, 1.12); s.rad = s.rad0; s.vr = 0;
0871:   s.spd = 0.035 * Math.pow(1 / s.rad0, 1.5) * rnd(0.7, 1.3);
0872:   s.size = Math.random() < 0.35 ? rnd(0.03, 0.05) : rnd(0.055, 0.1);
0873:   s.seed = Math.random(); s.alpha = fresh ? 0 : 1; s.stretch = 1; s.heat = 0; s.wob = rnd(0, 6.28); s.tilt = rnd(-0.5, 0.5);
0874:   s.x = Math.cos(s.a) * s.rad; s.y = Math.sin(s.a) * s.rad * 0.97; s.phi = s.a - Math.PI / 2; s.dead = 0;
0875: }
0876: for (let i = 0; i < NS; i++) { const s = {}; spawnShard(s, false); shards.push(s); }
0877: 
0878: function releaseAll(){
0879:   for (const p of parts) {
0880:     if (p.mode !== 1) continue;
0881:     p.mode = 0;
0882:     if (p.kind === 0) { p.a = Math.atan2(p.y, p.x); p.rad = Math.hypot(p.x, p.y) / 0.985; p.vr = rnd(0.5, 1.1); }
0883:     else { const dx = p.x - SCX, dy = p.y - SCY, l = Math.hypot(dx, dy) + 1e-4; const k = rnd(0.15, 0.4); p.vx = dx / l * k; p.vy = dy / l * k; }
0884:   }
0885:   for (const s of shards) {
0886:     if (s.mode !== 1) continue;
0887:     s.mode = 0; s.a = Math.atan2(s.y, s.x); s.rad = Math.hypot(s.x, s.y); s.vr = rnd(0.4, 0.9);
0888:   }
0889: }
0890: 
0891: function updateParticles(dt){
0892:   const suck = Math.max(0, SP.suck.v), rs = 0.125 * Math.max(SP.rs.v, 0);
0893:   const bandK = 0.6 + 0.4 * SP.band.v;
0894:   for (const p of parts) {
0895:     p.px = p.x; p.py = p.y;
0896:     if (p.mode === 0) {
0897:       if (p.kind === 0) {
0898:         p.a -= p.spd * dt * bandK;
0899:         p.vr += ((p.rad0 - p.rad) * 3.0 - p.vr * 1.6) * dt;
0900:         p.rad += p.vr * dt;
0901:         const w = 1 + 0.01 * Math.sin(T * 0.7 + p.wob);
0902:         p.x = Math.cos(p.a) * p.rad * w; p.y = Math.sin(p.a) * p.rad * 0.97 * w;
0903:       } else {
0904:         p.vx += (p.bvx - p.vx) * Math.min(1, dt * 1.2); p.vy += (p.bvy - p.vy) * Math.min(1, dt * 1.2);
0905:         p.x += p.vx * dt; p.y += p.vy * dt;
0906:         if (eggE(p.x, p.y) > 0.47) { p.x -= p.vx * dt * 2; p.y -= p.vy * dt * 2; p.vx *= -0.6; p.vy *= -0.6; p.bvx *= -1; p.bvy *= -1; }
0907:       }
0908:       p.fade = Math.min(1, p.fade + dt * 0.6);
0909:       if (suck > 0.04) {
0910:         const dx = p.x - SCX, dy = p.y - SCY, dist = Math.hypot(dx, dy);
0911:         const rate = suck * (p.kind === 1 ? 0.55 : 0.16) * (0.4 + 1.2 * Math.exp(-dist * 1.5));
0912:         if (Math.random() < rate * dt) { p.mode = 1; p.rho = dist; p.al = Math.atan2(dy, dx); }
0913:       }
0914:     } else {
0915:       const rho = Math.max(p.rho, 0.02);
0916:       const om = Math.min(0.34 * Math.pow(rho, -1.5), 14);
0917:       p.al -= om * dt * (0.35 + 0.65 * Math.min(1, suck * 1.5));
0918:       p.rho -= (0.07 + 0.022 / rho) * Math.max(suck, 0.05) * dt;
0919:       p.x = SCX + Math.cos(p.al) * p.rho; p.y = SCY + Math.sin(p.al) * p.rho;
0920:       p.heat = clamp01((0.32 - p.rho) / 0.22);
0921:       if (p.rho < rs * 1.04 + 0.004) { if (p.kind === 0) spawnDust(p, true); else spawnMote(p, true); }
0922:     }
0923:   }
0924:   for (const s of shards) {
0925:     if (s.mode === 2) { s.dead -= dt; if (s.dead <= 0) spawnShard(s, true); continue; }
0926:     if (s.mode === 0) {
0927:       s.a -= s.spd * dt * (0.5 + 0.5 * SP.band.v);
0928:       s.vr += ((s.rad0 - s.rad) * 2.5 - s.vr * 1.4) * dt; s.rad += s.vr * dt;
0929:       const bob = 1 + 0.012 * Math.sin(T * 0.5 + s.wob);
0930:       s.x = Math.cos(s.a) * s.rad * bob; s.y = Math.sin(s.a) * s.rad * 0.97 * bob;
0931:       s.phi = s.a - Math.PI / 2 + s.tilt + 0.25 * Math.sin(T * 0.3 + s.wob);
0932:       s.alpha = Math.min(1, s.alpha + dt * 0.5); s.stretch += (1 - s.stretch) * Math.min(1, dt * 3); s.heat *= Math.exp(-dt * 2);
0933:       if (suck > 0.3 && Math.random() < 0.12 * suck * dt) {
0934:         s.mode = 1; const dx = s.x - SCX, dy = s.y - SCY; s.rho = Math.hypot(dx, dy); s.rho0 = s.rho; s.al = Math.atan2(dy, dx); s.phi0 = s.phi;
0935:       }
0936:     } else {
0937:       const rho = Math.max(s.rho, 0.02);
0938:       const om = Math.min(0.3 * Math.pow(rho, -1.5), 10);
0939:       s.al -= om * dt * (0.35 + 0.65 * Math.min(1, suck * 1.5));
0940:       s.rho -= (0.05 + 0.016 / rho) * Math.max(suck, 0.05) * dt;
0941:       s.x = SCX + Math.cos(s.al) * s.rho; s.y = SCY + Math.sin(s.al) * s.rho;
0942:       const prog = ease(1 - s.rho / s.rho0);
0943:       const tx = Math.cos(s.phi0), ty = Math.sin(s.phi0), rx = Math.cos(s.al), ry = Math.sin(s.al);
0944:       s.phi = Math.atan2(lerp(ty, ry, prog), lerp(tx, rx, prog));   // align to radial: tidal stretching
0945:       s.stretch = 1 + 3.0 * prog * prog;
0946:       s.heat = sstep(0.38, 0.12, s.rho);
0947:       s.alpha = rs > 0.001 ? sstep(rs * 1.0, rs * 2.2, s.rho) : 1;
0948:       if (s.rho < rs * 1.05 + 0.004) { s.mode = 2; s.dead = rnd(1.5, 4); s.alpha = 0; }
0949:     }
0950:   }
0951: }
