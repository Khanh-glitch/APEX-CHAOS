/* Extracted from SHA-256 ccb889bb..., original GOLD modules with only asset prefixes and explicit visualOnly init guard. */
(function(){
const ASSETS = {"src/assets/char-body.png":"../assets/boxe-gold/char-body.png","src/assets/glove.png":"../assets/boxe-gold/glove.png","src/assets/dummy.png":"../assets/boxe-gold/dummy.png","src/assets/bot.png":"../assets/boxe-gold/bot.png","src/assets/fx-rock.png":"../assets/boxe-gold/fx-rock.png","src/assets/fx-rubble.png":"../assets/boxe-gold/fx-rubble.png","src/assets/fx-fracture.png":"../assets/boxe-gold/fx-fracture.png","src/assets/char-body-new.png":"../assets/boxe-gold/char-body-new.png","src/assets/char-body2.png":"../assets/boxe-gold/char-body2.png","src/assets/fx-fire.png":"../assets/boxe-gold/fx-fire.png"};
const modules={'src/game/skills.ts': function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SKILLS = void 0;
exports.SKILLS = [
    {
        id: 'jab',
        key: '1',
        icon: 'Zap',
        name: 'Liên Hoàn Sấm Jab',
        en: 'THUNDER JAB FLURRY',
        identity: 'Dồn dập tốc độ — 6 cú jab chớp nhoáng, sét nhảy sang mục tiêu gần.',
        desc: 'Hai găng thay nhau đâm ra như tia chớp 6 lần trong 0.5s về hướng ngắm. Mỗi cú trúng phóng hồ quang sét sang kẻ địch gần nhất trong 160px. Đòn kết thúc đẩy lùi mạnh hơn.',
        cd: 4,
        damage: '6 × 16 (+hồ quang 10)',
        range: '190px hình nón',
        color: '#ffd23c',
        tags: ['Tốc độ', 'Combo', 'Sét'],
    },
    {
        id: 'rocket',
        key: '2',
        icon: 'Rocket',
        name: 'Găng Tên Lửa',
        en: 'ROCKET FIST',
        identity: 'Đạn đạo sống — găng phải rời tay, xuyên tuyến, rồi boomerang quay về.',
        desc: 'Bắn găng phải như một quả tên lửa lửa-sét xuyên qua mọi kẻ địch (130 dmg). Bay hết tầm 880px, găng quay ngược về tay và gây thêm 60 dmg trên đường về. Trong lúc găng bay, tay phải không đấm thường được.',
        cd: 7,
        damage: '130 xuyên + 60 về',
        range: '880px đường thẳng',
        color: '#ff7a3c',
        tags: ['Xuyên tuyến', 'Boomerang', 'Tầm xa'],
    },
    {
        id: 'uppercut',
        key: '3',
        icon: 'Flame',
        name: 'Uppercut Núi Lửa',
        en: 'VOLCANO UPPERCUT',
        identity: 'Hất tung bùng nổ — móc hàm cận chiến, mặt đất phun 5 cột lửa đuổi theo.',
        desc: 'Cú móc từ dưới lên gây 150 dmg và hất kẻ địch lên không trung. Sau đó 5 cột lửa phun lên ngẫu nhiên quanh điểm chạm, mỗi cột 34 dmg. Để lại vết nứt cháy trên sàn.',
        cd: 9,
        damage: '150 + 5 × 34',
        range: '150px trước mặt',
        color: '#ff4d2e',
        tags: ['Hất tung', 'AoE', 'Lửa'],
    },
    {
        id: 'cyclone',
        key: '4',
        icon: 'Tornado',
        name: 'Lốc Xoáy Đỏ',
        en: 'CRIMSON CYCLONE',
        identity: 'Xoay tròn hút địch — 2.2s thành cơn lốc, khăn choàng xoáy thành vòng xoắn.',
        desc: 'Xoay người cực nhanh 2.2 giây: hai găng duỗi thẳng quét vòng tròn 210px, gây dmg mỗi 0.16s và hút kẻ địch vào tâm. Vẫn di chuyển được ở 55% tốc độ. Khăn choàng bị cuốn xoáy theo quán tính.',
        cd: 12,
        damage: '17 × ~13 nhịp',
        range: 'Bán kính 210px',
        color: '#38e1ff',
        tags: ['Kênh chiêu', 'Hút địch', 'Xoay'],
    },
    {
        id: 'phantom',
        key: '5',
        icon: 'Ghost',
        name: 'Ảnh Bộ Liên Kích',
        en: 'PHANTOM STEP COMBO',
        identity: 'Tốc biến ám sát — chớp sau lưng 3 mục tiêu, để lại tàn ảnh.',
        desc: 'Nháy mắt dịch chuyển ra sau lưng tối đa 3 kẻ địch gần nhất trong 560px, mỗi nơi tung cú đấm 78 dmg kèm vệt chém sét. Không có mục tiêu thì lướt 340px theo hướng ngắm. Bất tử trong lúc thi triển.',
        cd: 11,
        damage: '3 × 78',
        range: '560px tự tìm địch',
        color: '#b78bff',
        tags: ['Dịch chuyển', 'Tàn ảnh', 'Đơn mục'],
    },
    {
        id: 'meteor',
        key: '6',
        icon: 'Bomb',
        name: 'Thiên Thạch Giáng',
        en: 'METEOR SLAM',
        identity: 'Nhảy bổ điểm chuột — tiếp đất tạo hố va chạm, chậm diện rộng.',
        desc: 'Nhảy vọt lên trời tới vị trí con trỏ (tối đa 430px), nện xuống gây 195 dmg trong bán kính 225px, rung màn hình cực mạnh, để lại hố thiên thạch làm chậm 45% trong 4 giây.',
        cd: 13,
        damage: '195 AoE',
        range: 'Nhảy 430px / nổ 225px',
        color: '#ff9f2e',
        tags: ['Cơ động', 'Nổ lớn', 'Làm chậm'],
    },
    {
        id: 'orbit',
        key: '7',
        icon: 'Orbit',
        name: 'Vệ Tinh Găng Sấm',
        en: 'THUNDER ORBIT',
        identity: 'Triệu hồi vệ tinh — 2 găng mini bay quanh người tự đấm mọi thứ chạm vào.',
        desc: 'Trong 6 giây, hai găng năng lượng mini quay quanh nhân vật ở bán kính 108px với tốc độ cao, tự đấm 28 dmg mỗi cú (hồi 0.35s/mục tiêu) và đẩy lùi ra ngoài. Thoải mái đấm thường/di chuyển khi vệ tinh hoạt động.',
        cd: 16,
        damage: '28 / cú',
        range: 'Quỹ đạo 108px, 6s',
        color: '#4dffb8',
        tags: ['Triệu hồi', 'Duy trì', 'Phòng thủ vòng'],
    },
    {
        id: 'wave',
        key: '8',
        icon: 'Waves',
        name: 'Địa Chấn Ba',
        en: 'SEISMIC TRIPLE WAVE',
        identity: 'Sóng xung kích mặt đất — 3 đợt sóng nứt đất tỏa hình quạt.',
        desc: 'Đấm xuống đất phóng 3 sóng địa chấn (giữa + lệch ±14°) chạy dọc mặt đất 640px, mỗi sóng 88 dmg và xô ngã kẻ địch. Sóng để lại vệt nứt phát sáng rồi tắt dần.',
        cd: 8,
        damage: '3 sóng × 88',
        range: '640px hình quạt',
        color: '#ffb03c',
        tags: ['Mặt đất', 'Tầm trung', 'Đẩy lùi'],
    },
    {
        id: 'counter',
        key: '9',
        icon: 'Shield',
        name: 'Phản Đòn Hoàng Kim',
        en: 'GOLDEN COUNTER',
        identity: 'Phòng thủ phản công — khiên vàng chặn đạn, phản đòn dịch chuyển 175 dmg.',
        desc: 'Dựng khiên hoàng kim 1.6 giây: chặn mọi đạn bay tới. Nếu chặn được đạn, lập tức phản đòn — lao tới kẻ bắn và tung cú đấm vàng 175 dmg. Hết khiên mà không chặn được gì vẫn phát nổ nova 65 dmg quanh người. Hãy thả Robot đấu tập ra để test!',
        cd: 12,
        damage: 'Phản 175 / nova 65',
        range: 'Khiên 1.6s',
        color: '#f6b73c',
        tags: ['Phòng thủ', 'Phản đòn', 'Khiên'],
    },
    {
        id: 'ult',
        key: '0',
        icon: 'Crown',
        name: 'Võ Đài Tối Thượng',
        en: "CHAMPION'S FINAL ROUND",
        identity: 'Chiêu cuối điện ảnh — làm chậm thời gian, 10 cú đấm dịch chuyển, kết liễu K.O.',
        desc: 'Hiệp đấu cuối cùng: thời gian chậm lại, nhân vật chớp qua lại giữa các kẻ địch tung 10 cú đấm 48 dmg, kết thúc bằng cú uppercut hoàng kim 265 dmg diện rộng kèm mưa sao ăn mừng. Màn hình hiện K.O. nếu hạ gục mục tiêu.',
        cd: 30,
        damage: '10 × 48 + 265',
        range: 'Toàn võ đài 620px',
        color: '#ff2e63',
        tags: ['Chiêu cuối', 'Slow-mo', 'Điện ảnh'],
    },
];

},
'src/game/fx/textures.ts': function(module,exports,require){
"use strict";
/* Procedural textures — all effects are lit from real textures instead of
   flat circles, which is what makes smoke/fire/sparks read as material. */
Object.defineProperty(exports, "__esModule", { value: true });
exports.hexToRgb = hexToRgb;
exports.smokeTex = smokeTex;
exports.glowTex = glowTex;
exports.softTex = softTex;
exports.sparkTex = sparkTex;
exports.scorchTex = scorchTex;
exports.grainTex = grainTex;
exports.floorTex = floorTex;
const cache = new Map();
function mk(w, h) {
    const c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    return c;
}
function hexToRgb(hex) {
    const h = hex.replace('#', '');
    const n = parseInt(h.length === 3 ? h.split('').map((c) => c + c).join('') : h, 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}
function rndf(seed) {
    let s = (seed >>> 0) || 12345;
    return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };
}
/** tileable value-noise fBm in [0,1] */
function fbm(size, seed, octaves = 4, persist = 0.55, baseFreq = 4) {
    const out = new Float32Array(size * size);
    let amp = 1, total = 0, freq = baseFreq;
    const r = rndf(seed * 7919 + 13);
    for (let o = 0; o < octaves; o++) {
        const g = freq + 1;
        const grid = new Float32Array(g * g);
        for (let i = 0; i < grid.length; i++)
            grid[i] = r();
        for (let y = 0; y < size; y++) {
            const gy = (y / size) * freq, y0 = Math.floor(gy), ty = gy - y0;
            const sy = ty * ty * (3 - 2 * ty);
            for (let x = 0; x < size; x++) {
                const gx = (x / size) * freq, x0 = Math.floor(gx), tx = gx - x0;
                const sx = tx * tx * (3 - 2 * tx);
                const a = grid[y0 * g + x0], b = grid[y0 * g + x0 + 1];
                const c = grid[(y0 + 1) * g + x0], d = grid[(y0 + 1) * g + x0 + 1];
                out[y * size + x] += amp * ((a * (1 - sx) + b * sx) * (1 - sy) + (c * (1 - sx) + d * sx) * sy);
            }
        }
        total += amp;
        amp *= persist;
        freq *= 2;
    }
    for (let i = 0; i < out.length; i++)
        out[i] /= total;
    return out;
}
/** billowing smoke puff — noise broken into soft lobes with a radial falloff */
function smokeTex(color, seed = 1) {
    const key = `smoke:${color}:${seed}`;
    const hit = cache.get(key);
    if (hit)
        return hit;
    const S = 128;
    const n = fbm(S, seed, 4, 0.58, 3);
    const [r, g, b] = hexToRgb(color);
    const c = mk(S, S);
    const ctx = c.getContext('2d');
    const img = ctx.createImageData(S, S);
    const d = img.data;
    for (let i = 0; i < S * S; i++) {
        const px = (i % S) / S - 0.5, py = Math.floor(i / S) / S - 0.5;
        const dist = Math.hypot(px, py) * 2;
        const fall = Math.max(0, 1 - dist * 1.25);
        let v = (n[i] - 0.33) / 0.46;
        v = v < 0 ? 0 : v > 1 ? 1 : v;
        v = Math.pow(v, 0.8);
        const a = Math.round(255 * v * fall * fall);
        const o = i * 4;
        d[o] = r;
        d[o + 1] = g;
        d[o + 2] = b;
        d[o + 3] = a;
    }
    ctx.putImageData(img, 0, 0);
    cache.set(key, c);
    return c;
}
/** hot light: white core → colour → transparent */
function glowTex(color) {
    const key = `glow:${color}`;
    const hit = cache.get(key);
    if (hit)
        return hit;
    const S = 128;
    const c = mk(S, S);
    const x = c.getContext('2d');
    const g = x.createRadialGradient(S / 2, S / 2, 0, S / 2, S / 2, S / 2);
    g.addColorStop(0, '#ffffff');
    g.addColorStop(0.16, color);
    g.addColorStop(0.45, color + '66');
    g.addColorStop(1, color + '00');
    x.fillStyle = g;
    x.fillRect(0, 0, S, S);
    cache.set(key, c);
    return c;
}
/** diffuse light without the white core (fire haze, dust bounce light) */
function softTex(color) {
    const key = `soft:${color}`;
    const hit = cache.get(key);
    if (hit)
        return hit;
    const S = 96;
    const c = mk(S, S);
    const x = c.getContext('2d');
    const g = x.createRadialGradient(S / 2, S / 2, 0, S / 2, S / 2, S / 2);
    g.addColorStop(0, color + 'b4');
    g.addColorStop(0.45, color + '58');
    g.addColorStop(1, color + '00');
    x.fillStyle = g;
    x.fillRect(0, 0, S, S);
    cache.set(key, c);
    return c;
}
/** motion-blurred spark streak, drawn along its velocity */
function sparkTex(color) {
    const key = `spark:${color}`;
    const hit = cache.get(key);
    if (hit)
        return hit;
    const W = 64, H = 12;
    const c = mk(W, H);
    const x = c.getContext('2d');
    x.globalCompositeOperation = 'lighter';
    const grad = x.createLinearGradient(0, 0, W, 0);
    grad.addColorStop(0, color + '00');
    grad.addColorStop(0.55, color + 'b0');
    grad.addColorStop(0.9, '#ffffff');
    grad.addColorStop(1, '#ffffff');
    x.fillStyle = grad;
    x.fillRect(0, 0, W, H);
    // vertical softening
    const m = x.createLinearGradient(0, 0, 0, H);
    m.addColorStop(0, 'rgba(0,0,0,1)');
    m.addColorStop(0.5, 'rgba(0,0,0,0)');
    m.addColorStop(1, 'rgba(0,0,0,1)');
    x.globalCompositeOperation = 'destination-out';
    x.fillStyle = m;
    x.fillRect(0, 0, W, H);
    cache.set(key, c);
    return c;
}
/** burnt ground blotch with ragged edge and hairline cracks */
function scorchTex(seed = 3) {
    const key = `scorch:${seed}`;
    const hit = cache.get(key);
    if (hit)
        return hit;
    const S = 128;
    const n = fbm(S, seed, 3, 0.6, 3);
    const c = mk(S, S);
    const ctx = c.getContext('2d');
    const img = ctx.createImageData(S, S);
    const d = img.data;
    for (let i = 0; i < S * S; i++) {
        const px = (i % S) / S - 0.5, py = Math.floor(i / S) / S - 0.5;
        const dist = Math.hypot(px, py) * 2;
        const edge = 0.82 + n[i] * 0.42;
        const a = Math.max(0, 1 - dist / edge);
        const o = i * 4;
        d[o] = 12;
        d[o + 1] = 9;
        d[o + 2] = 8;
        d[o + 3] = Math.round(235 * Math.pow(a, 0.7));
    }
    ctx.putImageData(img, 0, 0);
    // hairline cracks radiating out
    const r = rndf(seed + 55);
    ctx.globalCompositeOperation = 'destination-out';
    ctx.strokeStyle = 'rgba(0,0,0,0.55)';
    for (let i = 0; i < 9; i++) {
        const a = (i / 9) * Math.PI * 2 + r() * 0.5;
        ctx.lineWidth = 1 + r() * 1.6;
        ctx.beginPath();
        ctx.moveTo(S / 2 + Math.cos(a) * 12, S / 2 + Math.sin(a) * 12);
        let px = S / 2, py = S / 2;
        for (let k = 0; k < 5; k++) {
            px += Math.cos(a + (r() - 0.5) * 0.8) * 13;
            py += Math.sin(a + (r() - 0.5) * 0.8) * 13;
            ctx.lineTo(px, py);
        }
        ctx.stroke();
    }
    cache.set(key, c);
    return c;
}
/** film grain tile for the post pass */
function grainTex() {
    const key = 'grain';
    const hit = cache.get(key);
    if (hit)
        return hit;
    const S = 128;
    const c = mk(S, S);
    const x = c.getContext('2d');
    const img = x.createImageData(S, S);
    const r = rndf(4242);
    for (let i = 0; i < S * S; i++) {
        const v = 110 + r() * 90;
        const o = i * 4;
        img.data[o] = img.data[o + 1] = img.data[o + 2] = v;
        img.data[o + 3] = 255;
    }
    x.putImageData(img, 0, 0);
    cache.set(key, c);
    return c;
}
/** Gritty ring floor, generated once and repeated in world space. */
function floorTex() {
    const key = 'floor';
    const hit = cache.get(key);
    if (hit)
        return hit;
    const S = 256;
    const c = mk(S, S);
    const x = c.getContext('2d');
    const coarse = fbm(S, 97, 4, 0.55, 3);
    const fine = fbm(S, 812, 3, 0.5, 20);
    const image = x.createImageData(S, S);
    for (let i = 0; i < S * S; i++) {
        const n = Math.round((coarse[i] - 0.5) * 35 + (fine[i] - 0.5) * 20);
        const o = i * 4;
        image.data[o] = Math.max(0, 31 + n);
        image.data[o + 1] = Math.max(0, 35 + n);
        image.data[o + 2] = Math.max(0, 39 + n);
        image.data[o + 3] = 255;
    }
    x.putImageData(image, 0, 0);
    const r = rndf(313);
    for (let i = 0; i < 105; i++) {
        const px = r() * S, py = r() * S;
        x.fillStyle = r() < 0.5 ? 'rgba(189,177,151,0.055)' : 'rgba(0,0,0,0.12)';
        x.fillRect(px, py, r() * 5 + 1, r() * 2 + 0.4);
    }
    cache.set(key, c);
    return c;
}

},
'src/game/sprites.ts': function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.tint = tint;
exports.loadSprites = loadSprites;
const char_body_png_1 = require("../assets/char-body.png");
const glove_png_1 = require("../assets/glove.png");
const dummy_png_1 = require("../assets/dummy.png");
const bot_png_1 = require("../assets/bot.png");
function loadImage(url) {
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.onload = () => resolve(img);
        img.onerror = reject;
        img.src = url;
    });
}
/**
 * Remove a (near-)solid background by flood-filling from the image borders.
 * Interior pixels of similar colour (white hood panels, white wraps) survive
 * because the character outline blocks the flood. A second pass deletes the
 * soft grey drop-shadow blobs baked into the generated art.
 */
function cutout(img) {
    const w = img.naturalWidth;
    const h = img.naturalHeight;
    const cvs = document.createElement('canvas');
    cvs.width = w;
    cvs.height = h;
    const ctx = cvs.getContext('2d', { willReadFrequently: true });
    ctx.drawImage(img, 0, 0);
    const imageData = ctx.getImageData(0, 0, w, h);
    const d = imageData.data;
    // reference background colour = average of the 4 corners
    const corners = [0, (w - 1) * 4, (h - 1) * w * 4, ((h - 1) * w + (w - 1)) * 4];
    let br = 0, bg = 0, bb = 0;
    for (const i of corners) {
        br += d[i];
        bg += d[i + 1];
        bb += d[i + 2];
    }
    br /= 4;
    bg /= 4;
    bb /= 4;
    const isBg = (idx) => {
        const dr = d[idx] - br, dg = d[idx + 1] - bg, db = d[idx + 2] - bb;
        return dr * dr + dg * dg + db * db < 2600; // ~51 euclidean tolerance
    };
    const visited = new Uint8Array(w * h);
    const stack = [];
    const push = (p) => {
        if (!visited[p]) {
            visited[p] = 1;
            stack.push(p);
        }
    };
    for (let x = 0; x < w; x++) {
        push(x);
        push((h - 1) * w + x);
    }
    for (let y = 0; y < h; y++) {
        push(y * w);
        push(y * w + (w - 1));
    }
    while (stack.length) {
        const p = stack.pop();
        const idx = p * 4;
        if (!isBg(idx))
            continue;
        d[idx + 3] = 0;
        const x = p % w, y = (p / w) | 0;
        if (x > 0)
            push(p - 1);
        if (x < w - 1)
            push(p + 1);
        if (y > 0)
            push(p - w);
        if (y < h - 1)
            push(p + w);
    }
    const isShadowTone = (idx) => {
        const r = d[idx], g = d[idx + 1], b = d[idx + 2];
        const mx = Math.max(r, g, b), mn = Math.min(r, g, b);
        const sat = mx === 0 ? 0 : (mx - mn) / mx;
        return sat < 0.16 && mx > 110 && mx < 238;
    };
    // 1px halo erosion: bright low-sat pixels touching transparency are
    // anti-aliasing residue from the white backdrop.
    const halo = [];
    for (let y = 1; y < h - 1; y++) {
        for (let x = 1; x < w - 1; x++) {
            const p = y * w + x, idx = p * 4;
            if (d[idx + 3] === 0)
                continue;
            const r = d[idx], g = d[idx + 1], b = d[idx + 2];
            const mx = Math.max(r, g, b), mn = Math.min(r, g, b);
            const sat = mx === 0 ? 0 : (mx - mn) / mx;
            if (mx > 205 && sat < 0.25 &&
                (d[idx - 4 + 3] === 0 || d[idx + 4 + 3] === 0 || d[idx - w * 4 + 3] === 0 || d[idx + w * 4 + 3] === 0)) {
                halo.push(idx);
            }
        }
    }
    for (const idx of halo)
        d[idx + 3] = 0;
    // delete baked-in grey ground shadows — but only blobs connected to the
    // transparent outside, so beige bandages / silver armour inside survive.
    const seen = new Uint8Array(w * h);
    const stack2 = [];
    const pushShadow = (p) => {
        const idx = p * 4;
        if (!seen[p] && d[idx + 3] !== 0 && isShadowTone(idx)) {
            seen[p] = 1;
            stack2.push(p);
        }
    };
    for (let y = Math.floor(h * 0.5); y < h; y++) {
        for (let x = 0; x < w; x++) {
            const p = y * w + x, idx = p * 4;
            if (d[idx + 3] === 0 || !isShadowTone(idx))
                continue;
            if (x === 0 || y === h - 1 || d[idx - 4 + 3] === 0 || d[idx + 4 + 3] === 0 || d[idx + w * 4 + 3] === 0)
                pushShadow(p);
        }
    }
    while (stack2.length) {
        const p = stack2.pop();
        d[p * 4 + 3] = 0;
        const x = p % w, y = (p / w) | 0;
        if (x > 0)
            pushShadow(p - 1);
        if (x < w - 1)
            pushShadow(p + 1);
        if (y > 0)
            pushShadow(p - w);
        if (y < h - 1)
            pushShadow(p + w);
    }
    ctx.putImageData(imageData, 0, 0);
    return cvs;
}
/** Crop to the opaque bounding box so the canvas centre == visual centre. */
function trim(src) {
    const w = src.width, h = src.height;
    const d = src.getContext('2d', { willReadFrequently: true }).getImageData(0, 0, w, h).data;
    let minX = w, minY = h, maxX = 0, maxY = 0;
    for (let y = 0; y < h; y++) {
        for (let x = 0; x < w; x++) {
            if (d[(y * w + x) * 4 + 3] > 24) {
                if (x < minX)
                    minX = x;
                if (x > maxX)
                    maxX = x;
                if (y < minY)
                    minY = y;
                if (y > maxY)
                    maxY = y;
            }
        }
    }
    if (maxX <= minX || maxY <= minY)
        return src;
    const pad = 2;
    minX = Math.max(0, minX - pad);
    minY = Math.max(0, minY - pad);
    maxX = Math.min(w - 1, maxX + pad);
    maxY = Math.min(h - 1, maxY + pad);
    const out = document.createElement('canvas');
    out.width = maxX - minX + 1;
    out.height = maxY - minY + 1;
    out.getContext('2d').drawImage(src, minX, minY, out.width, out.height, 0, 0, out.width, out.height);
    return out;
}
/** Solid-colour silhouette of a sprite (afterimages, hit flashes). */
function tint(src, color) {
    const c = document.createElement('canvas');
    c.width = src.width;
    c.height = src.height;
    const x = c.getContext('2d');
    x.drawImage(src, 0, 0);
    x.globalCompositeOperation = 'source-in';
    x.fillStyle = color;
    x.fillRect(0, 0, c.width, c.height);
    return c;
}
let boxeSpritesPromise = null;
async function loadSprites() {
    // Match-owned Gold engines share one decoded sprite set.  It is critical
    // on 1v1 mobile: two fighters must not fetch/decode 4 sheets twice.
    if (!boxeSpritesPromise) boxeSpritesPromise = Promise.all([
        loadImage(char_body_png_1.default),
        loadImage(glove_png_1.default),
        loadImage(dummy_png_1.default),
        loadImage(bot_png_1.default),
    ]).then(([body, glove, dummy, bot]) => ({
        body: trim(cutout(body)),
        glove: trim(cutout(glove)),
        dummy: trim(cutout(dummy)),
        bot: trim(cutout(bot)),
    })).catch(err => { boxeSpritesPromise = null; throw err; });
    return boxeSpritesPromise;
}

},
'src/game/fx/fluid.ts': function(module,exports,require){
"use strict";
/* Stable-fluids solver (Stam 1999) on a world-space grid covering the arena.
   Fields: velocity (u,v), smoke density, temperature.
   - semi-Lagrangian advection, Gauss-Seidel pressure projection
   - buoyancy from temperature, vorticity confinement for curling detail
   - temperature cools, smoke dissipates, heat burns smoke away (fire eats soot)
   Rendering: temperature → blackbody emission (additive), density → lit soot. */
Object.defineProperty(exports, "__esModule", { value: true });
exports.Fluid = exports.BB = exports.N = exports.HALF = exports.CELL = void 0;
exports.CELL = 12; // world px per cell
exports.HALF = 936; // grid covers [-HALF, HALF]
exports.N = Math.ceil((exports.HALF * 2) / exports.CELL) + 2; // +2 boundary
const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
/* Graphics-quality gate.
 *
 * These modules are bundled IIFEs with their own scope: the `g` alias used by
 * the bridge scripts is NOT visible here. `typeof g !== 'undefined'` therefore
 * evaluated to false on every call, so each PERFORMANCE candidate silently
 * fell back to its HIGH default and the mode switch changed nothing. Read the
 * flag off the real global instead, per call, so a mid-battle switch applies on
 * the next frame. */
const gfxFlag = (name, dflt) => {
    const root = typeof globalThis !== 'undefined' ? globalThis : (typeof window !== 'undefined' ? window : null);
    if (!root) return dflt;
    const v = root[name];
    return v === undefined ? dflt : v;
};

/* Render constants hoisted out of the per-frame path: the destination rect and
   the authored blur strings never change, so building them each call only
   allocated temporaries for the filter parser. Same values as before. */
const FLUID_OX = -exports.HALF - exports.CELL * 1.5;
const FLUID_OY = -exports.HALF - exports.CELL * 1.5;
const FLUID_SZ = exports.N * exports.CELL;
const FIRE_BLUR_WIDE = 'blur(7px)';
const FIRE_BLUR_CORE = 'blur(2.5px)';
const SMOKE_BLUR_WIDE = 'blur(6px)';

/* blackbody-ish LUT: t∈[0,1] → rgb (dark red → orange → yellow → white) */
exports.BB = new Uint8ClampedArray(256 * 3);
for (let i = 0; i < 256; i++) {
    const t = i / 255;
    const r = clamp(t * 3.2, 0, 1);
    const g = clamp(Math.pow(Math.max(0, t - 0.18), 1.25) * 1.9, 0, 1);
    const b = clamp(Math.pow(Math.max(0, t - 0.55), 2.1) * 2.6, 0, 1);
    exports.BB[i * 3] = Math.round(Math.pow(r, 0.9) * 255);
    exports.BB[i * 3 + 1] = Math.round(Math.pow(g, 1.05) * 255);
    exports.BB[i * 3 + 2] = Math.round(b * 255);
}
class Fluid {
    constructor() {
        this.n = exports.N;
        this.u = new Float32Array(exports.N * exports.N);
        this.v = new Float32Array(exports.N * exports.N);
        this.u0 = new Float32Array(exports.N * exports.N);
        this.v0 = new Float32Array(exports.N * exports.N);
        this.dens = new Float32Array(exports.N * exports.N);
        this.dens0 = new Float32Array(exports.N * exports.N);
        this.temp = new Float32Array(exports.N * exports.N);
        this.temp0 = new Float32Array(exports.N * exports.N);
        this.curl = new Float32Array(exports.N * exports.N);
        this.p = new Float32Array(exports.N * exports.N);
        this.div = new Float32Array(exports.N * exports.N);
        /** per-cell tint of the smoke (warm soot vs. cool dust) 0=dust 1=soot */
        this.soot = new Float32Array(exports.N * exports.N);
        // activity bounding box in cell coords, so idle regions cost nothing
        this.minI = exports.N;
        this.maxI = 0;
        this.minJ = exports.N;
        this.maxJ = 0;
        // One backing canvas per rendered layer. The frame draws smoke twice
        // (behind and in front of the fighters) with different alpha; with a
        // shared canvas the second draw had to re-rasterise the identical
        // field. Per-layer surfaces let the second draw reuse the first one's
        // pixels.
        this.cvsByLayer = Object.create(null);
        this.ctxByLayer = Object.create(null);
        this.imgByLayer = Object.create(null);
        this.stampByLayer = Object.create(null);
        this.frameMemo = Object.create(null);
        // Peak alpha per layer for the current epoch (see _peakAlphaCached).
        this.peakAlphaByLayer = Object.create(null);
        this.peakStampByLayer = Object.create(null);
        this.epoch = 0;
        this.cvs = this.layerCanvas('smoke');
        this.cctx = this.ctxByLayer.smoke;
        this.img = this.imgByLayer.smoke;
    }
    /**
     * Canvases are keyed by RENDER PASS, not merely by layer.
     *
     * `softPass` is the second smoke composite of the frame (drawn in front of
     * the fighters at alpha 0.45). The field cannot change between the two
     * smoke draws, so PERFORMANCE serves the second pass from the first pass's
     * already-rasterised surface: one raster + one putImageData per frame
     * instead of two, with identical pixels (the same field is sampled).
     */
    surfaceKey(layer) {
        return (layer === 'smoke' && this.softPass === true) ? 'smoke-soft' : layer;
    }
    layerCanvas(layer) {
        let cv = this.cvsByLayer[layer];
        if (!cv) {
            cv = document.createElement('canvas');
            cv.width = exports.N;
            cv.height = exports.N;
            this.cvsByLayer[layer] = cv;
            this.ctxByLayer[layer] = cv.getContext('2d');
            this.imgByLayer[layer] = this.ctxByLayer[layer].createImageData(exports.N, exports.N);
        }
        return cv;
    }
    /* ---------------------------------------------------------------- coords */
    toCell(x, y) {
        return { i: clamp(Math.round((x + exports.HALF) / exports.CELL) + 1, 1, exports.N - 2), j: clamp(Math.round((y + exports.HALF) / exports.CELL) + 1, 1, exports.N - 2) };
    }
    touch(i, j, r = 1) {
        this.minI = Math.min(this.minI, i - r);
        this.maxI = Math.max(this.maxI, i + r);
        this.minJ = Math.min(this.minJ, j - r);
        this.maxJ = Math.max(this.maxJ, j + r);
    }
    /* ---------------------------------------------------------------- sources */
    /** inject heat + soot in a soft disc (fire source) */
    addHeat(x, y, radius, heat, smoke = 0.4) {
        const { i: ci, j: cj } = this.toCell(x, y);
        const rc = Math.max(1, radius / exports.CELL);
        const r2 = rc * rc;
        const R = Math.ceil(rc);
        this.touch(ci, cj, R + 2);
        for (let j = -R; j <= R; j++)
            for (let i = -R; i <= R; i++) {
                const d2 = i * i + j * j;
                if (d2 > r2)
                    continue;
                const w = 1 - d2 / r2;
                const idx = (cj + j) * exports.N + (ci + i);
                if (idx < 0 || idx >= exports.N * exports.N)
                    continue;
                this.temp[idx] = Math.min(1.6, this.temp[idx] + heat * w);
                this.dens[idx] = Math.min(1.8, this.dens[idx] + smoke * w);
                this.soot[idx] = Math.min(1, this.soot[idx] + w);
            }
    }
    /** cold dust/smoke only */
    addSmoke(x, y, radius, amount, sootiness = 0.1) {
        const { i: ci, j: cj } = this.toCell(x, y);
        const rc = Math.max(1, radius / exports.CELL), r2 = rc * rc, R = Math.ceil(rc);
        this.touch(ci, cj, R + 2);
        for (let j = -R; j <= R; j++)
            for (let i = -R; i <= R; i++) {
                const d2 = i * i + j * j;
                if (d2 > r2)
                    continue;
                const w = 1 - d2 / r2;
                const idx = (cj + j) * exports.N + (ci + i);
                if (idx < 0 || idx >= exports.N * exports.N)
                    continue;
                this.dens[idx] = Math.min(1.8, this.dens[idx] + amount * w);
                this.soot[idx] = this.soot[idx] * 0.7 + sootiness * 0.3;
            }
    }
    /** directional force (punch wind, dash wake) */
    addForce(x, y, radius, fx, fy) {
        const { i: ci, j: cj } = this.toCell(x, y);
        const rc = Math.max(1, radius / exports.CELL), r2 = rc * rc, R = Math.ceil(rc);
        this.touch(ci, cj, R + 2);
        for (let j = -R; j <= R; j++)
            for (let i = -R; i <= R; i++) {
                const d2 = i * i + j * j;
                if (d2 > r2)
                    continue;
                const w = 1 - d2 / r2;
                const idx = (cj + j) * exports.N + (ci + i);
                if (idx < 0 || idx >= exports.N * exports.N)
                    continue;
                this.u[idx] += fx * w;
                this.v[idx] += fy * w;
            }
    }
    /** radial pressure burst (impact / explosion) */
    burst(x, y, radius, strength) {
        const { i: ci, j: cj } = this.toCell(x, y);
        const rc = Math.max(1, radius / exports.CELL), R = Math.ceil(rc);
        this.touch(ci, cj, R + 3);
        for (let j = -R; j <= R; j++)
            for (let i = -R; i <= R; i++) {
                const d = Math.hypot(i, j);
                if (d > rc || d < 0.01)
                    continue;
                const w = (1 - d / rc) * strength;
                const idx = (cj + j) * exports.N + (ci + i);
                if (idx < 0 || idx >= exports.N * exports.N)
                    continue;
                this.u[idx] += (i / d) * w;
                this.v[idx] += (j / d) * w * 0.7;
            }
    }
    /** swirl (cyclone) */
    vortex(x, y, radius, strength) {
        const { i: ci, j: cj } = this.toCell(x, y);
        const rc = Math.max(1, radius / exports.CELL), R = Math.ceil(rc);
        this.touch(ci, cj, R + 3);
        for (let j = -R; j <= R; j++)
            for (let i = -R; i <= R; i++) {
                const d = Math.hypot(i, j);
                if (d > rc || d < 0.5)
                    continue;
                const w = Math.sin((d / rc) * Math.PI) * strength;
                const idx = (cj + j) * exports.N + (ci + i);
                if (idx < 0 || idx >= exports.N * exports.N)
                    continue;
                this.u[idx] += (-j / d) * w;
                this.v[idx] += (i / d) * w;
                // inward suction
                this.u[idx] -= (i / d) * w * 0.25;
                this.v[idx] -= (j / d) * w * 0.25;
            }
    }
    /** sample velocity at world pos (for advecting detail particles) */
    velAt(x, y) {
        const fi = (x + exports.HALF) / exports.CELL + 1, fj = (y + exports.HALF) / exports.CELL + 1;
        const i0 = clamp(Math.floor(fi), 1, exports.N - 3), j0 = clamp(Math.floor(fj), 1, exports.N - 3);
        const s = fi - i0, t = fj - j0;
        const a = j0 * exports.N + i0;
        const lerp2 = (f) => (f[a] * (1 - s) + f[a + 1] * s) * (1 - t) + (f[a + exports.N] * (1 - s) + f[a + exports.N + 1] * s) * t;
        return { vx: lerp2(this.u) * exports.CELL, vy: lerp2(this.v) * exports.CELL };
    }
    tempAt(x, y) {
        const { i, j } = this.toCell(x, y);
        return this.temp[j * exports.N + i];
    }
    /* ---------------------------------------------------------------- solver */
    setBnd(f) {
        const n = exports.N;
        for (let i = 1; i < n - 1; i++) {
            f[i] = f[n + i];
            f[(n - 1) * n + i] = f[(n - 2) * n + i];
            f[i * n] = f[i * n + 1];
            f[i * n + n - 1] = f[i * n + n - 2];
        }
    }
    advect(d, d0, u, v, dt, i0b, i1b, j0b, j1b) {
        const n = exports.N;
        for (let j = j0b; j <= j1b; j++) {
            for (let i = i0b; i <= i1b; i++) {
                const idx = j * n + i;
                let x = i - dt * u[idx], y = j - dt * v[idx];
                if (x < 0.5)
                    x = 0.5;
                if (x > n - 1.5)
                    x = n - 1.5;
                if (y < 0.5)
                    y = 0.5;
                if (y > n - 1.5)
                    y = n - 1.5;
                const ii = x | 0, jj = y | 0;
                const s1 = x - ii, s0 = 1 - s1, t1 = y - jj, t0 = 1 - t1;
                const a = jj * n + ii;
                d[idx] = s0 * (t0 * d0[a] + t1 * d0[a + n]) + s1 * (t0 * d0[a + 1] + t1 * d0[a + n + 1]);
            }
        }
    }
    project(i0b, i1b, j0b, j1b) {
        const n = exports.N, u = this.u, v = this.v, p = this.p, div = this.div;
        for (let j = j0b; j <= j1b; j++)
            for (let i = i0b; i <= i1b; i++) {
                const idx = j * n + i;
                div[idx] = -0.5 * (u[idx + 1] - u[idx - 1] + v[idx + n] - v[idx - n]);
                p[idx] = 0;
            }
        for (let k = 0; k < 14; k++) {
            for (let j = j0b; j <= j1b; j++)
                for (let i = i0b; i <= i1b; i++) {
                    const idx = j * n + i;
                    p[idx] = (div[idx] + p[idx - 1] + p[idx + 1] + p[idx - n] + p[idx + n]) * 0.25;
                }
        }
        for (let j = j0b; j <= j1b; j++)
            for (let i = i0b; i <= i1b; i++) {
                const idx = j * n + i;
                u[idx] -= 0.5 * (p[idx + 1] - p[idx - 1]);
                v[idx] -= 0.5 * (p[idx + n] - p[idx - n]);
            }
    }
    step(dt) {
        // decay the activity box toward the live region each frame
        const n = exports.N;
        if (this.maxI < this.minI)
            return; // nothing active
        const i0b = clamp(this.minI, 1, n - 2), i1b = clamp(this.maxI, 1, n - 2);
        const j0b = clamp(this.minJ, 1, n - 2), j1b = clamp(this.maxJ, 1, n - 2);
        const u = this.u, v = this.v, t = this.temp, d = this.dens;
        // forces: buoyancy (hot rises → -y), gravity on heavy smoke, vorticity confinement
        for (let j = j0b; j <= j1b; j++)
            for (let i = i0b; i <= i1b; i++) {
                const idx = j * n + i;
                v[idx] -= (t[idx] * 24 - d[idx] * 1.2) * dt;
                // curl magnitude
                this.curl[idx] = Math.abs(0.5 * (u[idx + n] - u[idx - n] - v[idx + 1] + v[idx - 1]));
            }
        for (let j = j0b + 1; j <= j1b - 1; j++)
            for (let i = i0b + 1; i <= i1b - 1; i++) {
                const idx = j * n + i;
                const dx = this.curl[idx + 1] - this.curl[idx - 1];
                const dy = this.curl[idx + n] - this.curl[idx - n];
                const len = Math.hypot(dx, dy) + 1e-5;
                const w = 0.5 * (u[idx + n] - u[idx - n] - v[idx + 1] + v[idx - 1]);
                const eps = 3.2 * dt;
                u[idx] += (dy / len) * w * eps;
                v[idx] -= (dx / len) * w * eps;
            }
        // velocity advect + project
        this.u0.set(u);
        this.v0.set(v);
        this.advect(u, this.u0, this.u0, this.v0, dt * 1.0, i0b, i1b, j0b, j1b);
        this.advect(v, this.u0, this.u0, this.v0, dt * 1.0, i0b, i1b, j0b, j1b);
        this.setBnd(u);
        this.setBnd(v);
        this.project(i0b, i1b, j0b, j1b);
        // scalar advect
        this.dens0.set(d);
        this.temp0.set(t);
        this.advect(d, this.dens0, u, v, dt, i0b, i1b, j0b, j1b);
        this.advect(t, this.temp0, u, v, dt, i0b, i1b, j0b, j1b);
        // dissipation & combustion coupling; track the live region
        let nMinI = n, nMaxI = 0, nMinJ = n, nMaxJ = 0;
        const tDecay = Math.exp(-2.6 * dt), dDecay = Math.exp(-0.55 * dt), vDecay = Math.exp(-0.9 * dt);
        for (let j = j0b; j <= j1b; j++)
            for (let i = i0b; i <= i1b; i++) {
                const idx = j * n + i;
                t[idx] *= tDecay;
                // fire consumes soot, dust persists
                d[idx] *= dDecay * (1 - clamp(t[idx] * 0.35, 0, 0.6));
                u[idx] *= vDecay;
                v[idx] *= vDecay;
                if (t[idx] < 0.004)
                    t[idx] = 0;
                if (d[idx] < 0.004)
                    d[idx] = 0;
                if (t[idx] > 0 || d[idx] > 0 || Math.abs(u[idx]) + Math.abs(v[idx]) > 0.05) {
                    if (i < nMinI)
                        nMinI = i;
                    if (i > nMaxI)
                        nMaxI = i;
                    if (j < nMinJ)
                        nMinJ = j;
                    if (j > nMaxJ)
                        nMaxJ = j;
                }
            }
        this.minI = nMinI - 2;
        this.maxI = nMaxI + 2;
        this.minJ = nMinJ - 2;
        this.maxJ = nMaxJ + 2;
        // Field changed: cached per-layer rasters are stale.
        this.epoch++;
    }
    /* ---------------------------------------------------------------- render */
    /** write fire (emission) + smoke into the ImageData then blit to world */
    draw(ctx, layer) {
        if (this.maxI < this.minI)
            return;
        const n = exports.N;
        const i0b = clamp(this.minI, 0, n - 1), i1b = clamp(this.maxI, 0, n - 1);
        const j0b = clamp(this.minJ, 0, n - 1), j1b = clamp(this.maxJ, 0, n - 1);
        // Which backing surface this pass paints.
        //   HIGH          -> one surface per layer (two independent rasters).
        //   PERFORMANCE   -> the soft (second) smoke pass shares the first
        //                    pass's surface; the field is identical between the
        //                    two calls, so this is one raster per frame.
        const softMode = (gfxFlag('APEX_GRAPHICS_FLUID_SOFT_ALPHA', 1) === 0);
        // surfaceKey() gives the soft pass its OWN surface in HIGH ('smoke-soft')
        // and lets it share the first pass's surface in PERFORMANCE. Keying on
        // the bare layer name would collapse both passes onto one surface and
        // silently remove the authored double-composite.
        const paintKey = (layer === 'smoke' && this.softPass === true && softMode)
            ? layer
            : this.surfaceKey(layer);
        const cvs = this.layerCanvas(paintKey);
        const cctx = this.ctxByLayer[paintKey];
        const img = this.imgByLayer[paintKey];
        const stampKey = paintKey + ':' + this.epoch + ':' + i0b + ',' + i1b + ',' + j0b + ',' + j1b;
        // ---- rasterise the field into this layer's canvas (memoised) --------
        // render() is called twice per frame for smoke; the field cannot change
        // between those calls, so the second call reuses the first's pixels
        // instead of re-running the per-cell loop and putImageData.
        let wrote = this.frameMemo[stampKey];
        if (wrote === undefined) {
            const px = img.data;
            // Clear only the previously written rectangle plus this frame's, in
            // full rows: the cell loop below can only touch [i0b..i1b] within
            // [j0b..j1b], so everything else is already transparent. This keeps
            // the canvas byte-identical to a full clear without zeroing the
            // whole N*N buffer every call.
            const prev = this.stampByLayer[paintKey];
            if (prev) {
                const pj0 = Math.min(prev[2], j0b), pj1 = Math.max(prev[3], j1b);
                const pi0 = Math.min(prev[0], i0b), pi1 = Math.max(prev[1], i1b);
                for (let j = pj0; j <= pj1; j++)
                    px.fill(0, (j * n + pi0) * 4, (j * n + pi1 + 1) * 4);
            }
            else {
                px.fill(0);
            }
            this.stampByLayer[paintKey] = [i0b, i1b, j0b, j1b];
            let any = 0;
            let peak8 = 0;
            if (layer === 'fire') {
                for (let j = j0b; j <= j1b; j++)
                    for (let i = i0b; i <= i1b; i++) {
                        const idx = j * n + i, o = idx * 4;
                        const t = this.temp[idx];
                        if (t < 0.02)
                            continue;
                        const e = clamp(Math.pow(t, 1.15), 0, 1);
                        const li = Math.min(255, (e * 255) | 0) * 3;
                        px[o] = exports.BB[li];
                        px[o + 1] = exports.BB[li + 1];
                        px[o + 2] = exports.BB[li + 2];
                        const af = Math.min(255, (clamp(t * 1.7, 0, 1) * 255) | 0);
                        px[o + 3] = af;
                        if (af > peak8) peak8 = af;
                        any = 1;
                    }
            }
            else {
                for (let j = j0b; j <= j1b; j++)
                    for (let i = i0b; i <= i1b; i++) {
                        const idx = j * n + i, o = idx * 4;
                        const d = this.dens[idx];
                        if (d < 0.02)
                            continue;
                        const t = this.temp[idx];
                        const s = this.soot[idx];
                        // dust: warm khaki; soot: near black. Lit from within by temperature.
                        const lit = clamp(t * 1.6, 0, 1);
                        px[o] = clamp(lerp(132, 36, s) + lit * 190, 0, 255);
                        px[o + 1] = clamp(lerp(120, 32, s) + lit * 95, 0, 255);
                        px[o + 2] = clamp(lerp(100, 30, s) + lit * 20, 0, 255);
                        const a8 = Math.min(255, (clamp(d * 0.78, 0, 0.92) * 255) | 0);
                        px[o + 3] = a8;
                        if (a8 > peak8) peak8 = a8;
                        any = 1;
                    }
            }
            cctx.putImageData(img, 0, 0);
            wrote = any;
            this.frameMemo[stampKey] = wrote;
            // Peak 8-bit alpha is accumulated by the same pass that writes the
            // pixels, so PERFORMANCE's soft-pass decision costs nothing extra.
            this.peakAlphaByLayer[paintKey] = peak8;
            this.peakStampByLayer[paintKey] = stampKey;
            // Keep the memo bounded: it is keyed by epoch, so it grows during a
            // long fight. A handful of entries per frame is all that is live.
            if (this.size === undefined) this.size = 0;
            this.size++;
            if (this.size > 64) { this.frameMemo = Object.create(null); this.size = 1; this.frameMemo[stampKey] = wrote; }
        }
        // A layer with no cell above its visibility threshold renders zero alpha.
        // Blurring and compositing a fully transparent 1896px surface produced
        // identical pixels, so skip those passes outright.
        if (!wrote)
            return;
        // PERFORMANCE candidate P2: the smoke layer is composited twice per
        // frame (behind the fighters, then again in front at alpha 0.45). The
        // second blend only changes a pixel when 0.45 * sourceAlpha exceeds one
        // 8-bit step, i.e. when the field is dense. While the field is sparse
        // the pass is a full-surface blend for (mostly) nothing, so it is
        // skipped and the single remaining pass keeps the silhouette.
        // HIGH leaves APEX_GRAPHICS_FLUID_SOFT_ALPHA at 1 → always drawn.
        if (layer === 'smoke' && this.softPass === true) {
            const soft = gfxFlag('APEX_GRAPHICS_FLUID_SOFT_ALPHA', 1);
            // The second pass is drawn at host alpha 0.45 over the already
            // composited first pass. Its strongest possible effect is therefore
            // 0.45 * (this layer's peak alpha as an 8-bit step). Below one
            // quantisation step the pass cannot produce a resolvable difference
            // anywhere, so it is skipped; above it, it is drawn exactly as in
            // HIGH. This is a measured bound, not a tuned percentage.
            if (soft === 0) {
                // Read the peak recorded by the rasterisation pass for THIS
                // layer/epoch. The earlier version recomputed it by scanning
                // the grid again on every call — including on memo hits — which
                // made PERFORMANCE measurably SLOWER than HIGH on BOXE
                // (p50 21.5 -> 30.3 ms, reproduced 3/3). The value is the same
                // number, obtained for free.
                const peakAlpha = this._peakAlphaCached(paintKey);
                if (peakAlpha * 0.45 < 1) {
                    this.softPass = false;
                    return;
                }
            }
        }
        this.softPass = false;
        ctx.save();
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        if (layer === 'fire')
            ctx.globalCompositeOperation = 'lighter';
        // cell (i,j) centre is at world ((i-1)*CELL - HALF, (j-1)*CELL - HALF)
        ctx.filter = layer === 'fire' ? FIRE_BLUR_WIDE : SMOKE_BLUR_WIDE;
        ctx.drawImage(cvs, FLUID_OX, FLUID_OY, FLUID_SZ, FLUID_SZ);
        if (layer === 'fire') {
            // tighter hot core on top of the soft glow
            ctx.globalAlpha = 0.55;
            ctx.filter = FIRE_BLUR_CORE;
            ctx.drawImage(cvs, FLUID_OX, FLUID_OY, FLUID_SZ, FLUID_SZ);
        }
        ctx.filter = 'none';
        ctx.restore();
    }
    /**
     * Peak 8-bit alpha this smoke layer can produce in the live region.
     *
     * Mirrors the density→alpha mapping in draw() exactly:
     *   alpha8 = min(255, clamp(d * 0.78, 0, 0.92) * 255)
     * so the value is the true maximum destination contribution of the layer,
     * not an estimate. Early-exits at full opacity.
     */
    /**
     * Peak 8-bit alpha for `layer` as recorded by the last rasterisation of the
     * current epoch. Falls back to a direct scan only when no raster exists yet
     * (first call of a frame before draw() has written pixels).
     */
    _peakAlphaCached(layer) {
        const key = layer + ':' + this.epoch;
        const stamp = this.peakStampByLayer && this.peakStampByLayer[layer];
        if (stamp && stamp.indexOf(key + ':') === 0) return this.peakAlphaByLayer[layer] || 0;
        return this._peakAlpha8();
    }
    _peakAlpha8() {
        if (this.maxI < this.minI)
            return 0;
        const n = exports.N;
        const i0b = clamp(this.minI, 0, n - 1), i1b = clamp(this.maxI, 0, n - 1);
        const j0b = clamp(this.minJ, 0, n - 1), j1b = clamp(this.maxJ, 0, n - 1);
        let peak = 0;
        for (let j = j0b; j <= j1b; j++)
            for (let i = i0b; i <= i1b; i++) {
                const idx = j * n + i;
                const d = this.dens[idx];
                if (d < 0.02)
                    continue;
                const a8 = Math.min(255, (clamp(d * 0.78, 0, 0.92) * 255) | 0);
                if (a8 > peak) {
                    peak = a8;
                    if (peak >= 235) return peak;
                }
            }
        return peak;
    }
    /** hot regions in world space for the heat-haze pass */
    hotRegions() {
        const out = [];
        if (this.maxI < this.minI)
            return out;
        const n = exports.N, step = 4;
        for (let j = clamp(this.minJ, 1, n - 2); j <= clamp(this.maxJ, 1, n - 2); j += step) {
            for (let i = clamp(this.minI, 1, n - 2); i <= clamp(this.maxI, 1, n - 2); i += step) {
                let m = 0;
                for (let jj = 0; jj < step; jj++)
                    for (let ii = 0; ii < step; ii++) {
                        const t = this.temp[(j + jj) * n + i + ii] || 0;
                        if (t > m)
                            m = t;
                    }
                if (m > 0.22)
                    out.push({ x: (i - 1) * exports.CELL - exports.HALF, y: (j - 1) * exports.CELL - exports.HALF, w: step * exports.CELL, h: step * exports.CELL, heat: m });
                if (out.length > 40)
                    return out;
            }
        }
        return out;
    }
    clear() {
        this.u.fill(0);
        this.v.fill(0);
        this.dens.fill(0);
        this.temp.fill(0);
        this.soot.fill(0);
        this.epoch++;
        this.frameMemo = Object.create(null);
        this.stampByLayer = Object.create(null);
        this.peakAlphaByLayer = Object.create(null);
        this.peakStampByLayer = Object.create(null);
        this.minI = exports.N;
        this.maxI = 0;
        this.minJ = exports.N;
        this.maxJ = 0;
    }
}
exports.Fluid = Fluid;
function lerp(a, b, t) { return a + (b - a) * t; }

},
'src/game/fx/fire.ts': function(module,exports,require){
"use strict";
/* Procedural fire on top of the fluid field.
   The fluid gives bulk motion/soft glow; this layer adds the fine structure:
   - flame tongues: teardrop masks × noise, advected by fluid velocity, own
     buoyancy, cooling → shrinking → smoke hand-off into the density field
   - embers that cool through the blackbody ramp and flutter in the flow
   - every emitter injects heat + soot into the solver each frame. */
Object.defineProperty(exports, "__esModule", { value: true });
exports.Fire = void 0;
const fluid_1 = require("./fluid");
const TAU = Math.PI * 2;
const rand = (a, b) => a + Math.random() * (b - a);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const SHAPES = 4;
const TEMPS = 10;
/* tongue textures: teardrop mask with noise-eaten edges, tinted along the blackbody ramp */
function buildTongues() {
    const out = [];
    const S = 64;
    const rnd = (seed) => { let s = seed >>> 0 || 1; return () => (s = (s * 1664525 + 1013904223) >>> 0) / 4294967296; };
    for (let sh = 0; sh < SHAPES; sh++) {
        const r = rnd(97 + sh * 31);
        const mask = new Float32Array(S * S);
        // random lobes for a torn edge
        const lobes = Array.from({ length: 5 }, () => ({ a: r() * TAU, f: 2 + r() * 4, amp: 0.12 + r() * 0.16 }));
        for (let y = 0; y < S; y++)
            for (let x = 0; x < S; x++) {
                const px = (x / S - 0.5) * 2, py = (y / S - 0.5) * 2;
                const ang = Math.atan2(py, px);
                let edge = 0.78;
                for (const l of lobes)
                    edge += Math.sin(ang * l.f + l.a) * l.amp * (0.6 + 0.4 * Math.abs(py));
                // teardrop: narrower at top (−y), rounder at bottom
                const stretch = py < 0 ? 1 + (-py) * 0.9 : 1;
                const d = Math.hypot(px * stretch, py) / edge;
                let v = clamp(1 - d, 0, 1);
                v = Math.pow(v, 0.55);
                mask[y * S + x] = v;
            }
        const row = [];
        for (let ti = 0; ti < TEMPS; ti++) {
            const c = document.createElement('canvas');
            c.width = c.height = S;
            const ctx = c.getContext('2d');
            const img = ctx.createImageData(S, S);
            const t = ti / (TEMPS - 1);
            for (let i = 0; i < S * S; i++) {
                const m = mask[i];
                if (m <= 0)
                    continue;
                // core is hotter than the rim
                const tt = clamp(t * (0.55 + m * 0.75), 0, 1);
                const li = ((tt * 255) | 0) * 3;
                const o = i * 4;
                img.data[o] = fluid_1.BB[li];
                img.data[o + 1] = fluid_1.BB[li + 1];
                img.data[o + 2] = fluid_1.BB[li + 2];
                img.data[o + 3] = (m * 255 * (0.35 + t * 0.65)) | 0;
            }
            ctx.putImageData(img, 0, 0);
            row.push(c);
        }
        out.push(row);
    }
    return out;
}
class Fire {
    constructor(fluid) {
        this.fluid = fluid;
        this.emitters = [];
        this.tongues = [];
        this.embers = [];
        this.tex = null;
        this.t = 0;
    }
    textures() { return this.tex ?? (this.tex = buildTongues()); }
    /** fire column: w = base width, h = nominal height, life s, power scales heat */
    column(x, y, w, h, life, power = 1) {
        this.emitters.push({ x, y, w, h, life, max: life, power, seed: rand(0, 100) });
        // initial flash of heat so the fluid responds immediately
        this.fluid.addHeat(x, y - h * 0.15, w * 0.6, 1.1 * power, 0.5);
        this.fluid.burst(x, y, w * 0.9, 2.2 * power);
        for (let i = 0; i < 8 * power; i++)
            this.spawnTongue(x + rand(-w * 0.35, w * 0.35), y - rand(0, h * 0.25), power, rand(-80, 80), -rand(120, 320) * power);
        for (let i = 0; i < 10 * power; i++)
            this.spawnEmber(x, y - h * 0.2, power);
        if (this.emitters.length > 48)
            this.emitters.shift();
    }
    /** short burst of flame (fire trail, explosion lick) */
    puff(x, y, size, vx = 0, vy = -120, power = 1) {
        this.fluid.addHeat(x, y, size * 0.9, 0.55 * power, 0.3);
        for (let i = 0; i < 3; i++)
            this.spawnTongue(x + rand(-size * 0.3, size * 0.3), y, power * 0.8, vx + rand(-50, 50), vy + rand(-60, 20), size * 0.5);
        for (let i = 0; i < 2; i++)
            this.spawnEmber(x, y, power * 0.6);
    }
    spawnTongue(x, y, power, vx, vy, size = rand(22, 42) * power) {
        if (this.tongues.length > 360)
            this.tongues.shift();
        this.tongues.push({
            x, y, vx, vy, rot: rand(-0.3, 0.3), vr: rand(-1.4, 1.4),
            temp: rand(0.82, 1), size, life: 0, max: rand(0.35, 0.7),
            shape: (Math.random() * SHAPES) | 0, seed: rand(0, 100),
        });
    }
    spawnEmber(x, y, power) {
        if (this.embers.length > 400)
            this.embers.shift();
        this.embers.push({
            x: x + rand(-14, 14), y, vx: rand(-60, 60), vy: -rand(90, 260) * power,
            temp: 1, size: rand(1.2, 3) * Math.sqrt(power), life: 0, max: rand(0.8, 1.9), seed: rand(0, 100),
        });
    }
    clear() { this.emitters = []; this.tongues = []; this.embers = []; }
    update(dt) {
        this.t += dt;
        const f = this.fluid;
        // emitters feed the solver and spawn detail
        for (let i = this.emitters.length - 1; i >= 0; i--) {
            const e = this.emitters[i];
            e.life -= dt;
            if (e.life <= 0) {
                this.emitters.splice(i, 1);
                continue;
            }
            const k = e.life / e.max;
            const env = Math.min(1, k * 3) * Math.min(1, (1 - k) * 6 + 0.35); // ramp in / out
            const flick = 0.85 + Math.sin(this.t * 29 + e.seed) * 0.1 + Math.sin(this.t * 17.3 + e.seed * 2) * 0.05;
            const heat = 0.9 * e.power * env * flick;
            f.addHeat(e.x + rand(-e.w * 0.2, e.w * 0.2), e.y - e.h * 0.08, e.w * 0.55, heat * dt * 9, 0.45 * dt * 9);
            // the column pulls air in at the base and pushes it up
            f.addForce(e.x, e.y - e.h * 0.1, e.w * 0.7, rand(-1, 1) * 2, -12 * e.power * env * dt * 6);
            const rate = (10 + e.power * 10) * env;
            if (Math.random() < rate * dt)
                this.spawnTongue(e.x + rand(-e.w * 0.4, e.w * 0.4), e.y - rand(0, e.h * 0.12), e.power * env, rand(-50, 50), -rand(140, 260) * (0.6 + e.power * 0.4), rand(18, 36) * (0.6 + e.power * 0.5) * (0.5 + env * 0.5));
            if (Math.random() < 6 * env * dt)
                this.spawnEmber(e.x + rand(-e.w * 0.3, e.w * 0.3), e.y - e.h * 0.3, e.power);
        }
        // tongues: advect with the air, rise, cool, hand their soot to the fluid
        for (let i = this.tongues.length - 1; i >= 0; i--) {
            const tg = this.tongues[i];
            tg.life += dt;
            const k = tg.life / tg.max;
            if (k >= 1) {
                f.addSmoke(tg.x, tg.y, tg.size * 0.8, 0.22, 0.85);
                this.tongues.splice(i, 1);
                continue;
            }
            const fv = f.velAt(tg.x, tg.y);
            tg.vx += (fv.vx * 3.2 - tg.vx) * (1 - Math.exp(-4 * dt)) + Math.sin(this.t * 9 + tg.seed) * 90 * dt;
            tg.vy += (fv.vy * 3.2 - tg.vy) * (1 - Math.exp(-2 * dt)) - 420 * dt * (1 - k);
            tg.x += tg.vx * dt;
            tg.y += tg.vy * dt;
            tg.rot += tg.vr * dt;
            tg.temp = clamp(1 - k * 1.05, 0, 1);
            tg.size *= 1 + (k < 0.35 ? 1.6 : -0.9) * dt;
        }
        // embers
        for (let i = this.embers.length - 1; i >= 0; i--) {
            const em = this.embers[i];
            em.life += dt;
            const k = em.life / em.max;
            if (k >= 1) {
                this.embers.splice(i, 1);
                continue;
            }
            const fv = f.velAt(em.x, em.y);
            em.vx += (fv.vx * 4 - em.vx) * (1 - Math.exp(-2.5 * dt)) + Math.sin(this.t * 13 + em.seed) * 160 * dt;
            em.vy += (fv.vy * 4 - em.vy) * (1 - Math.exp(-1.5 * dt)) - 60 * dt;
            em.x += em.vx * dt;
            em.y += em.vy * dt;
            em.temp = clamp(1 - k * 0.9 + Math.sin(this.t * 40 + em.seed) * 0.12, 0, 1);
        }
    }
    draw(ctx) {
        const tex = this.textures();
        ctx.save();
        ctx.globalCompositeOperation = 'lighter';
        for (const tg of this.tongues) {
            const ti = clamp(Math.round(tg.temp * (TEMPS - 1)), 0, TEMPS - 1);
            const img = tex[tg.shape][ti];
            const k = tg.life / tg.max;
            const a = clamp(Math.min(1, k * 6) * (1 - k * k), 0, 1);
            const w = tg.size, h = tg.size * (1.35 + (1 - k) * 0.6);
            ctx.save();
            ctx.globalAlpha = a * 0.95;
            ctx.translate(tg.x, tg.y);
            // lean into the air flow
            ctx.rotate(Math.atan2(tg.vy, tg.vx) + Math.PI / 2 + tg.rot * 0.35);
            ctx.drawImage(img, -w / 2, -h * 0.72, w, h);
            ctx.restore();
        }
        // embers: blackbody dots with a soft halo
        for (const em of this.embers) {
            const li = ((em.temp * 255) | 0) * 3;
            const r = fluid_1.BB[li], g = fluid_1.BB[li + 1], b = fluid_1.BB[li + 2];
            ctx.globalAlpha = 0.9 * em.temp + 0.05;
            ctx.fillStyle = `rgb(${r},${g},${b})`;
            ctx.beginPath();
            ctx.arc(em.x, em.y, em.size, 0, TAU);
            ctx.fill();
            ctx.globalAlpha = 0.28 * em.temp;
            ctx.beginPath();
            ctx.arc(em.x, em.y, em.size * 3.2, 0, TAU);
            ctx.fill();
        }
        ctx.restore();
    }
}
exports.Fire = Fire;

},
'src/game/fx/lightning.ts': function(module,exports,require){
"use strict";
/* Procedural lightning.
   - stepped leader: the channel is grown segment by segment over a few ms
   - return stroke: when the leader connects, the whole channel flashes to
     peak brightness, then decays with 1–3 re-strikes (dart leaders)
   - fractal branching with tapering width and shorter life than the trunk
   - per-frame micro jitter on interior nodes, so the channel never freezes
   - corona: wide dim halo + coloured sheath + white core
   - surface crawl: after the strike, short arcs skitter over the target for
     a moment, regenerated every couple of frames (flicker) */
Object.defineProperty(exports, "__esModule", { value: true });
exports.Lightning = void 0;
const TAU = Math.PI * 2;
const rand = (a, b) => a + Math.random() * (b - a);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
function buildChannel(ax, ay, bx, by, rough, depth, width, parentT) {
    let pts = [{ x: ax, y: ay }, { x: bx, y: by }];
    const iters = depth === 0 ? 5 : 4;
    for (let d = 0; d < iters; d++) {
        const next = [];
        const r = rough * Math.pow(0.55, d);
        for (let i = 0; i < pts.length - 1; i++) {
            const a = pts[i], b = pts[i + 1];
            const len = Math.hypot(b.x - a.x, b.y - a.y);
            const nx = -(b.y - a.y) / (len || 1), ny = (b.x - a.x) / (len || 1);
            const off = rand(-r, r) * len;
            next.push(a, { x: (a.x + b.x) / 2 + nx * off, y: (a.y + b.y) / 2 + ny * off });
        }
        next.push(pts[pts.length - 1]);
        pts = next;
    }
    let totalLen = 0;
    for (let i = 1; i < pts.length; i++)
        totalLen += Math.hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y);
    return {
        nodes: pts.map((p, i) => ({ x: p.x, y: p.y, bx: p.x, by: p.y, jit: i === 0 || i === pts.length - 1 ? 0 : 1 })),
        width, depth, totalLen, parentT,
    };
}
class Lightning {
    constructor() {
        this.strikes = [];
        this.crawls = [];
        this.t = 0;
    }
    /**
     * @param opts.branches number of primary branches
     * @param opts.life     total visible time
     * @param opts.crawl    radius of surface arcs at the endpoint (0 = none)
     */
    strike(x1, y1, x2, y2, color = '#ffd23c', width = 3, opts = {}) {
        const branches = opts.branches ?? 2;
        const life = opts.life ?? 0.32;
        const trunk = buildChannel(x1, y1, x2, y2, opts.rough ?? 0.34, 0, width, 0);
        const channels = [trunk];
        const spawnBranches = (parent, count, depth) => {
            for (let i = 0; i < count; i++) {
                const ti = clamp(Math.floor(rand(0.15, 0.85) * (parent.nodes.length - 1)), 1, parent.nodes.length - 2);
                const s = parent.nodes[ti], nx = parent.nodes[ti + 1];
                const dirA = Math.atan2(nx.y - s.y, nx.x - s.x) + rand(-1, 1) * (0.5 + depth * 0.2);
                const l = parent.totalLen * rand(0.18, 0.42) * Math.pow(0.7, depth);
                const ch = buildChannel(s.x, s.y, s.x + Math.cos(dirA) * l, s.y + Math.sin(dirA) * l, 0.4, depth + 1, parent.width * 0.5, ti / (parent.nodes.length - 1));
                channels.push(ch);
                if (depth < 2 && Math.random() < 0.6)
                    spawnBranches(ch, 1, depth + 1);
            }
        };
        spawnBranches(trunk, branches, 0);
        const restrikes = [];
        const nRe = Math.random() < 0.7 ? 1 + ((Math.random() * 2) | 0) : 0;
        for (let i = 0; i < nRe; i++)
            restrikes.push(rand(0.07, life * 0.75));
        this.strikes.push({ channels, color, width, age: 0, life, leaderT: 0, restrikes, endX: x2, endY: y2, crawlR: opts.crawl ?? 0 });
        if (this.strikes.length > 40)
            this.strikes.shift();
    }
    /** electrical arcs skittering over a surface */
    crawl(x, y, r, color, life = 0.4) {
        this.crawls.push({ x, y, r, color, age: 0, life, arcs: [], nextGen: 0 });
        if (this.crawls.length > 24)
            this.crawls.shift();
    }
    clear() { this.strikes = []; this.crawls = []; }
    update(dt) {
        this.t += dt;
        for (let i = this.strikes.length - 1; i >= 0; i--) {
            const s = this.strikes[i];
            s.age += dt;
            if (s.age > s.life) {
                this.strikes.splice(i, 1);
                continue;
            }
            // leader propagation ~45 ms, then connected
            const wasConnected = s.leaderT >= 1;
            s.leaderT = clamp(s.age / 0.045, 0, 1);
            if (!wasConnected && s.leaderT >= 1 && s.crawlR > 0)
                this.crawl(s.endX, s.endY, s.crawlR, s.color, 0.35);
            // micro jitter: interior nodes vibrate, amplitude falls over life
            const amp = (1 - s.age / s.life) * 2.2;
            for (const ch of s.channels)
                for (const n of ch.nodes) {
                    if (!n.jit)
                        continue;
                    n.x = n.bx + rand(-amp, amp) * ch.width;
                    n.y = n.by + rand(-amp, amp) * ch.width;
                }
        }
        for (let i = this.crawls.length - 1; i >= 0; i--) {
            const c = this.crawls[i];
            c.age += dt;
            if (c.age > c.life) {
                this.crawls.splice(i, 1);
                continue;
            }
            c.nextGen -= dt;
            if (c.nextGen <= 0) {
                c.nextGen = rand(0.025, 0.05);
                c.arcs = [];
                const n = 3 + ((Math.random() * 4) | 0);
                for (let k = 0; k < n; k++) {
                    const a0 = rand(0, TAU);
                    const pts = [];
                    let a = a0, rr = c.r * rand(0.7, 1.05);
                    const steps = 4 + ((Math.random() * 4) | 0);
                    for (let q = 0; q <= steps; q++) {
                        pts.push({ x: c.x + Math.cos(a) * rr * (1 + rand(-0.12, 0.12)), y: c.y + Math.sin(a) * rr * 0.75 * (1 + rand(-0.12, 0.12)) });
                        a += rand(0.15, 0.4);
                    }
                    pts.push({ x: c.x + Math.cos(a + 0.3) * rr * rand(0.3, 0.9), y: c.y + Math.sin(a + 0.3) * rr * 0.75 * rand(0.3, 0.9) });
                    c.arcs.push(pts);
                }
            }
        }
    }
    /** brightness envelope: leader dim → return stroke peak → decay with re-strikes */
    intensity(s) {
        if (s.leaderT < 1)
            return 0.35 + s.leaderT * 0.2;
        const k = (s.age - 0.045) / Math.max(0.01, s.life - 0.045);
        let v = Math.pow(1 - k, 1.6) * (0.55 + 0.45 * Math.exp(-k * 9));
        for (const rt of s.restrikes) {
            const d = s.age - rt;
            if (d >= 0 && d < 0.06)
                v = Math.max(v, 1 - d / 0.06);
        }
        // high-frequency flicker
        v *= 0.86 + Math.sin(this.t * 190 + s.endX) * 0.08 + (Math.random() < 0.15 ? -0.3 : 0);
        return clamp(v, 0, 1);
    }
    draw(ctx) {
        ctx.save();
        ctx.globalCompositeOperation = 'lighter';
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        for (const s of this.strikes) {
            const I = this.intensity(s);
            if (I <= 0.01)
                continue;
            for (const ch of s.channels) {
                // leader: trunk reveals progressively, branches only once the leader has passed their root
                let reveal = 1;
                if (s.leaderT < 1) {
                    if (ch.depth === 0)
                        reveal = s.leaderT;
                    else if (s.leaderT < ch.parentT)
                        continue;
                    else
                        reveal = clamp((s.leaderT - ch.parentT) / 0.25, 0, 1);
                }
                const last = Math.max(1, Math.floor(reveal * (ch.nodes.length - 1)));
                const branchFade = ch.depth === 0 ? 1 : clamp(1 - (s.age / s.life) * (1 + ch.depth * 0.6), 0, 1);
                if (branchFade <= 0)
                    continue;
                const w = ch.width;
                const passes = [
                    [w * 10, s.color, 0.07],
                    [w * 4.2, s.color, 0.22],
                    [w * 1.6, s.color, 0.85],
                    [w * 0.6, '#ffffff', 1],
                ];
                for (const [pw, col, a] of passes) {
                    ctx.globalAlpha = I * a * branchFade;
                    ctx.strokeStyle = col;
                    ctx.beginPath();
                    for (let i = 0; i <= last; i++) {
                        const n = ch.nodes[i];
                        // taper toward the tip
                        if (i === 0)
                            ctx.moveTo(n.x, n.y);
                        else
                            ctx.lineTo(n.x, n.y);
                    }
                    ctx.lineWidth = pw * (0.6 + 0.4 * (1 - last / ch.nodes.length)) + 0.3;
                    ctx.stroke();
                }
            }
        }
        for (const c of this.crawls) {
            const k = 1 - c.age / c.life;
            for (const pts of c.arcs) {
                for (const [pw, col, a] of [[5, c.color, 0.18], [2, c.color, 0.8], [0.8, '#ffffff', 1]]) {
                    ctx.globalAlpha = k * a;
                    ctx.strokeStyle = col;
                    ctx.lineWidth = pw;
                    ctx.beginPath();
                    pts.forEach((p, i) => (i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y)));
                    ctx.stroke();
                }
            }
        }
        ctx.restore();
    }
    /** points that should emit light this frame (for ground pools) */
    lights() {
        const out = [];
        for (const s of this.strikes) {
            const I = this.intensity(s);
            if (I > 0.2)
                out.push({ x: s.endX, y: s.endY, i: I, color: s.color });
        }
        return out;
    }
}
exports.Lightning = Lightning;

},
'src/game/vfx.ts': function(module,exports,require){
"use strict";
/* Realistic effect layer. Every element is drawn from procedural textures and
   simulated, not hand-drawn shapes:
     - smoke: fBm billow textures, curl drift, buoyancy, growth, hot → cool
     - sparks: velocity streaks with gravity, ground bounce and light head
     - embers: flickering rising motes that light the air
     - trails: tapered ribbon strips (real motion blur, not thick lines)
     - bolts: tapering branching lightning with core + halo + flicker
     - light pools: additive ground bounce light under every bright source
*/
Object.defineProperty(exports, "__esModule", { value: true });
exports.VFX = void 0;
const textures_1 = require("./fx/textures");
const TAU = Math.PI * 2;
const rand = (a, b) => a + Math.random() * (b - a);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const easeOut = (t) => 1 - Math.pow(1 - t, 3);
class VFX {
    constructor() {
        this.impacts = [];
        this.wedges = [];
        this.slashes = [];
        this.flashes = [];
        this.pillars = [];
        this.spikes = [];
        this.bolts = [];
        this.streaks = [];
        this.shocks = [];
        this.pools = [];
        this.scorches = [];
        this.smokes = [];
        this.sparks = [];
        this.embers = [];
        this.ghosts = [];
        this.trails = new Map();
        this.screen = {
            flashColor: '#ffffff', flashT: 0, flashMax: 1, flashAlpha: 0.5,
            dark: 0, darkTarget: 0,
            letter: 0, letterTarget: 0,
            speedT: 0, speedColor: '#ffffff',
        };
        this.t = 0;
    }
    /* ------------------------------------------------------------ textures */
    glow(color) { return (0, textures_1.glowTex)(color); }
    soft(color) { return (0, textures_1.softTex)(color); }
    smoke(color, seed) { return (0, textures_1.smokeTex)(color, seed); }
    spark(color) { return (0, textures_1.sparkTex)(color); }
    /* ------------------------------------------------------------ spawners */
    /** Contact light and physically moving sparks. No graphic star or fan. */
    impact(x, y, angle, color, size = 1) {
        this.flash(x, y, 44 * size, color, 0.11);
        this.pool(x, y + 25, 52 * size, color, 0.16);
        const cnt = Math.round(6 + size * 6);
        for (let i = 0; i < cnt; i++) {
            const a = angle + rand(-1.2, 1.2);
            this.addSpark(x + Math.cos(a) * 12, y + Math.sin(a) * 12, a, rand(380, 980) * (0.5 + size * 0.4), i % 4 === 0 ? '#ffffff' : color, rand(1.4, 3.4) * size, rand(0.22, 0.5));
        }
    }
    wedge(x, y, angle, color, r1, spread = 0.4, life = 0.18) {
        this.wedges.push({ x, y, angle, r0: 16, r1, spread, color, life, max: life });
        if (this.wedges.length > 70)
            this.wedges.shift();
    }
    slash(x, y, angle, r, color, o = {}) {
        const life = o.life ?? 0.24;
        this.slashes.push({ x, y, angle, r, width: o.width ?? 14, span: o.span ?? 2, color, life, max: life, dir: o.dir ?? 1 });
        if (this.slashes.length > 60)
            this.slashes.shift();
    }
    flash(x, y, r, color, life = 0.18, core = true) {
        this.flashes.push({ x, y, r, color, life, max: life, core });
        if (this.flashes.length > 200)
            this.flashes.shift();
    }
    pillar(x, y, color, w = 60, h = 260, life = 0.45) {
        this.pillars.push({ x, y, w, h, color, life, max: life, seed: rand(0, 100) });
    }
    spike(x, y, size, color = '#c58a45') {
        this.spikes.push({ x, y, size, lean: rand(-0.35, 0.35), color, life: 0.6, max: 0.6 });
        if (this.spikes.length > 130)
            this.spikes.shift();
    }
    shock(x, y, r1, color, width = 10, life = 0.42, squash = 0.62) {
        this.shocks.push({ x, y, r: 6, r1, color, width, life, max: life, squash });
    }
    /** additive bounce-light on the floor plane under a bright source */
    pool(x, y, rx, color, life = 0.3, ryScale = 0.42) {
        this.pools.push({ x, y, rx, ry: rx * ryScale, color, life, max: life });
        if (this.pools.length > 90)
            this.pools.shift();
    }
    scorchMark(x, y, r, life = 6) {
        this.scorches.push({ x, y, r, rot: rand(0, TAU), life, max: life });
        if (this.scorches.length > 70)
            this.scorches.shift();
    }
    /** billowing smoke. hot = self-lit by fire (additive), cool = occluding */
    addSmoke(x, y, vx, vy, size, life, color, hot = false) {
        if (this.smokes.length > 240)
            this.smokes.shift();
        this.smokes.push({
            x, y, vx, vy, rot: rand(0, TAU), vr: rand(-0.7, 0.7),
            life, max: life, size, grow: size * rand(1.7, 2.6), alpha: hot ? 0.85 : 0.5,
            tex: this.smoke(color, 1 + ((Math.random() * 4) | 0)), hot, seed: rand(0, 100),
        });
    }
    addSpark(x, y, angle, speed, color, size, life, floorY = y + 30) {
        if (this.sparks.length > 700)
            this.sparks.shift();
        this.sparks.push({
            x, y, vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed - rand(20, 130),
            size, color, life, max: life, floorY, bounces: 0, drag: 1.1,
        });
    }
    addEmber(x, y, color, up = 140) {
        if (this.embers.length > 320)
            this.embers.shift();
        this.embers.push({
            x: x + rand(-14, 14), y: y + rand(-10, 10),
            vx: rand(-46, 46), vy: -rand(up * 0.4, up), size: rand(1.6, 4.2),
            color, life: rand(0.4, 1), max: 1, seed: rand(0, 100),
        });
    }
    bolt(x1, y1, x2, y2, color = '#ffd23c', width = 3, branches = 2) {
        const make = (ax, ay, bx, by, depth, rough) => {
            let pts = [{ x: ax, y: ay }, { x: bx, y: by }];
            for (let d = 0; d < depth; d++) {
                const next = [];
                for (let i = 0; i < pts.length - 1; i++) {
                    const a = pts[i], b = pts[i + 1];
                    const len = Math.hypot(b.x - a.x, b.y - a.y);
                    const nx = -(b.y - a.y) / (len || 1), ny = (b.x - a.x) / (len || 1);
                    const off = rand(-rough, rough) * len;
                    next.push(a, { x: (a.x + b.x) / 2 + nx * off, y: (a.y + b.y) / 2 + ny * off });
                }
                next.push(pts[pts.length - 1]);
                pts = next;
            }
            return pts;
        };
        const main = make(x1, y1, x2, y2, 4, 0.3);
        const paths = [main];
        for (let i = 0; i < branches; i++) {
            const s = main[(Math.random() * (main.length - 2) + 1) | 0];
            const a = Math.atan2(y2 - y1, x2 - x1) + rand(-1.1, 1.1);
            const l = Math.hypot(x2 - x1, y2 - y1) * rand(0.18, 0.42);
            paths.push(make(s.x, s.y, s.x + Math.cos(a) * l, s.y + Math.sin(a) * l, 3, 0.34));
        }
        this.bolts.push({ paths, color, width, life: 0.19, max: 0.19 });
        this.flash(x2, y2, 34, color, 0.13);
        this.pool(x2, y2 + 28, 46, color, 0.2);
        if (this.bolts.length > 46)
            this.bolts.shift();
    }
    streak(x, y, angle, color, speed = 900, len = 60, width = 3, life = 0.22) {
        this.streaks.push({ x, y, vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed, len, width, color, life, max: life });
        if (this.streaks.length > 260)
            this.streaks.shift();
    }
    streakCone(x, y, angle, n, color, spread = 0.35, speed = 900, len = 60) {
        for (let i = 0; i < n; i++) {
            const a = angle + rand(-spread, spread);
            const off = rand(-20, 20);
            this.streak(x - Math.sin(angle) * off, y + Math.cos(angle) * off, a, color, rand(speed * 0.6, speed), rand(len * 0.6, len * 1.3), rand(1.5, 3.5), rand(0.12, 0.24));
        }
    }
    radialStreaks(x, y, n, color, speed = 1100, len = 90) {
        for (let i = 0; i < n; i++) {
            const a = (i / n) * TAU + rand(-0.1, 0.1);
            this.streak(x + Math.cos(a) * 30, y + Math.sin(a) * 30, a, color, rand(speed * 0.6, speed), rand(len * 0.6, len * 1.2), rand(2, 5), rand(0.2, 0.34));
        }
    }
    ghost(img, x, y, angle, rotOffset, s0, s1, dist, life = 0.3, alpha = 0.85, mirror = false) {
        this.ghosts.push({ img, x, y, angle, rotOffset, mirror, s0, s1, dist, life, max: life, alpha });
    }
    screenFlash(color, t = 0.2, alpha = 0.45) {
        this.screen.flashColor = color;
        this.screen.flashT = t;
        this.screen.flashMax = t;
        this.screen.flashAlpha = alpha;
    }
    speedLines(t, color = '#ffffff') {
        this.screen.speedT = Math.max(this.screen.speedT, t);
        this.screen.speedColor = color;
    }
    /** sample a glove/weapon position — builds a real tapered motion-blur ribbon */
    trail(id, x, y, color, width) {
        let tr = this.trails.get(id);
        if (!tr) {
            tr = { pts: [], color, width, idle: 0 };
            this.trails.set(id, tr);
        }
        tr.color = color;
        tr.width = width;
        tr.idle = 0;
        const last = tr.pts[tr.pts.length - 1];
        if (!last || Math.hypot(x - last.x, y - last.y) > 2.5)
            tr.pts.push({ x, y, t: this.t });
        if (tr.pts.length > 13)
            tr.pts.shift();
    }
    clear() {
        this.impacts = [];
        this.wedges = [];
        this.slashes = [];
        this.flashes = [];
        this.pillars = [];
        this.spikes = [];
        this.bolts = [];
        this.streaks = [];
        this.shocks = [];
        this.pools = [];
        this.scorches = [];
        this.smokes = [];
        this.sparks = [];
        this.embers = [];
        this.ghosts = [];
        this.trails.clear();
    }
    /* ------------------------------------------------------------ update */
    update(dt, rawDt) {
        this.t += dt;
        const dec = (arr) => {
            for (let i = arr.length - 1; i >= 0; i--) {
                arr[i].life -= dt;
                if (arr[i].life <= 0)
                    arr.splice(i, 1);
            }
        };
        dec(this.impacts);
        dec(this.wedges);
        dec(this.slashes);
        dec(this.flashes);
        dec(this.pillars);
        dec(this.spikes);
        dec(this.bolts);
        dec(this.ghosts);
        dec(this.shocks);
        dec(this.pools);
        dec(this.scorches);
        // smoke: buoyancy + curl drift + expansion
        for (let i = this.smokes.length - 1; i >= 0; i--) {
            const s = this.smokes[i];
            s.life -= dt;
            if (s.life <= 0) {
                this.smokes.splice(i, 1);
                continue;
            }
            const k = 1 - s.life / s.max;
            s.vx += Math.sin(s.y * 0.021 + this.t * 1.9 + s.seed) * 26 * dt;
            s.vy += Math.cos(s.x * 0.017 + this.t * 1.4 + s.seed) * 16 * dt - (s.hot ? 120 : 46) * dt;
            const dr = Math.exp(-(s.hot ? 2.1 : 1.5) * dt);
            s.vx *= dr;
            s.vy *= dr;
            s.x += s.vx * dt;
            s.y += s.vy * dt;
            s.rot += s.vr * dt;
            s.size += (s.grow - s.size) * (1 - Math.exp(-2.4 * dt));
            s.alpha = (s.hot ? 0.85 : 0.5) * Math.min(1, k * 7) * (1 - k);
        }
        // sparks: gravity, ground bounce, cooling
        for (let i = this.sparks.length - 1; i >= 0; i--) {
            const s = this.sparks[i];
            s.life -= dt;
            if (s.life <= 0) {
                this.sparks.splice(i, 1);
                continue;
            }
            s.vy += 1500 * dt;
            const dr = Math.exp(-s.drag * dt);
            s.vx *= dr;
            s.vy *= dr;
            s.x += s.vx * dt;
            s.y += s.vy * dt;
            if (s.y > s.floorY && s.vy > 0) {
                s.y = s.floorY;
                if (s.bounces++ < 2 && Math.abs(s.vy) > 90) {
                    s.vy *= -rand(0.3, 0.5);
                    s.vx *= 0.7;
                }
                else {
                    s.vy = 0;
                    s.vx *= 0.82;
                    s.life = Math.min(s.life, 0.12);
                }
            }
        }
        // embers flicker and rise
        for (let i = this.embers.length - 1; i >= 0; i--) {
            const e = this.embers[i];
            e.life -= dt;
            if (e.life <= 0) {
                this.embers.splice(i, 1);
                continue;
            }
            e.vx += Math.sin(this.t * 6 + e.seed) * 40 * dt;
            e.vy -= 40 * dt;
            e.x += e.vx * dt;
            e.y += e.vy * dt;
        }
        for (let i = this.streaks.length - 1; i >= 0; i--) {
            const s = this.streaks[i];
            s.life -= dt;
            if (s.life <= 0) {
                this.streaks.splice(i, 1);
                continue;
            }
            s.x += s.vx * dt;
            s.y += s.vy * dt;
            s.vx *= Math.exp(-4 * dt);
            s.vy *= Math.exp(-4 * dt);
        }
        for (const sh of this.shocks) {
            const k = 1 - sh.life / sh.max;
            sh.r = 6 + (sh.r1 - 6) * easeOut(k);
        }
        for (const [, tr] of this.trails) {
            tr.pts = tr.pts.filter((p) => this.t - p.t < 0.14);
            tr.idle += dt;
        }
        const sc = this.screen;
        sc.flashT = Math.max(0, sc.flashT - rawDt);
        sc.speedT = Math.max(0, sc.speedT - rawDt);
        sc.dark += (sc.darkTarget - sc.dark) * (1 - Math.exp(-7 * rawDt));
        sc.letter += (sc.letterTarget - sc.letter) * (1 - Math.exp(-9 * rawDt));
    }
    /* ------------------------------------------------------------ ground pass */
    drawGround(ctx) {
        // bounce light on the floor
        ctx.save();
        ctx.globalCompositeOperation = 'lighter';
        for (const p of this.pools) {
            const k = p.life / p.max;
            ctx.globalAlpha = k * 0.55;
            ctx.drawImage(this.soft(p.color), p.x - p.rx, p.y - p.ry, p.rx * 2, p.ry * 2);
        }
        ctx.restore();
        // burnt decals
        for (const s of this.scorches) {
            const k = clamp(s.life / s.max, 0, 1);
            ctx.save();
            ctx.globalAlpha = 0.55 * Math.min(1, k * 3);
            ctx.translate(s.x, s.y);
            ctx.rotate(s.rot);
            ctx.drawImage((0, textures_1.scorchTex)(3), -s.r, -s.r * 0.55, s.r * 2, s.r * 1.1);
            ctx.restore();
        }
        // ground shockwaves: rim light + darker inner ring reads as displaced earth
        for (const s of this.shocks) {
            const k = s.life / s.max;
            ctx.save();
            ctx.globalCompositeOperation = 'lighter';
            ctx.globalAlpha = k * 0.18;
            ctx.strokeStyle = s.color;
            ctx.lineWidth = s.width * k * 0.45 + 0.4;
            ctx.beginPath();
            ctx.ellipse(s.x, s.y, s.r, s.r * s.squash, 0, 0, TAU);
            ctx.stroke();
            ctx.globalAlpha = k * 0.07;
            ctx.lineWidth = s.width * 2.8 * k;
            ctx.beginPath();
            ctx.ellipse(s.x, s.y, s.r * 0.9, s.r * 0.9 * s.squash, 0, 0, TAU);
            ctx.stroke();
            ctx.restore();
        }
        // erupting rock
        for (const sp of this.spikes) {
            const k = 1 - sp.life / sp.max;
            const hgt = sp.size * (k < 0.25 ? easeOut(k / 0.25) : 1 - ((k - 0.25) / 0.75) * 0.85);
            const bw = sp.size * 0.42;
            ctx.save();
            ctx.translate(sp.x, sp.y);
            ctx.globalAlpha = clamp((sp.life / sp.max) * 2, 0, 1);
            ctx.fillStyle = 'rgba(0,0,0,0.35)';
            ctx.beginPath();
            ctx.ellipse(0, 2, bw * 1.15, bw * 0.4, 0, 0, TAU);
            ctx.fill();
            const g = ctx.createLinearGradient(0, 0, 0, -hgt);
            g.addColorStop(0, '#4a3320');
            g.addColorStop(0.6, sp.color);
            g.addColorStop(1, '#ffcf7a');
            ctx.fillStyle = g;
            ctx.beginPath();
            ctx.moveTo(-bw, 0);
            ctx.lineTo(sp.lean * hgt, -hgt);
            ctx.lineTo(bw, 0);
            ctx.closePath();
            ctx.fill();
            ctx.strokeStyle = '#ffb03c';
            ctx.globalCompositeOperation = 'lighter';
            ctx.lineWidth = 1.8;
            ctx.beginPath();
            ctx.moveTo(-bw, 0);
            ctx.lineTo(sp.lean * hgt, -hgt);
            ctx.lineTo(bw, 0);
            ctx.stroke();
            ctx.restore();
        }
    }
    /* ------------------------------------------------------------ top pass */
    drawTop(ctx) {
        ctx.save();
        ctx.globalCompositeOperation = 'lighter';
        // fire columns, lit and flickering
        for (const p of this.pillars) {
            const k = p.life / p.max;
            const flick = 0.82 + Math.sin(this.t * 34 + p.seed) * 0.12 + Math.sin(this.t * 21 + p.seed * 2) * 0.06;
            const w = p.w * (0.3 + 0.7 * k) * flick;
            const g = ctx.createLinearGradient(0, p.y, 0, p.y - p.h);
            g.addColorStop(0, '#ffffff');
            g.addColorStop(0.12, p.color);
            g.addColorStop(0.5, p.color + '77');
            g.addColorStop(1, p.color + '00');
            ctx.globalAlpha = k;
            ctx.fillStyle = g;
            ctx.beginPath();
            ctx.moveTo(p.x - w * 0.5, p.y);
            ctx.quadraticCurveTo(p.x - w * 0.62, p.y - p.h * 0.5, p.x - w * 0.16, p.y - p.h);
            ctx.lineTo(p.x + w * 0.16, p.y - p.h);
            ctx.quadraticCurveTo(p.x + w * 0.62, p.y - p.h * 0.5, p.x + w * 0.5, p.y);
            ctx.closePath();
            ctx.fill();
            ctx.globalAlpha = k * 0.9;
            ctx.drawImage(this.glow(p.color), p.x - p.w * 1.4, p.y - p.w * 0.55, p.w * 2.8, p.w * 1.1);
            this.pool(p.x, p.y + 6, p.w * 1.6, p.color, 0.12);
        }
        // light flashes
        for (const f of this.flashes) {
            const k = f.life / f.max;
            const r = f.r * (1.28 - k * 0.28);
            ctx.globalAlpha = k;
            ctx.drawImage(this.glow(f.color), f.x - r, f.y - r, r * 2, r * 2);
            if (f.core) {
                ctx.globalAlpha = k * 0.9;
                ctx.drawImage(this.soft('#ffffff'), f.x - r * 0.35, f.y - r * 0.35, r * 0.7, r * 0.7);
            }
        }
        // speed streaks
        ctx.lineCap = 'round';
        for (const s of this.streaks) {
            const k = s.life / s.max;
            const sp = Math.hypot(s.vx, s.vy) || 1;
            ctx.globalAlpha = k;
            ctx.strokeStyle = s.color;
            ctx.lineWidth = s.width * k + 0.4;
            ctx.beginPath();
            ctx.moveTo(s.x, s.y);
            ctx.lineTo(s.x - (s.vx / sp) * s.len * k, s.y - (s.vy / sp) * s.len * k);
            ctx.stroke();
        }
        // sparks: textured streak + light head, they bounce so they read physical
        for (const s of this.sparks) {
            const k = clamp(s.life / s.max, 0, 1);
            const sp = Math.hypot(s.vx, s.vy) || 1;
            const len = clamp(sp * 0.045, s.size * 2, s.size * 13);
            ctx.save();
            ctx.translate(s.x, s.y);
            ctx.rotate(Math.atan2(s.vy, s.vx));
            ctx.globalAlpha = k;
            ctx.drawImage(this.spark(s.color), -len, -s.size, len * 2, s.size * 2);
            ctx.restore();
            ctx.globalAlpha = k * 0.8;
            const hr = s.size * 3.4;
            ctx.drawImage(this.glow(s.color), s.x - hr, s.y - hr, hr * 2, hr * 2);
        }
        // embers
        for (const e of this.embers) {
            const k = clamp(e.life / e.max, 0, 1);
            const flick = 0.55 + Math.sin(this.t * 42 + e.seed) * 0.45;
            ctx.globalAlpha = k * flick;
            const hr = e.size * 4;
            ctx.drawImage(this.glow(e.color), e.x - hr, e.y - hr, hr * 2, hr * 2);
            ctx.globalAlpha = k;
            ctx.fillStyle = '#fff6e0';
            ctx.beginPath();
            ctx.arc(e.x, e.y, e.size * 0.7, 0, TAU);
            ctx.fill();
        }
        // impact light fans
        for (const wg of this.wedges) {
            const t = 1 - wg.life / wg.max;
            const r = wg.r0 + (wg.r1 - wg.r0) * easeOut(t);
            const alpha = Math.pow(1 - t, 1.4) * 0.8;
            ctx.save();
            ctx.translate(wg.x, wg.y);
            ctx.rotate(wg.angle);
            ctx.globalAlpha = alpha;
            const g2 = ctx.createLinearGradient(0, 0, r, 0);
            g2.addColorStop(0, '#ffffff');
            g2.addColorStop(0.26, wg.color);
            g2.addColorStop(1, wg.color + '00');
            ctx.fillStyle = g2;
            ctx.beginPath();
            ctx.moveTo(0, 0);
            ctx.lineTo(r, -r * wg.spread);
            ctx.lineTo(r * 0.7, 0);
            ctx.lineTo(r, r * wg.spread);
            ctx.closePath();
            ctx.fill();
            ctx.restore();
        }
        // slashes: soft-edged crescent with a hot leading edge
        for (const s of this.slashes) {
            const life = 1 - s.life / s.max;
            const reveal = clamp(life / 0.32, 0, 1);
            const fade = clamp((s.life / s.max) * 1.7, 0, 1);
            const a0 = s.angle - (s.span / 2) * s.dir;
            const span = s.span * easeOut(reveal) * s.dir;
            const N = 26;
            const crescent = (width, color, alpha, rOff) => {
                ctx.globalAlpha = alpha * fade;
                ctx.fillStyle = color;
                ctx.beginPath();
                for (let i = 0; i <= N; i++) {
                    const t = i / N, a = a0 + span * t;
                    const r = s.r + rOff;
                    const px = s.x + Math.cos(a) * r, py = s.y + Math.sin(a) * r;
                    if (i === 0)
                        ctx.moveTo(px, py);
                    else
                        ctx.lineTo(px, py);
                }
                for (let i = N; i >= 0; i--) {
                    const t = i / N, a = a0 + span * t;
                    const th = width * Math.pow(Math.sin(t * Math.PI), 0.75) * (0.4 + 0.6 * t);
                    const r = s.r + rOff - th;
                    ctx.lineTo(s.x + Math.cos(a) * r, s.y + Math.sin(a) * r);
                }
                ctx.closePath();
                ctx.fill();
            };
            crescent(s.width * 2.6, s.color, 0.22, 6);
            crescent(s.width * 1.3, s.color, 0.6, 2);
            crescent(s.width * 0.5, '#ffffff', 0.95, -1);
        }
        // lightning: halo pass, colour pass, white core
        ctx.lineJoin = 'round';
        for (const b of this.bolts) {
            const k = b.life / b.max;
            const flick = Math.random() < 0.22 ? 0.45 : 1;
            b.paths.forEach((path, pi) => {
                const wm = pi === 0 ? 1 : 0.5;
                for (const [w, c, a] of [[b.width * 9, b.color, 0.16], [b.width * 4, b.color, 0.3], [b.width * 1.7, b.color, 0.85], [b.width * 0.65, '#ffffff', 1]]) {
                    ctx.globalAlpha = k * a * flick;
                    ctx.strokeStyle = c;
                    ctx.lineWidth = w * wm;
                    ctx.beginPath();
                    path.forEach((pt, i) => (i === 0 ? ctx.moveTo(pt.x, pt.y) : ctx.lineTo(pt.x, pt.y)));
                    ctx.stroke();
                }
            });
        }
        // ghost fists
        for (const g of this.ghosts) {
            const t = 1 - g.life / g.max;
            const e = easeOut(t);
            const s = g.s0 + (g.s1 - g.s0) * e;
            const d = g.dist * e;
            const iw = g.img.width, ih = g.img.height;
            const scl = s / Math.max(iw, ih);
            ctx.save();
            ctx.globalAlpha = g.alpha * (1 - t);
            ctx.translate(g.x + Math.cos(g.angle) * d, g.y + Math.sin(g.angle) * d);
            ctx.rotate(g.angle);
            if (g.mirror)
                ctx.scale(1, -1);
            ctx.rotate(g.rotOffset);
            ctx.drawImage(g.img, (-iw * scl) / 2, (-ih * scl) / 2, iw * scl, ih * scl);
            ctx.restore();
        }
        // tapered motion-blur ribbons
        for (const [, tr] of this.trails) {
            const pts = tr.pts;
            if (pts.length < 3)
                continue;
            for (let pass = 0; pass < 2; pass++) {
                const col = pass === 0 ? tr.color : '#ffffff';
                const wMul = pass === 0 ? 2.4 : 1;
                ctx.globalAlpha = pass === 0 ? 0.3 : 0.62;
                ctx.fillStyle = col;
                ctx.beginPath();
                for (let i = 0; i < pts.length; i++) {
                    const p = pts[i], n = pts[Math.min(pts.length - 1, i + 1)], pv = pts[Math.max(0, i - 1)];
                    const ang = Math.atan2(n.y - pv.y, n.x - pv.x) + Math.PI / 2;
                    const age = clamp(1 - (this.t - p.t) / 0.14, 0, 1);
                    const w = tr.width * wMul * age * age;
                    const px = p.x + Math.cos(ang) * w, py = p.y + Math.sin(ang) * w;
                    if (i === 0)
                        ctx.moveTo(px, py);
                    else
                        ctx.lineTo(px, py);
                }
                for (let i = pts.length - 1; i >= 0; i--) {
                    const p = pts[i], n = pts[Math.min(pts.length - 1, i + 1)], pv = pts[Math.max(0, i - 1)];
                    const ang = Math.atan2(n.y - pv.y, n.x - pv.x) + Math.PI / 2;
                    const age = clamp(1 - (this.t - p.t) / 0.14, 0, 1);
                    const w = tr.width * wMul * age * age;
                    ctx.lineTo(p.x - Math.cos(ang) * w, p.y - Math.sin(ang) * w);
                }
                ctx.closePath();
                ctx.fill();
            }
        }
        ctx.restore();
        // impact stars (solid, so the white core reads as a hot contact point)
        for (const im of this.impacts) {
            const t = 1 - im.life / im.max;
            const grow = easeOut(clamp(t / 0.3, 0, 1));
            const R = 36 * im.size * (0.5 + grow * 0.7);
            const fade = clamp((im.life / im.max) * 2.2, 0, 1);
            ctx.save();
            ctx.translate(im.x, im.y);
            ctx.rotate(im.angle);
            ctx.scale(1.4, 0.82);
            const star = (scale) => {
                ctx.beginPath();
                im.spikes.forEach((m, i) => {
                    const a = (i / im.spikes.length) * TAU;
                    const r = R * m * scale;
                    if (i === 0)
                        ctx.moveTo(Math.cos(a) * r, Math.sin(a) * r);
                    else
                        ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r);
                });
                ctx.closePath();
            };
            ctx.globalAlpha = fade * 0.55;
            ctx.fillStyle = im.color;
            star(1.5);
            ctx.fill();
            ctx.globalAlpha = fade;
            star(1);
            ctx.fill();
            ctx.fillStyle = '#ffffff';
            star(0.5);
            ctx.fill();
            ctx.restore();
        }
        // cool smoke drawn last, it occludes the scene like real atmosphere
        for (const s of this.smokes) {
            ctx.save();
            if (s.hot)
                ctx.globalCompositeOperation = 'lighter';
            ctx.globalAlpha = s.alpha * (s.hot ? 1 : 0.62);
            ctx.translate(s.x, s.y);
            ctx.rotate(s.rot);
            ctx.drawImage(s.tex, -s.size, -s.size, s.size * 2, s.size * 2);
            ctx.restore();
        }
    }
    /* ------------------------------------------------------------ screen pass */
    drawScreen(ctx, w, h, fx, fy) {
        const sc = this.screen;
        if (sc.speedT > 0) {
            ctx.save();
            ctx.globalCompositeOperation = 'lighter';
            ctx.strokeStyle = sc.speedColor;
            const R = Math.hypot(w, h);
            for (let i = 0; i < 46; i++) {
                const a = Math.random() * TAU;
                const r0 = rand(0.3, 0.55) * R * 0.5;
                ctx.globalAlpha = rand(0.1, 0.4) * clamp(sc.speedT * 3, 0, 1);
                ctx.lineWidth = rand(1, 3.5);
                ctx.beginPath();
                ctx.moveTo(fx + Math.cos(a) * r0, fy + Math.sin(a) * r0);
                ctx.lineTo(fx + Math.cos(a) * R, fy + Math.sin(a) * R);
                ctx.stroke();
            }
            ctx.restore();
        }
        if (sc.letter > 0.01) {
            const bh = h * 0.085 * sc.letter;
            ctx.fillStyle = '#000';
            ctx.fillRect(0, 0, w, bh);
            ctx.fillRect(0, h - bh, w, bh);
            ctx.fillStyle = 'rgba(246,183,60,0.6)';
            ctx.fillRect(0, bh - 2, w, 2);
            ctx.fillRect(0, h - bh, w, 2);
        }
        if (sc.flashT > 0) {
            ctx.save();
            ctx.globalAlpha = (sc.flashT / sc.flashMax) * sc.flashAlpha;
            ctx.fillStyle = sc.flashColor;
            ctx.fillRect(0, 0, w, h);
            ctx.restore();
        }
    }
}
exports.VFX = VFX;

},
'src/game/post.ts': function(module,exports,require){
"use strict";
/* Offscreen post-processing: the world renders into a scene buffer, then we
   run a real bloom chain (bright-pass → tight blur → wide blur → additive
   composite), impact-driven RGB split, radial streak blur for the ultimate,
   plus lens vignette and film grain. This is what turns flat vector shapes
   into light that behaves like light. */
Object.defineProperty(exports, "__esModule", { value: true });
exports.Post = void 0;
const textures_1 = require("./fx/textures");
function mk() { const c = document.createElement('canvas'); c.width = 2; c.height = 2; return c; }
class Post {
    constructor() {
        this.scene = mk();
        this.sctx = this.scene.getContext('2d');
        this.a = mk();
        this.actx = this.a.getContext('2d'); // bloom tight
        this.b = mk();
        this.bctx = this.b.getContext('2d'); // bloom wide
        this.r1 = mk();
        this.rctx1 = this.r1.getContext('2d'); // chroma red
        this.r2 = mk();
        this.rctx2 = this.r2.getContext('2d'); // chroma cyan
        this.rb = mk();
        this.rbctx = this.rb.getContext('2d'); // radial
        this.grainPattern = null;
        this.cp = mk();
        this.cpctx = this.cp.getContext('2d'); // scene copy for refraction
    }
    /** returns a context to draw the world into, already scaled by dpr */
    begin(w, h, dpr) {
        const pw = Math.max(2, Math.round(w * dpr));
        const ph = Math.max(2, Math.round(h * dpr));
        if (this.scene.width !== pw || this.scene.height !== ph) {
            this.scene.width = pw;
            this.scene.height = ph;
        }
        this.sctx.setTransform(1, 0, 0, 1, 0, 0);
        this.sctx.clearRect(0, 0, pw, ph);
        this.sctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        return this.sctx;
    }
    fit(c, ctx, w, h) {
        if (c.width !== w || c.height !== h) {
            c.width = w;
            c.height = h;
        }
        else
            ctx.setTransform(1, 0, 0, 1, 0, 0);
        ctx.clearRect(0, 0, w, h);
    }
    /* ---- refraction: shockwaves & heat haze bend the rendered scene ---- */
    distort(w, h, dpr, o) {
        // Only refract regions that intersect the viewport. Each refractive region
        // is a costly offscreen scene read/copy, so cap simultaneous passes on
        // impact frames while leaving *all* source VFX and particles intact.
        const shocks = (o.shocks ?? [])
            .filter((s) => s.strength > 0.002 && s.x + s.r > -40 && s.x - s.r < w + 40 && s.y + s.r > -40 && s.y - s.r < h + 40)
            .sort((a, b) => b.strength - a.strength).slice(0, 5);
        const heat = (o.heat ?? [])
            .filter((hr) => hr.heat > 0.22 && hr.x + hr.w > 0 && hr.x < w && hr.y + hr.h > 0 && hr.y - hr.h < h)
            .sort((a, b) => b.heat - a.heat).slice(0, 14);
        if (!shocks.length && !heat.length)
            return;
        const pw = this.scene.width, ph = this.scene.height;
        this.fit(this.cp, this.cpctx, pw, ph);
        this.cpctx.drawImage(this.scene, 0, 0);
        const s = this.sctx;
        s.save();
        s.setTransform(dpr, 0, 0, dpr, 0, 0);
        for (const sh of shocks) {
            // annulus clip; inside it the scene is magnified about the centre, so
            // everything behind the wave front bulges outward like a pressure lens
            const r0 = Math.max(1, sh.r - sh.width), r1 = sh.r + sh.width * 0.6;
            s.save();
            s.beginPath();
            s.ellipse(sh.x, sh.y, r1, r1 * sh.squash, 0, 0, Math.PI * 2);
            s.ellipse(sh.x, sh.y, r0, r0 * sh.squash, 0, 0, Math.PI * 2, true);
            s.clip();
            const mag = 1 + sh.strength;
            s.translate(sh.x, sh.y);
            s.scale(mag, mag);
            s.translate(-sh.x, -sh.y);
            s.drawImage(this.cp, 0, 0, pw, ph, 0, 0, w, h);
            // thin compression rim: slightly brighter band at the front
            s.globalCompositeOperation = 'lighter';
            s.globalAlpha = Math.min(0.35, sh.strength * 4);
            s.fillStyle = '#ffffff';
            s.beginPath();
            s.ellipse(sh.x, sh.y, sh.r + sh.width * 0.25, (sh.r + sh.width * 0.25) * sh.squash, 0, 0, Math.PI * 2);
            // A new pressure wave can have r < width * 0.1. Canvas.ellipse()
            // throws IndexSizeError for negative radii; the old render would then
            // abort every frame as the ultimate spawned overlapping shocks.
            const innerRim = Math.max(0.25, sh.r - sh.width * 0.1);
            s.ellipse(sh.x, sh.y, innerRim, innerRim * sh.squash, 0, 0, Math.PI * 2, true);
            s.fill();
            s.restore();
        }
        // heat shimmer: horizontal slices above hot cells shift sideways with a
        // travelling wave; amplitude scales with temperature
        const t = o.time ?? 0;
        for (const hr of heat) {
            const slices = 6;
            const sh = hr.h / slices;
            const amp = 1.2 + hr.heat * 2.6;
            for (let i = 0; i < slices; i++) {
                const sy = hr.y - hr.h * 0.9 + i * sh; // shimmer rises above the flame
                const off = Math.sin(t * 11 + i * 1.7 + hr.x * 0.03) * amp + Math.sin(t * 23 + i * 0.9) * amp * 0.5;
                s.drawImage(this.cp, hr.x * dpr, sy * dpr, hr.w * dpr, sh * dpr, hr.x + off, sy, hr.w, sh);
            }
        }
        s.restore();
    }
    end(dst, w, h, dpr, o) {
        const pw = Math.max(2, Math.round(w * dpr));
        const ph = Math.max(2, Math.round(h * dpr));
        const bw = Math.max(2, Math.round(pw / 4));
        const bh = Math.max(2, Math.round(ph / 4));
        this.distort(w, h, dpr, o);
        /* ---- bloom: bright pass with contrast so only light survives ---- */
        this.fit(this.a, this.actx, bw, bh);
        this.actx.filter = 'brightness(1.06) contrast(2.05) saturate(1.18) blur(1.1px)';
        this.actx.drawImage(this.scene, 0, 0, bw, bh);
        this.actx.filter = 'none';
        this.fit(this.b, this.bctx, bw, bh);
        this.bctx.filter = 'blur(3.4px)';
        this.bctx.drawImage(this.a, 0, 0, bw, bh);
        this.bctx.filter = 'none';
        /* ---- impact RGB split, done on quarter-res channel copies ---- */
        const chroma = o.chroma ?? 0;
        if (chroma > 0.01) {
            const offs = Math.round(1 + chroma * 5);
            this.fit(this.r1, this.rctx1, bw, bh);
            this.rctx1.drawImage(this.scene, 0, 0, bw, bh);
            this.rctx1.globalCompositeOperation = 'multiply';
            this.rctx1.fillStyle = '#ff3b30';
            this.rctx1.fillRect(0, 0, bw, bh);
            this.rctx1.globalCompositeOperation = 'source-over';
            this.fit(this.r2, this.rctx2, bw, bh);
            this.rctx2.drawImage(this.scene, 0, 0, bw, bh);
            this.rctx2.globalCompositeOperation = 'multiply';
            this.rctx2.fillStyle = '#2bffff';
            this.rctx2.fillRect(0, 0, bw, bh);
            this.rctx2.globalCompositeOperation = 'source-over';
            dst.setTransform(1, 0, 0, 1, 0, 0);
            dst.globalCompositeOperation = 'lighter';
            dst.globalAlpha = Math.min(0.6, chroma * 0.55);
            dst.drawImage(this.r1, offs, 0, pw, ph);
            dst.drawImage(this.r2, -offs, 0, pw, ph);
            dst.globalAlpha = 1;
            dst.globalCompositeOperation = 'source-over';
        }
        /* ---- radial streak blur during the ultimate ---- */
        const radial = o.radial ?? 0;
        if (radial > 0.01) {
            this.fit(this.rb, this.rbctx, bw, bh);
            const cx = (o.fx / w) * bw, cy = (o.fy / h) * bh;
            for (let i = 1; i <= 5; i++) {
                const s = 1 + i * 0.022 * radial;
                this.rbctx.globalAlpha = 1 / (i + 1.2);
                this.rbctx.drawImage(this.scene, cx - cx * s, cy - cy * s, bw * s, bh * s);
            }
            this.rbctx.globalAlpha = 1;
            dst.setTransform(1, 0, 0, 1, 0, 0);
            dst.globalCompositeOperation = 'lighter';
            dst.globalAlpha = 0.4 * radial;
            dst.drawImage(this.rb, 0, 0, pw, ph);
            dst.globalAlpha = 1;
            dst.globalCompositeOperation = 'source-over';
        }
        /* ---- base scene ---- */
        dst.setTransform(1, 0, 0, 1, 0, 0);
        dst.globalCompositeOperation = 'source-over';
        dst.globalAlpha = 1;
        dst.drawImage(this.scene, 0, 0);
        /* ---- bloom composite ---- */
        const bloom = o.bloom ?? 1;
        dst.globalCompositeOperation = 'lighter';
        dst.globalAlpha = 0.34 * bloom;
        dst.drawImage(this.b, 0, 0, pw, ph);
        dst.globalAlpha = 0.42 * bloom;
        dst.drawImage(this.a, 0, 0, pw, ph);
        dst.globalAlpha = 1;
        dst.globalCompositeOperation = 'source-over';
        /* ---- vignette ---- */
        const vig = o.vignette ?? 0.45;
        if (vig > 0.01) {
            const fx = o.fx * dpr, fy = o.fy * dpr;
            const inner = Math.min(pw, ph) * 0.2;
            const outer = Math.hypot(pw, ph) * 0.62;
            const g = dst.createRadialGradient(fx, fy, inner, fx, fy, outer);
            g.addColorStop(0, 'rgba(0,0,0,0)');
            g.addColorStop(0.62, `rgba(4,2,6,${0.24 * vig})`);
            g.addColorStop(1, `rgba(2,1,3,${0.82 * vig})`);
            dst.fillStyle = g;
            dst.fillRect(0, 0, pw, ph);
        }
        /* ---- film grain ---- */
        const grain = o.grain ?? 0;
        if (grain > 0.001) {
            if (!this.grainPattern)
                this.grainPattern = dst.createPattern((0, textures_1.grainTex)(), 'repeat');
            if (this.grainPattern) {
                const ox = (Math.random() * 128) | 0, oy = (Math.random() * 128) | 0;
                dst.save();
                dst.globalCompositeOperation = 'overlay';
                dst.globalAlpha = grain;
                dst.translate(-ox, -oy);
                dst.fillStyle = this.grainPattern;
                dst.fillRect(0, 0, pw + 128, ph + 128);
                dst.restore();
            }
        }
    }
}
exports.Post = Post;

},
'src/game/materialFx.ts': function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MaterialFX = void 0;
const fx_rock_png_1 = require("../assets/fx-rock.png");
const fx_rubble_png_1 = require("../assets/fx-rubble.png");
const fx_fracture_png_1 = require("../assets/fx-fracture.png");
const textures_1 = require("./fx/textures");
const TAU = Math.PI * 2;
const rand = (a, b) => a + Math.random() * (b - a);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const load = (url) => new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = reject;
    image.src = url;
});
/** Material-driven environment FX. Rock and torn ground use authored PNGs;
 * motion, dust and broken pieces are simulated independently from the combat. */
class MaterialFX {
    constructor() {
        this.assets = null;
        this.marks = [];
        this.formations = [];
        this.chunks = [];
        this.puffs = [];
        this.wakes = [];
        this.clock = 0;
        /** A stone column actually rises through the floor; stones break away and land. */
        /** optional hook so fire can be handed to the procedural fire system */
        this.onFire = null;
        Promise.all([load(fx_rock_png_1.default), load(fx_rubble_png_1.default), load(fx_fracture_png_1.default)])
            .then(([rock, rubble, fracture]) => { this.assets = { rock, rubble, fracture }; })
            .catch(() => { });
    }
    clear() {
        this.marks = [];
        this.formations = [];
        this.chunks = [];
        this.puffs = [];
        this.wakes = [];
    }
    fracture(x, y, r, life = 7, alpha = 0.94) {
        this.marks.push({ x, y, r, rot: rand(-0.45, 0.45), age: 0, life, alpha });
        if (this.marks.length > 80)
            this.marks.shift();
    }
    eruption(x, y, power = 1, fire = false) {
        const r = 85 * power;
        this.fracture(x, y + 16, r, 7 + power * 2);
        const count = Math.round(2 + power * 2);
        for (let i = 0; i < count; i++) {
            const a = (i / count) * TAU + rand(-0.45, 0.45);
            const d = i === 0 ? 0 : rand(24, 80) * power;
            this.formations.push({
                x: x + Math.cos(a) * d, y: y + Math.sin(a) * d * 0.58,
                size: rand(56, 104) * power * (i === 0 ? 1.3 : 0.75),
                age: -i * 0.035, life: rand(1.8, 2.9) + power * 0.5,
                lean: rand(-0.24, 0.24), height: rand(72, 112) * power, variant: i % 3, collapsed: false,
            });
        }
        this.throwRubble(x, y, Math.round(8 + power * 9), 340 + power * 220, power);
        this.dust(x, y + 18, 14 + Math.round(power * 9), 200 * power, 1.25);
        if (fire && this.onFire) {
            this.onFire(x, y, 58 * power, 160 * power, 1 + power * 0.3, power);
            for (let i = 0; i < Math.round(2 + power); i++) {
                const a = rand(0, TAU), d = rand(35, 100) * power;
                this.onFire(x + Math.cos(a) * d, y + Math.sin(a) * d * 0.6, 30 * power, 100 * power, 0.7, power * 0.6);
            }
        }
        if (this.formations.length > 85)
            this.formations.splice(0, this.formations.length - 85);
    }
    throwRubble(x, y, count, speed = 380, size = 1, angle) {
        for (let i = 0; i < count; i++) {
            const a = angle === undefined ? rand(0, TAU) : angle + rand(-0.9, 0.9);
            const v = rand(speed * 0.35, speed);
            this.chunks.push({
                x, y, z: rand(6, 26), vx: Math.cos(a) * v, vy: Math.sin(a) * v * 0.66,
                vz: rand(260, 560) * size, size: rand(9, 28) * size,
                rot: rand(-Math.PI, Math.PI), spin: rand(-9, 9), age: 0, life: rand(1.5, 2.7), bounces: 0,
            });
        }
        if (this.chunks.length > 270)
            this.chunks.splice(0, this.chunks.length - 270);
    }
    /** Dust puffs carry material, not light. They can cover the player/target. */
    dust(x, y, count = 8, speed = 170, life = 1) {
        for (let i = 0; i < count; i++) {
            const a = rand(0, TAU), v = rand(speed * 0.2, speed);
            this.puffs.push({
                x: x + rand(-12, 12), y: y + rand(-10, 10),
                vx: Math.cos(a) * v, vy: Math.sin(a) * v * 0.45 - rand(12, 70),
                size: rand(18, 42), grow: rand(1.8, 2.6), rot: rand(0, TAU), spin: rand(-0.9, 0.9),
                age: 0, life: rand(life * 0.65, life * 1.2), color: i % 4 === 0 ? '#5d5852' : '#a99b83', seed: 1 + (i % 4),
            });
        }
        if (this.puffs.length > 310)
            this.puffs.splice(0, this.puffs.length - 310);
    }
    /** Earth is displaced along the direction of a running ground wave. */
    tear(x, y, angle, strength = 1) {
        this.fracture(x, y + 12, 34 * strength, 4, 0.62);
        const side = (Math.random() < 0.5 ? -1 : 1) * rand(12, 40);
        this.formations.push({
            x: x - Math.sin(angle) * side, y: y + Math.cos(angle) * side * 0.5,
            size: rand(27, 53) * strength, age: 0, life: 1.5,
            lean: angle + rand(-0.3, 0.3), height: rand(30, 58) * strength, variant: 1, collapsed: false,
        });
        this.throwRubble(x, y, 2, 180, 0.55 * strength, angle);
        this.dust(x, y, 3, 110, 0.7);
    }
    /** Long displacement leaves repeated, overlapping dust along the swept path. */
    slide(x, y, angle, heavy = false, cool = false) {
        this.wakes.push({ x, y, angle, length: heavy ? 180 : 110, width: heavy ? 72 : 50, age: 0, life: 0.35, cool });
        this.dust(x - Math.cos(angle) * 30, y + 25, heavy ? 7 : 4, heavy ? 220 : 140, 0.65);
        if (heavy)
            this.throwRubble(x, y + 22, 4, 160, 0.55, angle + Math.PI);
    }
    /** Wind is an entrained mixture of dust and grit, not a clean blue circle. */
    vortex(x, y, phase) {
        for (let i = 0; i < 3; i++) {
            const a = phase + (i / 3) * TAU + rand(-0.12, 0.12);
            const r = rand(95, 185);
            const px = x + Math.cos(a) * r, py = y + Math.sin(a) * r * 0.65;
            this.puffs.push({
                x: px, y: py, vx: -Math.sin(a) * 260, vy: Math.cos(a) * 150 - 55,
                size: rand(24, 39), grow: 1.55, rot: a, spin: 2.2, age: 0, life: 0.5,
                color: '#a6a49c', seed: 1 + (i % 4),
            });
        }
        if (Math.random() < 0.55)
            this.throwRubble(x + rand(-130, 130), y + rand(-80, 80), 1, 210, 0.45);
        if (this.puffs.length > 310)
            this.puffs.splice(0, this.puffs.length - 310);
    }
    update(dt) {
        this.clock += dt;
        const step = (arr) => {
            for (let i = arr.length - 1; i >= 0; i--) {
                arr[i].age += dt;
                if (arr[i].age > arr[i].life)
                    arr.splice(i, 1);
            }
        };
        step(this.marks);
        step(this.wakes);
        for (let i = this.formations.length - 1; i >= 0; i--) {
            const f = this.formations[i];
            f.age += dt;
            if (f.age > f.life) {
                this.formations.splice(i, 1);
                continue;
            }
            if (!f.collapsed && f.age > f.life * 0.72) {
                f.collapsed = true;
                // The column shears apart; its top falls as separately simulated rock.
                for (let j = 0; j < 3; j++) {
                    this.chunks.push({
                        x: f.x + rand(-f.size * 0.25, f.size * 0.25), y: f.y,
                        z: rand(f.height * 0.3, f.height * 0.9),
                        vx: rand(-140, 140), vy: rand(-80, 80), vz: rand(40, 160),
                        size: rand(9, 19) * (f.size / 80), rot: rand(0, TAU), spin: rand(-8, 8),
                        age: 0, life: 1.7, bounces: 0,
                    });
                }
                this.dust(f.x, f.y + 8, 4, 95, 0.7);
            }
        }
        for (let i = this.chunks.length - 1; i >= 0; i--) {
            const c = this.chunks[i];
            c.age += dt;
            if (c.age > c.life) {
                this.chunks.splice(i, 1);
                continue;
            }
            c.x += c.vx * dt;
            c.y += c.vy * dt;
            c.z += c.vz * dt;
            c.vz -= 1700 * dt;
            c.vx *= Math.exp(-1.7 * dt);
            c.vy *= Math.exp(-1.7 * dt);
            c.rot += c.spin * dt;
            if (c.z <= 0) {
                c.z = 0;
                if (c.vz < -90 && c.bounces < 2) {
                    c.vz *= -0.32;
                    c.vx *= 0.55;
                    c.vy *= 0.55;
                    c.bounces++;
                    if (Math.random() < 0.45)
                        this.dust(c.x, c.y, 2, 50, 0.48);
                }
                else {
                    c.vz = 0;
                    c.vx *= 0.72;
                    c.vy *= 0.72;
                    c.spin *= 0.8;
                }
            }
        }
        for (let i = this.puffs.length - 1; i >= 0; i--) {
            const p = this.puffs[i];
            p.age += dt;
            if (p.age > p.life) {
                this.puffs.splice(i, 1);
                continue;
            }
            // Curl and buoyancy keep dust billowing instead of translating rigidly.
            p.vx += Math.sin(p.y * 0.023 + this.clock * 2.3 + p.seed) * 28 * dt;
            p.vy -= 25 * dt;
            p.x += p.vx * dt;
            p.y += p.vy * dt;
            p.rot += p.spin * dt;
            p.vx *= Math.exp(-2.5 * dt);
            p.vy *= Math.exp(-2.2 * dt);
            p.size *= 1 + (p.grow - 1) * dt;
        }
    }
    drawGround(ctx) {
        if (!this.assets)
            return;
        const img = this.assets.fracture;
        for (const m of this.marks) {
            const fade = clamp((m.life - m.age) / Math.min(1.1, m.life * 0.35), 0, 1);
            const grow = Math.min(1, m.age * 9);
            ctx.save();
            ctx.translate(m.x, m.y);
            ctx.rotate(m.rot);
            ctx.globalAlpha = m.alpha * fade;
            ctx.drawImage(img, -m.r * grow, -m.r * 0.66 * grow, m.r * 2 * grow, m.r * 1.32 * grow);
            ctx.restore();
        }
        // A real wake is the ground disappearing into blown dust, not a curved line.
        for (const w of this.wakes) {
            const k = 1 - w.age / w.life;
            const tex = (0, textures_1.smokeTex)(w.cool ? '#728287' : '#9e9180', 2);
            ctx.save();
            ctx.translate(w.x, w.y + 23);
            ctx.rotate(w.angle);
            ctx.globalAlpha = k * 0.58;
            ctx.drawImage(tex, -w.length, -w.width, w.length * 2, w.width * 2);
            ctx.restore();
        }
    }
    drawWorld(ctx) {
        if (!this.assets)
            return;
        // Painter's order: low formations first; airborne fragments land in front.
        for (const f of [...this.formations].sort((a, b) => a.y - b.y)) {
            if (f.age < 0)
                continue;
            const rise = 1 - Math.pow(1 - clamp(f.age / 0.18, 0, 1), 3);
            const fall = clamp((f.life - f.age) / 0.48, 0, 1);
            const h = f.height * rise * Math.min(1, fall * 1.3);
            const w = f.size;
            const img = f.variant === 0 ? this.assets.rock : this.assets.rubble;
            ctx.save();
            ctx.globalAlpha = Math.min(1, fall * 2);
            ctx.fillStyle = 'rgba(5,3,2,0.34)';
            ctx.beginPath();
            ctx.ellipse(f.x + h * 0.18, f.y + 8, w * 0.42, w * 0.16, 0, 0, TAU);
            ctx.fill();
            ctx.translate(f.x, f.y + (1 - rise) * h * 0.55);
            ctx.rotate(f.lean * 0.32);
            ctx.drawImage(img, -w * 0.5, -h, w, h);
            ctx.restore();
        }
        for (const c of this.chunks) {
            const fade = clamp((c.life - c.age) / 0.5, 0, 1);
            const size = c.size;
            ctx.save();
            ctx.globalAlpha = fade;
            ctx.fillStyle = 'rgba(0,0,0,0.32)';
            const shadowScale = 1 - clamp(c.z / 500, 0, 0.65);
            ctx.beginPath();
            ctx.ellipse(c.x + c.z * 0.12, c.y + size * 0.2, size * shadowScale, size * 0.3 * shadowScale, 0, 0, TAU);
            ctx.fill();
            ctx.translate(c.x, c.y - c.z);
            ctx.rotate(c.rot);
            ctx.drawImage(this.assets.rubble, -size * 0.52, -size * 0.52, size * 1.04, size * 1.04);
            ctx.restore();
        }
    }
    drawAtmosphere(ctx) {
        if (!this.assets)
            return;
        // Dust is alpha-blended on top, so it can actually occlude rocks and fists.
        for (const p of this.puffs) {
            const t = p.age / p.life;
            const alpha = Math.min(1, t * 7) * Math.pow(1 - t, 1.45) * 0.57;
            ctx.save();
            ctx.globalAlpha = alpha;
            ctx.translate(p.x, p.y);
            ctx.rotate(p.rot);
            const img = (0, textures_1.smokeTex)(p.color, p.seed);
            ctx.drawImage(img, -p.size, -p.size, p.size * 2, p.size * 2);
            ctx.restore();
        }
    }
}
exports.MaterialFX = MaterialFX;

},
'src/game/engine.ts': function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Engine = void 0;
const skills_1 = require("./skills");
const sprites_1 = require("./sprites");
const vfx_1 = require("./vfx");
const post_1 = require("./post");
const materialFx_1 = require("./materialFx");
const fluid_1 = require("./fx/fluid");
const fire_1 = require("./fx/fire");
const lightning_1 = require("./fx/lightning");
const textures_1 = require("./fx/textures");
/* character layout (3/4 top-down, body always upright like the key art) */
const BODY_H = 124; // on-screen height of the body sprite
const BODY_FOOT = 34; // sprite bottom sits this far below p.y
const SHOULDER_X = 46; // glove anchor offset left/right of centre
const SHOULDER_Y = -10; // glove anchor height (chest line)
const GLOVE_SIZE = 70; // glove sprite max dimension
const GLOVE_ROT = (Math.PI * 3) / 4; // sprite fist points up-left → align to +x
/* ------------------------------------------------------------------ utils */
const TAU = Math.PI * 2;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;
const rand = (a, b) => a + Math.random() * (b - a);
const easeOutQuart = (t) => 1 - Math.pow(1 - t, 4);
const easeInOut = (t) => (t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2);
function angDiff(a, b) {
    let d = (b - a) % TAU;
    if (d > Math.PI)
        d -= TAU;
    if (d < -Math.PI)
        d += TAU;
    return d;
}
const angLerp = (a, b, t) => a + angDiff(a, b) * clamp(t, 0, 1);
const ARENA_R = 920;
class Engine {
    constructor(canvas, opts) {
        this.raf = 0;
        this.lastTs = 0;
        this.ro = null;
        this.sprites = null;
        this.paused = false;
        this.w = 960;
        this.h = 640;
        this.time = 0;
        this.fpsEma = 60;
        /* camera */
        this.cam = { x: 0, y: 0, shakeT: 0, shakeMag: 0 };
        this.camZoom = 0.5;
        this.camZoomBase = 0.5;
        // Idle-only visual adjustments: never alter hitboxes, projectiles or attack timing.
        // Owner-approved GOLD idle stance (exact exported L/R pose; gameplay ownership unchanged).
        this.idlePose = {
            L: { x: 2, y: -12, rot: 39, flip: false, layer: 'front' },
            R: { x: -4, y: 24, rot: -24, flip: false, layer: 'front' },
            front: 'L', holdMotion: false, swapSides: false
        };
        this.idleEditMode = false;
        this.idleDrag = null;
        this.onIdlePoseChange = null;
        /* input */
        this.keys = new Set();
        this.mouse = { x: 480, y: 320, wx: 0, wy: 0, down: false };
        /* player */
        this.player = {
            x: 0, y: 120, vx: 0, vy: 0, r: 34,
            aim: -Math.PI / 2, bodyAngle: -Math.PI / 2,
            hp: 1000, maxHp: 1000, z: 0,
            dashT: 0, dashCd: 0, dashDir: 0, invulnT: 0,
            castLockT: 0, guardT: 0, counterDone: false,
            cycloneT: 0, cycloneTick: 0, spinA: 0,
            orbitT: 0, orbitA: 0, fury: 0, empoweredT: 0,
            basicCd: 0, comboStep: 0, comboWinT: 0,
            flashT: 0, lastHurtT: -99, stepT: 0,
            faceX: 1, lean: 0, squashT: 0,
        };
        this.fx = new vfx_1.VFX();
        this.material = new materialFx_1.MaterialFX();
        this.fluid = new fluid_1.Fluid();
        this.fire = new fire_1.Fire(this.fluid);
        this.lightning = new lightning_1.Lightning();
        /** refractive pressure waves (world space) */
        this.pressure = [];
        this.view = { shX: 0, shY: 0 };
        this.post = new post_1.Post();
        this.dpr = 1;
        this.chroma = 0; // impact-driven RGB split
        this.radialAmt = 0; // radial streak blur (ultimate)
        this.tintCache = new Map();
        this.trailColor = '#fff1c2';
        this.afterColor = '#38e1ff';
        this.hands = {
            L: { t: -1, dur: 0.3, angle: 0, reach: 100, heavy: false, missing: false },
            R: { t: -1, dur: 0.3, angle: 0, reach: 100, heavy: false, missing: false },
        };
        this.leap = null;
        // Owner-approved rocket return catch motion: no new impact sprites.
        this.rocketCatch = null;
        this.rocketCatchApproach = 0;
        this.ultLockT = 0;
        this.slowmoT = 0;
        this.hitstopT = 0;
        /* world */
        this.enemies = [];
        this.particles = [];
        this.rings = [];
        this.arcs = [];
        this.texts = [];
        this.zones = [];
        this.projs = [];
        this.afters = [];
        this.timeline = [];
        this.ribbons = [];
        this.nextId = 1;
        this.banner = null;
        /* skill state */
        this.cds = new Map();
        this.castingName = null;
        /* stats */
        this.stats = {
            totalDamage: 0, hits: 0, combo: 0, comboT: 0, bestCombo: 0,
            maxHit: 0, kos: 0, dmgEvents: [],
        };
        this.logArr = [];
        this.logId = 1;
        this.ultKillFlag = false;
        /* audio */
        this.actx = null;
        this.lastSfx = 0;
        /* -------------------------------------------------------------- input */
        this.onKeyDown = (e) => {
            if (e.target instanceof Element && e.target.closest('input,select,textarea')) return;
            if (this.idleEditMode) return;
            if (e.repeat) {
                if (e.code === 'Space')
                    e.preventDefault();
                return;
            }
            this.keys.add(e.code);
            if (e.code === 'Space' || e.code.startsWith('Arrow'))
                e.preventDefault();
            if (e.code === 'Space' || e.code === 'ShiftLeft' || e.code === 'ShiftRight')
                this.dash();
            if (e.code === 'KeyP')
                this.paused = !this.paused;
            const digitMap = {
                Digit1: 0, Digit2: 1, Digit3: 2, Digit4: 3, Digit5: 4,
                Digit6: 5, Digit7: 6, Digit8: 7, Digit9: 8, Digit0: 9,
            };
            if (e.code in digitMap)
                this.castSkill(skills_1.SKILLS[digitMap[e.code]].id);
        };
        this.onKeyUp = (e) => this.keys.delete(e.code);
        this.onPointerMove = (e) => {
            const rect = this.canvas.getBoundingClientRect();
            this.mouse.x = e.clientX - rect.left;
            this.mouse.y = e.clientY - rect.top;
            if (this.idleEditMode && this.idleDrag) {
                const { hand, sx, sy, ox, oy } = this.idleDrag;
                this.idlePose[hand].x = clamp(Math.round(ox + (this.mouse.x - sx) / this.camZoom), -160, 160);
                this.idlePose[hand].y = clamp(Math.round(oy + (this.mouse.y - sy) / this.camZoom), -160, 160);
                this.onIdlePoseChange?.();
            }
        };
        this.onPointerDown = (e) => {
            if (this.idleEditMode) {
                if (e.button !== 0) return;
                this.onPointerMove(e);
                let closest = null, dist2 = Infinity;
                for (const hand of ['L', 'R']) {
                    if (this.hands[hand].missing || !this.glovePose(hand).idle) continue;
                    const pose = this.glovePose(hand), pt = this.toScreen(pose.x, pose.y);
                    const d2 = (this.mouse.x - pt.x) ** 2 + (this.mouse.y - pt.y) ** 2;
                    if (d2 < dist2) { closest = hand; dist2 = d2; }
                }
                if (closest && dist2 < Math.max(24, 48 * this.camZoom) ** 2) {
                    this.idleDrag = { hand: closest, sx: this.mouse.x, sy: this.mouse.y,
                        ox: this.idlePose[closest].x, oy: this.idlePose[closest].y };
                    this.canvas.setPointerCapture?.(e.pointerId);
                    e.preventDefault();
                }
                return;
            }
            this.initAudio();
            this.onPointerMove(e);
            if (e.button === 0) {
                this.mouse.down = true;
                this.basicAttack();
            }
            if (e.button === 2)
                this.dash();
        };
        this.onPointerUp = (e) => { if (e.button === 0) { this.mouse.down = false; this.idleDrag = null; } };
        this.onCtx = (e) => e.preventDefault();
        this.canvas = canvas;
        this.opts = { ...opts };
        this.ctx = canvas.getContext('2d');
        for (const s of skills_1.SKILLS)
            this.cds.set(s.id, 0);
        (0, sprites_1.loadSprites)().then((s) => { this.sprites = s; }).catch((error) => { console.error("BOXE SPRITES",error); });
        this.material.onFire = (x, y, w, h, life, power) => this.fire.column(x, y + 4, w, h, life, power);
        this.initRibbons();
        if (this.opts.visualOnly) return; // Integration-only: do not spawn, attach keys, or start a second rAF.
        this.attach();
        this.resize();
        // starter test setup
        this.spawn('dummy', 3);
        this.spawn('tank', 1);
        this.spawn('bot', 1);
        this.log('Phòng lab sẵn sàng — WASD di chuyển, chuột ngắm, 1–0 tung chiêu!', '#f6b73c');
        this.lastTs = performance.now();
        const loop = (ts) => {
            this.raf = requestAnimationFrame(loop);
            const rawDt = Math.min(0.05, (ts - this.lastTs) / 1000 || 0.016);
            this.lastTs = ts;
            this.fpsEma = lerp(this.fpsEma, 1 / Math.max(rawDt, 1e-4), 0.05);
            if (!this.paused)
                this.update(rawDt);
            this.render();
        };
        this.raf = requestAnimationFrame(loop);
    }
    destroy() {
        cancelAnimationFrame(this.raf);
        this.detach();
        this.ro?.disconnect();
    }
    /* -------------------------------------------------------------- public */
    setOptions(o) { Object.assign(this.opts, o); }
    setPaused(v) { this.paused = v; }
    resetAll() {
        this.enemies = [];
        this.projs = [];
        this.timeline = [];
        this.zones = [];
        this.rocketCatch = null;
        this.rocketCatchApproach = 0;
        this.player.x = 0;
        this.player.y = 120;
        this.player.vx = this.player.vy = 0;
        this.player.hp = this.player.maxHp;
        this.player.cycloneT = 0;
        this.ultLockT = 0;
        this.leap = null;
        this.fx.clear();
        this.material.clear();
        this.fluid.clear();
        this.fire.clear();
        this.lightning.clear();
        this.pressure = [];
        this.afters = [];
        this.hands.L.missing = this.hands.R.missing = false;
        for (const s of skills_1.SKILLS)
            this.cds.set(s.id, 0);
        this.stats = { totalDamage: 0, hits: 0, combo: 0, comboT: 0, bestCombo: 0, maxHit: 0, kos: 0, dmgEvents: [] };
        this.resetRibbons();
        this.spawn('dummy', 3);
        this.spawn('tank', 1);
        this.spawn('bot', 1);
        this.log('Đã reset phòng lab.', '#a1a1aa');
    }
    clearEnemies() {
        this.enemies = [];
        this.log('Đã dọn sạch mục tiêu.', '#a1a1aa');
    }
    spawn(kind, count) {
        const names = { dummy: 'Bao cát gỗ', bot: 'Robot đấu tập', tank: 'Bao cát Tank', boss: 'BOSS Trùm bao cát' };
        for (let i = 0; i < count; i++) {
            const a = rand(0, TAU);
            const d = rand(240, 430);
            let x = clamp(this.player.x + Math.cos(a) * d, -ARENA_R + 80, ARENA_R - 80);
            let y = clamp(this.player.y + Math.sin(a) * d, -ARENA_R + 80, ARENA_R - 80);
            if (kind === 'boss') {
                x = this.player.x + 320;
                y = this.player.y - 240;
            }
            const base = {
                dummy: { hp: 650, r: 36 }, bot: { hp: 480, r: 34 },
                tank: { hp: 4200, r: 54 }, boss: { hp: 16000, r: 76 },
            }[kind];
            this.enemies.push({
                id: this.nextId++, kind, x, y, vx: 0, vy: 0,
                r: base.r, hp: base.hp, maxHp: base.hp,
                angle: Math.PI / 2, flash: 0, wob: 0, wobV: 0, z: 0, vz: 0,
                shootT: rand(1, 2), strafeDir: Math.random() < 0.5 ? -1 : 1, strafeT: rand(1.5, 3),
                orbitHitAt: 0, slowT: 0, dead: false,
            });
        }
        this.log(`Đã thả ×${count} ${names[kind]}`, '#7dd3fc');
    }
    attach() {
        window.addEventListener('keydown', this.onKeyDown);
        window.addEventListener('keyup', this.onKeyUp);
        this.canvas.addEventListener('pointermove', this.onPointerMove);
        this.canvas.addEventListener('pointerdown', this.onPointerDown);
        window.addEventListener('pointerup', this.onPointerUp);
        this.canvas.addEventListener('contextmenu', this.onCtx);
        this.ro = new ResizeObserver(() => this.resize());
        if (this.canvas.parentElement)
            this.ro.observe(this.canvas.parentElement);
    }
    detach() {
        window.removeEventListener('keydown', this.onKeyDown);
        window.removeEventListener('keyup', this.onKeyUp);
        this.canvas.removeEventListener('pointermove', this.onPointerMove);
        this.canvas.removeEventListener('pointerdown', this.onPointerDown);
        window.removeEventListener('pointerup', this.onPointerUp);
        this.canvas.removeEventListener('contextmenu', this.onCtx);
    }
    resize() {
        const parent = this.canvas.parentElement;
        if (!parent)
            return;
        const dpr = Math.min(2, window.devicePixelRatio || 1);
        this.w = parent.clientWidth;
        this.h = parent.clientHeight;
        this.canvas.width = Math.max(2, Math.floor(this.w * dpr));
        this.canvas.height = Math.max(2, Math.floor(this.h * dpr));
        this.canvas.style.width = `${this.w}px`;
        this.canvas.style.height = `${this.h}px`;
        this.dpr = dpr;
        this.dpr = dpr;
        this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
    /* -------------------------------------------------------------- audio */
    initAudio() {
        // Battle-only Gold presentation has no audio ownership. The base Gold
        // VFX/motion methods remain intact; semantic SFX come from APEX once
        // owner supplies them, and this visual-only library never starts an
        // AudioContext outside the shared music / UI-SFX authorities.
        return;
    }
    sfx(kind, power = 1) {
        if (globalThis.APEX_OWNER_TOOLS?.isPortraitStudio?.()) return;
        if (!this.opts.sound || !this.actx)
            return;
        const now = performance.now();
        if (now - this.lastSfx < 35)
            return;
        this.lastSfx = now;
        const ac = this.actx;
        const t = ac.currentTime;
        const master = ac.createGain();
        master.gain.value = 0.16 * power;
        master.connect(ac.destination);
        const noiseBuf = ac.createBuffer(1, ac.sampleRate * 0.3, ac.sampleRate);
        const nd = noiseBuf.getChannelData(0);
        for (let i = 0; i < nd.length; i++)
            nd[i] = Math.random() * 2 - 1;
        const noise = (freq, q, dur, type = 'lowpass') => {
            const src = ac.createBufferSource();
            src.buffer = noiseBuf;
            const f = ac.createBiquadFilter();
            f.type = type;
            f.frequency.value = freq;
            f.Q.value = q;
            const g = ac.createGain();
            g.gain.setValueAtTime(1, t);
            g.gain.exponentialRampToValueAtTime(0.001, t + dur);
            src.connect(f);
            f.connect(g);
            g.connect(master);
            src.start(t);
            src.stop(t + dur);
        };
        const tone = (f0, f1, dur, type, vol = 1) => {
            const o = ac.createOscillator();
            o.type = type;
            o.frequency.setValueAtTime(f0, t);
            o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
            const g = ac.createGain();
            g.gain.setValueAtTime(vol, t);
            g.gain.exponentialRampToValueAtTime(0.001, t + dur);
            o.connect(g);
            g.connect(master);
            o.start(t);
            o.stop(t + dur);
        };
        switch (kind) {
            case 'punch':
                noise(900, 0.6, 0.09);
                tone(160, 45, 0.1, 'sine', 0.9);
                break;
            case 'whoosh':
                noise(1800, 1.4, 0.14, 'bandpass');
                break;
            case 'zap':
                tone(880, 160, 0.09, 'sawtooth', 0.4);
                noise(3200, 2, 0.07, 'highpass');
                break;
            case 'boom':
                noise(420, 0.4, 0.34);
                tone(110, 28, 0.32, 'sine', 1.1);
                break;
            case 'shield':
                tone(520, 980, 0.16, 'triangle', 0.5);
                break;
            case 'rocket':
                noise(700, 0.8, 0.4);
                tone(220, 660, 0.35, 'sawtooth', 0.25);
                break;
        }
    }
    /* -------------------------------------------------------------- cloth */
    initRibbons() {
        const mk = (n, rest, width, side, back, palette, tip) => ({
            pts: Array.from({ length: n }, () => ({ x: 0, y: 130, px: 0, py: 130 })),
            rest, width, side, back, palette, tip,
        });
        this.ribbons = [
            mk(11, 8.5, 20, -17, 12, ['#e8232a', '#f5efe2', '#e8232a', '#f5efe2'], '#f6b73c'),
            mk(11, 8.5, 20, 17, 12, ['#f5efe2', '#e8232a', '#f5efe2', '#e8232a'], '#f6b73c'),
            mk(9, 7.5, 12, 0, 16, ['#1c1c22', '#2b2b33'], '#e8232a'),
            mk(8, 7, 10, -28, 4, ['#e8232a', '#c01420'], '#f6b73c'),
            mk(8, 7, 10, 28, 4, ['#f5efe2', '#e8ddc8'], '#e8232a'),
        ];
        this.resetRibbons();
    }
    resetRibbons() {
        for (const r of this.ribbons) {
            for (const p of r.pts) {
                p.x = this.player.x;
                p.y = this.player.y + 10;
                p.px = p.x;
                p.py = p.y;
            }
        }
    }
    ribbonAnchor(r) {
        // upright 3/4 body: tails hang from the back hem of the cloak
        const p = this.player;
        if (p.cycloneT > 0) {
            const a = p.spinA + r.side * 0.06;
            return { x: p.x + Math.cos(a) * 26, y: p.y + 8 + Math.sin(a) * 14 - p.z };
        }
        return {
            x: p.x + r.side * 1.15 * p.faceX - Math.cos(p.aim) * 6,
            y: p.y + 6 + r.back * 0.5 - p.z,
        };
    }
    updateRibbons(dt) {
        const soft = this.opts.clothSoft;
        const damping = lerp(0.9, 0.982, soft);
        const iterations = Math.round(lerp(5, 2, soft));
        const windX = this.opts.wind * 130 + Math.sin(this.time * 1.9) * 16;
        const windY = Math.cos(this.time * 1.6) * 12 + 62; // gravity: tails hang below the cloak
        for (const r of this.ribbons) {
            const anchor = this.ribbonAnchor(r);
            const pts = r.pts;
            pts[0].x = anchor.x;
            pts[0].y = anchor.y;
            pts[0].px = anchor.x;
            pts[0].py = anchor.y;
            for (let i = 1; i < pts.length; i++) {
                const p = pts[i];
                let vx = (p.x - p.px) * damping;
                let vy = (p.y - p.py) * damping;
                // swirl force while cycloning — the scarf becomes a spiral
                if (this.player.cycloneT > 0) {
                    const dx = p.x - this.player.x, dy = p.y - this.player.y;
                    const d = Math.max(30, Math.hypot(dx, dy));
                    vx += (-dy / d) * 640 * dt;
                    vy += (dx / d) * 640 * dt;
                }
                // flutter wave travelling down the tail + outward splay like the key art
                const sway = Math.sin(this.time * 3.1 + i * 0.7 + r.side) * 22 + r.side * 1.8 * this.player.faceX;
                p.px = p.x;
                p.py = p.y;
                p.x += vx + (windX + sway) * dt * dt * 60;
                p.y += vy + windY * dt * dt * 60;
            }
            for (let k = 0; k < iterations; k++) {
                pts[0].x = anchor.x;
                pts[0].y = anchor.y;
                for (let i = 0; i < pts.length - 1; i++) {
                    const a = pts[i], b = pts[i + 1];
                    let dx = b.x - a.x, dy = b.y - a.y;
                    const d = Math.hypot(dx, dy) || 0.001;
                    const diff = (d - r.rest) / d;
                    if (i === 0) {
                        b.x -= dx * diff;
                        b.y -= dy * diff;
                    }
                    else {
                        a.x += dx * diff * 0.5;
                        a.y += dy * diff * 0.5;
                        b.x -= dx * diff * 0.5;
                        b.y -= dy * diff * 0.5;
                    }
                }
                // keep the cloth out of the body
                const cy = this.player.y - 30 - this.player.z;
                for (let i = 2; i < pts.length; i++) {
                    const p = pts[i];
                    const dx = p.x - this.player.x, dy = p.y - cy;
                    const d = Math.hypot(dx, dy);
                    const min = 36;
                    if (d < min && d > 0.01) {
                        p.x = this.player.x + (dx / d) * min;
                        p.y = cy + (dy / d) * min;
                    }
                }
            }
        }
    }
    /* -------------------------------------------------------------- combat helpers */
    log(msg, color = '#e4e4e7') {
        this.logArr.unshift({ id: this.logId++, msg, color });
        if (this.logArr.length > 30)
            this.logArr.pop();
    }
    shake(mag) {
        this.cam.shakeMag = Math.max(this.cam.shakeMag, mag * this.opts.shake);
        this.cam.shakeT = 0.35;
    }
    /** camera punch-in on impact — sells weight far more than shake alone */
    kickZoom(a) {
        const base = this.camZoomBase || 0.5;
        this.camZoom = Math.min(base * 1.085, Math.max(this.camZoom, base * (1 + a * this.opts.shake)));
    }
    /** refractive pressure wave; r1 = final radius, strength = lens magnification */
    wave(x, y, r1, strength = 0.06, life = 0.34) {
        this.pressure.push({ x, y, r: 6, r1, life, max: life, strength });
        if (this.pressure.length > 14)
            this.pressure.shift();
        this.fluid.burst(x, y, r1 * 0.7, strength * 60);
    }
    /**
     * The full contact package every melee hit funnels through: hot contact
     * star, light fan, directional sparks, physical debris, billowing smoke,
     * a bounce-light pool on the floor and an RGB-split kick.
     */
    impactPackage(x, y, angle, color, power = 1, groundY = y + 30) {
        this.fx.impact(x, y, angle, color, power);
        this.wave(x, groundY, 120 * power, 0.035 + power * 0.02, 0.3 + power * 0.05);
        this.fluid.addSmoke(x, groundY, 40 * power, 0.5 * power, 0.25);
        this.fluid.addForce(x, y, 50 * power, Math.cos(angle) * 40 * power, Math.sin(angle) * 20 * power);
        for (let i = 0; i < Math.round(6 * power); i++) {
            const a = angle + rand(-1.3, 1.3);
            this.fx.addSpark(x, y, a, rand(340, 900) * power, Math.random() < 0.3 ? '#ffffff' : color, rand(1.5, 3.2) * power, rand(0.25, 0.55), groundY);
        }
        this.material.throwRubble(x, groundY, Math.round(3 + power * 3), 230 + power * 110, 0.6 + power * 0.26, angle);
        for (let i = 0; i < Math.round(2 + power * 3); i++) {
            this.fx.addSmoke(x + rand(-12, 12), y + rand(-8, 8), Math.cos(angle) * rand(40, 140), rand(-40, 30), rand(16, 30) * power, rand(0.5, 0.95), '#8d8579', false);
        }
        for (let i = 0; i < Math.round(3 * power); i++)
            this.fx.addEmber(x, y, color, 150);
        this.fx.pool(x, groundY, 60 * power, color, 0.3);
        this.dustPuff(x, groundY, 0.6 + power * 0.5);
        this.chroma = Math.max(this.chroma, Math.min(0.9, power * 0.34));
    }
    /** soft dust cloud — reads as real material, unlike flat circles */
    dustPuff(x, y, power = 1, color = '#c9b694') {
        const n = Math.round(3 + power * 4);
        for (let i = 0; i < n; i++) {
            if (this.particles.length > 950)
                this.particles.shift();
            const a = rand(0, TAU), s = rand(30, 170) * power;
            this.particles.push({
                x: x + rand(-14, 14), y: y + rand(-10, 10),
                vx: Math.cos(a) * s, vy: Math.sin(a) * s * 0.45 - rand(10, 60),
                life: rand(0.55, 1), maxLife: 1, size: rand(11, 24) * (0.65 + power * 0.35),
                color, kind: 'dust', rot: 0, vr: 0, drag: 2.7, grav: -26,
            });
        }
    }
    hitstop(t) {
        if (this.opts.hitstop)
            this.hitstopT = Math.max(this.hitstopT, t);
    }
    addText(x, y, text, color, size = 17) {
        if (!this.opts.showDamage && size < 30)
            return;
        this.texts.push({ x: x + rand(-8, 8), y, life: 0.85, maxLife: 0.85, text, color, size });
    }
    ring(x, y, color, vr = 420, width = 5, life = 0.38) {
        this.rings.push({ x, y, r: 8, vr, life, maxLife: life, color, width });
    }
    arc(x1, y1, x2, y2, color = '#ffd23c', width = 3) {
        const len = Math.hypot(x2 - x1, y2 - y1);
        this.lightning.strike(x1, y1, x2, y2, color, width, { branches: len > 120 ? 3 : 1, life: 0.3, crawl: 26 });
        this.fx.flash(x2, y2, 40, color, 0.1);
    }
    tinted(img, key, color) {
        const k = `${key}|${color}`;
        let c = this.tintCache.get(k);
        if (!c) {
            c = (0, sprites_1.tint)(img, color);
            this.tintCache.set(k, c);
        }
        return c;
    }
    /** directional sparks spraying along the hit direction */
    sparkCone(x, y, angle, n, colors, speed = 520, spread = 0.6, size = 4) {
        for (let i = 0; i < n; i++) {
            if (this.particles.length > 950)
                this.particles.shift();
            const a = angle + rand(-spread, spread), s = rand(speed * 0.35, speed);
            this.particles.push({
                x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s,
                life: rand(0.18, 0.4), maxLife: 0.4, size: rand(size * 0.6, size * 1.4),
                color: colors[(Math.random() * colors.length) | 0],
                kind: 'spark', rot: 0, vr: 0, drag: 4, grav: 0,
            });
        }
    }
    burst(x, y, n, colors, kind, speed = 260, size = 4, life = 0.5) {
        for (let i = 0; i < n; i++) {
            if (this.particles.length > 950)
                this.particles.shift();
            const a = rand(0, TAU), s = rand(speed * 0.25, speed);
            this.particles.push({
                x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s,
                life: rand(life * 0.5, life), maxLife: life,
                size: rand(size * 0.5, size * 1.4),
                color: colors[(Math.random() * colors.length) | 0],
                kind, rot: rand(0, TAU), vr: rand(-9, 9),
                drag: kind === 'smoke' ? 1.4 : 3.2, grav: 0,
            });
        }
    }
    after(x, y, angle, kind = 'body', color = this.afterColor, mirror = false) {
        if (!this.opts.afterimage)
            return;
        if (this.afters.length > 70)
            this.afters.shift();
        const life = kind === 'body' ? 0.34 : 0.16;
        this.afters.push({ kind, x, y, angle, life, maxLife: life, color, sx: this.player.faceX, mirror });
    }
    damageEnemy(e, raw, o = {}) {
        if (e.dead)
            return 0;
        const p = this.player;
        let dmg = raw * this.opts.damageScale * (p.empoweredT > 0 ? 1.25 : 1);
        dmg = Math.round(dmg * rand(0.92, 1.08));
        e.hp -= dmg;
        e.flash = 1;
        e.wobV += rand(6, 11);
        if (o.kx || o.ky) {
            e.vx += (o.kx ?? 0);
            e.vy += (o.ky ?? 0);
        }
        if (o.knockup) {
            e.vz = Math.max(e.vz, o.knockup);
        }
        // stats
        this.stats.totalDamage += dmg;
        this.stats.hits++;
        this.stats.combo++;
        this.stats.comboT = 2.6;
        this.stats.bestCombo = Math.max(this.stats.bestCombo, this.stats.combo);
        this.stats.maxHit = Math.max(this.stats.maxHit, dmg);
        this.stats.dmgEvents.push({ t: this.time, dmg });
        p.fury = Math.min(100, p.fury + 3.5);
        if (!o.quiet) {
            this.addText(e.x, e.y - e.r - 14 - e.z, `${dmg}`, o.color ?? (dmg >= 120 ? '#ffd23c' : '#ffffff'), o.size ?? (dmg >= 120 ? 23 : 16));
            // Contact light, grit and stone travel in the same direction as the punch.
            const ha = (o.kx || o.ky) ? Math.atan2(o.ky ?? 0, o.kx ?? 0) : Math.atan2(e.y - p.y, e.x - p.x);
            const ix = e.x - Math.cos(ha) * e.r * 0.55, iy = e.y - e.z - 18 - Math.sin(ha) * e.r * 0.4;
            const big = clamp(dmg / 90, 0.55, 2.2);
            const col = o.color && o.color !== '#ffffff' ? o.color : '#ffd23c';
            this.fx.impact(ix, iy, ha, col, big);
            this.fluid.addForce(ix, iy, 36 + big * 18, Math.cos(ha) * 30 * big, Math.sin(ha) * 14 * big);
            this.fluid.addSmoke(e.x, e.y + e.r * 0.5, 26 + big * 12, 0.16 * big, 0.2);
            if (dmg >= 100)
                this.wave(e.x, e.y + e.r * 0.5, 110 + big * 40, 0.03 + big * 0.015, 0.3);
            this.sparkCone(ix, iy, ha, Math.round(6 + big * 6), ['#ffffff', col, '#ff7a3c'], 420 + big * 160, 0.55, 4);
            this.dustPuff(ix, iy, 0.6 + big * 0.4);
            this.material.throwRubble(ix, e.y + e.r * 0.5, dmg >= 100 ? 4 : 2, 170 + big * 80, 0.46 + big * 0.13, ha);
            this.material.dust(e.x, e.y + e.r * 0.6, dmg >= 100 ? 5 : 2, 90 + big * 30, 0.55);
            if (dmg >= 100) {
                this.fx.shock(e.x, e.y + e.r * 0.6, 90 + big * 40, col, 6, 0.32);
                this.material.throwRubble(ix, e.y + e.r * 0.5, 4, 290, 0.65, ha);
                this.dustPuff(ix, iy + 16, 1.1);
                this.kickZoom(dmg >= 200 ? 0.055 : 0.03);
                this.chroma = Math.max(this.chroma, dmg >= 200 ? 0.85 : 0.4);
                if (dmg >= 200) {
                    this.fx.screenFlash(col, 0.1, 0.16);
                    this.fx.speedLines(0.12, col);
                }
            }
            else {
                this.kickZoom(0.012);
            }
        }
        if (e.hp <= 0) {
            this.stats.kos++;
            p.fury = Math.min(100, p.fury + 10);
            this.ultKillFlag = true;
            this.addText(e.x, e.y - e.r - 40 - e.z, 'K.O.!', '#ffd23c', 30);
            this.material.throwRubble(e.x, e.y + e.r * 0.5, 12, 450, 0.8);
            this.material.dust(e.x, e.y + e.r * 0.6, 11, 240, 1);
            this.ring(e.x, e.y, '#ffd23c', 520, 6);
            if (this.opts.infiniteDummyHp && e.kind !== 'bot') {
                e.hp = e.maxHp;
                e.vx *= -0.4;
                e.vy *= -0.4;
            }
            else {
                e.dead = true;
                this.burst(e.x, e.y, 22, ['#a1a1aa', '#52525b', '#f6b73c'], 'smoke', 200, 8, 0.8);
            }
        }
        return dmg;
    }
    /** melee hit in a cone in front of the player */
    hitCone(angle, range, half, dmg, kb = 160, knockup = 0) {
        const p = this.player;
        const hit = [];
        for (const e of this.enemies) {
            if (e.dead)
                continue;
            const dx = e.x - p.x, dy = e.y - p.y;
            const d = Math.hypot(dx, dy);
            if (d > range + e.r)
                continue;
            if (d > 30 && Math.abs(angDiff(angle, Math.atan2(dy, dx))) > half)
                continue;
            const dealt = this.damageEnemy(e, dmg, {
                kx: Math.cos(angle) * kb, ky: Math.sin(angle) * kb, knockup,
                color: dmg >= 100 ? '#ffd23c' : '#ffffff', size: dmg >= 100 ? 22 : 16,
            });
            if (dealt > 0)
                hit.push(e);
        }
        if (hit.length) {
            this.sfx('punch', clamp(0.7 + dmg / 120, 0.7, 1.6));
        }
        return hit;
    }
    hitCircle(x, y, r, dmg, o = {}) {
        const hit = [];
        for (const e of this.enemies) {
            if (e.dead)
                continue;
            const dx = e.x - x, dy = e.y - y;
            const d = Math.hypot(dx, dy);
            if (d > r + e.r)
                continue;
            const kb = o.kb ?? 200;
            this.damageEnemy(e, dmg, {
                kx: d > 1 ? (dx / d) * kb : 0, ky: d > 1 ? (dy / d) * kb : 0,
                knockup: o.knockup ?? 0, color: o.color ?? '#ffd23c', size: dmg >= 150 ? 25 : 19,
            });
            hit.push(e);
        }
        if (hit.length)
            this.sfx('punch', 1.2);
        return hit;
    }
    startPunch(hand, angle, reach, dur, heavy = false) {
        const h = this.hands[hand];
        if (h.missing)
            hand = hand === 'L' ? 'R' : 'L';
        const hh = this.hands[hand];
        hh.t = 0;
        hh.dur = dur;
        hh.angle = angle;
        hh.reach = reach;
        hh.heavy = heavy;
        this.sfx('whoosh', heavy ? 1.1 : 0.7);
    }
    schedule(t, fn) { this.timeline.push({ t, fn }); }
    teleport(x, y, color = '#b78bff') {
        const p = this.player;
        const tx = clamp(x, -ARENA_R + 40, ARENA_R - 40);
        const ty = clamp(y, -ARENA_R + 40, ARENA_R - 40);
        const travelAngle = Math.atan2(ty - p.y, tx - p.x);
        this.material.slide(p.x, p.y, travelAngle, true, true);
        for (let i = 0; i < 5; i++) {
            const t = i / 5;
            this.after(lerp(p.x, tx, t), lerp(p.y, ty, t), 0, 'body', color);
        }
        const a = Math.atan2(ty - p.y, tx - p.x);
        this.fx.flash(p.x, p.y - 30, 76, color, 0.22);
        this.fx.shock(p.x, p.y + 30, 80, color, 5, 0.3);
        this.fx.streakCone(lerp(p.x, tx, 0.5), lerp(p.y, ty, 0.5) - 30, a, 7, color, 0.06, 1500, 120);
        // move cloth with the body so it keeps its flow instead of snapping
        const dx = tx - p.x, dy = ty - p.y;
        for (const r of this.ribbons)
            for (const pt of r.pts) {
                pt.x += dx;
                pt.y += dy;
                pt.px += dx;
                pt.py += dy;
            }
        p.x = tx;
        p.y = ty;
        p.vx = 0;
        p.vy = 0;
        this.material.slide(tx, ty, travelAngle, false, true);
        this.fx.flash(tx, ty - 30, 84, color, 0.22);
        this.burst(tx, ty - 20, 12, [color, '#ffffff'], 'spark', 260, 4, 0.35);
    }
    /** where a punch of given reach lands (chest height, on the aim line) */
    punchTip(angle, reach) {
        const p = this.player;
        return { x: p.x + Math.cos(angle) * (reach + 28), y: p.y + SHOULDER_Y - p.z + Math.sin(angle) * (reach + 28) };
    }
    ghostFist(x, y, angle, color, s0, s1, dist, life = 0.26, alpha = 0.75) {
        if (!this.sprites)
            return;
        this.fx.ghost(this.tinted(this.sprites.glove, 'glove', color), x, y, angle, GLOVE_ROT, s0, s1, dist, life, alpha, Math.random() < 0.5);
    }
    /* -------------------------------------------------------------- skills */
    castSkill(id) {
        if (this.paused)
            return;
        const def = skills_1.SKILLS.find((s) => s.id === id);
        if (!def)
            return;
        if ((this.cds.get(id) ?? 0) > 0)
            return;
        const p = this.player;
        if (this.leap || this.ultLockT > 0)
            return;
        let ok = true;
        switch (id) {
            case 'jab':
                this.skillJab();
                break;
            case 'rocket':
                ok = this.skillRocket();
                break;
            case 'uppercut':
                this.skillUppercut();
                break;
            case 'cyclone':
                if (p.cycloneT > 0)
                    return;
                this.skillCyclone();
                break;
            case 'phantom':
                this.skillPhantom();
                break;
            case 'meteor':
                this.skillMeteor();
                break;
            case 'orbit':
                this.skillOrbit();
                break;
            case 'wave':
                this.skillWave();
                break;
            case 'counter':
                this.skillCounter();
                break;
            case 'ult':
                ok = this.skillUlt();
                break;
        }
        if (!ok)
            return;
        this.cds.set(id, this.opts.noCooldown ? Math.min(0.35, def.cd) : def.cd);
        this.castingName = def.name;
        this.log(`Dùng chiêu: ${def.name}`, def.color);
    }
    skillJab() {
        const p = this.player;
        p.castLockT = Math.max(p.castLockT, 0.35);
        this.trailColor = '#ffe066';
        this.fx.flash(p.x, p.y - 20, 70, '#ffe066', 0.2);
        for (let i = 0; i < 6; i++) {
            const hand = i % 2 === 0 ? 'L' : 'R';
            const last = i === 5;
            this.schedule(i * 0.085, () => {
                const a = p.aim + rand(-0.07, 0.07);
                const reach = last ? 122 : 104;
                this.startPunch(hand, a, reach, 0.17, last);
                this.schedule(0.05, () => {
                    const tip = this.punchTip(a, reach);
                    this.fx.streakCone(tip.x, tip.y, a, last ? 8 : 3, '#ffe066', 0.12, 1100, 70);
                    const ba = a + rand(-0.9, 0.9), bl = rand(34, 60);
                    this.lightning.strike(tip.x, tip.y, tip.x + Math.cos(ba) * bl, tip.y + Math.sin(ba) * bl, '#ffe066', 1.4, { branches: 1, life: 0.16, rough: 0.5 });
                    if (last) {
                        this.ghostFist(tip.x, tip.y, a, '#ffe066', 70, 130, 100, 0.24, 0.7);
                        this.material.fracture(tip.x, tip.y + 40, 54, 2, 0.62);
                        this.material.throwRubble(tip.x, tip.y + 40, 5, 270, 0.55, a);
                    }
                    const hits = this.hitCone(a, 205, 0.58, last ? 26 : 16, last ? 330 : 130);
                    if (hits.length) {
                        this.sfx('zap', 0.7);
                        const src = hits[0];
                        let best = null;
                        let bd = 190;
                        for (const e of this.enemies) {
                            if (e.dead || e === src)
                                continue;
                            const d = Math.hypot(e.x - src.x, e.y - src.y);
                            if (d < bd) {
                                bd = d;
                                best = e;
                            }
                        }
                        if (best) {
                            this.arc(src.x, src.y - src.z - 20, best.x, best.y - best.z - 20, '#ffe066', 3);
                            this.damageEnemy(best, 10, { color: '#ffe97a', size: 14 });
                        }
                        if (last) {
                            this.hitstop(0.05);
                            this.shake(4);
                        }
                    }
                });
            });
        }
    }
    skillRocket() {
        const p = this.player;
        if (this.hands.R.missing) {
            this.log('Găng phải chưa quay về!', '#f87171');
            return false;
        }
        this.hands.R.missing = true;
        this.hands.R.t = -1;
        this.rocketCatch = null;
        this.rocketCatchApproach = 0;
        const a = p.aim;
        const mx = p.x + SHOULDER_X * 0.6 + Math.cos(a) * 44;
        const my = p.y + SHOULDER_Y + Math.sin(a) * 44;
        this.projs.push({
            kind: 'rocket', x: p.x + Math.cos(a) * 40, y: p.y + Math.sin(a) * 40,
            vx: Math.cos(a) * 1250, vy: Math.sin(a) * 1250, angle: a,
            life: 3, traveled: 0, phase: 'out', hitSet: new Set(), src: null,
        });
        p.vx -= Math.cos(a) * 260;
        p.vy -= Math.sin(a) * 260;
        // muzzle blast
        this.fx.flash(mx, my, 120, '#ff7a3c', 0.26);
        this.fx.impact(mx, my, a, '#ff9f2e', 1.3);
        this.wave(p.x, p.y + 30, 150, 0.05, 0.3);
        this.sparkCone(mx, my, a + Math.PI, 14, ['#ffd23c', '#ff7a3c', '#ffffff'], 460, 0.55, 5);
        for (let i = 0; i < 8; i++)
            this.fx.addSmoke(mx + rand(-10, 10), my + rand(-8, 8), Math.cos(a + Math.PI) * rand(60, 200), rand(-50, 50), rand(18, 34), rand(0.7, 1.3), '#7d7568', false);
        for (let i = 0; i < 6; i++)
            this.fx.addEmber(mx, my, '#ff9f2e', 170);
        this.fx.pool(mx, my + 40, 110, '#ff7a3c', 0.4);
        this.fx.scorchMark(mx, my + 34, 46, 5);
        this.fire.column(mx, my + 18, 72, 180, 0.7, 1);
        this.material.fracture(mx, my + 36, 78, 4);
        this.material.throwRubble(mx, my + 28, 10, 270, 0.7, a + Math.PI);
        this.fx.streakCone(mx, my, a, 10, '#ffd23c', 0.1, 1500, 110);
        this.fx.screenFlash('#ff9f2e', 0.12, 0.12);
        this.sfx('rocket', 1.1);
        this.shake(5);
        return true;
    }
    skillUppercut() {
        const p = this.player;
        p.castLockT = Math.max(p.castLockT, 0.3);
        const a = p.aim;
        this.trailColor = '#ffb03c';
        this.startPunch('R', a, 118, 0.42, true);
        this.schedule(0.17, () => {
            const cx = p.x + Math.cos(a) * 92, cy = p.y + Math.sin(a) * 92;
            this.hitCircle(cx, cy, 128, 150, { kb: 330, knockup: 640, color: '#ffb03c' });
            // Stone and fire rise together, then broken pieces land separately.
            this.material.eruption(cx, cy + 20, 1.2, true);
            this.fire.column(cx, cy + 20, 104, 350, 1.4, 1.6);
            this.material.throwRubble(cx, cy + 18, 8, 350, 0.85);
            this.fx.impact(cx, cy - 34, -Math.PI / 2, '#ffb03c', 2.2);
            this.wave(cx, cy + 20, 200, 0.07, 0.4);
            this.ghostFist(cx, cy - 10, -Math.PI / 2, '#ffb03c', 80, 160, 130, 0.34, 0.8);
            for (let i = 0; i < 26; i++) {
                this.particles.push({
                    x: cx + rand(-50, 50), y: cy + rand(-10, 20), vx: rand(-60, 60), vy: rand(-420, -160),
                    life: rand(0.5, 1), maxLife: 1, size: rand(2, 5), color: Math.random() < 0.5 ? '#ffd23c' : '#ff7a3c',
                    kind: 'ember', rot: 0, vr: 0, drag: 1.5, grav: 0,
                });
            }
            for (let i = 0; i < 6; i++)
                this.fire.puff(cx + rand(-40, 40), cy + rand(-10, 10), 26, rand(-120, 120), -rand(80, 220), 1);
            this.shake(8);
            this.hitstop(0.07);
            this.sfx('boom', 0.9);
            for (let i = 0; i < 5; i++) {
                this.schedule(0.1 + i * 0.1, () => {
                    const pa = rand(0, TAU), pd = rand(20, 120);
                    const fx = cx + Math.cos(pa) * pd, fy = cy + Math.sin(pa) * pd;
                    this.zones.push({ x: fx, y: fy, r: 58, t: 0, dur: 0.55, kind: 'flame', pulsed: false });
                    this.fire.column(fx, fy, 42, 150, 0.85, 0.8);
                    this.material.fracture(fx, fy + 12, 45, 4.5, 0.75);
                });
            }
        });
    }
    skillCyclone() {
        const p = this.player;
        p.cycloneT = 2.2;
        p.cycloneTick = 0;
        this.trailColor = '#7dfcff';
        this.sfx('whoosh', 1.3);
        this.fx.flash(p.x, p.y - 20, 120, '#38e1ff', 0.3);
        this.material.vortex(p.x, p.y, p.spinA);
    }
    skillPhantom() {
        const p = this.player;
        p.invulnT = Math.max(p.invulnT, 0.7);
        p.castLockT = Math.max(p.castLockT, 0.55);
        this.trailColor = '#d6bcff';
        const sorted = this.enemies.filter((e) => !e.dead)
            .sort((a, b) => Math.hypot(a.x - p.x, a.y - p.y) - Math.hypot(b.x - p.x, b.y - p.y))
            .filter((e) => Math.hypot(e.x - p.x, e.y - p.y) <= 580);
        if (!sorted.length) {
            const a = p.aim;
            this.teleport(p.x + Math.cos(a) * 330, p.y + Math.sin(a) * 330);
            this.startPunch('R', a, 120, 0.3, true);
            this.schedule(0.1, () => {
                const tip = this.punchTip(a, 120);
                this.material.slide(tip.x, tip.y, a, true, true);
                this.hitCone(a, 210, 0.6, 60, 300);
            });
            return;
        }
        const targets = [];
        for (let i = 0; i < 3; i++)
            targets.push(sorted[i % sorted.length]);
        targets.forEach((tgt, i) => {
            this.schedule(i * 0.17, () => {
                if (tgt.dead)
                    return;
                const away = Math.atan2(p.y - tgt.y, p.x - tgt.x);
                this.teleport(tgt.x + Math.cos(away) * (tgt.r + 44), tgt.y + Math.sin(away) * (tgt.r + 44));
                p.aim = Math.atan2(tgt.y - p.y, tgt.x - p.x);
                this.startPunch(i % 2 === 0 ? 'L' : 'R', p.aim, 116, 0.24, true);
                this.fx.screenFlash('#b78bff', 0.08, 0.14);
                for (let i = 0; i < 5; i++)
                    this.fx.addSmoke(this.player.x + rand(-16, 16), this.player.y - rand(10, 50), rand(-60, 60), rand(-70, -20), rand(14, 26), rand(0.4, 0.7), '#b78bff', true);
                this.fx.pool(this.player.x, this.player.y + 34, 70, '#b78bff', 0.25);
                this.schedule(0.06, () => {
                    this.material.throwRubble(tgt.x, tgt.y, 5, 320, 0.58, p.aim);
                    this.material.dust(tgt.x, tgt.y, 6, 170, 0.65);
                    this.ghostFist(p.x, p.y + SHOULDER_Y, p.aim, '#b78bff', 66, 110, 70, 0.22, 0.75);
                    this.hitCircle(tgt.x, tgt.y, tgt.r + 52, 78, { kb: 260, color: '#d6bcff' });
                });
            });
        });
    }
    skillMeteor() {
        const p = this.player;
        let tx = this.mouse.wx, ty = this.mouse.wy;
        const dx = tx - p.x, dy = ty - p.y;
        const d = Math.hypot(dx, dy);
        if (d > 430) {
            tx = p.x + (dx / d) * 430;
            ty = p.y + (dy / d) * 430;
        }
        const dc = Math.hypot(tx, ty);
        if (dc > ARENA_R - 60) {
            tx *= (ARENA_R - 60) / dc;
            ty *= (ARENA_R - 60) / dc;
        }
        this.leap = { t: 0, dur: 0.55, fx: p.x, fy: p.y, tx, ty };
        p.invulnT = Math.max(p.invulnT, 0.75);
        this.fx.shock(p.x, p.y + 30, 140, '#ff9f2e', 6, 0.35);
        this.material.slide(p.x, p.y, p.aim, true);
        this.sfx('whoosh', 1.2);
    }
    landMeteor() {
        const p = this.player;
        const hits = this.hitCircle(p.x, p.y, 225, 195, { kb: 560, knockup: 330, color: '#ffcf7a' });
        this.zones.push({ x: p.x, y: p.y, r: 190, t: 0, dur: 4, kind: 'crater', pulsed: true });
        this.material.eruption(p.x, p.y + 20, 2.2, true);
        this.material.fracture(p.x, p.y + 30, 230, 11);
        this.fx.screenFlash('#ffe2b0', 0.22, 0.55);
        this.chroma = Math.max(this.chroma, 1);
        for (let i = 0; i < 16; i++)
            this.fx.addSmoke(p.x + rand(-140, 140), p.y + rand(-30, 40), rand(-180, 180), rand(-140, -30), rand(26, 54), rand(1, 1.8), '#b0a596', false);
        for (let i = 0; i < 22; i++)
            this.fx.addSpark(p.x, p.y - 10, rand(0, TAU), rand(500, 1250), Math.random() < 0.4 ? '#ffffff' : '#ffd23c', rand(2, 4), rand(0.35, 0.7), p.y + 34);
        this.fire.column(p.x, p.y + 20, 145, 430, 1.45, 2.2);
        this.fx.impact(p.x, p.y - 10, -Math.PI / 2, '#ff9f2e', 3.2);
        this.wave(p.x, p.y + 20, 360, 0.12, 0.55);
        this.wave(p.x, p.y + 20, 220, 0.07, 0.38);
        this.fluid.addSmoke(p.x, p.y + 20, 150, 1.2, 0.3);
        this.fx.radialStreaks(p.x, p.y, 28, '#ffd23c', 1300, 110);
        for (let i = 0; i < 8; i++) {
            const a = (i / 8) * TAU + rand(-0.15, 0.15);
            const r = rand(110, 210);
            this.schedule(i * 0.02, () => this.material.eruption(p.x + Math.cos(a) * r, p.y + Math.sin(a) * r * 0.7 + 20, 0.45));
        }
        this.material.throwRubble(p.x, p.y + 20, 24, 620, 1.1);
        this.burst(p.x, p.y + 20, 24, ['#d6c9a8'], 'dust', 320, 10, 1);
        p.squashT = 0.3;
        this.shake(17);
        this.hitstop(0.09);
        this.sfx('boom', 1.5);
        if (hits.length >= 3)
            this.banner = { text: 'METEOR!', sub: `Trúng ${hits.length} mục tiêu`, t: 0.9, max: 0.9 };
    }
    skillOrbit() {
        const p = this.player;
        p.orbitT = 6;
        this.material.dust(p.x, p.y + 25, 8, 140, 0.8);
        this.fx.flash(p.x, p.y - 20, 120, '#4dffb8', 0.3);
        this.fx.shock(p.x, p.y + 20, 150, '#4dffb8', 7, 0.45);
        this.fx.radialStreaks(p.x, p.y - 10, 14, '#4dffb8', 700, 60);
        this.sfx('zap', 1);
    }
    skillWave() {
        const p = this.player;
        p.castLockT = Math.max(p.castLockT, 0.4);
        this.trailColor = '#ffcf7a';
        for (let i = 0; i < 3; i++) {
            this.schedule(i * 0.13, () => {
                const a = p.aim + (i - 1) * 0.24;
                this.startPunch(i % 2 === 0 ? 'R' : 'L', a, 96, 0.3, true);
                const gx = p.x + Math.cos(a) * 60, gy = p.y + Math.sin(a) * 60;
                this.fx.impact(gx, gy + 10, a, '#ffb03c', 1.2);
                this.wave(gx, gy + 20, 110, 0.04, 0.3);
                this.material.eruption(gx, gy + 20, 0.4);
                this.projs.push({
                    kind: 'wave', x: p.x + Math.cos(a) * 46, y: p.y + Math.sin(a) * 46,
                    vx: Math.cos(a) * 700, vy: Math.sin(a) * 700, angle: a,
                    life: 1, traveled: 0, phase: 'out', hitSet: new Set(), src: null,
                });
                this.shake(3.5);
                this.sfx('boom', 0.6);
            });
        }
    }
    skillCounter() {
        const p = this.player;
        p.guardT = 1.6;
        p.counterDone = false;
        this.material.dust(p.x, p.y + 26, 7, 80, 0.7);
        this.fx.flash(p.x, p.y - 20, 110, '#f6b73c', 0.25);
        this.fx.shock(p.x, p.y + 20, 120, '#f6b73c', 6, 0.35);
        this.sfx('shield', 1);
    }
    counterStrike(src) {
        const p = this.player;
        p.guardT = 0;
        p.counterDone = true;
        this.fx.flash(p.x, p.y - 20, 160, '#ffe9a8', 0.25);
        this.fx.screenFlash('#ffd76a', 0.16, 0.35);
        this.slowmoT = Math.max(this.slowmoT, 0.22);
        const a = Math.atan2(src.y - p.y, src.x - p.x);
        this.teleport(src.x - Math.cos(a) * (src.r + 48), src.y - Math.sin(a) * (src.r + 48), '#f6b73c');
        p.aim = a;
        this.trailColor = '#ffe9a8';
        this.startPunch('R', a, 132, 0.34, true);
        this.schedule(0.09, () => {
            const sy = src.y - src.z - 20;
            this.hitCircle(src.x, src.y, src.r + 58, 175, { kb: 620, color: '#ffe97a' });
            this.ghostFist(p.x, p.y + SHOULDER_Y, a, '#ffd23c', 80, 190, 150, 0.34, 0.85);
            this.impactPackage(src.x, sy, a, '#ffd23c', 2.6, src.y + src.r * 0.6);
            this.material.eruption(src.x, src.y + 15, 0.75);
            this.fx.radialStreaks(src.x, sy, 20, '#ffe066', 1100, 80);
            this.wave(src.x, src.y + 20, 240, 0.08, 0.42);
            this.lightning.crawl(src.x, src.y - src.r * 0.4, src.r + 14, '#ffe066', 0.5);
            this.arc(p.x, p.y - 20, src.x, sy, '#f6b73c', 4);
        });
        this.banner = { text: 'PHẢN ĐÒN!', sub: 'Golden Counter', t: 0.9, max: 0.9 };
        this.hitstop(0.08);
        this.shake(9);
        this.log('Phản đòn hoàng kim trúng đích!', '#f6b73c');
    }
    skillUlt() {
        const p = this.player;
        const targets = this.enemies.filter((e) => !e.dead && Math.hypot(e.x - p.x, e.y - p.y) <= 640);
        if (!targets.length) {
            this.log('Chiêu cuối cần mục tiêu trong 640px!', '#f87171');
            this.addText(p.x, p.y - 80, 'KHÔNG CÓ MỤC TIÊU', '#f87171', 18);
            return false;
        }
        this.ultLockT = 1.55;
        this.ultKillFlag = false;
        this.slowmoT = 0.85;
        p.invulnT = Math.max(p.invulnT, 1.7);
        p.castLockT = Math.max(p.castLockT, 1.55);
        this.trailColor = '#ff6b8f';
        this.banner = { text: 'FINAL ROUND', sub: "Champion's Ultimate", t: 1, max: 1 };
        this.fx.screenFlash('#ff2e63', 0.25, 0.4);
        this.fx.speedLines(1.6, '#ffd7e0');
        this.material.slide(p.x, p.y, p.aim, true, true);
        this.material.dust(p.x, p.y + 26, 18, 260, 1);
        this.sfx('shield', 1.2);
        let lastTgt = null;
        for (let i = 0; i < 10; i++) {
            this.schedule(0.25 + i * 0.115, () => {
                const alive = this.enemies.filter((e) => !e.dead);
                if (!alive.length)
                    return;
                let pool = alive.filter((e) => e !== lastTgt);
                if (!pool.length)
                    pool = alive;
                const tgt = pool[(Math.random() * pool.length) | 0];
                lastTgt = tgt;
                const away = Math.atan2(p.y - tgt.y, p.x - tgt.x);
                this.teleport(tgt.x + Math.cos(away) * (tgt.r + 42), tgt.y + Math.sin(away) * (tgt.r + 42), i % 2 ? '#ff2e63' : '#f6b73c');
                p.aim = Math.atan2(tgt.y - p.y, tgt.x - p.x);
                this.startPunch(i % 2 === 0 ? 'L' : 'R', p.aim, 118, 0.2, i % 3 === 2);
                this.schedule(0.05, () => {
                    const ty = tgt.y - tgt.z - 22;
                    this.hitCircle(tgt.x, tgt.y, tgt.r + 50, 48, { kb: 200, color: i % 2 ? '#ff6b8f' : '#ffd23c' });
                    this.material.throwRubble(tgt.x, tgt.y, 4, 300, 0.5, p.aim);
                    this.material.fracture(tgt.x, tgt.y + 20, 42, 2.5, 0.55);
                    this.arc(p.x, p.y - 20, tgt.x, ty, '#ff2e63', 2.5);
                });
            });
        }
        this.schedule(1.5, () => {
            const cx = p.x + Math.cos(p.aim) * 70, cy = p.y + Math.sin(p.aim) * 70;
            this.startPunch('R', p.aim, 140, 0.45, true);
            this.hitCircle(cx, cy, 245, 265, { kb: 720, knockup: 560, color: '#ffe97a' });
            // giant golden fist projection + cinematic flash
            this.ghostFist(p.x, p.y + SHOULDER_Y, p.aim, '#ffd23c', 100, 320, 190, 0.55, 0.9);
            this.impactPackage(cx, cy - 20, p.aim, '#ffd23c', 3.2, cy + 40);
            this.material.eruption(cx, cy + 20, 2.4, true);
            this.material.fracture(cx, cy + 26, 250, 11);
            this.fire.column(cx, cy + 22, 175, 490, 1.5, 2.6);
            this.chroma = Math.max(this.chroma, 1);
            this.fx.screenFlash('#fff6dc', 0.3, 0.75);
            this.fx.impact(cx, cy - 20, p.aim, '#ffd23c', 3.6);
            this.fx.radialStreaks(cx, cy - 10, 36, '#ffe066', 1500, 130);
            this.wave(cx, cy + 20, 420, 0.14, 0.6);
            this.wave(cx, cy + 20, 260, 0.08, 0.42);
            this.fluid.addSmoke(cx, cy + 20, 170, 1.3, 0.35);
            for (let i = 0; i < 10; i++) {
                const a = (i / 10) * TAU;
                const rx = cx + Math.cos(a) * rand(140, 230), ry = cy + Math.sin(a) * rand(100, 170) + 20;
                this.schedule(i * 0.016, () => this.material.eruption(rx, ry, 0.55, i % 3 === 0));
            }
            this.material.throwRubble(cx, cy + 20, 30, 690, 1.2);
            this.material.dust(cx, cy + 25, 26, 360, 1.5);
            this.shake(20);
            this.hitstop(0.13);
            this.sfx('boom', 1.6);
            if (this.ultKillFlag)
                this.banner = { text: 'K.O.!', sub: 'Kết liễu hoàn hảo', t: 1.4, max: 1.4 };
        });
        // Ensure the finisher hands back input/camera authority after all 10 beats.
        // Scheduled after the impact so it does not cancel the final hit/VFX.
        this.schedule(1.76, () => {
            this.ultLockT = 0;
            p.castLockT = 0;
            this.radialAmt = 0;
            this.fx.screen.darkTarget = 0;
            this.fx.screen.letterTarget = 0;
            this.trailColor = '#fff1c2';
        });
        return true;
    }
    /* -------------------------------------------------------------- basics */
    basicAttack() {
        const p = this.player;
        if (this.paused || this.leap || this.ultLockT > 0 || p.cycloneT > 0)
            return;
        if (p.basicCd > 0)
            return;
        const step = p.comboStep;
        const heavy = step === 2;
        const hand = step === 1 ? 'R' : 'L';
        if (this.hands[hand].missing && this.hands[hand === 'L' ? 'R' : 'L'].missing)
            return;
        const useHand = this.hands[hand].missing ? (hand === 'L' ? 'R' : 'L') : hand;
        const a = p.aim;
        const reach = heavy ? 128 : 102;
        this.trailColor = p.empoweredT > 0 ? '#ff9f2e' : heavy ? '#ffe9a8' : '#fff1c2';
        this.startPunch(useHand, a, reach, heavy ? 0.42 : 0.3, heavy);
        p.basicCd = heavy ? 0.42 : 0.26;
        p.comboStep = (step + 1) % 3;
        p.comboWinT = 0.9;
        // forward lunge sells the power
        p.vx += Math.cos(a) * (heavy ? 300 : 150);
        p.vy += Math.sin(a) * (heavy ? 300 : 150);
        this.schedule(heavy ? 0.13 : 0.09, () => {
            const tip = this.punchTip(a, reach);
            this.fx.streakCone(tip.x, tip.y, a, heavy ? 6 : 3, heavy ? '#ffe9a8' : '#ffffff', 0.14, 1000, heavy ? 80 : 55);
            this.fx.flash(tip.x, tip.y, heavy ? 60 : 36, p.empoweredT > 0 ? '#ff7a3c' : '#fff1c2', 0.12);
            if (heavy) {
                this.ghostFist(tip.x, tip.y, a, p.empoweredT > 0 ? '#ff7a3c' : '#ffe9a8', 66, 120, 80, 0.22, 0.6);
                this.wave(tip.x, tip.y + 44, 95, 0.03, 0.26);
                this.material.fracture(tip.x, tip.y + 34, 38, 2, 0.48);
                this.material.throwRubble(tip.x, tip.y + 34, 4, 190, 0.5, a);
                this.dustPuff(tip.x, tip.y + 18, 0.55);
            }
            const hits = this.hitCone(a, heavy ? 218 : 195, 0.6, heavy ? 42 : 22, heavy ? 460 : 170, heavy ? 260 : 0);
            if (hits.length && heavy) {
                this.hitstop(0.06);
                this.shake(6);
            }
            else if (hits.length) {
                this.hitstop(0.025);
                this.shake(2);
            }
        });
    }
    dash() {
        const p = this.player;
        if (this.paused || p.dashCd > 0 || this.leap)
            return;
        let dx = 0, dy = 0;
        if (this.keys.has('KeyW') || this.keys.has('ArrowUp'))
            dy -= 1;
        if (this.keys.has('KeyS') || this.keys.has('ArrowDown'))
            dy += 1;
        if (this.keys.has('KeyA') || this.keys.has('ArrowLeft'))
            dx -= 1;
        if (this.keys.has('KeyD') || this.keys.has('ArrowRight'))
            dx += 1;
        if (dx === 0 && dy === 0) {
            dx = Math.cos(p.aim);
            dy = Math.sin(p.aim);
        }
        const d = Math.hypot(dx, dy);
        p.dashDir = Math.atan2(dy / d, dx / d);
        p.dashT = 0.2;
        p.dashCd = 2.1;
        p.invulnT = Math.max(p.invulnT, 0.26);
        this.afterColor = '#38e1ff';
        this.material.slide(p.x, p.y, p.dashDir, true, true);
        this.fx.shock(p.x, p.y + 30, 90, '#38e1ff', 5, 0.3);
        this.fx.streakCone(p.x, p.y - 20, p.dashDir + Math.PI, 8, '#a5f3fc', 0.25, 700, 70);
        this.burst(p.x, p.y + 30, 8, ['#d6c9a8'], 'dust', 200, 7, 0.5);
        this.sfx('whoosh', 0.9);
    }
    damagePlayer(dmg, fromAngle) {
        const p = this.player;
        if (p.invulnT > 0 || this.leap)
            return;
        p.hp -= dmg;
        p.flashT = 1;
        p.lastHurtT = this.time;
        p.vx += Math.cos(fromAngle) * 260;
        p.vy += Math.sin(fromAngle) * 260;
        this.shake(5);
        this.burst(p.x, p.y, 10, ['#f87171', '#ffffff'], 'spark', 280, 4, 0.4);
        this.addText(p.x, p.y - 70, `-${dmg}`, '#f87171', 17);
        this.sfx('punch', 0.9);
        if (p.hp <= 0) {
            p.hp = p.maxHp;
            p.x = 0;
            p.y = 120;
            p.vx = 0;
            p.vy = 0;
            this.resetRibbons();
            this.ring(0, 120, '#38e1ff', 600, 7, 0.6);
            this.banner = { text: 'HỒI SINH', sub: 'Lab respawn', t: 1, max: 1 };
            this.log('Nhân vật gục ngã — đã hồi sinh tại trung tâm.', '#f87171');
        }
    }
    /* -------------------------------------------------------------- update */
    update(rawDt) {
        // hitstop & slow-mo shape the *feel* of impacts
        let dt = rawDt * this.opts.timeScale;
        if (this.slowmoT > 0) {
            this.slowmoT -= rawDt;
            dt *= 0.32;
        }
        if (this.hitstopT > 0) {
            this.hitstopT -= rawDt;
            dt *= 0.06;
        }
        this.time += dt;
        this.material.update(dt);
        this.fluid.step(Math.min(dt, 0.034));
        this.fire.update(dt);
        this.lightning.update(dt);
        for (let i = this.pressure.length - 1; i >= 0; i--) {
            const w = this.pressure[i];
            w.life -= dt;
            if (w.life <= 0) {
                this.pressure.splice(i, 1);
                continue;
            }
            const k = 1 - w.life / w.max;
            w.r = 6 + (w.r1 - 6) * (1 - Math.pow(1 - k, 2.4));
        }
        for (const l of this.lightning.lights())
            this.fx.pool(l.x, l.y + 24, 70, l.color, 0.06);
        const p = this.player;
        if (this.rocketCatch) {
            this.rocketCatch.t += rawDt;
            if (this.rocketCatch.t >= this.rocketCatch.life) this.rocketCatch = null;
        }
        // Bracing only lasts while the flying glove is visibly approaching.
        this.rocketCatchApproach = Math.max(0, this.rocketCatchApproach - rawDt * 4.2);
        /* cooldowns */
        for (const [k, v] of this.cds)
            if (v > 0)
                this.cds.set(k, Math.max(0, v - dt * this.opts.haste));
        /* timeline */
        for (let i = this.timeline.length - 1; i >= 0; i--) {
            const ev = this.timeline[i];
            ev.t -= dt;
            if (ev.t <= 0) {
                this.timeline.splice(i, 1);
                ev.fn();
            }
        }
        /* mouse world */
        this.mouse.wx = (this.mouse.x - this.w / 2 - this.view.shX) / this.camZoom + this.cam.x;
        this.mouse.wy = (this.mouse.y - this.h / 2 - this.view.shY) / this.camZoom + this.cam.y;
        if (!this.idleEditMode)
            if (!this.idleEditMode) p.aim = Math.atan2(this.mouse.wy - p.y, this.mouse.wx - p.x);
        /* timers */
        p.dashCd = Math.max(0, p.dashCd - dt * this.opts.haste);
        p.basicCd = Math.max(0, p.basicCd - dt);
        p.invulnT = Math.max(0, p.invulnT - dt);
        p.castLockT = Math.max(0, p.castLockT - dt);
        p.flashT = Math.max(0, p.flashT - dt * 3);
        if (p.comboWinT > 0) {
            p.comboWinT -= dt;
            if (p.comboWinT <= 0)
                p.comboStep = 0;
        }
        if (this.stats.comboT > 0) {
            this.stats.comboT -= dt;
            if (this.stats.comboT <= 0)
                this.stats.combo = 0;
        }
        if (p.fury >= 100 && p.empoweredT <= 0) {
            p.empoweredT = 8;
            this.log('TRẠNG THÁI BỐC LỬA! +25% sát thương trong 8s', '#ff7a3c');
            this.ring(p.x, p.y, '#ff7a3c', 500, 7, 0.5);
        }
        if (p.empoweredT > 0) {
            p.empoweredT -= dt;
            p.fury = Math.max(0, p.fury - dt * 12.5);
            if (Math.random() < 0.25)
                this.fire.puff(p.x + rand(-26, 26), p.y - rand(0, 40), 14, 0, -90, 0.45);
        }
        this.ultLockT = Math.max(0, this.ultLockT - dt);
        if (this.banner) {
            this.banner.t -= rawDt;
            if (this.banner.t <= 0)
                this.banner = null;
        }
        /* guard expiry nova */
        if (p.guardT > 0) {
            p.guardT -= dt;
            if (p.guardT <= 0 && !p.counterDone) {
                this.hitCircle(p.x, p.y, 155, 65, { kb: 380, color: '#ffe97a' });
                this.wave(p.x, p.y + 20, 220, 0.07, 0.4);
                this.fx.flash(p.x, p.y - 20, 150, '#ffd76a', 0.25);
                this.fx.radialStreaks(p.x, p.y - 20, 18, '#ffe066', 900, 70);
                this.sfx('boom', 0.8);
            }
        }
        /* movement */
        const locked = !!this.leap || this.ultLockT > 0;
        let mx = 0, my = 0;
        if (this.keys.has('KeyW') || this.keys.has('ArrowUp'))
            my -= 1;
        if (this.keys.has('KeyS') || this.keys.has('ArrowDown'))
            my += 1;
        if (this.keys.has('KeyA') || this.keys.has('ArrowLeft'))
            mx -= 1;
        if (this.keys.has('KeyD') || this.keys.has('ArrowRight'))
            mx += 1;
        const mLen = Math.hypot(mx, my);
        let speedMul = 1;
        if (p.castLockT > 0 && this.ultLockT <= 0)
            speedMul = 0.35;
        if (p.cycloneT > 0)
            speedMul = 0.55;
        if (locked)
            speedMul = 0;
        if (mLen > 0 && !locked) {
            const sp = 345 * speedMul;
            const tx = (mx / mLen) * sp, ty = (my / mLen) * sp;
            const blend = 1 - Math.exp(-14 * dt);
            p.vx = lerp(p.vx, tx, blend);
            p.vy = lerp(p.vy, ty, blend);
            p.stepT -= dt;
            if (p.stepT <= 0 && p.z === 0) {
                p.stepT = 0.16;
                this.burst(p.x - p.vx * 0.08 + rand(-8, 8), p.y + 26, 1, ['#9aa3b2'], 'dust', 40, 5, 0.5);
            }
        }
        else if (!locked) {
            const f = Math.exp(-10 * dt);
            p.vx *= f;
            p.vy *= f;
        }
        if (p.dashT > 0) {
            p.dashT -= dt;
            p.vx = Math.cos(p.dashDir) * 1250;
            p.vy = Math.sin(p.dashDir) * 1250;
            this.after(p.x, p.y, 0, 'body', '#38e1ff');
            this.burst(p.x, p.y + 30, 2, ['#38e1ff', '#ffffff'], 'dust', 90, 5, 0.4);
            if (Math.random() < 0.5)
                this.material.slide(p.x, p.y, p.dashDir, false, true);
            this.fluid.addForce(p.x, p.y + 10, 60, Math.cos(p.dashDir) * 14, Math.sin(p.dashDir) * 14);
            this.fluid.addSmoke(p.x - Math.cos(p.dashDir) * 30, p.y + 20, 30, 0.08, 0.05);
            if (Math.random() < 0.6)
                this.fx.streak(p.x + rand(-25, 25), p.y - rand(0, 60), p.dashDir + Math.PI, '#a5f3fc', 500, 60, 2.5, 0.18);
        }
        /* leap (meteor) */
        if (this.leap) {
            const L = this.leap;
            L.t += dt;
            const pr = clamp(L.t / L.dur, 0, 1);
            p.x = lerp(L.fx, L.tx, easeInOut(pr));
            p.y = lerp(L.fy, L.ty, easeInOut(pr));
            p.z = Math.sin(pr * Math.PI) * 175;
            if (Math.random() < 0.7)
                this.fire.puff(p.x + rand(-20, 20), p.y - p.z - rand(10, 60), 22, rand(-40, 40), 60, 0.7);
            if (pr > 0.55)
                this.fx.streak(p.x + rand(-30, 30), p.y - p.z - 90, Math.PI / 2, '#ffd23c', 900, 80, 3, 0.16);
            if (pr >= 1) {
                this.leap = null;
                p.z = 0;
                this.landMeteor();
            }
        }
        else {
            p.x += p.vx * dt;
            p.y += p.vy * dt;
            const dc = Math.hypot(p.x, p.y);
            if (dc > ARENA_R - 40) {
                p.x *= (ARENA_R - 40) / dc;
                p.y *= (ARENA_R - 40) / dc;
            }
        }
        /* body facing */
        const targetAngle = p.cycloneT > 0 ? p.spinA : p.aim;
        p.bodyAngle = angLerp(p.bodyAngle, targetAngle, 1 - Math.exp(-18 * dt));
        if (p.cycloneT > 0)
            p.spinA += dt * 15;
        // upright 3/4 body: flip to face the aim side, lean into motion & punches
        const cA = Math.cos(p.aim);
        const faceTarget = cA > 0.12 ? 1 : cA < -0.12 ? -1 : Math.sign(p.faceX || 1);
        p.faceX = lerp(p.faceX, faceTarget, 1 - Math.exp(-16 * dt));
        const punching = (this.hands.L.t > 0.15 && this.hands.L.t < 0.65) || (this.hands.R.t > 0.15 && this.hands.R.t < 0.65);
        const leanTarget = clamp(p.vx / 345, -1, 1) * 0.07 + (punching ? cA * 0.1 : 0);
        p.lean = lerp(p.lean, leanTarget, 1 - Math.exp(-12 * dt));
        p.squashT = Math.max(0, p.squashT - dt);
        // cinematic framing for the ultimate
        this.fx.screen.darkTarget = this.ultLockT > 0 ? 0.75 : 0;
        if (this.slowmoT > 0)
            this.chroma = Math.max(this.chroma, 0.35);
        this.fx.screen.letterTarget = this.ultLockT > 0 ? 1 : 0;
        // lens: dolly out during the ultimate, punch in on every landing
        this.chroma = Math.max(0, this.chroma - rawDt * 2.1);
        this.radialAmt = this.ultLockT > 0 ? 1 : Math.max(0, this.radialAmt - rawDt * 2.6);
        this.camZoomBase = this.ultLockT > 0 ? 0.45 : this.slowmoT > 0 ? 0.48 : 0.5;
        this.camZoom += (this.camZoomBase - this.camZoom) * (1 - Math.exp(-4.5 * rawDt));
        if (Math.abs(this.camZoom - this.camZoomBase) < 0.0015)
            this.camZoom = this.camZoomBase;
        /* held basic attack */
        if (this.mouse.down)
            this.basicAttack();
        /* hands animation clocks */
        for (const k of ['L', 'R']) {
            const h = this.hands[k];
            if (h.t >= 0) {
                h.t += dt / h.dur;
                if (h.t >= 1)
                    h.t = -1;
            }
            // glove motion blur (tapered ribbon) + afterimages while the fist travels
            if (!h.missing) {
                const g = this.glovePose(k);
                this.fx.trail(k, g.x, g.y, this.trailColor, g.active ? 30 * g.scale : 13);
                if (g.active)
                    this.fluid.addForce(g.x, g.y, 34, Math.cos(g.angle) * 9, Math.sin(g.angle) * 5);
                if (g.active && Math.random() < 0.5)
                    this.after(g.x, g.y, g.angle, 'glove', this.trailColor, g.mirror);
                if (g.active && Math.random() < 0.6)
                    this.fx.addSpark(g.x, g.y, g.angle + Math.PI, rand(120, 340), this.trailColor, rand(1.2, 2.4), rand(0.12, 0.24), p.y + 34);
                if (p.empoweredT > 0 && Math.random() < 0.3)
                    this.fire.puff(g.x + rand(-10, 10), g.y + rand(-8, 8), 12, 0, -80, 0.4);
            }
        }
        /* cyclone */
        if (p.cycloneT > 0) {
            p.cycloneT -= dt;
            p.cycloneTick -= dt;
            if (Math.random() < 0.35)
                this.after(p.x, p.y, 0, 'body', '#38e1ff');
            if (Math.random() < 0.8) {
                const a = rand(0, TAU);
                this.particles.push({
                    x: p.x + Math.cos(a) * 170, y: p.y + Math.sin(a) * 170,
                    vx: -Math.sin(a) * 420, vy: Math.cos(a) * 420,
                    life: 0.4, maxLife: 0.4, size: rand(3, 6), color: '#a5f3fc',
                    kind: 'spark', rot: a, vr: 0, drag: 0.5, grav: 0,
                });
            }
            // vacuum pull
            for (const e of this.enemies) {
                if (e.dead)
                    continue;
                const dx = p.x - e.x, dy = p.y - e.y;
                const d = Math.hypot(dx, dy);
                if (d < 260 && d > 10) {
                    e.vx += (dx / d) * 620 * dt;
                    e.vy += (dy / d) * 620 * dt;
                }
            }
            if (p.cycloneTick <= 0) {
                p.cycloneTick = 0.16;
                // wind-blade crescents whipping around the spin
                this.material.vortex(p.x, p.y, p.spinA);
                this.fluid.vortex(p.x, p.y, 230, 9);
                this.fluid.addSmoke(p.x + rand(-150, 150), p.y + rand(-90, 90), 30, 0.12, 0.05);
                this.fx.addSmoke(p.x + rand(-140, 140), p.y + rand(-20, 40), rand(-160, 160), rand(-60, 60), rand(20, 38), rand(0.4, 0.7), '#7dd8e8', false);
                this.fx.pool(p.x, p.y + 30, 150, '#38e1ff', 0.18);
                this.hitCircle(p.x, p.y, 208, 17, { kb: -60, color: '#a5f3fc' });
                this.sfx('whoosh', 0.8);
            }
        }
        /* orbit gloves */
        if (p.orbitT > 0) {
            p.orbitT -= dt;
            p.orbitA += dt * 7.6;
            for (let i = 0; i < 2; i++) {
                const a = p.orbitA + i * Math.PI;
                const gx = p.x + Math.cos(a) * 108, gy = p.y + Math.sin(a) * 108;
                this.fx.flash(gx, gy + SHOULDER_Y, 34, '#4dffb8', 0.2); // neon comet tail
                if (Math.random() < 0.6)
                    this.burst(gx, gy + SHOULDER_Y, 1, ['#4dffb8'], 'spark', 30, 3, 0.3);
                for (const e of this.enemies) {
                    if (e.dead || this.time < e.orbitHitAt)
                        continue;
                    if (Math.hypot(e.x - gx, e.y - gy) < e.r + 30) {
                        e.orbitHitAt = this.time + 0.35;
                        const ka = Math.atan2(e.y - p.y, e.x - p.x);
                        this.damageEnemy(e, 28, { kx: Math.cos(ka) * 300, ky: Math.sin(ka) * 300, color: '#b8ffd9' });
                        this.material.throwRubble(e.x, e.y + e.r * 0.5, 2, 150, 0.4, ka);
                        this.arc(gx, gy, e.x, e.y, '#4dffb8', 2);
                        this.sfx('punch', 0.6);
                    }
                }
            }
        }
        /* hp regen */
        if (this.time - p.lastHurtT > 3 && p.hp < p.maxHp)
            p.hp = Math.min(p.maxHp, p.hp + 40 * dt);
        /* enemies */
        for (const e of this.enemies) {
            if (e.dead)
                continue;
            e.flash = Math.max(0, e.flash - dt * 5);
            e.wobV += (-e.wob * 130 - e.wobV * 9) * dt;
            e.wob += e.wobV * dt;
            e.slowT = Math.max(0, e.slowT - dt);
            // knock-up physics
            if (e.z > 0 || e.vz > 0) {
                e.z += e.vz * dt;
                e.vz -= 1750 * dt;
                if (e.z <= 0) {
                    e.z = 0;
                    e.vz = 0;
                    this.burst(e.x, e.y + e.r * 0.6, 8, ['#9aa3b2'], 'dust', 160, 6, 0.5);
                    this.ring(e.x, e.y + e.r * 0.5, '#9aa3b2', 200, 3, 0.3);
                }
            }
            const spd = e.slowT > 0 ? 0.55 : 1;
            e.x += e.vx * dt * spd;
            e.y += e.vy * dt * spd;
            const fr = Math.exp(-5.5 * dt);
            e.vx *= fr;
            e.vy *= fr;
            // targets torn off their feet drag a dust wake
            if (e.z === 0 && Math.hypot(e.vx, e.vy) > 330 && Math.random() < 0.5) {
                this.dustPuff(e.x - e.vx * 0.05, e.y + e.r * 0.55, 0.32);
            }
            const dc = Math.hypot(e.x, e.y);
            if (dc > ARENA_R - e.r) {
                e.x *= (ARENA_R - e.r) / dc;
                e.y *= (ARENA_R - e.r) / dc;
            }
            e.angle = angLerp(e.angle, Math.atan2(p.y - e.y, p.x - e.x), 1 - Math.exp(-4 * dt));
            if (e.kind === 'bot' && e.z === 0) {
                const dx = p.x - e.x, dy = p.y - e.y;
                const d = Math.hypot(dx, dy) || 1;
                e.strafeT -= dt;
                if (e.strafeT <= 0) {
                    e.strafeT = rand(1.4, 2.8);
                    e.strafeDir *= -1;
                }
                let ax = 0, ay = 0;
                if (d > 320) {
                    ax = dx / d;
                    ay = dy / d;
                }
                else if (d < 230) {
                    ax = -dx / d;
                    ay = -dy / d;
                }
                ax += (-dy / d) * 0.6 * e.strafeDir;
                ay += (dx / d) * 0.6 * e.strafeDir;
                e.vx += ax * 300 * dt;
                e.vy += ay * 300 * dt;
                e.shootT -= dt;
                if (e.shootT <= 0 && d < 560) {
                    e.shootT = rand(1.6, 2.2);
                    const sa = Math.atan2(dy, dx);
                    this.projs.push({
                        kind: 'orb', x: e.x + Math.cos(sa) * 30, y: e.y + Math.sin(sa) * 30,
                        vx: Math.cos(sa) * 385, vy: Math.sin(sa) * 385, angle: sa,
                        life: 2.4, traveled: 0, phase: 'out', hitSet: new Set(), src: e,
                    });
                    this.sfx('zap', 0.5);
                }
            }
        }
        // separation
        for (let i = 0; i < this.enemies.length; i++) {
            for (let j = i + 1; j < this.enemies.length; j++) {
                const a = this.enemies[i], b = this.enemies[j];
                if (a.dead || b.dead)
                    continue;
                const dx = b.x - a.x, dy = b.y - a.y;
                const d = Math.hypot(dx, dy);
                const min = a.r + b.r;
                if (d > 0.01 && d < min) {
                    const pushF = ((min - d) / d) * 0.5;
                    a.x -= dx * pushF * 0.5;
                    a.y -= dy * pushF * 0.5;
                    b.x += dx * pushF * 0.5;
                    b.y += dy * pushF * 0.5;
                }
            }
        }
        this.enemies = this.enemies.filter((e) => !e.dead);
        /* zones */
        for (let i = this.zones.length - 1; i >= 0; i--) {
            const z = this.zones[i];
            z.t += dt;
            if (z.kind === 'crater') {
                for (const e of this.enemies) {
                    if (!e.dead && Math.hypot(e.x - z.x, e.y - z.y) < z.r)
                        e.slowT = Math.max(e.slowT, 0.25);
                }
                if (Math.random() < 0.3)
                    this.burst(z.x + rand(-z.r, z.r) * 0.7, z.y + rand(-z.r, z.r) * 0.4, 1, ['#ff9f2e'], 'ember', 26, 4, 0.8);
            }
            else if (z.kind === 'flame') {
                if (!z.pulsed && z.t > 0.12) {
                    z.pulsed = true;
                    this.hitCircle(z.x, z.y, z.r, 34, { kb: 60, knockup: 200, color: '#ffb03c' });
                    this.sfx('boom', 0.5);
                }
                if (Math.random() < 0.5)
                    this.fire.puff(z.x + rand(-16, 16), z.y, 18, 0, -140, 0.6);
            }
            if (z.t >= z.dur)
                this.zones.splice(i, 1);
        }
        /* projectiles */
        for (let i = this.projs.length - 1; i >= 0; i--) {
            const pr = this.projs[i];
            let kill = false;
            if (pr.kind === 'rocket') {
                if (pr.phase === 'out') {
                    pr.traveled += Math.hypot(pr.vx, pr.vy) * dt;
                    pr.x += pr.vx * dt;
                    pr.y += pr.vy * dt;
                    if (Math.floor(pr.traveled / 100) !== Math.floor((pr.traveled - 1250 * dt) / 100)) {
                        this.fire.puff(pr.x - pr.vx * 0.04, pr.y - pr.vy * 0.04 + SHOULDER_Y, 26, -pr.vx * 0.12, -pr.vy * 0.12 - 60, 0.9);
                    }
                    this.fx.flash(pr.x, pr.y + SHOULDER_Y, 48, '#ff7a3c', 0.22);
                    this.fx.addSmoke(pr.x, pr.y + SHOULDER_Y, -pr.vx * 0.06, -pr.vy * 0.06 + rand(-16, 16), rand(13, 24), rand(0.45, 0.8), '#ff8a4c', true);
                    if (Math.random() < 0.5)
                        this.fx.addSmoke(pr.x, pr.y + SHOULDER_Y, rand(-20, 20), rand(-10, 26), rand(16, 28), rand(0.6, 1), '#6f6a62', false);
                    this.fx.addEmber(pr.x, pr.y + SHOULDER_Y, '#ffd23c', 90);
                    this.fx.pool(pr.x, p.y + 34, 90, '#ff7a3c', 0.16);
                    this.burst(pr.x, pr.y, 1, ['#ffe97a'], 'spark', 40, 3, 0.3);
                    if (Math.random() < 0.35)
                        this.lightning.strike(pr.x, pr.y + SHOULDER_Y, pr.x + rand(-40, 40), pr.y + SHOULDER_Y + rand(-40, 40), '#ffd23c', 1.6, { branches: 1, life: 0.14, rough: 0.5 });
                    // ADD ONLY: V1.1 Detail rocket micro-electricity / kinetic exhaust.
                    this.rocketDetailTravel(pr);
                    for (const e of this.enemies) {
                        if (e.dead || pr.hitSet.has(e.id))
                            continue;
                        if (Math.hypot(e.x - pr.x, e.y - pr.y) < e.r + 30) {
                            pr.hitSet.add(e.id);
                            this.damageEnemy(e, 130, { kx: pr.vx * 0.35, ky: pr.vy * 0.35, color: '#ffd7ae', size: 23 });
                            this.material.eruption(e.x, e.y + e.r * 0.5, 0.52, true);
                            this.ring(pr.x, pr.y, '#ff7a3c', 380, 5, 0.3);
                            this.shake(4);
                            this.hitstop(0.04);
                            // ADD ONLY: contact sparks and a stronger 1.1 Detail weight cue.
                            // No impact slash sprites, circular shapes, or additional damage events.
                            this.rocketDetailContact(pr, e);
                        }
                    }
                    if (pr.traveled > 880 || Math.hypot(pr.x, pr.y) > ARENA_R + 60) {
                        pr.phase = 'return';
                        pr.hitSet.clear();
                    }
                }
                else {
                    // Chase the *actual rendered fist slot*, including owner's idle L/R pose.
                    // Projectile coordinates omit SHOULDER_Y; the sprite renders with it.
                    const grip = this.glovePose('R');
                    const gx = grip.x, gy = grip.y - SHOULDER_Y;
                    const a = Math.atan2(gy - pr.y, gx - pr.x);
                    const prevX = pr.x, prevY = pr.y;
                    const approachDist = Math.hypot(gx - prevX, gy - prevY);
                    this.rocketCatchApproach = approachDist < 205 ?
                        Math.max(this.rocketCatchApproach, Math.max(0, (205 - approachDist) / 175)) : 0;
                    pr.angle = angLerp(pr.angle, a, 1 - Math.exp(-(approachDist < 185 ? 24 : 10) * dt));
                    pr.vx = Math.cos(pr.angle) * 1450;
                    pr.vy = Math.sin(pr.angle) * 1450;
                    pr.x += pr.vx * dt;
                    pr.y += pr.vy * dt;
                    this.burst(pr.x, pr.y, 2, ['#38e1ff', '#ffffff'], 'spark', 50, 4, 0.3);
                    // ADD ONLY: return electricity. Original return particles unchanged.
                    this.rocketDetailReturn(pr);
                    for (const e of this.enemies) {
                        if (e.dead || pr.hitSet.has(e.id))
                            continue;
                        if (Math.hypot(e.x - pr.x, e.y - pr.y) < e.r + 30) {
                            pr.hitSet.add(e.id);
                            this.damageEnemy(e, 60, { kx: pr.vx * 0.25, ky: pr.vy * 0.25, color: '#a5f3fc' });
                        }
                    }
                    // Swept interception: no missed catch when one frame steps past the hand.
                    const sx = pr.x - prevX, sy = pr.y - prevY;
                    const segLen2 = sx * sx + sy * sy;
                    const segT = segLen2 > 1e-6 ? clamp(((gx - prevX) * sx + (gy - prevY) * sy) / segLen2, 0, 1) : 0;
                    const meetX = prevX + sx * segT, meetY = prevY + sy * segT;
                    if (Math.hypot(gx - meetX, gy - meetY) < 31 || Math.hypot(gx - pr.x, gy - pr.y) < 31) {
                        this.hands.R.missing = false;
                        this.startRocketCatch(pr, grip, meetX, meetY);
                        // Original ring, logging and previous VFX are kept intact.
                        this.ring(p.x, p.y, '#38e1ff', 260, 4, 0.3);
                        this.log('Găng tên lửa đã quay về tay!', '#7dd3fc');
                        kill = true;
                    }
                }
            }
            else if (pr.kind === 'wave') {
                pr.x += pr.vx * dt;
                pr.y += pr.vy * dt;
                pr.traveled += Math.hypot(pr.vx, pr.vy) * dt;
                if (Math.floor(pr.traveled / 50) !== Math.floor((pr.traveled - 700 * dt) / 50)) {
                    this.material.tear(pr.x, pr.y, pr.angle, 0.9);
                }
                for (const e of this.enemies) {
                    if (e.dead || pr.hitSet.has(e.id))
                        continue;
                    if (Math.hypot(e.x - pr.x, e.y - pr.y) < e.r + 62) {
                        pr.hitSet.add(e.id);
                        this.damageEnemy(e, 88, { kx: pr.vx * 0.55, ky: pr.vy * 0.55, knockup: 130, color: '#ffd7ae' });
                    }
                }
                if (pr.traveled > 640)
                    kill = true;
            }
            else {
                // enemy orb
                pr.x += pr.vx * dt;
                pr.y += pr.vy * dt;
                pr.life -= dt;
                this.burst(pr.x, pr.y, 1, ['#f87171'], 'spark', 20, 3, 0.25);
                const d = Math.hypot(p.x - pr.x, p.y - pr.y);
                if (d < p.r + 13) {
                    if (p.guardT > 0 && pr.src && !pr.src.dead) {
                        this.counterStrike(pr.src);
                    }
                    else if (p.guardT <= 0) {
                        this.damagePlayer(34, pr.angle);
                    }
                    kill = true;
                }
                if (pr.life <= 0)
                    kill = true;
            }
            if (kill)
                this.projs.splice(i, 1);
        }
        /* fx pools */
        for (let i = this.particles.length - 1; i >= 0; i--) {
            const pt = this.particles[i];
            pt.life -= dt;
            if (pt.life <= 0) {
                this.particles.splice(i, 1);
                continue;
            }
            pt.vy += pt.grav * dt;
            const dr = Math.exp(-pt.drag * dt);
            pt.vx *= dr;
            pt.vy *= dr;
            pt.x += pt.vx * dt;
            pt.y += pt.vy * dt;
            pt.rot += pt.vr * dt;
            // debris bounces on the floor plane and settles
            if (pt.floorY !== undefined && pt.y > pt.floorY) {
                pt.y = pt.floorY;
                if (Math.abs(pt.vy) > 55) {
                    pt.vy *= -0.42;
                    pt.vx *= 0.72;
                    pt.vr *= 0.5;
                }
                else {
                    pt.vy = 0;
                    pt.vx *= 0.86;
                    pt.vr *= 0.86;
                }
            }
        }
        for (let i = this.rings.length - 1; i >= 0; i--) {
            const r = this.rings[i];
            r.life -= dt;
            r.r += r.vr * dt;
            if (r.life <= 0)
                this.rings.splice(i, 1);
        }
        for (let i = this.arcs.length - 1; i >= 0; i--) {
            this.arcs[i].life -= dt;
            if (this.arcs[i].life <= 0)
                this.arcs.splice(i, 1);
        }
        for (let i = this.texts.length - 1; i >= 0; i--) {
            const t = this.texts[i];
            t.life -= dt;
            t.y -= 56 * dt;
            if (t.life <= 0)
                this.texts.splice(i, 1);
        }
        for (let i = this.afters.length - 1; i >= 0; i--) {
            this.afters[i].life -= dt;
            if (this.afters[i].life <= 0)
                this.afters.splice(i, 1);
        }
        this.fx.update(dt, rawDt);
        /* camera */
        const camBlend = 1 - Math.exp(-6 * rawDt);
        this.cam.x = lerp(this.cam.x, p.x, camBlend);
        this.cam.y = lerp(this.cam.y, p.y, camBlend);
        if (this.cam.shakeT > 0) {
            this.cam.shakeT -= rawDt;
            if (this.cam.shakeT <= 0)
                this.cam.shakeMag = 0;
        }
        this.updateRibbons(dt);
        this.castingName = p.cycloneT > 0 ? 'Lốc Xoáy Đỏ' : this.leap ? 'Thiên Thạch Giáng' : this.ultLockT > 0 ? 'Võ Đài Tối Thượng' : p.guardT > 0 ? 'Phản Đòn Hoàng Kim' : null;
    }
    /* -------------------------------------------------------------- glove pose */
    /** Fixed shoulder anchors beside the chest of the upright 3/4 body. */
    shoulder(hand) {
        const p = this.player;
        const s = hand === 'L' ? -1 : 1;
        return { x: p.x + s * SHOULDER_X, y: p.y + SHOULDER_Y - p.z };
    }
    /**
     * Glove placement:
     *  - guard: fists hold the key-art slots beside the chest — near fist lower
     *    and larger, far fist higher and smaller, both cocked toward the aim
     *  - punch: wind-up back along the punch line → straight drive from the
     *    shoulder to the strike point (stretch) → impact squash → recoil home
     *  - gloves above the chest line are drawn BEHIND the body (depth sort)
     */
    // Rocket catch: directional force absorption, with no slash icons or extra shapes.
    startRocketCatch(pr, grip, meetX, meetY) {
        const p = this.player;
        const speed = Math.max(1, Math.hypot(pr.vx, pr.vy));
        const dx = pr.vx / speed, dy = pr.vy / speed;
        const visibleX = meetX, visibleY = meetY + SHOULDER_Y;
        this.rocketCatch = {
            t: 0, life: 0.49, dx, dy,
            // Start at the *same visible point* where the rocket was intercepted.
            gapX: visibleX - grip.x, gapY: visibleY - grip.y,
            angle: pr.angle,
        };
        this.rocketCatchApproach = 0;
        // The impulse is not a teleport or a camera-only fake: the physical
        // fighter velocity gets kicked in the fist's actual travel direction.
        const impulse = Math.min(speed * 0.21, 315);
        p.vx += dx * impulse;
        p.vy += dy * impulse;
        p.castLockT = Math.max(p.castLockT, 0.095);
        this.hitstop(0.055);
        this.shake(10);
        this.kickZoom(0.34);
        this.sfx('boom', 0.65);
    }
    rocketCatchResponse() {
        const c = this.rocketCatch;
        if (!c) return 0;
        const t = c.t;
        // 0–55ms: catch/compression. Afterward: damped counter-recoil.
        return t < 0.055 ? easeOutQuart(t / 0.055) :
            Math.exp(-(t - 0.055) * 8.6) * Math.cos((t - 0.055) * 13.2);
    }
    glovePose(hand) {
        const p = this.player;
        const h = this.hands[hand];
        const idle = h.t < 0 && p.guardT <= 0 && p.cycloneT <= 0 && !this.leap;
        // L/R visual swap is ONLY a sprite-orientation switch; each glove stays on its native side.
        const s = hand === 'L' ? -1 : 1;
        const ax = Math.cos(p.aim), ay = Math.sin(p.aim);
        const sh = this.shoulder(hand);
        const baseY = p.y + SHOULDER_Y - p.z;
        const near = s < 0; // the left fist sits nearer the camera in the key art
        const steady = idle && this.idleEditMode && this.idlePose.holdMotion;
        const bounce = steady ? 0 : Math.sin(this.time * 5.2 + (s > 0 ? Math.PI : 0)) * 2.4;
        const roll = steady ? 0 : Math.sin(this.time * 1.15) * 5; // boxer rolling on his feet
        const tremor = steady ? 0 : Math.sin(this.time * 2.3 + (near ? 0 : 1.7));
        // --- boxing stance -----------------------------------------------------
        // The body sprite is a fixed 3/4 view, so the fists hold the key-art
        // slots: the near fist is lower and bigger, the far fist higher and
        // smaller — a real diagonal stance, not two mirrored balls on a circle.
        let gx = sh.x + (near ? -13 : 15) + ax * (near ? 18 : 7) + roll;
        let gy = baseY + (near ? 17 : -13) + ay * (near ? 13 : 4) + tremor * 2.6 + bounce;
        // both fists cocked inward toward the line of attack
        let angle = p.aim + (near ? -0.36 : 0.2) + tremor * 0.055;
        let scale = near ? 1.14 : 0.99, sx = 1, sy = 1, ext = 0, active = false;
        if (p.guardT > 0) {
            // high peek-a-boo guard: fists stacked tight in front of the chin
            gx = p.x + (near ? -14 : 16) + ax * 24 + roll * 0.35;
            gy = baseY + (near ? 19 : -3) + ay * 19 + tremor * 1.6;
            angle = p.aim + (near ? -0.16 : 0.11);
            scale = near ? 1.18 : 1.04;
        }
        else if (p.cycloneT > 0) {
            const a = p.spinA + (s < 0 ? 0 : Math.PI);
            gx = p.x + Math.cos(a) * 112;
            gy = baseY + Math.sin(a) * 112 * 0.8;
            angle = a + Math.PI / 2;
            scale = 1.1;
            sx = 1.14;
            sy = 0.9;
            active = true;
        }
        else if (h.t >= 0) {
            const t = h.t;
            const tip = this.punchTip(h.angle, h.reach);
            const dirA = Math.atan2(tip.y - gy, tip.x - gx);
            const dx = Math.cos(dirA), dy = Math.sin(dirA);
            const windX = gx - dx * 18, windY = gy - dy * 18;
            if (t < 0.2) {
                const k = easeOutQuart(t / 0.2);
                gx = lerp(gx, windX, k);
                gy = lerp(gy, windY, k);
                scale = 1 - 0.08 * k;
                sx = 1 - 0.06 * k;
                sy = 1 + 0.06 * k;
            }
            else if (t < 0.45) {
                const k = (t - 0.2) / 0.25;
                const e = easeOutQuart(k);
                gx = lerp(windX, tip.x, e);
                gy = lerp(windY, tip.y, e);
                scale = 0.92 + 0.32 * e;
                sx = 1.22;
                sy = 0.85;
                ext = e;
                active = true;
            }
            else if (t < 0.62) {
                const k = (t - 0.45) / 0.17;
                gx = tip.x;
                gy = tip.y;
                scale = 1.24;
                ext = 1;
                active = true;
                sx = 1 - 0.14 * Math.sin(k * Math.PI);
                sy = 1 + 0.14 * Math.sin(k * Math.PI);
            }
            else {
                const k = easeInOut((t - 0.62) / 0.38);
                gx = lerp(tip.x, gx, k);
                gy = lerp(tip.y, gy, k);
                scale = lerp(1.24, 1, k);
                ext = 1 - k;
            }
            angle = dirA;
        }
        // User-defined idle offsets are additive to the original GOLD pose.
        // Attacks, guard, orbit, cyclone and leap keep their native motion.
        if (idle) {
            const cfg = this.idlePose[hand];
            gx += cfg.x;
            gy += cfg.y;
            angle += cfg.rot * Math.PI / 180;
        }
        // Before impact the off-hand braces; on impact the returned fist
        // compresses and releases while the other fist counterbalances.
        if (idle && this.rocketCatch) {
            const c = this.rocketCatch, reaction = this.rocketCatchResponse();
            if (hand === 'R') {
                const rejoin = Math.exp(-c.t * 34);
                gx += c.gapX * rejoin + c.dx * 13 * reaction;
                gy += c.gapY * rejoin + c.dy * 10 * reaction;
                angle = angLerp(angle, c.angle, 0.34 * rejoin);
                sx *= 1 - 0.16 * Math.max(0, reaction);
                sy *= 1 + 0.12 * Math.max(0, reaction);
            } else {
                gx -= c.dx * 11 * reaction;
                gy -= c.dy * 7 * reaction;
                angle -= 0.10 * reaction;
            }
        } else if (idle && hand === 'L' && this.rocketCatchApproach > 0) {
            gx -= Math.cos(p.aim) * 7 * this.rocketCatchApproach;
            gy -= Math.sin(p.aim) * 5 * this.rocketCatchApproach;
        }
        const behind = idle ? this.idlePose[hand].layer === 'back'
            : p.cycloneT > 0 ? gy < baseY
                : (h.t >= 0 && p.guardT <= 0) ? gy < baseY - 18 : false;
        const mirror = (hand === 'L') !== (idle && this.idlePose.swapSides) !== (idle && this.idlePose[hand].flip);
        return { x: gx, y: gy, angle, scale, sx, sy, ext, active, behind, mirror, idle };
    }
    toScreen(x, y) {
        const z = this.camZoom;
        return {
            x: (x - this.cam.x) * z + this.w / 2 + this.view.shX,
            y: (y - this.cam.y) * z + this.h / 2 + this.view.shY,
        };
    }
    /* -------------------------------------------------------------- render */
    render() {
        // the world draws into an offscreen buffer, then post-processing grades it
        const { w, h } = this;
        const p = this.player;
        const ctx = this.post.begin(w, h, this.dpr);
        ctx.fillStyle = '#08080d';
        ctx.fillRect(0, 0, w, h);
        const shX = this.cam.shakeMag ? rand(-this.cam.shakeMag, this.cam.shakeMag) : 0;
        const shY = this.cam.shakeMag ? rand(-this.cam.shakeMag, this.cam.shakeMag) : 0;
        this.view.shX = shX;
        this.view.shY = shY;
        ctx.save();
        ctx.translate(w / 2 - this.cam.x + shX, h / 2 - this.cam.y + shY);
        if (this.camZoom !== 1) {
            ctx.translate(this.cam.x, this.cam.y);
            ctx.scale(this.camZoom, this.camZoom);
            ctx.translate(-this.cam.x, -this.cam.y);
        }
        this.drawArena(ctx);
        if (this.opts.materialFx)
            this.material.drawGround(ctx);
        this.fx.drawGround(ctx);
        this.drawAfters(ctx);
        if (this.opts.materialFx)
            this.material.drawWorld(ctx);
        this.fluid.draw(ctx, 'smoke');
        const order = this.enemies.map((e) => ({ y: e.y, e }));
        order.push({ y: p.y, e: null });
        order.sort((a, b) => a.y - b.y);
        for (const o of order) {
            if (o.e)
                this.drawEnemy(ctx, o.e);
            else
                this.drawPlayer(ctx);
        }
        this.drawProjs(ctx);
        if (this.opts.materialFx)
            this.material.drawAtmosphere(ctx);
        ctx.save();
        ctx.globalAlpha = 0.45;
        this.fluid.draw(ctx, 'smoke');
        ctx.restore();
        this.fluid.draw(ctx, 'fire');
        this.fire.draw(ctx);
        this.lightning.draw(ctx);
        this.drawFx(ctx);
        this.fx.drawTop(ctx);
        if (this.opts.showHitbox)
            this.drawHitboxes(ctx);
        ctx.restore();
        /* bloom → RGB split → radial blur → vignette → film grain */
        this.post.end(this.ctx, w, h, this.dpr, {
            bloom: 0.28,
            chroma: this.chroma * 0.12,
            radial: this.radialAmt * 0.08,
            fx: p.x - this.cam.x + w / 2,
            fy: p.y - 20 - this.cam.y + h / 2,
            vignette: 0.36 + this.fx.screen.dark * 0.3,
            grain: 0.025,
            time: this.time,
            shocks: this.pressure.map((pw) => {
                const sp = this.toScreen(pw.x, pw.y);
                const k = pw.life / pw.max;
                return { x: sp.x, y: sp.y, r: pw.r * this.camZoom, width: (18 + pw.r1 * 0.12) * this.camZoom, strength: pw.strength * k * k, squash: 0.62 };
            }),
            heat: this.fluid.hotRegions().map((hr) => {
                const sp = this.toScreen(hr.x, hr.y);
                return { x: sp.x, y: sp.y, w: hr.w * this.camZoom, h: hr.h * this.camZoom, heat: hr.heat };
            }),
        });
        /* crisp overlays on top of the graded frame */
        this.ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
        const hud = this.ctx;
        this.fx.drawScreen(hud, w, h, p.x - this.cam.x + w / 2, p.y - 20 - this.cam.y + h / 2);
        if (p.flashT > 0) {
            hud.fillStyle = `rgba(232,35,42,${p.flashT * 0.16})`;
            hud.fillRect(0, 0, w, h);
        }
        this.drawReticle(hud);
        if (this.idleEditMode) {
            for (const hand of ['L', 'R']) {
                if (this.hands[hand].missing) continue;
                const pose = this.glovePose(hand);
                if (!pose.idle) continue;
                const pt = this.toScreen(pose.x, pose.y);
                hud.save();
                hud.beginPath();
                hud.arc(pt.x, pt.y, 23, 0, TAU);
                hud.strokeStyle = hand === 'L' ? '#ffcd72' : '#63dbff';
                hud.lineWidth = 1.5;
                hud.setLineDash([4, 4]);
                hud.stroke();
                hud.setLineDash([]);
                hud.fillStyle = '#0a0b10d9';
                hud.fillRect(pt.x - 14, pt.y - 39, 28, 16);
                hud.textAlign = 'center';
                hud.font = '900 12px sans-serif';
                hud.fillStyle = hand === 'L' ? '#ffcd72' : '#63dbff';
                hud.fillText(hand, pt.x, pt.y - 26);
                hud.restore();
            }
        }
        if (this.banner) {
            const b = this.banner;
            const k = b.t / b.max;
            const scale = 1 + Math.max(0, k - 0.8) * 2.2;
            hud.save();
            hud.translate(w / 2, h * 0.3);
            hud.scale(scale, scale);
            hud.globalAlpha = clamp(k * 2.4, 0, 1);
            hud.textAlign = 'center';
            hud.font = '44px "Archivo Black", sans-serif';
            hud.lineWidth = 9;
            hud.strokeStyle = 'rgba(60,5,10,0.9)';
            const grad = hud.createLinearGradient(-140, 0, 140, 0);
            grad.addColorStop(0, '#fff3d6');
            grad.addColorStop(0.5, '#f6b73c');
            grad.addColorStop(1, '#ff2e63');
            hud.fillStyle = grad;
            hud.strokeText(b.text, 0, 0);
            hud.fillText(b.text, 0, 0);
            hud.font = '600 14px "Be Vietnam Pro", sans-serif';
            hud.fillStyle = 'rgba(255,255,255,0.85)';
            hud.fillText(b.sub.toUpperCase(), 0, 26);
            hud.restore();
        }
    }
    drawArena(ctx) {
        const view = { x: this.cam.x - this.w / 2 - 60, y: this.cam.y - this.h / 2 - 60, w: this.w + 120, h: this.h + 120 };
        // lab floor
        ctx.fillStyle = '#0c0e15';
        ctx.fillRect(view.x, view.y, view.w, view.h);
        ctx.strokeStyle = 'rgba(120,140,190,0.07)';
        ctx.lineWidth = 1;
        const gs = 100;
        ctx.beginPath();
        for (let x = Math.floor(view.x / gs) * gs; x < view.x + view.w; x += gs) {
            ctx.moveTo(x, view.y);
            ctx.lineTo(x, view.y + view.h);
        }
        for (let y = Math.floor(view.y / gs) * gs; y < view.y + view.h; y += gs) {
            ctx.moveTo(view.x, y);
            ctx.lineTo(view.x + view.w, y);
        }
        ctx.stroke();
        // boxing ring (top-down)
        const R = 800;
        ctx.fillStyle = ctx.createPattern((0, textures_1.floorTex)(), 'repeat') ?? '#25272b';
        ctx.fillRect(-R, -R, R * 2, R * 2);
        const grd = ctx.createRadialGradient(0, 0, 100, 0, 0, R * 1.3);
        grd.addColorStop(0, 'rgba(133,114,91,0.16)');
        grd.addColorStop(1, 'rgba(0,0,0,0.52)');
        ctx.fillStyle = grd;
        ctx.fillRect(-R, -R, R * 2, R * 2);
        // ropes
        const ropes = [[800, '#e8232a'], [772, '#f5efe2'], [744, '#2f6df6']];
        for (const [r, c] of ropes) {
            ctx.strokeStyle = c;
            ctx.globalAlpha = 0.75;
            ctx.lineWidth = 7;
            ctx.strokeRect(-r, -r, r * 2, r * 2);
        }
        ctx.globalAlpha = 1;
        // corner pads
        const corners = [[-800, -800, '#e8232a'], [800, -800, '#f5efe2'], [-800, 800, '#f5efe2'], [800, 800, '#2f6df6']];
        for (const [x, y, c] of corners) {
            ctx.fillStyle = c;
            ctx.beginPath();
            ctx.arc(x, y, 42, 0, TAU);
            ctx.fill();
            ctx.strokeStyle = 'rgba(0,0,0,0.4)';
            ctx.lineWidth = 3;
            ctx.stroke();
        }
        // measurement rings
        ctx.setLineDash([10, 14]);
        for (const r of [220, 420, 620]) {
            ctx.strokeStyle = 'rgba(246,183,60,0.16)';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.arc(0, 0, r, 0, TAU);
            ctx.stroke();
        }
        ctx.setLineDash([]);
        // arena boundary
        ctx.strokeStyle = 'rgba(255,80,80,0.35)';
        ctx.lineWidth = 3;
        ctx.setLineDash([16, 12]);
        ctx.beginPath();
        ctx.arc(0, 0, ARENA_R, 0, TAU);
        ctx.stroke();
        ctx.setLineDash([]);
        // center emblem: gold ring + lightning bolt
        ctx.strokeStyle = 'rgba(246,183,60,0.5)';
        ctx.lineWidth = 5;
        ctx.beginPath();
        ctx.arc(0, 0, 165, 0, TAU);
        ctx.stroke();
        ctx.fillStyle = 'rgba(246,183,60,0.2)';
        ctx.beginPath();
        const bolt = [[18, -92], [-38, 8], [-6, 8], [-20, 92], [42, -14], [8, -14]];
        bolt.forEach(([x, y], i) => (i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y)));
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,0.05)';
        ctx.font = '900 54px "Be Vietnam Pro", sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('TEST LAB', 0, 248);
    }
    drawRibbons(ctx) {
        for (const r of this.ribbons) {
            const pts = r.pts;
            const n = pts.length;
            // segment quads, alternating palette — the striped ribbon look
            for (let i = 0; i < n - 1; i++) {
                const a = pts[i], b = pts[i + 1];
                const dx = b.x - a.x, dy = b.y - a.y;
                const d = Math.hypot(dx, dy) || 1;
                const nx = -dy / d, ny = dx / d;
                const wa = (r.width / 2) * (1 - (i / n) * 0.78);
                const wb = (r.width / 2) * (1 - ((i + 1) / n) * 0.78);
                ctx.fillStyle = i === n - 2 ? r.tip : r.palette[i % r.palette.length];
                ctx.beginPath();
                ctx.moveTo(a.x + nx * wa, a.y + ny * wa);
                ctx.lineTo(b.x + nx * wb, b.y + ny * wb);
                ctx.lineTo(b.x - nx * wb, b.y - ny * wb);
                ctx.lineTo(a.x - nx * wa, a.y - ny * wa);
                ctx.closePath();
                ctx.fill();
                ctx.strokeStyle = 'rgba(46,8,10,0.4)';
                ctx.lineWidth = 1;
                ctx.stroke();
            }
            // gold pointed tip
            const last = pts[n - 1], prev = pts[n - 2];
            const dx = last.x - prev.x, dy = last.y - prev.y;
            const d = Math.hypot(dx, dy) || 1;
            ctx.fillStyle = r.tip;
            ctx.beginPath();
            ctx.moveTo(last.x, last.y);
            ctx.lineTo(last.x + (dx / d) * 16 - (-dy / d) * 5, last.y + (dy / d) * 16 - (dx / d) * 5);
            ctx.lineTo(last.x + (dx / d) * 22, last.y + (dy / d) * 22);
            ctx.lineTo(last.x + (dx / d) * 16 + (-dy / d) * 5, last.y + (dy / d) * 16 + (dx / d) * 5);
            ctx.closePath();
            ctx.fill();
        }
    }
    drawAfters(ctx) {
        if (!this.sprites)
            return;
        ctx.save();
        ctx.globalCompositeOperation = 'lighter';
        for (const a of this.afters) {
            const k = a.life / a.maxLife;
            if (a.kind === 'body') {
                const img = this.tinted(this.sprites.body, 'body', a.color);
                const scl = BODY_H / img.height;
                const bw = img.width * scl;
                ctx.save();
                ctx.globalAlpha = k * 0.42;
                ctx.translate(a.x, a.y + BODY_FOOT);
                ctx.scale(a.sx, 1);
                ctx.drawImage(img, -bw / 2, -BODY_H, bw, BODY_H);
                ctx.restore();
            }
            else {
                ctx.globalAlpha = k * 0.5;
                this.drawGloveImg(ctx, this.tinted(this.sprites.glove, 'glove', a.color), a.x, a.y, a.angle, GLOVE_SIZE * 1.1, a.mirror, 1.2, 0.9);
            }
        }
        ctx.restore();
    }
    drawEnemy(ctx, e) {
        const spr = this.sprites ? (e.kind === 'bot' ? this.sprites.bot : this.sprites.dummy) : null;
        // shadow
        ctx.fillStyle = 'rgba(0,0,0,0.4)';
        ctx.beginPath();
        const shadowScale = Math.max(0.04, 1 - e.z / 420);
        ctx.ellipse(e.x, e.y + e.r * 0.72, e.r * shadowScale, e.r * 0.36 * shadowScale, 0, 0, TAU);
        ctx.fill();
        ctx.save();
        ctx.translate(e.x, e.y - e.z);
        const squash = 1 + Math.sin(clamp(e.wob, -1.2, 1.2)) * 0.09;
        ctx.rotate(Math.sin(e.wob) * 0.1);
        ctx.scale(2 - squash > 0 ? 1 / squash : 1, squash);
        if (e.kind === 'bot')
            ctx.translate(0, Math.sin(this.time * 3 + e.id) * 3);
        const size = e.r * 2.9;
        if (spr) {
            if (e.flash > 0.15)
                ctx.filter = `brightness(${1 + e.flash * 1.8}) saturate(0.6)`;
            ctx.drawImage(spr, -size / 2, -size / 2, size, size);
            ctx.filter = 'none';
        }
        else {
            ctx.fillStyle = e.kind === 'bot' ? '#3f3f46' : '#b08954';
            ctx.beginPath();
            ctx.arc(0, 0, e.r, 0, TAU);
            ctx.fill();
        }
        ctx.restore();
        if (e.kind === 'boss') {
            ctx.strokeStyle = 'rgba(255,46,99,0.55)';
            ctx.lineWidth = 3;
            ctx.setLineDash([8, 8]);
            ctx.beginPath();
            ctx.arc(e.x, e.y, e.r + 14 + Math.sin(this.time * 4) * 3, 0, TAU);
            ctx.stroke();
            ctx.setLineDash([]);
        }
        if (e.slowT > 0) {
            ctx.strokeStyle = 'rgba(56,225,255,0.7)';
            ctx.lineWidth = 2.5;
            ctx.beginPath();
            ctx.arc(e.x, e.y - e.z, e.r + 6, 0, TAU);
            ctx.stroke();
        }
        // hp bar
        const bw = Math.max(52, e.r * 1.9);
        const bx = e.x - bw / 2, by = e.y - e.z - e.r - 26;
        ctx.fillStyle = 'rgba(0,0,0,0.55)';
        ctx.fillRect(bx - 1.5, by - 1.5, bw + 3, 9);
        const f = clamp(e.hp / e.maxHp, 0, 1);
        ctx.fillStyle = f > 0.5 ? '#4ade80' : f > 0.25 ? '#facc15' : '#ef4444';
        ctx.fillRect(bx, by, bw * f, 6);
        ctx.fillStyle = 'rgba(255,255,255,0.92)';
        ctx.font = '700 10px "Be Vietnam Pro", sans-serif';
        ctx.textAlign = 'center';
        const label = { dummy: 'BAO CÁT', bot: 'ROBOT', tank: 'TANK', boss: 'BOSS' }[e.kind];
        ctx.fillText(`${label} · ${Math.max(0, Math.ceil(e.hp))}`, e.x, by - 5);
    }
    drawPlayer(ctx) {
        const p = this.player;
        // meteor landing marker
        if (this.leap) {
            const L = this.leap;
            const pr = clamp(L.t / L.dur, 0, 1);
            ctx.save();
            ctx.strokeStyle = '#ff9f2e';
            ctx.globalAlpha = 0.8;
            ctx.lineWidth = 3;
            ctx.setLineDash([14, 10]);
            ctx.beginPath();
            ctx.ellipse(L.tx, L.ty + 20, 225 * (1 - pr * 0.3), 225 * 0.7 * (1 - pr * 0.3), 0, 0, TAU);
            ctx.stroke();
            ctx.setLineDash([]);
            ctx.globalCompositeOperation = 'lighter';
            ctx.globalAlpha = 0.25 + pr * 0.5;
            ctx.drawImage(this.fx.glow('#ff7a3c'), L.tx - 90, L.ty - 40, 180, 120);
            ctx.restore();
        }
        const poses = {
            L: this.hands.L.missing ? null : this.glovePose('L'),
            R: this.hands.R.missing ? null : this.glovePose('R'),
        };
        // ground shadows: body + one per glove (sells the floating fists)
        const groundY = p.y + BODY_FOOT - 2;
        const zf = Math.max(0.04, 1 - p.z / 460);
        ctx.fillStyle = 'rgba(0,0,0,0.42)';
        ctx.beginPath();
        ctx.ellipse(p.x, groundY, 38 * zf, 13 * zf, 0, 0, TAU);
        ctx.fill();
        for (const k of ['L', 'R']) {
            const g = poses[k];
            if (!g)
                continue;
            const off = g.y - (p.y + SHOULDER_Y - p.z);
            ctx.fillStyle = 'rgba(0,0,0,0.3)';
            ctx.beginPath();
            ctx.ellipse(g.x, groundY - 2 + off, 19 * g.scale * zf, 7 * zf, 0, 0, TAU);
            ctx.fill();
        }
        if (p.invulnT > 0 && p.dashT <= 0 && !this.leap) {
            ctx.strokeStyle = 'rgba(56,225,255,0.5)';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.ellipse(p.x, groundY, 52 + Math.sin(this.time * 10) * 3, 20, 0, 0, TAU);
            ctx.stroke();
        }
        // meteor fire aura while airborne
        if (this.leap) {
            ctx.save();
            ctx.globalCompositeOperation = 'lighter';
            ctx.globalAlpha = 0.85;
            const r = 90 + Math.sin(this.time * 30) * 6;
            ctx.drawImage(this.fx.glow('#ff7a3c'), p.x - r, p.y - p.z - 30 - r, r * 2, r * 2);
            ctx.restore();
        }
        this.drawRibbons(ctx);
        // Only use user-selected z-order when both gloves are idle.
        const handOrder = (poses.L?.idle && poses.R?.idle)
            ? (this.idlePose.front === 'L' ? ['R', 'L'] : ['L', 'R'])
            : ['L', 'R'];
        for (const k of handOrder) {
            const g = poses[k];
            if (g && g.behind) this.drawGlovePose(ctx, g);
        }
        this.drawBody(ctx);
        for (const k of handOrder) {
            const g = poses[k];
            if (g && !g.behind) this.drawGlovePose(ctx, g);
        }
        // orbit gloves
        if (p.orbitT > 0 && this.sprites) {
            ctx.save();
            ctx.globalCompositeOperation = 'lighter';
            ctx.globalAlpha = 0.35;
            ctx.strokeStyle = '#4dffb8';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.ellipse(p.x, p.y, 108, 108, 0, 0, TAU);
            ctx.stroke();
            ctx.restore();
            for (let i = 0; i < 2; i++) {
                const a = p.orbitA + i * Math.PI;
                const gx = p.x + Math.cos(a) * 108, gy = p.y + Math.sin(a) * 108 + SHOULDER_Y;
                ctx.save();
                ctx.globalCompositeOperation = 'lighter';
                ctx.drawImage(this.fx.glow('#4dffb8'), gx - 46, gy - 46, 92, 92);
                ctx.restore();
                this.drawGloveImg(ctx, this.tinted(this.sprites.glove, 'glove', '#4dffb8'), gx, gy, a + Math.PI / 2, 60, i === 0, 1.15, 0.9);
                ctx.save();
                ctx.globalAlpha = 0.75;
                this.drawGlove(ctx, gx, gy, a + Math.PI / 2, 52, i === 0);
                ctx.restore();
            }
        }
        // Counter stance is protected by moving, textured energy vapor rather
        // than flat hexagons; the fists remain visible through the wisps.
        if (p.guardT > 0) {
            const cx = p.x, cy = p.y - 24 - p.z;
            ctx.save();
            ctx.globalCompositeOperation = 'screen';
            for (let i = 0; i < 4; i++) {
                const a = this.time * (1.1 + i * 0.15) + (i / 4) * TAU;
                const w = 86 + Math.sin(this.time * 4 + i) * 10;
                ctx.globalAlpha = 0.23 + Math.sin(this.time * 7 + i) * 0.07;
                ctx.drawImage((0, textures_1.smokeTex)(i % 2 ? '#b48c45' : '#d8bc78', 1 + i), cx + Math.cos(a) * 30 - w / 2, cy + Math.sin(a) * 25 - w / 2, w, w);
            }
            ctx.restore();
        }
        // empowered aura
        if (p.empoweredT > 0) {
            ctx.save();
            ctx.globalCompositeOperation = 'lighter';
            ctx.globalAlpha = 0.35 + Math.sin(this.time * 9) * 0.12;
            ctx.drawImage(this.fx.glow('#ff7a3c'), p.x - 80, p.y - 40 - p.z - 80, 160, 160);
            ctx.restore();
        }
    }
    drawBody(ctx) {
        const p = this.player;
        ctx.save();
        ctx.translate(p.x, p.y + BODY_FOOT - p.z);
        const catchK = this.rocketCatchResponse();
        const catchC = this.rocketCatch;
        if (catchC) {
            ctx.translate(catchC.dx * 21 * catchK, catchC.dy * 12 * catchK);
        }
        ctx.rotate(p.lean + (catchC ? (catchC.dx * 0.17 + catchC.dy * 0.10 * Math.sign(p.faceX || 1)) * catchK : 0)); // pivot at the feet
        let sx = p.faceX, sy = 1;
        if (catchC) {
            sx *= 1 + 0.14 * Math.max(0, catchK);
            sy *= 1 - 0.22 * Math.max(0, catchK) + 0.035 * Math.max(0, -catchK);
        }
        const breathe = Math.sin(this.time * 2.6) * 0.022;
        sy += breathe;
        sx *= 1 - breathe * 0.5;
        if (p.squashT > 0) {
            const k = p.squashT / 0.3;
            sy *= 1 - 0.24 * k;
            sx *= 1 + 0.2 * k;
        }
        if (this.leap) {
            sy *= 1.08;
            sx *= 0.94;
        }
        if (p.cycloneT > 0) {
            const c = Math.cos(p.spinA * 0.5);
            sx = Math.sign(c || 1) * Math.max(0.28, Math.abs(c));
        }
        ctx.scale(sx, sy);
        const sp = this.sprites?.body;
        if (sp) {
            const scl = BODY_H / sp.height;
            const bw = sp.width * scl;
            if (p.flashT > 0.2)
                ctx.filter = `brightness(${1 + p.flashT}) sepia(0.6) hue-rotate(-30deg)`;
            ctx.drawImage(sp, -bw / 2, -BODY_H, bw, BODY_H);
            ctx.filter = 'none';
        }
        else {
            ctx.fillStyle = '#e8232a';
            ctx.beginPath();
            ctx.arc(0, -BODY_H / 2, 40, 0, TAU);
            ctx.fill();
        }
        ctx.restore();
    }
    drawGlovePose(ctx, g) {
        const p = this.player;
        if (g.active || p.empoweredT > 0) {
            ctx.save();
            ctx.globalCompositeOperation = 'lighter';
            ctx.globalAlpha = g.active ? 0.75 : 0.4;
            const r = 54 * g.scale;
            ctx.drawImage(this.fx.glow(p.empoweredT > 0 ? '#ff7a3c' : this.trailColor), g.x - r, g.y - r, r * 2, r * 2);
            ctx.restore();
        }
        this.drawGlove(ctx, g.x, g.y, g.angle, GLOVE_SIZE * g.scale, g.mirror, g.sx, g.sy);
    }
    drawGloveImg(ctx, img, x, y, angle, size, mirror, sx = 1, sy = 1) {
        const scl = size / Math.max(img.width, img.height);
        const iw = img.width * scl, ih = img.height * scl;
        ctx.save();
        ctx.translate(x, y);
        ctx.rotate(angle); // local +x = punch direction
        ctx.scale(sx, sy); // stretch/squash along the punch axis
        if (mirror)
            ctx.scale(1, -1); // mirror across the punch axis (left hand)
        ctx.rotate(GLOVE_ROT); // sprite fist (up-left) → +x
        ctx.drawImage(img, -iw / 2, -ih / 2, iw, ih);
        ctx.restore();
    }
    drawGlove(ctx, x, y, angle, size, mirror, sx = 1, sy = 1) {
        if (!this.sprites) {
            ctx.fillStyle = '#e8232a';
            ctx.beginPath();
            ctx.arc(x, y, size / 2.4, 0, TAU);
            ctx.fill();
            return;
        }
        this.drawGloveImg(ctx, this.sprites.glove, x, y, angle, size, mirror, sx, sy);
    }
    // V1.1 DETAIL ADDITIVE ROCKET ACCENTS — no replacements to any base VFX.
    // Intentionally no fx.impact / fx.slash / ring / shock / ellipse impact graphics.
    rocketDetailTravel(pr) {
        if (pr.phase !== 'out') return;
        if (pr.traveled - (pr.detailLastDist ?? -70) < 68) return;
        pr.detailLastDist = pr.traveled;
        const spd = Math.hypot(pr.vx, pr.vy) || 1;
        const nx = pr.vx / spd, ny = pr.vy / spd;
        const x = pr.x - nx * 21, y = pr.y + SHOULDER_Y - ny * 21;
        const side = (Math.sin(pr.traveled * 0.08) >= 0 ? 1 : -1);
        // Use the ORIGINAL fractal-electric engine; just two short leader filaments.
        this.lightning.strike(x, y, x - nx * 28 - ny * side * 19, y - ny * 28 + nx * side * 19,
            '#ffd86d', 1.15, { branches: 0, life: 0.10, rough: 0.44 });
        this.burst(x, y, 2, ['#fff0b8', '#ff963f'], 'spark', 80, 2.4, 0.22);
    }
    rocketDetailContact(pr, e) {
        const spd = Math.hypot(pr.vx, pr.vy) || 1;
        const nx = pr.vx / spd, ny = pr.vy / spd;
        const x = pr.x + nx * 15, y = pr.y + SHOULDER_Y + ny * 15;
        // Radial glyphs/impact slash icons forbidden: only straight directional sparks
        // and fractal lightning. Base's original contact ring/eruption is retained.
        this.sparkCone(x, y, Math.atan2(ny,nx), 9,
            ['#ffffff','#ffe5a3','#ff963f'], 330, 0.30, 2.6);
        this.lightning.strike(x, y, x + nx * 35 - ny * 25, y + ny * 35 + nx * 25,
            '#ffda78', 1.5, { branches: 1, life: 0.14, rough: 0.48 });
        this.lightning.strike(x, y, x + nx * 28 + ny * 23, y + ny * 28 - nx * 23,
            '#fff4c6', 1.1, { branches: 0, life: 0.11, rough: 0.46 });
        this.shake(5.4);      // base already calls shake(4), this increases feel only
        this.hitstop(0.053); // base already calls hitstop(.04); same genuine contact
    }
    rocketDetailReturn(pr) {
        if (pr.phase !== 'return') return;
        if (this.time - (pr.detailReturnTime ?? -1e6) < 0.070) return;
        pr.detailReturnTime = this.time;
        const spd = Math.hypot(pr.vx, pr.vy) || 1;
        const nx = pr.vx / spd, ny = pr.vy / spd;
        const x = pr.x - nx * 25, y = pr.y + SHOULDER_Y - ny * 25;
        this.lightning.strike(x, y, x - nx * 25 - ny * 13, y - ny * 25 + nx * 13,
            '#82ffd5', 1.35, { branches: 0, life: 0.12, rough: 0.43 });
    }
    drawRocketDetail(ctx, pr) {
        const speed = Math.hypot(pr.vx, pr.vy) || 1;
        const ux = pr.vx / speed, uy = pr.vy / speed;
        const y = pr.y + SHOULDER_Y;
        ctx.save();
        ctx.translate(pr.x, y);
        ctx.rotate(Math.atan2(uy, ux));
        ctx.globalCompositeOperation = 'lighter';
        ctx.lineCap = 'round';
        // Longitudinal speed lines from the true rocket position: NOT an impact icon.
        if (pr.phase === 'out') {
            const t = this.time * 30;
            for (let i = 0; i < 4; i++) {
                const stagger = i * 11 + (Math.sin(t + i * 2.3) + 1) * 5;
                const off = i * 13 - 20;
                ctx.globalAlpha = 0.36 + 0.11 * Math.sin(t + i);
                ctx.strokeStyle = i % 2 ? '#ffb04f' : '#ffe5b4';
                ctx.lineWidth = i % 2 ? 1.8 : 1.25;
                ctx.beginPath();
                ctx.moveTo(-28 - stagger, off * 0.65);
                ctx.lineTo(-67 - stagger, off * 0.65 + Math.sin(t + i) * 2.5);
                ctx.stroke();
            }
        } else if (pr.phase === 'return') {
            // A continuous open emerald spring / helical ribbon, not a closed ring.
            // Only renders for the actual glove on its return trajectory.
            const t = this.time * 24;
            for (let lane = 0; lane < 2; lane++) {
                ctx.beginPath();
                for (let i = 0; i <= 36; i++) {
                    const k = i / 36, x = -10 - k * 115;
                    const envelope = Math.pow(1-k, 0.85);
                    const yy = Math.sin(k * Math.PI * 7 + t + lane * Math.PI) * 19 * envelope;
                    if (i===0)ctx.moveTo(x,yy); else ctx.lineTo(x,yy);
                }
                ctx.globalAlpha = lane === 0 ? 0.68 : 0.36;
                ctx.lineWidth = lane===0 ? 2.5 : 1.6;
                ctx.strokeStyle = lane === 0 ? '#72ffd0' : '#d0fff1';
                ctx.shadowColor = '#3ddfb4';
                ctx.shadowBlur = 6;
                ctx.stroke();
            }
        }
        ctx.restore();
    }
    drawProjs(ctx) {
        for (const pr of this.projs) {
            if (pr.kind === 'rocket') {
                const col = pr.phase === 'out' ? '#ff7a3c' : '#38e1ff';
                const y = pr.y + SHOULDER_Y;
                ctx.save();
                ctx.globalCompositeOperation = 'lighter';
                ctx.globalAlpha = 0.9;
                ctx.drawImage(this.fx.glow(col), pr.x - 70, y - 70, 140, 140);
                // spiralling energy rings around the fist
                ctx.strokeStyle = pr.phase === 'out' ? '#ffd23c' : '#a5f3fc';
                ctx.lineWidth = 3;
                for (let i = 0; i < 3; i++) {
                    const off = ((this.time * 9 + i / 3) % 1) * 70;
                    ctx.globalAlpha = 1 - off / 70;
                    const rx = pr.x - Math.cos(pr.angle) * off, ry = y - Math.sin(pr.angle) * off;
                    ctx.beginPath();
                    ctx.ellipse(rx, ry, 10 + off * 0.25, 30 + off * 0.3, pr.angle, 0, TAU);
                    ctx.stroke();
                }
                ctx.restore();
                // All original rocket render layers above remain byte-for-byte unchanged.
                this.drawRocketDetail(ctx, pr);
                this.drawGlove(ctx, pr.x, y, pr.angle, 86, false, 1.15, 0.92);
            }
            else if (pr.kind === 'wave') {
                ctx.save();
                ctx.translate(pr.x, pr.y + 10);
                ctx.rotate(pr.angle);
                ctx.globalCompositeOperation = 'lighter';
                ctx.drawImage(this.fx.glow('#ffb03c'), -60, -70, 120, 140);
                ctx.strokeStyle = 'rgba(255,176,60,0.95)';
                ctx.lineWidth = 9;
                ctx.beginPath();
                ctx.arc(0, 0, 54, -1.1, 1.1);
                ctx.stroke();
                ctx.strokeStyle = 'rgba(255,255,255,0.9)';
                ctx.lineWidth = 3;
                ctx.beginPath();
                ctx.arc(0, 0, 44, -1, 1);
                ctx.stroke();
                ctx.strokeStyle = 'rgba(255,120,40,0.6)';
                ctx.lineWidth = 5;
                ctx.beginPath();
                ctx.arc(0, 0, 30, -0.9, 0.9);
                ctx.stroke();
                ctx.restore();
            }
            else {
                ctx.save();
                ctx.globalCompositeOperation = 'lighter';
                ctx.drawImage(this.fx.glow('#ef4444'), pr.x - 26, pr.y - 30 - 26, 52, 52);
                ctx.restore();
                ctx.fillStyle = '#f87171';
                ctx.beginPath();
                ctx.arc(pr.x, pr.y - 30, 9, 0, TAU);
                ctx.fill();
                ctx.fillStyle = '#fff1f2';
                ctx.beginPath();
                ctx.arc(pr.x, pr.y - 30, 4, 0, TAU);
                ctx.fill();
            }
        }
    }
    drawFx(ctx) {
        // Very restrained pressure fronts; dust and fractured ground do the work.
        for (const r of this.rings) {
            const k = r.life / r.maxLife;
            ctx.save();
            ctx.globalAlpha = k * 0.17;
            ctx.strokeStyle = r.color;
            ctx.lineWidth = Math.max(0.8, r.width * k * 0.35);
            ctx.beginPath();
            ctx.arc(r.x, r.y, r.r, 0, TAU);
            ctx.stroke();
            ctx.restore();
        }
        // lightning arcs
        for (const a of this.arcs) {
            const k = a.life / a.maxLife;
            ctx.save();
            ctx.globalAlpha = k;
            ctx.lineJoin = 'round';
            ctx.strokeStyle = a.color;
            ctx.lineWidth = a.width * 2.6;
            ctx.globalAlpha = k * 0.25;
            ctx.beginPath();
            a.pts.forEach((pt, i) => (i === 0 ? ctx.moveTo(pt.x, pt.y) : ctx.lineTo(pt.x, pt.y)));
            ctx.stroke();
            ctx.globalAlpha = k;
            ctx.strokeStyle = '#ffffff';
            ctx.lineWidth = a.width * 0.8;
            ctx.beginPath();
            a.pts.forEach((pt, i) => (i === 0 ? ctx.moveTo(pt.x, pt.y) : ctx.lineTo(pt.x, pt.y)));
            ctx.stroke();
            ctx.restore();
        }
        // particles
        for (const pt of this.particles) {
            const k = clamp(pt.life / pt.maxLife, 0, 1);
            ctx.save();
            ctx.globalAlpha = pt.kind === 'smoke' || pt.kind === 'dust' ? k * 0.4 : k;
            ctx.fillStyle = pt.color;
            ctx.strokeStyle = pt.color;
            if (pt.kind === 'spark') {
                ctx.lineWidth = pt.size * 0.5;
                ctx.beginPath();
                ctx.moveTo(pt.x, pt.y);
                ctx.lineTo(pt.x - pt.vx * 0.03, pt.y - pt.vy * 0.03);
                ctx.stroke();
            }
            else if (pt.kind === 'smoke' || pt.kind === 'dust') {
                // soft volumetric puffs instead of flat circles
                const r = pt.size * (2.6 - k * 1.15);
                ctx.globalAlpha = (pt.kind === 'dust' ? 0.17 : 0.12) * k;
                ctx.drawImage(this.fx.soft(pt.color), pt.x - r, pt.y - r, r * 2, r * 2);
            }
            else {
                ctx.beginPath();
                ctx.arc(pt.x, pt.y, pt.size * k, 0, TAU);
                ctx.fill();
            }
            ctx.restore();
        }
        // floating texts
        ctx.textAlign = 'center';
        for (const t of this.texts) {
            const k = clamp(t.life / t.maxLife, 0, 1);
            const pop = 1 + Math.max(0, k - 0.85) * 3;
            ctx.save();
            ctx.globalAlpha = Math.min(1, k * 2);
            ctx.translate(t.x, t.y);
            ctx.scale(pop, pop);
            ctx.font = `900 ${t.size}px "Be Vietnam Pro", sans-serif`;
            ctx.lineWidth = 4;
            ctx.strokeStyle = 'rgba(20,4,6,0.85)';
            ctx.strokeText(t.text, 0, 0);
            ctx.fillStyle = t.color;
            ctx.fillText(t.text, 0, 0);
            ctx.restore();
        }
        ctx.globalAlpha = 1;
    }
    drawHitboxes(ctx) {
        const p = this.player;
        ctx.save();
        ctx.strokeStyle = 'rgba(56,225,255,0.8)';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, TAU);
        ctx.stroke();
        for (const e of this.enemies) {
            ctx.strokeStyle = 'rgba(248,113,113,0.8)';
            ctx.beginPath();
            ctx.arc(e.x, e.y, e.r, 0, TAU);
            ctx.stroke();
        }
        for (const hand of ['L', 'R']) {
            if (this.hands[hand].missing)
                continue;
            const pose = this.glovePose(hand);
            ctx.strokeStyle = 'rgba(250,204,21,0.8)';
            ctx.beginPath();
            ctx.arc(pose.x, pose.y, 30 * pose.scale, 0, TAU);
            ctx.stroke();
        }
        // aim line
        ctx.strokeStyle = 'rgba(255,255,255,0.25)';
        ctx.setLineDash([4, 8]);
        ctx.beginPath();
        ctx.moveTo(p.x, p.y);
        ctx.lineTo(this.mouse.wx, this.mouse.wy);
        ctx.stroke();
        ctx.restore();
    }
    drawReticle(ctx) {
        const { x, y } = this.mouse;
        ctx.save();
        ctx.strokeStyle = '#ff4757';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(x, y, 11, 0, TAU);
        ctx.stroke();
        ctx.beginPath();
        for (const [dx, dy] of [[0, -17], [0, 17], [-17, 0], [17, 0]]) {
            ctx.moveTo(x + dx * 0.65, y + dy * 0.65);
            ctx.lineTo(x + dx, y + dy);
        }
        ctx.stroke();
        ctx.fillStyle = '#ffd23c';
        ctx.beginPath();
        ctx.arc(x, y, 2.4, 0, TAU);
        ctx.fill();
        ctx.restore();
    }
    /* -------------------------------------------------------------- snapshot */
    getSnapshot() {
        const cooldowns = {};
        const cooldownMax = {};
        for (const s of skills_1.SKILLS) {
            cooldowns[s.id] = this.cds.get(s.id) ?? 0;
            cooldownMax[s.id] = this.opts.noCooldown ? Math.min(0.35, s.cd) : s.cd;
        }
        const cutoff = this.time - 5;
        this.stats.dmgEvents = this.stats.dmgEvents.filter((e) => e.t >= cutoff);
        const dps = this.stats.dmgEvents.reduce((a, e) => a + e.dmg, 0) / 5;
        const p = this.player;
        return {
            fps: Math.round(this.fpsEma),
            enemies: this.enemies.length,
            hp: Math.max(0, Math.round(p.hp)),
            maxHp: p.maxHp,
            fury: Math.round(p.fury),
            empowered: p.empoweredT > 0,
            dashReady: 1 - clamp(p.dashCd / 2.1, 0, 1),
            cooldowns, cooldownMax,
            dps: Math.round(dps),
            totalDamage: this.stats.totalDamage,
            hits: this.stats.hits,
            combo: this.stats.combo,
            bestCombo: this.stats.bestCombo,
            maxHit: this.stats.maxHit,
            kos: this.stats.kos,
            casting: this.castingName,
            paused: this.paused,
            log: [...this.logArr],
        };
    }
}
exports.Engine = Engine;

}};
const cache={};
function load(f){
 f=f.replace(/^\.\//,'');
 if(f in ASSETS) return {default:ASSETS[f]};
 if(cache[f]) return cache[f].exports;
 const func=modules[f]; if(!func) throw new Error('Missing bundled module: '+f);
 const module={exports:{}}; cache[f]=module;
 const req=(specifier)=>{
   const target=specifier.startsWith('.')? resolvePath(f,specifier):specifier;
   return load(target);
 };
 func(module,module.exports,req);
 return module.exports;
}
function resolvePath(from, rel){
 const a=from.split('/');a.pop();
 for(const s of rel.split('/')) if(s==='..')a.pop();else if(s&&s!=='.')a.push(s);
 const base=a.join('/');
 for(const suffix of ['', '.ts', '.png', '/index.ts']) if((base+suffix) in modules || (base+suffix) in ASSETS) return base+suffix;
 throw new Error('Missing asset '+rel+' from '+from);
}

window.APEX_BOXE_GOLD_LIBRARY={Engine:load('src/game/engine.ts').Engine, preloadSprites:()=>load('src/game/sprites.ts').loadSprites(), sourceSha256:'ccb889bb08cb2e741c4f7f5e0b33d08047c08fb28bfc1c31ae9401604444e2b2'};
})();
