/* =============================================================================
 * APEX CHAOS — Hero Rework Registry (canonical product authority).
 *
 * HeroDefinitions for the canonical visible 12 (Core Six playable; six locked):
 *   ROBOT, CRYSTAL, MAGNET, BLACK_HOLE, MATH_V2, ICE, RUBBER,
 *   HUNTER, TIME, MIRROR, SLIME, SNIPER.
 *
 * Authority: docs/hero-rework/phase1/02_LEVEL1_CANONICAL_BASELINE_V1_2.md
 *            docs/hero-rework/phase1/03_HERO_DEFINITION_CONTRACT_V1_FINAL.md
 *            docs/hero-rework/phase1/04 (progression knob map)
 *            docs/hero-rework/phase1/06 (pre-pilot roster correction: six
 *            playable fighters; the remaining six stay visibly locked)
 *
 * Laws encoded here:
 *   - Lv1 baseConfig is EXACTLY the canonical baseline (hard law).
 *   - One progression knob per skill; knobPath is a FROZEN ARRAY of path
 *     segments (never a dot-split string — keys may contain dots).
 *   - maxLevel 5; minLevel 1.
 *   - No visual/final-art direction is embedded here; presentation is
 *     neutral/temporary and flagged as such.
 * ========================================================================== */

(function (globalScope) {
  'use strict';

  if (globalScope.APEX_HERO_REWORK_REGISTRY) return; // idempotent

  /* ------------------------------------------------------------------ *
   * Progression curves.
   * Lv1 MUST resolve to the exact canonical value. Lv2-5 exact live
   * balance is deferred (doc 04); curves below are bounded provisional
   * tuning slots, monotonic in the "better for the player" direction.
   * Each curve receives the Lv1 base value and the level.
   * ------------------------------------------------------------------ */
  /* ------------------------------------------------------------------ *
   * TEST-ONLY NON-PRODUCTION FIXTURE CURVES.
   *
   * Phase 1 froze progression STRUCTURE only (one knobPath per skill,
   * levels 1..5). Exact Lv2-Lv5 numeric balance is explicitly UNRESOLVED
   * (doc 04: "Exact Lv2-Lv5 values are not frozen here. What may scale is
   * frozen."). These fixtures exist ONLY so structural tests can prove the
   * one-knob law at Lv2-5. They are NOT production balance, are NOT active
   * by default, and must never be used to resolve live gameplay configs.
   * ------------------------------------------------------------------ */
  const TEST_ONLY_FIXTURE_CURVES = {
    // fixture: cooldown -12.5% per level above 1
    cooldown_step: (base, level) => (level <= 1 ? base : base * Math.pow(0.875, level - 1)),
    // fixture: magnitude +12% per level above 1
    magnitude_step: (base, level) => (level <= 1 ? base : base * (1 + 0.12 * (level - 1))),
    // fixture: fraction percentage points +0.04 (4pp) per level above 1
    pp_step: (base, level) => (level <= 1 ? base : base + 0.04 * (level - 1)),
    // fixture: fraction threshold -0.04 (4pp) per level above 1 — triggers sooner
    pp_threshold_step: (base, level) => (level <= 1 ? base : base - 0.04 * (level - 1)),
    // fixture: capacity +1 per level above 1
    capacity_step: (base, level) => (level <= 1 ? base : base + (level - 1)),
    // fixture: seconds step +0.5s per level above 1
    seconds_step: (base, level) => (level <= 1 ? base : base + 0.5 * (level - 1)),
    // fixture: multiplicative N (xN / /N) +1 per level above 1
    factor_step: (base, level) => (level <= 1 ? base : base + (level - 1)),
    // fixture: spread multiplier toward 0: -15% of remaining per level
    spread_step: (base, level) => (level <= 1 ? base : base * Math.pow(0.85, level - 1)),
    // fixture: threshold (continuous-chill / split) -0.25s or -2pp per level
    threshold_step: (base, level) => (level <= 1 ? base : base - 0.25 * (level - 1)),
  };
  // Production state: NO approved Lv2-5 curves. Fixtures activate only via
  // the explicit test hook below and are always uninstallable.
  let testCurveOverride = null;
  function installTestCurves(map) { testCurveOverride = map || TEST_ONLY_FIXTURE_CURVES; }
  function uninstallTestCurves() { testCurveOverride = null; }

  /* ------------------------------------------------------------------ *
   * Helpers — skill definition factory keeps every entry uniform.
   * ------------------------------------------------------------------ */
  function skill(id, slot, mechanicId, baseConfig, knobPath, curveId, extra) {
    return Object.freeze({
      id,
      slot,
      kind: slot === 'PASSIVE' ? 'PASSIVE' : 'ACTIVE',
      mechanicId,
      baseConfig: Object.freeze(baseConfig),
      progressionBinding: Object.freeze({
        minLevel: 1,
        maxLevel: 5,
        knobPath: Object.freeze(knobPath.slice()), // frozen ARRAY (law)
        // Lv1 canonical values are authority; Lv2-5 numeric balance is
        // UNRESOLVED. fixtureCurveRef names a TEST-ONLY fixture for
        // structural one-knob proofs — never a production balance source.
        curveRef: null,
        curveStatus: 'UNRESOLVED',
        fixtureCurveRef: curveId,
      }),
      activationPolicy: slot === 'PASSIVE' ? 'ALWAYS' : 'MANUAL',
      lifecyclePolicyRef: `${mechanicId}.lifecycle@lv1`,
      presentationEventNamespace: 'hero-rework.presentation',
      telemetrySkillId: id,
      ...(extra || {}),
    });
  }

  /* ------------------------------------------------------------------ *
   * The canonical 12. Every baseConfig number below is copied verbatim
   * from the Level-1 canonical baseline doc — do not "fix" them without
   * a newer design authority.
   * ------------------------------------------------------------------ */

  const HEROES = {
    /* ---------------------------------------------------------------- *
     * 1. ROBOT — product-facing replacement for legacy NEWBIE.
     * ---------------------------------------------------------------- */
    ROBOT: {
      id: 'ROBOT',
      name: 'ROBOT',
      // Product display copy only; storage/canonical id stays ROBOT.
      displayName: 'NEWBOT',
      classRef: 'rework.robot',
      skills: {
        A1: skill('robot.weapon_dash', 'A1', 'robot.weapon_dash', {
          cooldown: 10, dashSpeed: 3400, maxDashTime: 0.55, turnRate: 11,
          arriveRadius: 34, targetRevealedPickups: true, t6AutoTarget: false,
        }, ['cooldown'], 'cooldown_step', { displayName: 'Weapon Dash', archiveProfile: { description: 'Quickly closes the distance to a revealed floor weapon.' } }),
        A2: skill('robot.virtual_armor', 'A2', 'robot.virtual_armor', {
          cooldown: 10, duration: 3.0, incomingMult: 0.45, ccImmunity: false,
        }, ['incomingMult'], 'magnitude_step', { displayName: 'Virtual Armor', archiveProfile: { description: 'Reduces incoming damage for 3 seconds.' } }),
        PASSIVE: skill('robot.damage_milestones', 'PASSIVE', 'robot.damage_milestones', {
          // POST-PLAYTEST 2026-09-29 owner correction: rolling 1.2s damage
          // burst window. Thresholds 150 -> +50 each, one crossing per
          // threshold per burst. No permanent match-wide ladder.
          burstWindowSec: 1.2, firstThreshold: 150, thresholdStep: 50,
          milestoneRefundsSec: [0, 0.5, 1.0, 1.5], // index = milestone # - 1
          stepAfterLadder: 0.5, // canonical Lv1: subsequent milestones +0.5s each
          oneProcPerMilestone: true,
        }, ['stepAfterLadder'], 'seconds_step', { displayName: 'Rolling Burst', archiveProfile: { description: 'Damage dealt inside a 1.2-second burst window refunds skill cooldown.' } }),
      },
    },

    /* ---------------------------------------------------------------- *
     * 2. CRYSTAL
     * ---------------------------------------------------------------- */
    CRYSTAL: {
      id: 'CRYSTAL',
      name: 'CRYSTAL',
      // Product display copy only; storage/canonical id stays CRYSTAL.
      displayName: 'CRYSTALA',
      classRef: 'rework.crystal',
      // CRYSTALA V1 (docs/hero-rework/crystala-v1/00_CRYSTALA_IMPLEMENTATION_AUTHORITY.md
      // §4) with the V2 minimal-delta override
      // (02_CRYSTALA_V2_SIX_SHARD_RESOURCE_AUTHORITY.md §1-§2): Wall HP 80,
      // J cooldown 8.0 s, Wall fallback on BLADE L/R [0,1] does NOT require K
      // (the live HEXA path still does — resolved in crystalGameplayRuntime),
      // K cooldown 12.0 s, read radius 450 / contact ring 300, contact->dock
      // 1.60 s. Six immortal shards; the passive scales reflected damage only
      // (no automatic body block/reflect). Lv1 numbers are FROZEN.
      skills: {
        A1: skill('crystal.context_construct', 'A1', 'crystal.context_construct', {
          // V2 §1.1: WALL may be cast without K; the HEXA (six-facet) path is
          // still an Awakening-only commitment (decisionWindow/maxCasts stay).
          cooldown: 8.0, requiresAwakening: false, minShards: 2, prisonShards: 6,
          inputBuffer: false, failConsumesCooldown: false,
          // Commitment law: HEXA is a first-half Awakening choice, not a free
          // end-of-K conversion. One successful construct maximum per K.
          decisionWindow: 1.2, maxCastsPerAwakening: 1,
          constructHpMult: 1,
          wall: { width: 220, hp: 80, solidLifetime: 4.0 },
          prison: { radius: 135, facets: 6, facetHp: 75, solidLifetime: 3.0 },
          preSolidTarget: 0.75,
        }, ['constructHpMult'], 'magnitude_step', { displayName: 'Hexa Construct', archiveProfile: { description: 'Raises a crystal wall; during Awakening it can become the HEXA.' } }),
        A2: skill('crystal.awakening', 'A2', 'crystal.awakening', {
          cooldown: 12.0, active: 2.4, shards: 6, scanRadius: 450, interceptBand: 300,
          minAnticipation: 0.12, contactToDock: 1.6,
        }, ['cooldown'], 'cooldown_step', { displayName: 'Awakening', archiveProfile: { description: 'Activates the six floating shards to defend and enable the HEXA window.' } }),
        PASSIVE: skill('crystal.refraction', 'PASSIVE', 'crystal.refraction', {
          reflectedDamagePct: 0.50, controllerChange: 'CRYSTAL', provenanceRetained: true,
          maxReflectionsPerProjectile: 1, autoBodyReflect: false, t6Reflect: false,
        }, ['reflectedDamagePct'], 'pp_step', { displayName: 'Refraction', archiveProfile: { description: 'Reflected projectiles turn against their owner.' } }),
      },
    },

    /* ---------------------------------------------------------------- *
     * 3. MAGNET
     * ---------------------------------------------------------------- */
    MAGNET: {
      id: 'MAGNET',
      name: 'MAGNET',
      classRef: 'rework.magnet',
      skills: {
        A1: skill('magnet.acquisition', 'A1', 'magnet.acquisition', {
          cooldown: 11, gameplayDuration: 1.00,
          gunAccelerationMin: 1400, gunAccelerationMax: 2400,
          gunDistanceSpan: 700, gunSpeedCap: 900, postFieldDrag: 1.8,
          bulletRadius: 480, bulletAcceleration: 14000, bulletSpeedCapMult: 1.10,
          t6Immune: true,
        }, ['gunAccelerationMax'], 'magnitude_step', { displayName: 'Magnetic Attraction', archiveProfile: { description: 'Pulls revealed floor guns toward you and curves bullets.' } }),
        A2: skill('magnet.repulsion_field', 'A2', 'magnet.repulsion_field', {
          cooldown: 13, duration: 1.80, radius: 225,
          bodyAcceleration: 2200, bodyRadialSpeedCap: 650,
          gunAcceleration: 3000, gunSpeedCap: 950,
          bulletAcceleration: 18000, bulletSpeedCapMult: 1.10,
          t6Immune: true,
        }, ['bodyAcceleration'], 'magnitude_step', { displayName: 'Magnetic Repel', archiveProfile: { description: 'Repels nearby bullets, weapons and the opponent.' } }),
        PASSIVE: skill('magnet.acceleration', 'PASSIVE', 'magnet.acceleration', {
          ownedProjectileVelocityBonus: 0.18, t6Immune: true,
        }, ['ownedProjectileVelocityBonus'], 'pp_step', { displayName: 'Magnetic Acceleration', archiveProfile: { description: 'Your projectiles fly 18% faster. T6 weapons are immune.' } }),
      },
    },

    /* ---------------------------------------------------------------- *
     * 4. BLACK_HOLE
     * ---------------------------------------------------------------- */
    BLACK_HOLE: {
      id: 'BLACK_HOLE',
      name: 'BLACK_HOLE',
      displayName: 'BLACK HOLE',
      classRef: 'rework.black_hole',
      skills: {
        A1: skill('black_hole.transit', 'A1', 'black_hole.transit', {
          cooldown: 14, activeDuration: 2.7, capacity: 8, transitDelay: 0.35,
          exitTargetDistance: 120, preserveVelocity: true, preserveProvenance: true,
          t6Immune: true,
        }, ['capacity'], 'capacity_step', { displayName: 'Gravity Transit' }),
        A2: skill('black_hole.damage_singularity', 'A2', 'black_hole.damage_singularity', {
          cooldown: 18, escrowWindow: 1.0, storedDamageCap: 300,
          returnPct: 0.65, vulnerabilityDuration: 3, vulnerabilityIncomingMult: 2,
          t6DamageCaptured: false,
        }, ['storedDamageCap'], 'magnitude_step', { displayName: 'Singularity' }),
        PASSIVE: skill('black_hole.event_horizon', 'PASSIVE', 'black_hole.event_horizon', {
          radiusPerHp: 1 / 10, maxGrowth: 100, healingShrinks: false,
          countsEscrowedDamage: false, biggerIsTargetable: true,
        }, ['radiusPerHp'], 'magnitude_step', { displayName: 'Event Horizon' }),
      },
    },

    /* ---------------------------------------------------------------- *
     * 5. MATH_V2
     * ---------------------------------------------------------------- */
    MATH_V2: {
      id: 'MATH_V2',
      name: 'MATH_V2',
      displayName: 'MATH V2',
      classRef: 'rework.math_v2',
      skills: {
        A1: skill('math.parabola_graph', 'A1', 'math.parabola_graph', {
          cooldown: 10, maxLifetime: 10, endsOnOffensiveEquipment: true,
          healPickupDoesNotEnd: false, recastReplaces: true,
          equation: 'tuning-slot', // exact parabola equation/scale/orientation is a tuning slot
        }, ['cooldown'], 'cooldown_step', { displayName: 'Parabola' }),
        A2: skill('math.damage_equation', 'A2', 'math.damage_equation', {
          cooldown: 20, armorDuration: 3,
          countersStartAt: 0, cashOnPhysicalBodyCollision: true,
          noLv1Cap: true,
        }, ['cooldown'], 'cooldown_step', { displayName: 'Final Equation' }),
        PASSIVE: skill('math.multiply_divide', 'PASSIVE', 'math.multiply_divide', {
          gateDuration: 2, xFactor: 2, divFactor: 2,
          duplicateDamagePct: 1.0, halvedDamagePct: 0.5,
          separationAngle: 'tuning-slot',
          loopSuppression: 'same-surface-zero-progress', t6Immune: true,
        }, ['xFactor'], 'factor_step', { displayName: 'Multiply / Divide' }),
      },
    },

    /* ---------------------------------------------------------------- *
     * 6. ICE (FROST V1 product identity — authority §1/§12).
     * Storage key stays ICE; class/mechanic identity is rework.frost /
     * frost.*. The old ice.bullets / ice.lane / ice.deep_freeze design is
     * intentionally superseded (authority §0/§8) and must not return.
     * Per-skill numbers below are the owner-locked Playtest V0 values.
     * Shared Frozen Floor law (Frost x1.5 / enemy x0.5) lives once in
     * APEX_FROST.FROST_LAW, never triplicated across skills.
     * ---------------------------------------------------------------- */
    ICE: {
      id: 'ICE',
      name: 'ICE',
      // FROST V1 (authority §1): stable storage/canonical key stays ICE;
      // product/display identity is FROST. No duplicate roster entry.
      displayName: 'FROST',
      classRef: 'rework.frost',
      skills: {
        A1: skill('frost.breath', 'A1', 'frost.breath', {
          // Gameplay stores full lane width. Owner micro-balance pass sets
          // full width 310, i.e. effective half-width / radial extent 155.
          cooldown: 10.5, castCommit: 0.25, length: 650, width: 310,
          floorLifetime: 4.5, thawSeconds: 0.30, lingerSeconds: 0.35,
          directDamage: 0, progressionAnchor: 1,
        }, ['progressionAnchor'], 'cooldown_step', { displayName: 'Frost Breath', archiveProfile: { description: 'Lays down ice that changes movement speed on frozen ground.' } }),
        A2: skill('frost.hunt', 'A2', 'frost.hunt', {
          cooldown: 12.5, activeWindow: 2.0, trailWidth: 120,
          segmentLifetime: 3.5, coldShockMult: 0.50,
          coldShockDuration: 1.0, directDamage: 0, progressionAnchor: 1,
        }, ['progressionAnchor'], 'cooldown_step', { displayName: 'Frost Rush', archiveProfile: { description: 'Rushes forward over fresh ice and can steal a weapon on contact.' } }),
        PASSIVE: skill('frost.deep_frost', 'PASSIVE', 'frost.deep_frost', {
          baseProcPct: 0.04, bonusProcPct: 0.04,
          freezeDuration: 0.90, postThawLock: 0.50,
          directDamage: 0, progressionAnchor: 1,
        }, ['progressionAnchor'], 'cooldown_step', { displayName: 'Frozen Bullet', archiveProfile: { description: 'Weapon hits have a chance to freeze the opponent for 0.9 seconds.' } }),
      },
    },

    /* ---------------------------------------------------------------- *
     * 7. RUBBER
     * ---------------------------------------------------------------- */
    RUBBER: {
      id: 'RUBBER',
      name: 'RUBBER',
      classRef: 'rework.rubber',
      skills: {
        A1: skill('rubber.elastic_state', 'A1', 'rubber.elastic_state', {
          cooldown: 12, activeWindow: 4, energyCap: 100,
          maxSpeedBonusPct: 0.55, postActiveDecay: 25,
          collisionStunThreshold: 60, collisionStun: 0.55,
          impulseCalibration: 'tuning-slot',
        }, ['maxSpeedBonusPct'], 'pp_step', { displayName: 'Elastic State' }),
        A2: skill('rubber.compression', 'A2', 'rubber.compression', {
          cooldown: 15, duration: 2.5, capacity: 8,
          speedLossPerStored: 0.07, speedFloorPct: 0.45,
          releasedDamagePct: 1.0, debtOnMissPct: 1.0, t6Immune: true,
        }, ['capacity'], 'capacity_step', { displayName: 'Compression' }),
        PASSIVE: skill('rubber.afterbounce', 'PASSIVE', 'rubber.afterbounce', {
          duration: 2.2, pushImpulse: 650, selfSpeedLossPct: 0.15,
          reprocRequiresNewContact: true, stun: false,
        }, ['pushImpulse'], 'magnitude_step', { displayName: 'Afterbounce' }),
      },
    },

    /* ---------------------------------------------------------------- *
     * 8. HUNTER
     * ---------------------------------------------------------------- */
    HUNTER: {
      id: 'HUNTER',
      name: 'HUNTER',
      classRef: 'rework.hunter',
      skills: {
        A1: skill('hunter.snare', 'A1', 'hunter.snare', {
          cooldown: 6.5, maxCharges: 3, trapLifetime: 6, maxActiveTraps: 3, rootDuration: 1.25,
          weakDuration: 1.0, // POST-PLAYTEST 2026-09-29: real trigger applies WEAK 1.0
          placedAtCaster: true, bulletsPickupsVfxDoNotTrigger: true,
        }, ['cooldown'], 'cooldown_step', { displayName: 'Trap Deploy', archiveProfile: { description: 'Plants a trap that roots the first opponent who steps in.' } }),
        A2: skill('hunter.pounce_weak', 'A2', 'hunter.pounce_weak', {
          cooldown: 12, windup: 0.16, moveSpeed: 2200, maxMoveTime: 0.50,
          directDamage: 0, stunDuration: 2.0, weakDuration: 1.0,
          canMiss: true, weakScope: 'combatant',
        }, ['weakDuration'], 'seconds_step', { displayName: 'Dash / Strike', archiveProfile: { description: 'Dashes in with a strike that can disarm the opponent.' } }),
        // POST-PLAYTEST 2026-09-29: passive owns WEAK amplification progression.
        // One-knob profile selector; Lv2-Lv5 numbers unresolved until owner balance.
        PASSIVE: skill('hunter.weak_law', 'PASSIVE', 'hunter.weak_law', {
          weakProfileTier: 1,
          weakDuration: 1.0, hunterIncomingMult: 1.25, outgoingMult: 0.75,
        }, ['weakProfileTier'], 'pp_step', { displayName: 'Predator\'s Law', archiveProfile: { description: 'Marked prey turns WEAK for 1 second: it takes 25% more damage and deals 25% less.' } }),
      },
    },

    /* ---------------------------------------------------------------- *
     * 9. TIME
     * ---------------------------------------------------------------- */
    TIME: {
      id: 'TIME',
      name: 'TIME',
      classRef: 'rework.time',
      skills: {
        A1: skill('time.loop', 'A1', 'time.loop', {
          cooldown: 18, recordWindow: 2, loops: 2, loopDuration: 2,
          ghostBodiesIntangible: true,
          replayWhitelist: ['bullet', 'burst', 'shotgun-fan', 'grenade-throw', 'thrown-melee'],
          replayBlacklist: ['melee-swing', 'shield', 'persistent-field', 'hero-active', 'replay-event', 't6'],
        }, ['cooldown'], 'cooldown_step', { displayName: 'Time Loop' }),
        A2: skill('time.rewind', 'A2', 'time.rewind', {
          cooldown: 16, snapshotDelay: 3,
          restores: ['hp', 'position', 'velocity'],
          doesNotRewind: ['opponent', 'world', 'projectiles', 'inventory', 'ammo', 'cooldowns'],
          noRevive: true, onlyIfAlive: true,
        }, ['cooldown'], 'cooldown_step', { displayName: 'Rewind' }),
        PASSIVE: skill('time.timeline_markers', 'PASSIVE', 'time.timeline_markers', {
          markerHorizons: [1, 2], gameplayMutation: false,
        }, ['markerHorizons', '1'], 'seconds_step', { displayName: 'Timeline Markers' }),
      },
    },

    /* ---------------------------------------------------------------- *
     * 10. MIRROR
     * ---------------------------------------------------------------- */
    MIRROR: {
      id: 'MIRROR',
      name: 'MIRROR',
      classRef: 'rework.mirror',
      skills: {
        // Checkpoint E: no copy exists before the canonical Gold OWN edge
        // (first crossing of u >= .58 on A1TS = 1.6, step 112, ~0.93333s).
        // copyLifetime starts AT OWN, never at cast.
        A1: skill('mirror.arsenal', 'A1', 'mirror.arsenal', {
          cooldown: 15, copyLifetime: 6,
          timeScale: 1.6, ownU: 0.58, actionEndU: 0.92,
          canonicalOwnSeconds: 0.93333, presentationBusySeconds: 2.2,
          copyMaterialisesAtOwn: true, instanceSafeExpiry: true,
          copiesOpponentHeldEligible: true, freshInstance: true, freshAmmo: true,
          opponentKeepsOriginal: true, whiffIfIneligible: true,
          t6Copy: false, shieldCopyExcluded: true,
        }, ['cooldown'], 'cooldown_step', { displayName: 'Mirror Arsenal', archiveProfile: { description: 'Copies the enemy\'s held weapon for a short time. T6 excluded.' } }),
        // Checkpoint E: timing is the canonical Gold fixed-step FIRST
        // CROSSING of u >= .25 on A2TS = 1.0 (step 31, ~0.25833s), resolved in
        // the post-movement seam. `snapU`/`actionEndU` are descriptive of that
        // canonical law; there is deliberately no generic scheduler delay
        // field, and the exchange no longer uses RelocationTransaction (whose
        // commit() emits between its two writes and is observer-non-atomic).
        A2: skill('mirror.exchange', 'A2', 'mirror.exchange', {
          cooldown: 12, atomicPositionSwapOnly: true,
          timeScale: 1.0, snapU: 0.25, actionEndU: 0.64,
          canonicalSnapSeconds: 0.25833, presentationBusySeconds: 1.8,
          resolvesPostMovement: true, observerAtomicPairExchange: true,
          keepsOwn: ['velocity', 'hp', 'weapon', 'status'],
        }, ['cooldown'], 'cooldown_step', { displayName: 'Atomic Exchange', archiveProfile: { description: 'Swaps the two bodies\' positions without swapping HP, velocity or weapons.' } }),
        PASSIVE: skill('mirror.shattered_mirrors', 'PASSIVE', 'mirror.shattered_mirrors', {
          // Realized-damage -> shard law (doc 08 §4, binding):
          // realized < minEventDamage -> 0; else clamp(round(d/35),1,5).
          damagePerShard: 35, minEventDamage: 20, maxShardsPerEvent: 5,
          // Checkpoint F1 — Gold-first per-owner shard/node formation law.
          // The cap is the 16/5 ECONOMY itself: three nodes own 15 of 16
          // slots, leaving 1 free shard — never the 5 required by tryForm,
          // so a fourth concurrent node is UNPRODUCIBLE. No node-count cap
          // field and no retirement mechanic exist on purpose.
          shardSlots: 16, shardsPerNode: 5, freeShardLifetime: 6,
          formAgeGate: 0.7, scanCadence: 0.3, seedRadius: 170,
          assemblyStart: 0.18, assemblyStagger: 0.06, shardTravel: 0.4,
          fillDelay: 0.04, fillSpan: 0.30, activeDelayAfterLock: 0.38,
          activeLifetime: 10, foldDuration: 0.55, orientationRange: 0.35,
          exitController: 'NEUTRAL', damageUnchanged: true, noHeroCredit: true,
          provenanceRetained: true, t6Immune: true,
          loopSuppression: 'zero-progress-only',
        }, ['freeShardLifetime'], 'seconds_step', { displayName: 'Mirror Shards', archiveProfile: { description: 'Damage creates shards that can assemble into mirror nodes.' } }),
      },
    },

    /* ---------------------------------------------------------------- *
     * 11. SLIME — one Combatant, multiple Bodies (doc 06 correction:
     * child Bodies live in AIL body collections, never in the legacy
     * global fighters[] array).
     * ---------------------------------------------------------------- */
    SLIME: {
      id: 'SLIME',
      name: 'SLIME',
      classRef: 'rework.slime',
      skills: {
        A1: skill('slime.mitosis', 'A1', 'slime.mitosis', {
          cooldown: 14, splitDuration: 6, splitInto: 2,
          hpDividedEvenly: true, areaConserveFormula: true,
          // "Initial heading divergence target is +/- 25" (doc 10) — the
          // SEMANTIC/UNIT IS AN EXPLICIT UNRESOLVED TUNING SLOT (not frozen:
          // degrees/px/px-per-s all plausible). The executor carries a
          // clearly-labeled PROVISIONAL pilot interpretation, isolated
          // behind this knob; owner freezes the unit later. It must never
          // disturb the frozen laws: non-overlap spawn, seeded
          // reproducibility, independent physical motion.
          divergenceTarget: 25, equipmentDeterministicMerge: true,
        }, ['cooldown'], 'cooldown_step', { displayName: 'Mitosis' }),
        A2: skill('slime.damage_shedding', 'A2', 'slime.damage_shedding', {
          cooldown: 16, duration: 5, damagePerChild: 100,
          carryOverProgress: true, maxChildren: 3,
          childHp: 140, childLifetime: 5, childRadius: 45,
          childSpeedPct: 0.9, childValidAutoTarget: true,
          childMayEquip: true, expiryReturnHp: true, killedChildHpLost: true,
        }, ['cooldown'], 'cooldown_step', { displayName: 'Shedding' }),
        PASSIVE: skill('slime.emergency_mitosis', 'PASSIVE', 'slime.emergency_mitosis', {
          triggerAtLostPct: 0.80, minSplitShareHp: 100,
          successfulSplitReplacesSource: true,
          combatantDiesWhenNoLivingBody: true,
        }, ['triggerAtLostPct'], 'pp_threshold_step', { displayName: 'Emergency Mitosis' }),
      },
    },

    /* ---------------------------------------------------------------- *
     * 12. SNIPER
     * ---------------------------------------------------------------- */
    SNIPER: {
      id: 'SNIPER',
      name: 'SNIPER',
      classRef: 'rework.sniper',
      skills: {
        A1: skill('sniper.farthest_corner', 'A1', 'sniper.farthest_corner', {
          cooldown: 14, cornerInset: 110, aimLostDuration: 2.2,
          opponentMayStillFireLastAim: true, t6HomingUnaffected: true,
        }, ['aimLostDuration'], 'seconds_step', { displayName: 'Farthest Corner' }),
        A2: skill('sniper.nest', 'A2', 'sniper.nest', {
          cooldown: 12, maxDuration: 4, movementSpeed: 0,
          predictiveIntercept: true, postMuzzleNormal: true,
          spreadMultiplier: 0.25,
        }, ['spreadMultiplier'], 'spread_step', { displayName: 'Sniper\'s Nest' }),
        PASSIVE: skill('sniper.distance_crit', 'PASSIVE', 'sniper.distance_crit', {
          breakpoints: [
            { dist: 250, crit: 0.00 },
            { dist: 500, crit: 0.08 },
            { dist: 750, crit: 0.16 },
            { dist: 1000, crit: 0.24 },
          ],
          additive: true, critChanceCap: 0.55, critDamageUnchanged: true,
        }, ['breakpoints'], 'pp_step', { displayName: 'Longshot' }),
      },
    },
  };

  // BOXE is an append-only, owner-approved seventh playable fighter.
  // Gold art and SFX are separate presentation authority; these fields are
  // normal Arsenal Battle gameplay only (never copy Gold's damage values).
  HEROES.BOXE = {
    id: 'BOXE',
    name: 'BOXE',
    displayName: 'BOXE',
    classRef: 'rework.boxe',
    // The canonical BOXE visual identity: projected by Shell, Pick, HUD and Result.
    identityColor: '#ffac42',
    archiveProfile: {
      subtitle: 'The Fist of Dawn',
      intro: 'An experienced rocket-glove boxer. BOXE controls space with real impacts, but both hands must physically return before he can counter again.',
      artwork: {
        avatar: '../assets/dictionary/heroes/boxe/avatar.png',
        standing: '../assets/dictionary/heroes/boxe/standing.png',
        cover: '../assets/dictionary/heroes/boxe/cover.png',
      },
      skillArt: {
        PASSIVE: '../assets/dictionary/heroes/boxe/passive.png',
        A1: '../assets/dictionary/heroes/boxe/a1.png',
        A2: '../assets/dictionary/heroes/boxe/a2.png',
      },
      traits: { damage: 0, control: 92, mobility: 65, defense: 88, field: 38 },
    },
    skills: {
      A1: skill('boxe.fist_rocket', 'A1', 'boxe.fist_rocket', {
        cooldown: 15, outboundSeconds: 5, flightSpeed: 1250,
        returnSpeed: 1450, reboundOn: ['wall','opponent'],
        flurrySeconds: 2, flurryInterval: .085, flurryPunches: 24,
        flurryHitStunSeconds: .07, impactStunSeconds: .35,
        flurryHeavyEvery: 6, flurryHeavyPushRatio: 330 / 130,
        cooldownStarts: 'after-both-gloves-caught',
        manualFlurryCancel: 'cancel-unplayed-and-recall-both',
        naturalFlurryEnd: 'recall-both',
        bulletContact: 'physical-emergency-recall',
        stunLaw: 'relative-normal-closing-speed',
        disarmOnHit: false, maxGroundGuns: 1, baseDamage: 0,
      }, ['cooldown'], 'cooldown_step', {
        displayName: 'Fist Rocket',
        archiveProfile: {
          description: 'Launch a rebounding glove for up to 5s and recall it anytime. In Heat, a hit starts a 24-hit two-glove flurry.',
        },
      }),
      A2: skill('boxe.block_and_hit', 'A2', 'boxe.block_and_hit', {
        cooldown: 20, guardSeconds: 1, counterStunSeconds: 2,
        finisherFractionRemainingHP: .10, baseDamage: 0,
      }, ['cooldown'], 'cooldown_step', {
        displayName: 'Block & Hit',
        archiveProfile: {
          description: 'Guard for 1s. A blocked attack triggers a disarming counter that stuns for 2s; Heat adds a finisher.',
        },
      }),
      PASSIVE: skill('boxe.heat', 'PASSIVE', 'boxe.heat', {
        damageThreshold: 300, enhancedSeconds: 3, cooldownRecoveryMultiplier: 2,
        eligible: 'realized-dealt-or-received-HP', resetAtEnd: true,
      }, ['damageThreshold'], 'magnitude_step', {
        displayName: 'Càng đánh càng hăng',
        archiveProfile: {
          description: 'Every 300 damage dealt or taken grants 3s of Heat: empowered casts and double cooldown recovery.',
        },
      }),
    },
  };

  // SHURI: gameplay staged on the developer branch. Do not surface in
  // product selection or assign art until the owner supplies final Gold.
  HEROES.SHURI = {
    id:'SHURI',name:'SHURI',displayName:'SHURI',classRef:'rework.shuri',
    identityColor:'#f16c41',
    archiveProfile:{
      subtitle:'Scrap Engineer',
      intro:'A scrap engineer who recycles spent guns and commands one modular field machine.',
      artwork:{
        avatar:'../assets/dictionary/heroes/shuri/avatar.webp',
        standing:'../assets/dictionary/heroes/shuri/standing.webp',
        cover:'../assets/dictionary/heroes/shuri/cover.webp',
      },
      skillArt:{
        PASSIVE:'../assets/dictionary/heroes/shuri/passive.webp',
        A1:'../assets/dictionary/heroes/shuri/a1.webp',
        A2:'../assets/dictionary/heroes/shuri/a2.webp',
      },
      traits:{damage:48,control:67,mobility:82,defense:70,field:98},
    },
    skills:{
      PASSIVE:skill('shuri.recycle','PASSIVE','shuri.recycle',{
        initialScrap:20,minimumTier:1,maximumTier:5,
        validEquipment:'canonical-gun-or-launcher',
      },['initialScrap'],'capacity_step',{
        displayName:'Recycle Snap',
        archiveProfile:{description:'Recycle each finished held T1–T5 gun into Scrap equal to its tier.'},
      }),
      A1:skill('shuri.shock_recoil','A1','shuri.shock_recoil',{
        cooldown:15,bombRadius:100,bombStunSeconds:1,bombArmedLifetime:5,
        // Pending Gold motion approval: recoil duration/speed are staging
        // defaults, NOT an owner-approved balance parameter.
        recoilSpeedPreview:1300,recoilSecondsPreview:.18,
      },['cooldown'],'cooldown_step',{
        displayName:'Shock Recoil',
        archiveProfile:{description:'Plant a bomb and build anchor, then recoil away. Its shock stuns, disarms, and recycles the enemy gun.'},
      }),
      A2:skill('shuri.machine','A2','shuri.machine',{
        cooldown:15,buildScrap:20,buildSeconds:5,structureHP:200,
        repairPerScrap:10,healPerSecond:20,
        // One operating range, measured from the structure circumference
        // (owner law 2026-10-17). It gates rack acquisition and recovery.
        operatingRange:200,
        // Each rack reload costs Scrap equal to the mounted gun's tier.
        reloadScrapPerTier:1,
      },['cooldown'],'cooldown_step',{
        displayName:'Mechanical Genesis',
        archiveProfile:{description:'Spend Scrap to build or repair her machine; it can mount a finished gun to auto-fire, or shelter SHURI to heal.'},
      }),
    },
  };

  const CANONICAL_IDS = Object.freeze(Object.keys(HEROES)); // insertion order = doc order

  /* ------------------------------------------------------------------ *
   * Level resolution. Returns a DEEP COPY of baseConfig with only the
   * knob field replaced by the curve value for `level` (2..5). Lv1
   * returns an exact deep copy of baseConfig (no mutation of the static
   * definition — hard law).
   * ------------------------------------------------------------------ */
  function deepCopy(v) {
    if (Array.isArray(v)) return v.map(deepCopy);
    if (v && typeof v === 'object') {
      const out = {};
      for (const k of Object.keys(v)) out[k] = deepCopy(v[k]);
      return out;
    }
    return v;
  }

  function resolveSkillLevel(heroId, slot, level) {
    const hero = HEROES[heroId];
    if (!hero) throw new Error(`resolveSkillLevel: unknown hero ${heroId}`);
    const def = hero.skills[slot];
    if (!def) throw new Error(`resolveSkillLevel: unknown slot ${slot} for ${heroId}`);
    const lvl = Math.max(1, Math.min(5, level | 0));
    const cfg = deepCopy(def.baseConfig);
    if (lvl === 1) return cfg; // Lv1 exact canonical baseline
    // Lv2-5: refuse to invent production balance. Only explicitly installed
    // TEST-ONLY fixtures may resolve above Lv1.
    const knobPath = def.progressionBinding.knobPath; // frozen array
    const curve = testCurveOverride && testCurveOverride[def.progressionBinding.fixtureCurveRef];
    if (!curve) {
      throw new Error(`resolveSkillLevel: Lv${lvl} of ${heroId}.${slot} is UNRESOLVED — ` +
        `no approved Lv2-5 curve exists (installTestCurves() fixtures are test-only)`);
    }
    // Read current knob value from the deep copy.
    let holder = cfg;
    for (let i = 0; i < knobPath.length - 1; i++) {
      const seg = knobPath[i];
      if (holder[seg] === undefined) holder[seg] = {};
      holder = holder[seg];
    }
    const last = knobPath[knobPath.length - 1];
    const baseVal = holder[last];
    if (typeof baseVal === 'number') {
      holder[last] = curve(baseVal, lvl);
    } else if (Array.isArray(baseVal)) {
      // SNIPER breakpoints: scale every step's crit bonus by the curve ratio
      // using the Lv1 total step as base.
      const totalStep = baseVal.reduce((s, b) => s + (b.crit || 0), 0);
      const scaled = curve(totalStep, lvl);
      const ratio = totalStep > 0 ? scaled / totalStep : 1;
      holder[last] = baseVal.map((b) => ({ dist: b.dist, crit: (b.crit || 0) * ratio }));
    } else {
      throw new Error(`resolveSkillLevel: knob ${knobPath.join('.')} of ${heroId}.${slot} is not numeric`);
    }
    return cfg;
  }

  /* ------------------------------------------------------------------ *
   * deepDiffPaths — list of shallow-deep paths where a !== b (for the
   * one-knob structural proof). Values are compared by JSON equality.
   * ------------------------------------------------------------------ */
  function deepDiffPaths(a, b, prefix, out) {
    prefix = prefix || ''; out = out || [];
    const keys = new Set([...Object.keys(a || {}), ...Object.keys(b || {})]);
    for (const k of keys) {
      const key = prefix ? prefix + '.' + k : k;
      const av = (a || {})[k], bv = (b || {})[k];
      const bothPlainObjects = av && bv && typeof av === 'object' && typeof bv === 'object'
        && !Array.isArray(av) && !Array.isArray(bv);
      const bothArrays = Array.isArray(av) && Array.isArray(bv);
      if (bothPlainObjects) {
        deepDiffPaths(av, bv, key, out);
      } else if (bothArrays) {
        // Recurse by index so a knobPath like ['markerHorizons','1']
        // diffs as exactly that element, not the whole array.
        const len = Math.max(av.length, bv.length);
        for (let i = 0; i < len; i++) {
          if (JSON.stringify(av[i]) !== JSON.stringify(bv[i])) out.push(key + '.' + i);
        }
      } else if (JSON.stringify(av) !== JSON.stringify(bv)) {
        out.push(key);
      }
    }
    return out;
  }

  /* ------------------------------------------------------------------ *
   * Registry validation — used by gates and smoke tests.
   * Invariants: original 12 heroes/36 skills remain REQUIRED and ordered;
   * well-defined extension heroes may append to the roster. Every hero
   * still has exactly 3 skill slots and exactly one progression knob.
   * knobPath is a non-empty frozen array, Lv1 resolves to canonical.
   * ------------------------------------------------------------------ */
  function validateRegistry() {
    const errors = [];
    const heroes = Object.keys(HEROES);
    const expected = ['ROBOT', 'CRYSTAL', 'MAGNET', 'BLACK_HOLE', 'MATH_V2', 'ICE', 'RUBBER', 'HUNTER', 'TIME', 'MIRROR', 'SLIME', 'SNIPER'];
    if (heroes.length < expected.length)
      errors.push(`missing legacy heroes: expected at least ${expected.length}, got ${heroes.length}`);
    // CP5.4: compare the original subset by ordinal. A future registered
    // hero may APPEND but cannot replace, reorder or silently delete a base ID.
    for (let i = 0; i < expected.length; i++) {
      if (heroes[i] !== expected[i]) errors.push(`hero order: position ${i} is ${heroes[i]}, expected ${expected[i]}`);
    }
    let skillCount = 0;
    for (const heroId of heroes) {
      const hero = HEROES[heroId];
      if (!hero || !hero.skills || typeof hero.skills !== 'object') {
        errors.push(`${heroId} missing skill registry`);
        continue;
      }
      const extras = Object.keys(hero.skills).filter(
        slot => !['A1', 'A2', 'PASSIVE'].includes(slot));
      if (extras.length) errors.push(`${heroId} unregistered extra skill slots: ${extras.join(',')}`);
      for (const slot of ['A1', 'A2', 'PASSIVE']) {
        const s = hero.skills[slot];
        if (!s) { errors.push(`${heroId}.${slot} missing`); continue; }
        skillCount++;
        const kp = s.progressionBinding && s.progressionBinding.knobPath;
        if (!Array.isArray(kp) || kp.length === 0) errors.push(`${heroId}.${slot} knobPath must be a non-empty array`);
        else {
          if (!Object.isFrozen(kp)) errors.push(`${heroId}.${slot} knobPath not frozen`);
          // exactly one knob = one terminal field; path segments must exist in baseConfig
          let holder = s.baseConfig;
          for (let i = 0; i < kp.length - 1; i++) {
            if (!holder || typeof holder !== 'object' || !(kp[i] in holder)) { errors.push(`${heroId}.${slot} knobPath segment '${kp[i]}' missing in baseConfig`); holder = null; break; }
            holder = holder[kp[i]];
          }
          if (holder && !(kp[kp.length - 1] in holder)) errors.push(`${heroId}.${slot} knob '${kp[kp.length - 1]}' missing in baseConfig`);
        }
        if (s.progressionBinding.maxLevel !== 5) errors.push(`${heroId}.${slot} maxLevel must be 5`);
        if (s.progressionBinding.minLevel !== 1) errors.push(`${heroId}.${slot} minLevel must be 1`);
        // Lv1 exactness is structural here (returns deep copy of baseConfig).
        try { resolveSkillLevel(heroId, slot, 1); } catch (e) { errors.push(`${heroId}.${slot} Lv1 resolve failed: ${e.message}`); }
        // Lv2-5 balance is UNRESOLVED: resolving above Lv1 without test
        // fixtures MUST throw (never silently invent production values).
        for (let lvl = 2; lvl <= 5; lvl++) {
          let threw = false;
          try { resolveSkillLevel(heroId, slot, lvl); } catch (e) { threw = true; }
          if (!threw) errors.push(`${heroId}.${slot} Lv${lvl} resolved without approved curve (must be unresolved)`);
        }
        // Structural one-knob law at Lv2-5, proven with TEST-ONLY fixtures:
        // the resolved config may differ from Lv1 ONLY at the knob path.
        try {
          installTestCurves();
          for (let lvl = 2; lvl <= 5; lvl++) {
            const base = resolveSkillLevel(heroId, slot, 1);
            const up = resolveSkillLevel(heroId, slot, lvl);
            const kp = s.progressionBinding.knobPath;
            const diff = deepDiffPaths(base, up);
            const knobKey = kp.join('.');
            for (const d of diff) {
              // The knob itself, or any element nested INSIDE a knob array
              // (e.g. breakpoints.2 under knob 'breakpoints'), is legal.
              if (d !== knobKey && !d.startsWith(knobKey + '.')) errors.push(`${heroId}.${slot} Lv${lvl} moved non-knob field '${d}' (one-knob law)`);
            }
            if (diff.length === 0) errors.push(`${heroId}.${slot} Lv${lvl} fixture produced no knob change`);
          }
        } catch (e) {
          errors.push(`${heroId}.${slot} fixture one-knob proof failed: ${e.message}`);
        } finally {
          uninstallTestCurves();
        }
      }
    }
    if (skillCount !== heroes.length * 3) errors.push(`expected ${heroes.length * 3} skills, got ${skillCount}`);
    return { ok: errors.length === 0, errors, heroCount: heroes.length, skillCount };
  }

  globalScope.apexHeroReworkRegistry = 'ready';
  globalScope.APEX_HERO_REWORK_REGISTRY = {
    version: '1.0.1-rebuild2',
    HEROES,
    CANONICAL_IDS,
    // TEST-ONLY fixtures (structural one-knob proofs). Production Lv2-5
    // balance remains UNRESOLVED; resolveSkillLevel throws above Lv1
    // unless these are explicitly installed by a test.
    TEST_ONLY_FIXTURE_CURVES,
    installTestCurves,
    uninstallTestCurves,
    resolveSkillLevel,
    deepCopy,
    validateRegistry,
    isCanonicalHero(id) { return Object.prototype.hasOwnProperty.call(HEROES, id); },
    // FROST V1 (authority §1): external alias + product-display layer.
    // resolveHeroId maps an external lookup (ICE or FROST) to the single
    // canonical storage key. displayNameFor maps a canonical key to the
    // product copy shown in UI/shop/pick/HUD. Storage keys never change.
    resolveHeroId(id) {
      const k = String(id == null ? '' : id).toUpperCase();
      if (k === 'FROST') return 'ICE';
      return Object.prototype.hasOwnProperty.call(HEROES, k) ? k : id;
    },
    displayNameFor(id) {
      const k = String(id == null ? '' : id).toUpperCase();
      const hero = HEROES[k === 'FROST' ? 'ICE' : k];
      return (hero && hero.displayName) || id;
    },
  };
})(typeof window !== 'undefined' ? window : globalThis);
