// ARSENAL BATTLE — spawn / hidden-reveal pickup lifecycle.
// Authoritative override: docs/arsenal-quest/CORRECTION_PASS_HANDOFF.md
// TELEGRAPH -> REVEALED -> PICKED_UP -> REMOVED
// Spawn cadence is independent of collection state; reveal is proximity-predicted.
(function apexArsenalSpawnRuntime() {
  if (window.apexArsenalSpawnRuntime === 'ready') return;
  const AQ = window.APEX_ARSENAL;
  const CFG = window.APEX_ARSENAL_CONFIG;
  const log = (event, fields) => AQ.log(event, fields);

  // Kept only for secondary feedback/debug fallback colors. Normal revealed
  // pickup rendering MUST use the committed P0 weapon atlas.
  const PLACEHOLDER_ART = {
    PISTOL:       { tag: 'PIS', color: '#ffd479' },
    SHOTGUN:      { tag: 'SHG', color: '#ffbe6b' },
    SMG:          { tag: 'SMG', color: '#b9f6ca' },
    SNIPER:       { tag: 'SNP', color: '#f4f4f4' },
    GRENADE:      { tag: 'GRN', color: '#9ccc65' },
    SABRE:        { tag: 'SAB', color: '#c9e6ff' },
    BATTLE_AXE:   { tag: 'AXE', color: '#ffb3a0' },
    DAGGER:       { tag: 'DGR', color: '#e8f4ff' },
    SPEAR:        { tag: 'SPR', color: '#d9ffb3' },
    SPIKED_CLUB:  { tag: 'CLB', color: '#e6c9ff' },
    SWIRL_SHIELD: { tag: 'SWL', color: '#9fe8ff' },
    TOWER_SHIELD: { tag: 'TWR', color: '#9fd8ff' },
    STORMBREAKER: { tag: 'STB', color: '#8fd8ff' },
  };

  function pickSpawnPoint(slots) {
    const margin = CFG.SPAWN_MARGIN;
    let best = null;
    for (let attempt = 0; attempt < 24; attempt++) {
      const x = rand(margin, GAME_SIZE - margin);
      const y = rand(margin, GAME_SIZE - margin);
      let minSlot = Infinity;
      for (const s of slots) minSlot = Math.min(minSlot, dist(x, y, s.x, s.y));
      if (minSlot >= CFG.MIN_SLOT_SPACING) return { x, y };
      if (!best || minSlot > best.minSlot) best = { x, y, minSlot };
    }
    return best ? { x: best.x, y: best.y } : { x: rand(margin, GAME_SIZE - margin), y: rand(margin, GAME_SIZE - margin) };
  }

  function pickupTouchRadius(f) {
    // Match the Quest hostile collision silhouette instead of collecting
    // guns while their pincers are still visibly a body-width away.
    if(f?.questTeam==='HOSTILE'&&['scout','reaver','sentinel'].includes(f?.questSpecies))
      return (f.radius||75)*.52+CFG.PICKUP_RADIUS+23;
    return (f?.radius || 75) * 0.6 + CFG.PICKUP_RADIUS + CFG.PICKUP_TOUCH_BONUS;
  }

  function isEligibleForPickup(f) {
    if (!f || f.hp <= 0) return false;
    const weaponApi = AQ.weaponApi;
    return !(weaponApi && weaponApi.getHolder && weaponApi.getHolder(f));
  }

  // V2 B-handoff A-CORR-2: whole-circle reveal. The hidden slot IS the visible
  // question-mark pickup circle, and its radius is the shared config value
  // CFG.REVEAL_CIRCLE_RADIUS that drawSlots renders, so rendering and reveal
  // logic cannot drift. The fighter's CURRENT straight movement segment is
  // tested as a ray against that circle:
  //  - fighter already inside the circle        -> eta 0 (immediate reveal);
  //  - segment enters the circle within the
  //    fixed 2.0s lead                          -> that entry eta;
  //  - near miss OUTSIDE the visible circle     -> null (stays hidden);
  //  - a wall bounce happens before entry       -> null (no pre-bounce reveal;
  //    recomputed naturally after the bounce).
  // No center-crossing requirement, no multi-bounce future predictor.
  function predictContactETA(slot, fighter) {
    if (!slot || !fighter || !isEligibleForPickup(fighter)) return null;
    let dx = fighter.dir?.x || 0;
    let dy = fighter.dir?.y || 0;
    const mag = Math.hypot(dx, dy);
    if (!(mag > 1e-6)) return null;
    dx /= mag;
    dy /= mag;

    let speed = Number(fighter.baseSpeed ?? CFG.FIGHTER_SPEED ?? 0);
    if (typeof fighter.speedMult === 'function') speed *= Math.max(0, fighter.speedMult());
    if (!(speed > 0)) return null;

    const R = Number(CFG.REVEAL_CIRCLE_RADIUS ?? 42);
    const rx = slot.x - fighter.x;
    const ry = slot.y - fighter.y;
    const c2 = rx * rx + ry * ry;
    if (c2 <= R * R) return 0;                      // already inside visible circle

    const proj = rx * dx + ry * dy;                 // along-track distance to center
    if (proj <= 0) return null;                     // circle is behind the fighter
    const perp2 = c2 - proj * proj;                 // squared cross-track miss
    if (perp2 > R * R) return null;                 // near miss outside the circle

    const tEnter = (proj - Math.sqrt(R * R - perp2)) / speed;
    const lead = Number(CFG.REVEAL_LEAD_SECONDS ?? 2.0);
    if (!(tEnter >= 0) || tEnter > lead + 1e-9) return null;

    // Wall-bounce guard: only the current straight segment counts. Circle entry
    // must happen before the fighter body would touch any arena wall.
    const radius = fighter.radius || 75;
    let tWall = Infinity;
    if (dx > 1e-9) tWall = Math.min(tWall, (GAME_SIZE - radius - fighter.x) / (dx * speed));
    if (dx < -1e-9) tWall = Math.min(tWall, (radius - fighter.x) / (dx * speed));
    if (dy > 1e-9) tWall = Math.min(tWall, (GAME_SIZE - radius - fighter.y) / (dy * speed));
    if (dy < -1e-9) tWall = Math.min(tWall, (radius - fighter.y) / (dy * speed));
    if (tEnter > tWall + 1e-9) return null;         // would bounce first -> stay hidden

    return tEnter;
  }

  // Quest 01 weapon economy is explicitly ONLY white/green T1/T2.
  // The donor's T3–T6 loot weighting remains unchanged in Free Battle.
  const isQuestWeaponContext=()=>AQ.state?.questMultiActor===true
    ||AQ.state?.questReflex===true;
  function questTierAllowed(id){
    const tier=CFG.tierOf?.(id);
    return tier==='T1'||tier==='T2';
  }
  function questWeaponPool(){
    const ids=[...(CFG.BY_TIER?.T1||[]),...(CFG.BY_TIER?.T2||[])];
    return ids.filter(id=>CFG.isOffensive?.(id)
      &&id!=='SWIRL_SHIELD'&&id!=='TOWER_SHIELD');
  }
  function chooseQuestWeapon(random,onlyGun){
    const ids=questWeaponPool().filter(id=>!onlyGun||CFG.isGun?.(id));
    if(!ids.length)return 'PISTOL';
    let sum=0;
    for(const id of ids)sum+=weightFor(id);
    let roll=random()*sum;
    for(const id of ids){roll-=weightFor(id);if(roll<0)return id;}
    return ids[ids.length-1];
  }

  function ownerBotForcedWeapon(){
    const owner=window.APEX_ARSENAL_OWNER_TEST,st=AQ.state;
    if(!owner?.active||!owner.selectedWeaponId||st?.battleMode!=='BOT'
      ||st?.labMode||isQuestWeaponContext())return null;
    return CFG.P0_WEAPON_IDS.includes(owner.selectedWeaponId)?owner.selectedWeaponId:null;
  }
  function selectFirearmWeapon(rng) {
    const forced=ownerBotForcedWeapon();if(forced)return forced;
    const random = typeof rng === 'function' ? rng : (AQ.rng || Math.random);
    // Quest E01–E08 remains T1/T2-only, but now selects from registry
    // rather than excluding valid V4.3 specials on a fake handgun-only list.
    if(isQuestWeaponContext())return chooseQuestWeapon(random,false);
    const ids = (CFG.GUN_REGISTRY || []).map((e) => e.id);
    if (!ids.length) return 'PISTOL';
    if (CFG.selectOffensiveWeapon) {
      for (let i = 0; i < 24; i++) {
        const id = CFG.selectOffensiveWeapon(random).id;
        if (CFG.isGun && CFG.isGun(id)) return id;
      }
    }
    return ids[Math.floor(random() * ids.length)] || 'PISTOL';
  }

  function trySpawnSlot(opts) {
    const state = AQ.state;
    if (!state || state.labMode) return null; // Lab requests use spawnLabWeapon only.
    const active = state.slots.filter(s => s.phase !== 'REMOVED' && s.kind !== 'HEAL');
    if (active.length >= CFG.MAX_ACTIVE_SLOTS) {
      state.suppressedSpawns += 1;
      log('SPAWN_SUPPRESSED', `active=${active.length} cap=${CFG.MAX_ACTIVE_SLOTS}`);
      return null;
    }

    // E01 REFLEX only: authored R1/R2 PISTOL locations. This still enters
    // the canonical TELEGRAPH → REVEALED → actual pickup/equip pipeline.
    // Never let public normal/Local modes request a fixed weapon or point.
    const forcedReflex=state.questReflex===true && opts?.questWeaponId==='PISTOL'
      && (['R1_PISTOL','R2_PISTOL','BOTH_HALF'].includes(opts?.questStage))
      && (opts?.questPickupOwner==='NEWBOT'||opts?.questPickupOwner==='T.O.T');
    const forcedSwarm=state.questScrapSwarmProgression===true
      && state.questSwarmPhase==='COMBAT'
      && opts?.questWeaponId==='PISTOL'
      && opts?.questStage==='E03_OPENING'&&opts?.questPickupOwner==='NEWBOT';
    const forcedCharge=state.questBreakerChargeProgression===true
      &&opts?.questStage==='E05_OPENING'
      &&opts?.questPickupOwner==='NEWBOT'&&opts?.questWeaponId==='PISTOL';
    const forcedStoryStorm=state.questReflex===true
      &&state.questReflexHold?.phase==='AWAIT_RIVET'
      &&opts?.questStage==='E01_GROUND_SUPPRESSION'
      &&opts?.questWeaponId==='STORMBREAKER';
    const forcedTotStorm=state.questTotProgression===true
      &&state.questTotStormNative?.snapshot?.().phase==='STORM_ELIGIBLE'
      &&opts?.questStage==='E08_STORMBREAKER'
      &&opts?.questPickupOwner==='T.O.T'
      &&opts?.questWeaponId==='STORMBREAKER'
      &&state.questTotStormNative?.snapshot?.().spawned===false;
    const forcedQuest=(forcedReflex||forcedSwarm||forcedCharge||forcedStoryStorm||forcedTotStorm)
      && Number.isFinite(opts?.questPoint?.x)&&Number.isFinite(opts?.questPoint?.y);
    const point=forcedQuest
      ? {x:Math.max(120,Math.min(880,opts.questPoint.x)),
         y:Math.max(120,Math.min(880,opts.questPoint.y))}
      : pickSpawnPoint(state.slots);
    const slot = {
      id: state.nextSlotId++,
      x: point.x,
      y: point.y,
      phase: 'TELEGRAPH',
      kind: 'WEAPON', // canonical floor equipment, distinct from HEAL
      weaponId: null,
      forceFirearm: !!(opts && opts.forceFirearm),
      questWeaponId:forcedQuest?((forcedStoryStorm||forcedTotStorm)?'STORMBREAKER':'PISTOL'):null,
      questStage:forcedQuest?opts.questStage:null,
      questPickupOwner:forcedQuest?opts.questPickupOwner:null,
      questNarrativeOnly:!!forcedStoryStorm,
      // V2 B-handoff A-CORR-2: fixed 2.0s whole-circle reveal lead per slot.
      revealLeadSeconds: Number(CFG.REVEAL_LEAD_SECONDS ?? 2.0),
      revealedFor: 0,
      pickedBy: null,
      rejectedFor: {},
      spawnTime: state.time,
      predictedHeroETA: null,
      predictedRivalETA: null,
      earliestETA: null,
      predictedFighter: null,
    };
    state.slots.push(slot);
    state.spawnedTotal += 1;
    log('SPAWN_SLOT', `id=${slot.id} x=${Math.round(slot.x)} y=${Math.round(slot.y)} lead=${slot.revealLeadSeconds.toFixed(2)}`);
    window.avCue('telegraph', { x: slot.x, y: slot.y });
    return slot;
  }

  // Lab-only exact-ID request. All normal pickup/equip/attack handling below
  // remains unchanged; this bypasses only the random/telegraph creation path.
  function spawnLabWeapon(weaponId) {
    const state = AQ.state;
    if (!state || !state.active || !state.labMode || !(CFG.P0_WEAPON_IDS || []).includes(weaponId)) return null;
    const active = state.slots.filter((s) => s.phase !== 'REMOVED');
    if (active.length >= CFG.LAB_MANUAL_SLOT_CAP) return null;
    // Reuse the existing arena-margin/spacing sampler, treating live fighters
    // as occupied points as well: tapping a weapon must not auto-vacuum it on
    // the same frame before the owner can see the revealed pickup.
    const occupied = active.concat((typeof fighters !== 'undefined' ? fighters : [])
      .filter((f) => f && f.hp > 0).map((f) => ({ x: f.x, y: f.y })));
    const point = pickSpawnPoint(occupied);
    const slot = {
      id: state.nextSlotId++, x: point.x, y: point.y,
      phase: 'REVEALED', kind: 'WEAPON', weaponId,
      tier: CFG.tierOf ? CFG.tierOf(weaponId) : null,
      revealedFor: 0, pickedBy: null, rejectedFor: {},
      spawnTime: state.time,
    };
    state.slots.push(slot);
    state.spawnedTotal += 1;
    state.maxActiveSlots = Math.max(state.maxActiveSlots || 0, state.slots.length);
    log('LAB_SPAWN', `id=${slot.id} weapon=${weaponId} x=${Math.round(slot.x)} y=${Math.round(slot.y)}`);
    return slot;
  }

  // POST-C §4 — weighted selection. Raw weights: melee 0.5, everything else
  // 1.0 (NOT gun-count dilution: each non-melee id keeps full individual
  // weight). The RNG is injectable (AQ.rng) so probability gates are
  // deterministic in tests and the live game uses Math.random.
  function weightFor(weaponId) {
    const w = CFG.SPAWN_WEIGHTS || { melee: 0.5, base: 1.0 };
    return (CFG.MELEE_WEAPON_IDS || []).includes(weaponId) ? w.melee : w.base;
  }
  function selectSpawnWeapon(rng) {
    const forced=ownerBotForcedWeapon();if(forced)return forced;
    const random = typeof rng === 'function' ? rng : (AQ.rng || Math.random);
    if(isQuestWeaponContext())return chooseQuestWeapon(random,false);
    if (CFG.selectOffensiveWeapon) return CFG.selectOffensiveWeapon(random).id;
    const ids = (CFG.OFFENSIVE_WEAPON_IDS || CFG.P0_WEAPON_IDS).filter((id) => id !== 'SWIRL_SHIELD' && id !== 'TOWER_SHIELD');
    let total = 0;
    for (const id of ids) total += weightFor(id);
    let roll = random() * total;
    for (const id of ids) {
      roll -= weightFor(id);
      if (roll < 0) return id;
    }
    return ids[ids.length - 1];
  }

  function revealSlot(slot, eta, fighter, force = false) {
    slot.phase = 'REVEALED';
    slot.kind = 'WEAPON'; // retain type authority even for legacy telegraphs
    // E01 restricted training pool never rolls a late Stormbreaker or a
    // surprise melee while waiting on accepted J/K and both half-HP gates.
    // No changes to normal Arsenal or other Quest encounters.
    slot.weaponId=slot.questWeaponId || (AQ.state?.questReflex===true
      ? 'PISTOL'
      : (slot.forceFirearm ? selectFirearmWeapon() : selectSpawnWeapon()));
    // This is a SECOND authority barrier on the actual visible slot, so
    // newly added reveal pathways can never display blue+ Quest loot.
    const e08NativeStorm=AQ.state?.questTotProgression===true
      &&slot.questStage==='E08_STORMBREAKER'
      &&slot.questPickupOwner==='T.O.T'
      &&AQ.state.questTotStormNative?.snapshot?.().slotId===slot.id;
    if(isQuestWeaponContext()&&!slot.questNarrativeOnly
      &&!e08NativeStorm&&!questTierAllowed(slot.weaponId)){
      log('QUEST_RARITY_DENIED',String(slot.weaponId));
      slot.weaponId='PISTOL';
    }
    slot.tier = CFG.tierOf ? CFG.tierOf(slot.weaponId) : null;
    slot.revealedFor = 0;
    const etaText = Number.isFinite(eta) ? eta.toFixed(2) : 'null';
    const who = fighter?.name || 'TIMEOUT';
    if(e08NativeStorm&&AQ.state.questTotStormNative?.onReveal?.(slot)!==true)
      throw Error('E08 real floor Stormbreaker reveal receipt denied');
    log('REVEAL', `id=${slot.id} weapon=${slot.weaponId} eta=${etaText} lead=${slot.revealLeadSeconds.toFixed(2)} fighter=${who} force=${force}`);
    spawnShockwave(slot.x, slot.y, '#e8d9a0', 120);
    emitParticles(slot.x, slot.y, '#e8d9a0', 14, 260, 4, 0.45, 'square');
    playFighterSound('CARD', 'skill');
    window.avCue('reveal', { x: slot.x, y: slot.y, weapon: slot.weaponId });
  }

  function selectHealId(rng) {
    const random = typeof rng === 'function' ? rng : (AQ.rng || Math.random);
    const state = AQ.state;
    if (state && state.forceHealId) return state.forceHealId;
    const weights = CFG.HEAL_WEIGHTS || {};
    const ids = CFG.HEAL_IDS || Object.keys(weights);
    let total = 0;
    for (const id of ids) total += weights[id] || 0;
    let roll = random() * total;
    for (const id of ids) {
      roll -= weights[id] || 0;
      if (roll < 0) return id;
    }
    return ids[ids.length - 1];
  }

  // ARSENAL LAB V1 — owner law: in the Lab there is NO automatic spawning at
  // all (no offensive cadence, no emergency firearm, NO heal). Equipment
  // exists on the floor only after the owner taps a weapon in the lab panel.
  function trySpawnHealSupport() {
    const state = AQ.state;
    const feel = window.APEX_ARSENAL_FEEL;
    if (!state || !feel || !feel.healGameplayEnabled) return null;
    if (state.labMode) return null;
    if (state.spawnHeld) return null;
    if ((state.healCooldown || 0) > 0) return null;
    const activeHeal = state.slots.filter((s) => s.kind === 'HEAL' && s.phase !== 'REMOVED');
    if (activeHeal.length >= (CFG.HEAL_MAX_ACTIVE || 1)) return null;
    const living = (typeof fighters !== 'undefined' ? fighters : []).filter((f) =>
      f && f.hp > 0 && f.questWorldObject!==true);
    const eligible = living.some((f) => f.hp <= (CFG.HEAL_ELIGIBLE_HP || 80));
    if (!eligible) return null;
    const point = pickSpawnPoint(state.slots);
    const healId = selectHealId();
    const slot = {
      id: state.nextSlotId++,
      x: point.x,
      y: point.y,
      phase: 'REVEALED',
      kind: 'HEAL',
      weaponId: healId,
      healRestore: (CFG.HEAL_RESTORE && CFG.HEAL_RESTORE[healId]) || 0,
      revealedFor: 0,
      pickedBy: null,
      rejectedFor: {},
      spawnTime: state.time,
    };
    state.slots.push(slot);
    state.healCooldown = CFG.HEAL_SPAWN_COOLDOWN || 9;
    state.healSpawnedTotal = (state.healSpawnedTotal || 0) + 1;
    log('SPAWN_HEAL', `id=${slot.id} heal=${healId} restore=${slot.healRestore}`);
    return slot;
  }

  function updateSlots(dt) {
    const state = AQ.state;
    if (!state) return;
    if (state.healCooldown > 0) state.healCooldown = Math.max(0, state.healCooldown - dt);
    trySpawnHealSupport();

    for (const slot of state.slots) {
      if(slot.questNarrativeOnly===true)continue;
      applyFloorAttractors(slot,dt);
      if(slot.phase==='REVEALED'&&slot.boxeEjection){
        // A genuine Arsenal floor pickup with short-lived ejection momentum.
        // Wall reflection, drag and pickup eligibility remain world-owned.
        const e=slot.boxeEjection;
        const step=Math.max(0,Math.min(dt,e.remaining));
        const size=Number.isFinite(GAME_SIZE)?GAME_SIZE:1000,lo=60,hi=size-60;
        const nx=slot.x+e.vx*step,ny=slot.y+e.vy*step;
        slot.x=Math.max(lo,Math.min(hi,nx));
        slot.y=Math.max(lo,Math.min(hi,ny));
        if(slot.x!==nx)e.vx=-e.vx*.45;
        if(slot.y!==ny)e.vy=-e.vy*.45;
        const drag=Math.exp(-4*step);e.vx*=drag;e.vy*=drag;
        e.remaining-=step;
        if(e.remaining<=1e-6||Math.hypot(e.vx,e.vy)<25)slot.boxeEjection=null;
      }
      if (slot.kind === 'HEAL') {
        if (slot.phase === 'REVEALED') {
          slot.revealedFor += dt;
          if (slot.revealedFor >= (CFG.HEAL_LIFETIME_SECONDS || 12)) {
            slot.phase = 'REMOVED';
            log('EXPIRE_HEAL', `id=${slot.id}`);
          }
        }
        continue;
      }
      if (slot.phase === 'TELEGRAPH') {
        const hero = fighters?.[0] || null;
        const rival = fighters?.[1] || null;
        slot.predictedHeroETA = predictContactETA(slot, hero);
        slot.predictedRivalETA = predictContactETA(slot, rival);

        // Quest may have N independent canonical Fighters. Ordinary BOT/LOCAL still
        // uses the exact original two entries, including HUD telemetry.
        // E01 design authority: authored position does NOT confer pickup
        // rights. Every unarmed real Fighter can reveal / collect a floor gun.
        // E03/E05 retained directed opening arrangements, explicitly scoped.
        const questDirected=slot.questPickupOwner&&
          (state.questScrapSwarmProgression===true
            ||state.questBreakerChargeProgression===true);
        const stageOwner=questDirected
          ? (fighters||[]).find(f=>f&&f.hp>0&&f.questId===slot.questPickupOwner)
          : null;
        const predictionActors=questDirected
          ? (stageOwner?[stageOwner]:[])
          : state.questMultiActor
            ? (fighters || []).filter(f => f && f.hp > 0) : [hero, rival];
        const candidates = [];
        for (const actor of predictionActors) {
          const eta = actor === hero ? slot.predictedHeroETA
            : actor === rival ? slot.predictedRivalETA
            : predictContactETA(slot, actor);
          if (eta != null) candidates.push({ eta, fighter: actor });
        }
        candidates.sort((a, b) => a.eta - b.eta);

        const earliest = candidates[0] || null;
        slot.earliestETA = earliest ? earliest.eta : null;
        slot.predictedFighter = earliest?.fighter?.name || null;

        const weaponApi = AQ.weaponApi;
        // The generic automatic counter system may transform a floor gun
        // into SWIRL_SHIELD. Never let it replace the E01 authored PISTOL;
        // otherwise R2 can be armed with a shield and soft-lock indefinitely.
        if (state.questReflex!==true&&state.questMultiActor!==true
          && !slot.questPickupOwner && earliest && weaponApi && earliest.fighter && !weaponApi.getHolder(earliest.fighter)) {
          const opponents = state.questMultiActor && window.APEX_QUEST_MULTI_ACTOR_CORE
            ? window.APEX_QUEST_MULTI_ACTOR_CORE.livingEnemies(earliest.fighter, fighters)
            : [earliest.fighter === hero ? rival : hero];
          const other = opponents.find(f => f && weaponApi.getHolder(f)) || null;
          const otherHold = other ? weaponApi.getHolder(other) : null;
          const threatId = otherHold && otherHold.weaponId;
          if (threatId && CFG.isOffensive && CFG.isOffensive(threatId) && threatId !== 'SWIRL_SHIELD' && threatId !== 'TOWER_SHIELD') {
            slot.phase = 'COUNTER_RESERVED';
            slot.reservedFor = earliest.fighter.id;
            slot.weaponId = (CFG.threatShield && CFG.threatShield(threatId)) || 'SWIRL_SHIELD';
            slot.boundWeaponId = threatId;
            slot.boundOwnerId = other.id;
            slot.tier = null;
            log('COUNTER_RESERVED', `id=${slot.id} for=${earliest.fighter.name} shield=${slot.weaponId} vs=${threatId}`);
            continue;
          }
        }
        // Keep at least a brief visible telegraph when the authored pickup
        // materializes close enough to be immediately collected.
        if (slot.questStage&&state.questReflex===true
          &&state.time-slot.spawnTime<0.55)continue;
      if(slot.questStage==='E08_STORMBREAKER'
          &&state.time-slot.spawnTime<0.35)continue;
        if (questDirected && state.time-slot.spawnTime<0.65)continue;
        if (earliest && earliest.eta <= slot.revealLeadSeconds + 1e-6) {
          revealSlot(slot, earliest.eta, earliest.fighter, false);
        } else if (state.time - slot.spawnTime >= Number(CFG.FORCE_REVEAL_AGE_SECONDS ?? 3.0)) {
          revealSlot(slot, null, null, true);
        }
      } else if (slot.phase === 'COUNTER_RESERVED') {
        slot.revealedFor += dt;
        const weaponApi = AQ.weaponApi;
        const reserved = (fighters || []).find((f) => f && f.id === slot.reservedFor) || null;
        const owner = (fighters || []).find((f) => f && f.id === slot.boundOwnerId) || null;
        const oh = owner && weaponApi ? weaponApi.getHolder(owner) : null;
        const threatLive = !!(oh && oh.weaponId === slot.boundWeaponId);
        const reservedOk = !!(reserved && reserved.hp > 0 && weaponApi && !weaponApi.getHolder(reserved));
        const eta = reservedOk ? predictContactETA(slot, reserved) : null;
        const staleFailsafe = slot.revealedFor >= 14;
        if (!reservedOk || !owner || owner.hp <= 0 || !threatLive || eta == null || staleFailsafe) {
          log('COUNTER_RELEASE', `id=${slot.id} reason=${staleFailsafe ? 'failsafe' : 'invalid'}`);
          slot.phase = 'TELEGRAPH';
          slot.reservedFor = null;
          slot.boundWeaponId = null;
          slot.boundOwnerId = null;
          slot.weaponId = null;
          slot.tier = null;
          slot.revealedFor = 0;
        }
      } else if (slot.phase === 'REVEALED') {
        slot.revealedFor += dt;
        if (slot.revealedFor >= CFG.PICKUP_LIFETIME_SECONDS) {
          slot.phase = 'REMOVED';
          log('EXPIRE', `id=${slot.id} weapon=${slot.weaponId}`);
          emitParticles(slot.x, slot.y, '#8a8168', 10, 180, 4, 0.4, 'friction');
        }
      }
    }

    state.slots = state.slots.filter(s => s.phase !== 'REMOVED');
    state.maxActiveSlots = Math.max(state.maxActiveSlots || 0, state.slots.length);
  }

  // A revealed floor pickup is collected by the first living UNARMED fighter
  // whose collision volume overlaps it.
  // Shared tier-color rgba helper (B5/B12): parse CFG.TIER_COLORS hex once.
  const tierRgbCache = {};
  function tierRgba(tier, alpha) {
    const hex = (CFG.TIER_COLORS && CFG.TIER_COLORS[tier]) || '#C9D0D7';
    let rgb = tierRgbCache[hex];
    if (!rgb) {
      const n = parseInt(hex.slice(1), 16);
      rgb = [(n >> 16) & 255, (n >> 8) & 255, n & 255];
      tierRgbCache[hex] = rgb;
    }
    return 'rgba(' + rgb[0] + ',' + rgb[1] + ',' + rgb[2] + ',' + alpha.toFixed(3) + ')';
  }
  // B5 evidence counter (gates assert the treatment actually draws).
  const redTierStats = { draws: 0 };

  // A physical non-Fighter collector may compete for a public floor pickup,
  // but ONLY this canonical resolver can remove the slot. Evaluators are
  // read-only until their commit callback wins the nearest-contact arbitration.
  const externalPickupConsumers = new Map();
  // Existing slot coordinates remain authoritative; field owners only return
  // finite speed requests. This runs inside updateSlots, not an independent
  // RAF or a hero-side position integrator.
  const floorAttractors = new Map();
  function registerFloorAttractor(id, query) {
    const key=String(id||'');
    if(!key||typeof query!=='function')throw Error('invalid floor attractor');
    if(floorAttractors.has(key))throw Error('duplicate floor attractor '+key);
    floorAttractors.set(key,query);
    return ()=>{if(floorAttractors.get(key)===query)floorAttractors.delete(key);};
  }
  function applyFloorAttractors(slot,dt) {
    if(slot?.phase!=='REVEALED'||slot.kind!=='WEAPON'||!Number.isFinite(dt)||dt<=0)return;
    if(!window.APEX_ARSENAL_CONFIG?.isHeroManipulableFloorWeapon?.(slot))return;
    let vx=0,vy=0;
    for(const [key,query] of floorAttractors){
      let force;
      try{force=query(slot,dt);}catch(error){console.warn('[ARSENAL] floor attractor',key,error);continue;}
      if(!force||!Number.isFinite(force.vx)||!Number.isFinite(force.vy))continue;
      vx+=force.vx;vy+=force.vy;
    }
    const v=Math.hypot(vx,vy),limit=650;
    if(v>limit){vx*=limit/v;vy*=limit/v;}
    const S=typeof GAME_SIZE==='number'?GAME_SIZE:1000;
    slot.x=Math.max(60,Math.min(S-60,slot.x+vx*dt));
    slot.y=Math.max(60,Math.min(S-60,slot.y+vy*dt));
  }
  function registerExternalPickupConsumer(id, evaluate) {
    const key=String(id||'');
    if(!key || typeof evaluate!=='function')throw Error('invalid pickup consumer');
    if(externalPickupConsumers.has(key))throw Error('duplicate pickup consumer '+key);
    externalPickupConsumers.set(key,evaluate);
    return ()=>{if(externalPickupConsumers.get(key)===evaluate)externalPickupConsumers.delete(key);};
  }
  function bestExternalPickup(slot) {
    if(slot?.phase!=='REVEALED'||slot.kind!=='WEAPON'||slot.questPickupOwner)return null;
    const CFG=window.APEX_ARSENAL_CONFIG;
    if(!CFG?.isHeroManipulableFloorWeapon?.(slot))return null;
    let best=null;
    for(const [key,evaluate] of externalPickupConsumers){
      let proposed;
      try{proposed=evaluate(slot);}catch(e){console.warn('[ARSENAL] external pickup evaluation',key,e);continue;}
      if(!proposed||typeof proposed.commit!=='function')continue;
      const d=proposed.distance;
      if(!Number.isFinite(d)||d<0)continue;
      const receiver=proposed.owner;
      if(!receiver||receiver.hp<=0)continue;
      if(slot.__frostFrozen && window.APEX_FROST?.deniesPickup?.(slot,receiver))continue;
      const now=window.APEX_HERO_REWORK_AIL?.clock?.()??AQ.state?.time??0;
      if(slot.boxeDisarmedVictimId===receiver.id&&now<slot.boxePickupLockUntil)continue;
      if(!best||d<best.distance)best={...proposed,distance:d,key};
    }
    return best;
  }
  function resolvePickups() {
    const state = AQ.state;
    if (!state) return;
    const weaponApi = AQ.weaponApi;
    // HERO REWORK (doc-06): audited body-aware pickup actors — SLIME child
    // Bodies may physically collect pickups but never join fighters[].
    // Without the rework layer this is exactly the base fighters array.
    const pickupActorList = (window.APEX_HERO_REWORK && window.APEX_HERO_REWORK.pickupActors)
      ? window.APEX_HERO_REWORK.pickupActors()
      : undefined;
    const actors = state.questMultiActor
      ? (fighters || []).filter(f => f && f.hp > 0 && f.withdrawn!==true && f.questWorldObject!==true)
      : (pickupActorList || fighters);

    for (const slot of state.slots) {
      if (slot.phase !== 'REVEALED' && slot.phase !== 'COUNTER_RESERVED') continue;
      let closest = null;
      let closestDist = Infinity;

      // Story floor Stormbreaker is never an obtainable T6.
      if(slot.questNarrativeOnly===true)continue;
      if (slot.kind === 'HEAL') {
        const maxHp = CFG.MATCH_HP || 100;
        for (const f of actors) { // HERO REWORK doc-06 body-aware actors
          if (!f || f.hp <= 0) continue;
          const cap = f.maxHp || maxHp;
          if (f.hp >= cap) {
            if (!slot.rejectedFor[f.id]) {
              slot.rejectedFor[f.id] = true;
              log('REJECT_HEAL', `fighter=${f.name} id=${slot.id} reason=full-health`);
            }
            continue;
          }
          const d = dist(f.x, f.y, slot.x, slot.y);
          if (d > pickupTouchRadius(f)) continue;
          if (d < closestDist) { closest = f; closestDist = d; }
        }
        if (!closest) continue;
        const cap = closest.maxHp || maxHp;
        const nominal = slot.healRestore || 0;
        const actual = Math.min(nominal, Math.max(0, cap - closest.hp));
        closest.hp = Math.min(cap, closest.hp + actual);
        closest.healingDone = (closest.healingDone || 0) + actual;
        state.resultLedger?.onHeal?.(closest,actual);
        slot.phase = 'PICKED_UP';
        slot.pickedBy = closest.name;
        log('PICKUP_HEAL', `id=${slot.id} fighter=${closest.name} restore=${actual}`);
        if (typeof updateHUD === 'function') {
          try { updateHUD(); } catch (e) { /* headless HUD optional */ }
        }
        if (window.APEX_ARSENAL_FEEL && window.APEX_ARSENAL_FEEL.noteHeal) {
          window.APEX_ARSENAL_FEEL.noteHeal(closest, actual);
        }
        emitParticles(slot.x, slot.y, '#38E07A', 16, 280, 4, 0.4, 'square');
        slot.phase = 'REMOVED';
        continue;
      }

      // Frost Slice 1: resolve surface conversion in the authoritative pickup
      // transaction before collector eligibility. This covers a newly spawned
      // or newly entered gun without one unfrozen/collectible frame.
      const frostRuntime = window.APEX_FROST;
      if (frostRuntime && frostRuntime.ensureSurfaceFrozen) frostRuntime.ensureSurfaceFrozen(slot);

      for (const f of actors) { // HERO REWORK doc-06 body-aware actors
        if (!f || f.hp <= 0) continue;
        const d = dist(f.x, f.y, slot.x, slot.y);
        if (d > pickupTouchRadius(f)) continue;
        // A 'suggested' E01 receiver is a spawn-position hint only, not a
        // hidden ownership/eligibility gate. Truly revealed guns follow the
        // exact normal Arsenal physical pickup rules for EVERY Fighter.
        if ((state.questScrapSwarmProgression===true
          ||state.questBreakerChargeProgression===true
          ||(state.questTotProgression===true&&slot.questStage==='E08_STORMBREAKER'))
          &&slot.questPickupOwner&&f.questId!==slot.questPickupOwner) continue;
        // FROST V1 (authority §4.3): a Frozen firearm denies non-Frost
        // collectors. Dynamic denial only — never a rejected/blacklist mark.
        if (slot.__frostFrozen) {
          const FR = window.APEX_FROST;
          if (FR && FR.deniesPickup && FR.deniesPickup(slot, f)) continue;
        }
        if (slot.phase === 'COUNTER_RESERVED' && slot.reservedFor !== f.id) {
          if (!slot.rejectedFor[f.id]) {
            slot.rejectedFor[f.id] = true;
            log('REJECT_PICKUP', `fighter=${f.name} id=${slot.id} reason=not-reserved`);
          }
          continue;
        }
        if(slot.boxeDisarmedVictimId===f.id
          &&(window.APEX_HERO_REWORK_AIL?.clock?.()??state.time)<slot.boxePickupLockUntil)continue;
        if (weaponApi.getHolder(f)) {
          if (!slot.rejectedFor[f.id]) {
            slot.rejectedFor[f.id] = true;
            log('REJECT_PICKUP', `fighter=${f.name} id=${slot.id} reason=already-armed`);
          }
          continue;
        }
        if (d < closestDist) { closest = f; closestDist = d; }
      }

      const external=bestExternalPickup(slot);
      if(external && (!closest||external.distance<closestDist)){
        // One authoritative transaction; no slot removal occurs on a failed
        // commit and no second fighter/equipment collector may receive it.
        let accepted=false;
        try{accepted=external.commit(slot)===true;}
        catch(error){console.warn('[ARSENAL] pickup commit failed',external.key,error);}
        if(accepted){
          slot.phase='PICKED_UP';
          slot.pickedBy=external.key;
          log('PICKUP',`id=${slot.id} source=${external.key} weapon=${slot.weaponId}`);
          slot.phase='REMOVED';
          continue;
        }
      }
      if (!closest) continue;
      slot.phase = 'PICKED_UP';
      slot.pickedBy = closest.name;
      weaponApi.equip(closest, slot.weaponId);
      if(weaponApi.getHolder?.(closest)?.weaponId===slot.weaponId)
        state.resultLedger?.onPickup?.(closest,slot.weaponId,slot,weaponApi.getHolder?.(closest));
      const hold = weaponApi.getHolder(closest);
      // Stage receipt is derived ONLY from a genuine REVEALED floor pickup
      // completed by Arsenal. It is not synthesized from HP or skill presses.
      if (state.questReflex===true && slot.questStage && slot.questPickupOwner
        && hold?.weaponId===slot.questWeaponId
        && closest.questId===slot.questPickupOwner) {
        (state.questReflexPickupLog||(state.questReflexPickupLog=[])).push({
          stage:slot.questStage,owner:closest.questId,weapon:hold.weaponId,
          slotId:slot.id,time:state.time
        });
      }
      // FROST V1 (authority §4.3/§5): Frozen state carries onto the real
      // holder and persists until that holder is consumed.
      if (slot.__frostFrozen && hold) {
        const FR = window.APEX_FROST;
        if (FR && FR.noteFrozenPickup) FR.noteFrozenPickup(closest, hold, slot);
      }
      if (hold && hold.meta) {
        if (slot.boundWeaponId) hold.meta.boundWeaponId = slot.boundWeaponId;
        if (slot.boundOwnerId != null) hold.meta.boundOwnerId = slot.boundOwnerId;
        if (slot.tier) hold.meta.tier = slot.tier;
      }
      if(state.questTotProgression===true&&slot.questStage==='E08_STORMBREAKER'
         &&state.questTotStormNative?.onPickup?.(closest,slot,hold)!==true)
        throw Error('E08 actual floor pickup/Arsenal holder receipt denied');
      // Exactly one E06 owner-authorized storage seam: the genuine physical
      // pickup has already equipped a real holder, but no auto-fire tick has run.
      // A reserved gun goes dormant by OBJECT identity, not by cloned weaponId.
      if (state.questBreachEncounter===true && hold)
        state.questBreachCompanionSkills?.onRealPickup?.(closest,slot,hold);
      log('PICKUP', `id=${slot.id} fighter=${closest.name} weapon=${slot.weaponId}`);
      emitParticles(slot.x, slot.y, PLACEHOLDER_ART[slot.weaponId]?.color || '#ffffff', 22, 360, 5, 0.5, 'square');
      spawnShockwave(slot.x, slot.y, '#ffffff', 140);
      slot.phase = 'REMOVED';
    }
  }

  // POST-C §8: the missing-asset fallback is a glyph-free magenta plate with a
  // cross — debug tooling stays, arena text goes to zero. The weapon id is
  // still logged for F3/diagnostics.
  function drawDebugMissingWeapon(ctx, weaponId) {
    if (!(AQ.state && AQ.state.debugOverlay)) return;
    ctx.save();
    ctx.fillStyle = '#ff2bd6';
    ctx.strokeStyle = '#1b0016';
    ctx.lineWidth = 4;
    ctx.fillRect(-28, -28, 56, 56);
    ctx.strokeRect(-28, -28, 56, 56);
    ctx.strokeStyle = '#1b0016';
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.moveTo(-14, -14); ctx.lineTo(14, 14);
    ctx.moveTo(14, -14); ctx.lineTo(-14, 14);
    ctx.stroke();
    ctx.restore();
  }

  const rarityCache = new Map();
  const rarityStats = { builds: 0, draws: 0, hits: 0 };
  const wellCache = new Map();
  function contactWell(kind) {
    const key = kind || 'gun';
    const hit = wellCache.get(key);
    if (hit) return hit;
    const w = 96, h = 48;
    const canvas = document.createElement('canvas');
    canvas.width = w; canvas.height = h;
    const c = canvas.getContext('2d');
    const g = c.createRadialGradient(w / 2, h / 2, 2, w / 2, h / 2, kind === 'heal' ? 38 : 34);
    g.addColorStop(0, kind === 'heal' ? 'rgba(8,18,12,0.55)' : 'rgba(8,10,14,0.62)');
    g.addColorStop(0.55, kind === 'heal' ? 'rgba(8,18,12,0.28)' : 'rgba(8,10,14,0.32)');
    g.addColorStop(1, 'rgba(0,0,0,0)');
    c.fillStyle = g;
    c.beginPath();
    c.ellipse(w / 2, h / 2 + 4, kind === 'heal' ? 30 : 26, 11, 0, 0, Math.PI * 2);
    c.fill();
    const rec = { canvas, ox: w / 2, oy: h / 2 };
    wellCache.set(key, rec);
    return rec;
  }
  function raritySprite(tier, glow, glowSpec, q) {
    const key = tier + ':' + q;
    const hit = rarityCache.get(key);
    if (hit) return { canvas: hit.canvas, ox: hit.ox, oy: hit.oy, cached: true };
    const pulse = q / 7;
    const rx = glowSpec.rx + pulse * 4;
    const ry = glowSpec.ry + pulse * 1.5;
    const pad = 24 + glowSpec.rx * 0.5;
    const w = Math.ceil(rx * 2 + pad * 2);
    const h = Math.ceil(ry * 2 + pad * 2);
    const canvas = document.createElement('canvas');
    canvas.width = w; canvas.height = h;
    const c = canvas.getContext('2d');
    c.translate(w / 2, h / 2);
    const a0 = Math.min(0.95, glowSpec.a + glowSpec.pulse * pulse + 0.15);
    const grad = c.createRadialGradient(0, 0, 2, 0, 0, rx);
    grad.addColorStop(0, glow);
    grad.addColorStop(0.35, glow);
    grad.addColorStop(1, 'rgba(0,0,0,0)');
    c.globalAlpha = a0;
    c.fillStyle = grad;
    c.shadowColor = glow;
    c.shadowBlur = 18 + glowSpec.rx * 0.35 + pulse * 10;
    c.beginPath();
    c.ellipse(0, 0, rx, ry, 0, 0, Math.PI * 2);
    c.fill();
    c.shadowBlur = 0;
    if (glowSpec.shimmer) {
      const warm = c.createRadialGradient(0, 0, 1, 0, 0, rx * 0.55);
      warm.addColorStop(0, 'rgba(255,210,122,0.55)');
      warm.addColorStop(1, 'rgba(255,210,122,0)');
      c.globalAlpha = 0.22 + 0.16 * pulse;
      c.fillStyle = warm;
      c.beginPath();
      c.ellipse(0, 0, rx * 0.55, ry * 0.55, 0, 0, Math.PI * 2);
      c.fill();
    }
    const rec = { canvas, ox: w / 2, oy: h / 2 };
    rarityCache.set(key, rec);
    rarityStats.builds += 1;
    return { canvas, ox: rec.ox, oy: rec.oy, cached: false };
  }

  // Called inside the engine camera transform so slots sit in world space.
  function drawSlots(ctx) {
    const state = AQ.state;
    if (!state) return;
    const t = state.time;

    for (const slot of state.slots) {
      ctx.save();
      ctx.translate(slot.x, slot.y);

      // B5: red-tier floor shadow — soft rarity pool + thin rim under an
      // exceptional item. Semantic: keyed off slot.tier === 'T6', so any
      // future red-tier slot inherits the treatment unchanged. Colors come
      // from the shared CFG.TIER_COLORS authority (no magic hex here).
      if (slot.phase === 'REVEALED' && slot.tier === 'T6') {
        redTierStats.draws += 1;
        const spec = (CFG.TIER_GLOW && CFG.TIER_GLOW.T6) || { rx: 78, ry: 22, a: 0.72 };
        const pulse = 0.5 + 0.5 * Math.sin(t * 1.9 + slot.id);
        const rx = spec.rx * (0.94 + 0.06 * pulse);
        const ry = spec.ry * (0.94 + 0.06 * pulse);
        ctx.save();
        ctx.translate(0, 26); // ground plane — does NOT bob with the item
        ctx.globalAlpha = 0.55 + 0.2 * pulse;
        ctx.fillStyle = tierRgba('T6', 0.34 + 0.10 * pulse);
        ctx.beginPath();
        ctx.ellipse(0, 0, rx, ry, 0, 0, TAU);
        ctx.fill();
        ctx.globalAlpha = 0.5 + 0.22 * pulse;
        ctx.strokeStyle = tierRgba('T6', 0.55);
        ctx.lineWidth = 2.2;
        ctx.beginPath();
        ctx.ellipse(0, 0, rx * 0.99, ry * 0.99, 0, 0, TAU);
        ctx.stroke();
        ctx.restore();
      }

      if (slot.kind === 'HEAL' && slot.phase === 'REVEALED') {
        const bob = slot.weaponId === 'STORMBREAKER'
        ? Math.sin(t * 2.6) * 2
        : Math.sin(t * 3.1 + slot.id) * 4;
        const pulse = 0.5 + 0.5 * Math.sin(t * 2.2 + slot.id);
        // B12: heal floor shadow/glow reads BY TIER through the shared
        // tier-color authority (H1..H5 -> T1..T5). The heal item art itself
        // is NOT recolored — only the floor rarity language.
        const hTier = (CFG.HEAL_TIER && CFG.HEAL_TIER[slot.weaponId]) || 'T2';
        const hGlow = (CFG.TIER_GLOW && CFG.TIER_GLOW[hTier]) || CFG.TIER_GLOW.T2;
        const well = contactWell('heal');
        ctx.save();
        ctx.translate(0, bob + 18);
        ctx.globalAlpha = 0.9;
        ctx.drawImage(well.canvas, -well.ox, -well.oy + 6);
        ctx.globalAlpha = 0.24 + 0.20 * pulse;
        ctx.fillStyle = tierRgba(hTier, 0.42 + hGlow.a * 0.35);
        ctx.beginPath();
        ctx.ellipse(0, 8, 20 + hGlow.rx * 0.42 + pulse * 3, 8 + hGlow.ry * 0.34, 0, 0, TAU);
        ctx.fill();
        ctx.restore();
        ctx.globalAlpha = 1;
        ctx.translate(0, bob);
        const feel = window.APEX_ARSENAL_FEEL;
        const rec = feel && feel.heals && feel.heals.find((h) => h.id === slot.weaponId);
        const img = rec && rec.img;
        if (img && img.complete && img.naturalWidth) {
          const h = 52;
          const w = img.naturalWidth * (h / img.naturalHeight);
          ctx.drawImage(img, -w / 2, -h / 2, w, h);
        } else {
          ctx.fillStyle = '#38E07A';
          ctx.beginPath(); ctx.arc(0, 0, 16, 0, TAU); ctx.fill();
        }
        ctx.restore();
        continue;
      }

      if (slot.phase === 'TELEGRAPH' || slot.phase === 'COUNTER_RESERVED') {
        // A-CORR-2: the visible circle IS the reveal region. Radius is pinned
        // to the shared CFG.REVEAL_CIRCLE_RADIUS (pulse moves alpha/weight
        // only, never the geometry the reveal logic tests against).
        const pulse = 0.5 + 0.5 * Math.sin(t * 5.2 + slot.id * 1.7);
        ctx.globalAlpha = 0.45 + 0.35 * pulse;
        ctx.strokeStyle = '#cfc6a8';
        ctx.lineWidth = 3 + 2.5 * pulse;
        ctx.setLineDash([10, 8]);
        ctx.beginPath();
        ctx.arc(0, 0, CFG.REVEAL_CIRCLE_RADIUS, 0, TAU);
        ctx.stroke();
        ctx.setLineDash([]);

        ctx.globalAlpha = 0.55 + 0.3 * pulse;
        ctx.strokeStyle = '#a89f83';
        ctx.lineWidth = 2;
        for (let i = 0; i < 4; i++) {
          const a = i * Math.PI / 2;
          ctx.beginPath();
          ctx.moveTo(Math.cos(a) * (CFG.PICKUP_RADIUS + 10), Math.sin(a) * (CFG.PICKUP_RADIUS + 10));
          ctx.lineTo(Math.cos(a) * (CFG.PICKUP_RADIUS + 20), Math.sin(a) * (CFG.PICKUP_RADIUS + 20));
          ctx.stroke();
        }

        // POST-C §8: no '?' glyph — the unknown-pickup core is a glyph-free
        // rotating diamond that pulses with the same cadence as the ring.
        ctx.globalAlpha = 0.6 + 0.3 * pulse;
        ctx.fillStyle = '#efe6c8';
        ctx.strokeStyle = '#241f14';
        ctx.lineWidth = 4;
        ctx.save();
        ctx.rotate(t * 1.4 + slot.id);
        const core = 11 + 2.5 * pulse;
        ctx.beginPath();
        ctx.moveTo(0, -core);
        ctx.lineTo(core * 0.72, 0);
        ctx.lineTo(0, core);
        ctx.lineTo(-core * 0.72, 0);
        ctx.closePath();
        ctx.stroke();
        ctx.fill();
        ctx.restore();
      } else if (slot.phase === 'REVEALED') {
        const bob = Math.sin(t * 3.1 + slot.id) * 4;
        const glow = (CFG.TIER_COLORS && slot.tier && CFG.TIER_COLORS[slot.tier]) || null;
        const glowSpec = (CFG.TIER_GLOW && slot.tier && CFG.TIER_GLOW[slot.tier]) || { rx: 34, ry: 10, a: 0.35, pulse: 0 };
        // Stormbreaker V9 owns its floor aura/rings. The generic contact well
        // and tier halo were not present in the approved executable reference.
        if (slot.weaponId !== 'STORMBREAKER') {
          const well = contactWell('gun');
          ctx.save();
          ctx.translate(0, bob + 22);
          ctx.drawImage(well.canvas, -well.ox, -well.oy + 4);
          ctx.restore();
        }
        if (glow && slot.weaponId !== 'STORMBREAKER') {
          const pulse = 0.5 + 0.5 * Math.sin(t * (1.4 + glowSpec.pulse * 4) + slot.id);
          const q = Math.max(0, Math.min(7, pulse * 7 + 0.5 | 0));
          const sprite = raritySprite(slot.tier, glow, glowSpec, q);
          ctx.save();
          ctx.translate(0, bob + 22);
          ctx.drawImage(sprite.canvas, -sprite.ox, -sprite.oy);
          ctx.restore();
          rarityStats.draws += 1;
          if (sprite.cached) rarityStats.hits += 1;
        }
        const expireSoon = slot.revealedFor > CFG.PICKUP_LIFETIME_SECONDS - 3;
        ctx.globalAlpha = expireSoon && Math.floor(t * 8) % 2 === 0 ? 0.45 : 1;
        ctx.translate(0, bob);

        const av = window.APEX_ARSENAL_AV;
        const table = (CFG.FIREARM_LONG_SIDE) || {};
        const mul = (CFG.FIREARM_DISPLAY_MODE && CFG.FIREARM_DISPLAY_MODE.floor) || 0.92;
        const gunLong = table[slot.weaponId] ? table[slot.weaponId] * mul : 118;
        const stormLong = slot.weaponId === 'STORMBREAKER'
          ? ((CFG.STORMBREAKER && CFG.STORMBREAKER.spawnLongSide) || 261)
          : null;
        const drawn = !!(av && av.drawWeaponSprite && av.drawWeaponSprite(ctx, slot.weaponId, 0, 0, {
          mode: 'floor',
          useWorld: false,
          angle: slot.weaponId === 'STORMBREAKER' ? CFG.STORMBREAKER.floorAngleRad : 0,
          targetLongSide: slot.weaponId === 'GRENADE' ? 56 : (stormLong || gunLong),
          alpha: 1,
        }));
        if (!drawn) drawDebugMissingWeapon(ctx, slot.weaponId);
      }

      ctx.restore();
    }
  }

  window.APEX_ARSENAL_SPAWN = {
    trySpawnSlot,
    spawnLabWeapon,
    selectFirearmWeapon,
    trySpawnHealSupport,
    selectHealId,
    updateSlots,
    resolvePickups,
    registerExternalPickupConsumer,
    registerFloorAttractor,
    externalPickupConsumerIds:()=>Object.freeze([...externalPickupConsumers.keys()]),
    drawSlots,
    predictContactETA,
    isEligibleForPickup,
    selectSpawnWeapon,
    weightFor,
    PLACEHOLDER_ART,
    rarityStats,
    redTierStats,
    healShadowSpec: (id) => {
      const tier = (CFG.HEAL_TIER && CFG.HEAL_TIER[id]) || 'T2';
      const glow = (CFG.TIER_GLOW && CFG.TIER_GLOW[tier]) || CFG.TIER_GLOW.T2;
      return { id, tier, color: (CFG.TIER_COLORS && CFG.TIER_COLORS[tier]) || null, glow };
    },
  };
  window.apexArsenalSpawnRuntime = 'ready';
})();
