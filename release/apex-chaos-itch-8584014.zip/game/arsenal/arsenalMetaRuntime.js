// ARSENAL product meta: Shop / Lucky Draw / AC economy / owned roster.
// Public navigation lives in the semantic React product graph, not this file.
(function apexArsenalMetaRuntime() {
  if (window.apexArsenalMetaRuntime === 'ready') return;
  const KEY = 'apexChaos.arsenalMeta.v1';
  const SHOP_COST = 1000;
  const DRAW_COST = 1000; // Issue #105 owner rule: one Lucky draw = exactly 1000 AC
  const START_CREDITS = 350;
  const PROGRESSION_CATALOG = Object.freeze([
    Object.freeze({ id: 'first-bot', kind: 'mission', stat: 'botMatches', target: 1, ac: 100, vie: 'TRẬN ĐẤU ĐẦU TIÊN', eng: 'FIRST BOT MATCH' }),
    Object.freeze({ id: 'first-win', kind: 'mission', stat: 'botWins', target: 1, ac: 150, vie: 'CHIẾN THẮNG ĐẦU TAY', eng: 'FIRST BOT WIN' }),
    Object.freeze({ id: 'local-match', kind: 'mission', stat: 'localMatches', target: 1, ac: 75, vie: 'SO TÀI TẠI CHỖ', eng: 'LOCAL DUEL' }),
    Object.freeze({ id: 'bot-veteran', kind: 'achievement', stat: 'botWins', target: 3, ac: 250, vie: 'CHIẾN BINH ĐẤU TRƯỜNG', eng: 'ARENA VETERAN' }),
    Object.freeze({ id: 'bot-survivor', kind: 'achievement', stat: 'botMatches', target: 5, ac: 200, vie: 'KHÔNG BỎ CUỘC', eng: 'NEVER GIVE UP' }),
  ]);
  // CP3 mastery lives in THIS one wallet/profile state. It records the
  // owner-approved combat achievements already evaluated by the match
  // result ledger; it is not a second achievement authority and it never
  // pays AC. Sealed folding happens inside awardBattleResult(), behind the
  // same claimedMatchIds guard as the match AC award.
  const RESULT_HERO_BY_ENGINE = Object.freeze({ ROBOT: 'NEWBOT', ICE: 'FROST', CRYSTAL: 'CRYSTALA' });
  const ENGINE_HERO_BY_RESULT = Object.freeze({ NEWBOT: 'ROBOT', FROST: 'ICE', CRYSTALA: 'CRYSTAL' });
  const MASTERY_SKIN_GATES = Object.freeze([
    Object.freeze({ key: 'hero:ROBOT:ecobot', kind: 'hero', baseId: 'ROBOT', skinId: 'ecobot', resultHeroId: 'NEWBOT' }),
    Object.freeze({ key: 'weapon:RPG_7:vua-he', kind: 'weapon', baseId: 'RPG_7', skinId: 'vua-he', weaponId: 'RPG_7', damageThreshold: 1000 }),
  ]);
  const MASTERY_MAX_VALUE = 1000000000000;
  // Epoch-millisecond earn timestamps need a separate ceiling: real
  // Date.now() values already exceed 1e12, so clamping them to the damage
  // cap rewrote every live earn date to 2001 after reload (CP3.1 audit).
  const MASTERY_MAX_AT = 4102444800000; // 2100-01-01T00:00:00.000Z
  function resultHeroId(id) {
    const raw = String(id || '').trim().toUpperCase();
    return RESULT_HERO_BY_ENGINE[raw] || raw;
  }
  function engineHeroId(id) {
    const raw = String(id || '').trim().toUpperCase();
    return ENGINE_HERO_BY_RESULT[raw] || raw;
  }
  function resultCatalog() {
    try {
      const catalog = window.APEX_RESULT_OWNER_CATALOG;
      return Array.isArray(catalog)
        ? catalog.filter((def) => def && typeof def.id === 'string' && Array.isArray(def.params))
        : [];
    } catch (error) { return []; }
  }
  function awardDef(id) {
    const wanted = String(id || '');
    return resultCatalog().find((def) => def.id === wanted) || null;
  }
  function applicableAwardDefs(heroId) {
    const hero = resultHeroId(heroId);
    return resultCatalog().filter((def) => !def.heroId || def.heroId === hero);
  }
  function emptyMastery() {
    return { earned: {}, best: {}, weaponDamage: {}, recent: [], unseenSkinUnlocks: [] };
  }
  function cleanMasteryNumber(value) {
    const n = Number(value);
    return Number.isFinite(n) ? Math.min(MASTERY_MAX_VALUE, Math.max(0, n)) : null;
  }
  function cleanMasteryAt(value) {
    const n = Number(value);
    return Number.isFinite(n) && n >= 0 ? Math.min(MASTERY_MAX_AT, n) : 0;
  }
  function sanitizeMastery(raw) {
    const out = emptyMastery();
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return out;
    const catalog = resultCatalog();
    const validIds = catalog.length ? new Set(catalog.map((def) => def.id)) : null;
    const validAward = (hero, id) => {
      if (typeof id !== 'string' || !/^[a-z0-9-]{1,80}$/.test(id)) return false;
      if (validIds && !validIds.has(id)) return false;
      const def = catalog.find((entry) => entry.id === id);
      return !def?.heroId || def.heroId === hero;
    };
    const cleanHeroMap = (source, cleanValue) => {
      const result = {};
      if (!source || typeof source !== 'object' || Array.isArray(source)) return result;
      for (const [rawHero, entry] of Object.entries(source).slice(0, 32)) {
        const hero = resultHeroId(rawHero);
        if (!/^[A-Z0-9_]{1,32}$/.test(hero)) continue;
        const target = result[hero] || (result[hero] = {});
        if (Array.isArray(entry)) {
          for (const id of entry.slice(0, 128)) if (validAward(hero, id)) target[id] = 0;
        } else if (entry && typeof entry === 'object') {
          for (const [id, value] of Object.entries(entry).slice(0, 128)) {
            if (!validAward(hero, id)) continue;
            const cleaned = cleanValue(value);
            if (cleaned != null) target[id] = cleaned;
          }
        }
        if (!Object.keys(target).length) delete result[hero];
      }
      return result;
    };
    out.earned = cleanHeroMap(raw.earned, cleanMasteryAt);
    out.best = cleanHeroMap(raw.best, cleanMasteryNumber);
    if (raw.weaponDamage && typeof raw.weaponDamage === 'object' && !Array.isArray(raw.weaponDamage)) {
      for (const [rawId, value] of Object.entries(raw.weaponDamage).slice(0, 256)) {
        const weaponId = String(rawId || '').trim().toUpperCase();
        if (!/^[A-Z0-9_]{1,64}$/.test(weaponId)) continue;
        const cleaned = cleanMasteryNumber(value);
        if (cleaned != null) out.weaponDamage[weaponId] = cleaned;
      }
    }
    if (Array.isArray(raw.recent)) {
      out.recent = raw.recent.slice(0, 64).map((item) => {
        if (!item || typeof item !== 'object') return null;
        const hero = resultHeroId(item.heroId || item.hero);
        const id = String(item.achievementId || item.id || '');
        return validAward(hero, id)
          ? { achievementId: id, heroId: hero, at: cleanMasteryAt(item.at) }
          : null;
      }).filter(Boolean)
        .sort((a, b) => b.at - a.at)
        .filter((item, index, arr) => arr.findIndex((x) => x.heroId === item.heroId && x.achievementId === item.achievementId) === index)
        .slice(0, 12);
    }
    const gateKeys = new Set(MASTERY_SKIN_GATES.map((gate) => gate.key));
    if (Array.isArray(raw.unseenSkinUnlocks)) {
      out.unseenSkinUnlocks = [...new Set(raw.unseenSkinUnlocks.map(String).filter((key) => gateKeys.has(key)))].slice(0, 8);
    }
    return out;
  }
  // Product availability is centralized in src/game/productSurface.js and is
  // registered on window before classic runtimes load. These adapters never
  // invent a fallback broad roster: a missing authority fails closed to ROBOT.
  const PRODUCT = () => window.APEX_PRODUCT_SURFACE || null;
  const ROSTER = () => {
    const ids = PRODUCT()?.roster?.visibleIds;
    return Array.isArray(ids) && ids.length ? ids.slice() : ['ROBOT'];
  };
  const PLAYABLE_ROSTER = () => {
    const ids = PRODUCT()?.roster?.playableIds;
    return Array.isArray(ids) && ids.length ? ids.slice() : ['ROBOT'];
  };
  const isProductVisible = (name) => ROSTER().includes(String(name || '').toUpperCase());
  const isProductPlayable = (name) => PLAYABLE_ROSTER().includes(String(name || '').toUpperCase());

  // ── A1 PRODUCTION PROGRESSION (retires the r44 owner-playtest overrides) ─
  // A1 product law: a genuinely new player profile starts with exactly
  // START_CREDITS (350 AC) and ROBOT (NEWBOT) as the only owned fighter.
  // The r44 owner-playtest overrides that used to live here are DISABLED for
  // normal players:
  //   · OWNER_PLAYTEST_AC_SEED is 0 — no balance is ever seeded/refilled, on
  //     first boot, refresh or re-login. Existing balances are preserved
  //     verbatim by sanitize(); nothing is destructively reset.
  //   · OWNER_PLAYTEST_CORE_SIX_UNLOCK is false — selection requires real
  //     ownership (owns()).
  // Owner testing survives ONLY through the separate Admin authority
  // (src/game/adminAuthority.js → window.APEX_ADMIN_AUTHORITY): while an
  // authorized Admin Test Mode session is active, the playable roster is
  // selectable for testing. That session override is selection-only — it
  // never writes ownership, never touches credits/Shop, never widens the
  // Lucky Draw pool (poolLocked() uses owns()), never unlocks a future
  // visible-but-locked fighter, and its matches never pay AC (see
  // awardBattleResult). The legacy constant names/exports are retained for
  // one release so old saves and tooling keep resolving; rollback is still
  // this one fenced block.
  const OWNER_PLAYTEST_REVISION = '20261005-owner-playtest-r52';
  const OWNER_PLAYTEST_CORE_SIX_UNLOCK = false;
  const OWNER_PLAYTEST_CORE_SIX_UNLOCK_REVISION = OWNER_PLAYTEST_REVISION;
  const OWNER_PLAYTEST_AC_SEED = 0;
  const OWNER_PLAYTEST_AC_SEED_REVISION = OWNER_PLAYTEST_REVISION;
  // The ONE admin-session probe. The keyboard shortcut is an interface, not
  // authorization: the Admin authority decides who may hold a test session.
  // A missing authority fails closed (normal player).
  function adminTestSessionActive() {
    try {
      const admin = window.APEX_ADMIN_AUTHORITY;
      if (admin && typeof admin.isAdminTestSessionActive === 'function') {
        return admin.isAdminTestSessionActive() === true;
      }
    } catch (error) {}
    return false;
  }
  function adminTestSelectionUnlocked(name) {
    if (!adminTestSessionActive() && window.APEX_OWNER_TOOLS?.isPlaytestActive?.() !== true) return false;
    // ONLY the current production playable roster. A future
    // visible-but-locked fighter is never unlocked by the test session.
    return isProductPlayable(name);
  }
  // Legacy name retained as an alias of the admin-session rule above.
  function ownerPlaytestSelectionUnlocked(name) {
    return adminTestSelectionUnlocked(name);
  }
  const displayNameFor = (name) => {
    const id = String(name || '').toUpperCase();
    const registry = window.APEX_HERO_REWORK_REGISTRY;
    return (registry && typeof registry.displayNameFor === 'function' && registry.displayNameFor(id)) || id;
  };

  // HERO REWORK (doc 06): ROBOT replaces legacy NEWBIE as the default-owned
  // playable hero. Migration is IDEMPOTENT: any persisted NEWBIE ownership/
  // selection/unlock maps to ROBOT exactly once and never rewrites a state
  // that has already migrated.
  function migrateNewbieToRobot(st) {
    if (!st) return st;
    if (Array.isArray(st.ownedFighters) && st.ownedFighters.includes('NEWBIE')) {
      st.ownedFighters = st.ownedFighters.filter((n) => n !== 'NEWBIE' && n !== 'ROBOT');
      st.ownedFighters.unshift('ROBOT');
    }
    if (!st.ownedFighters.includes('ROBOT')) st.ownedFighters.unshift('ROBOT');
    if (st.lastSelectedP1 === 'NEWBIE' || !st.ownedFighters.includes(st.lastSelectedP1)) st.lastSelectedP1 = 'ROBOT';
    if (st.lastSelectedP2 === 'NEWBIE' || !st.ownedFighters.includes(st.lastSelectedP2)) st.lastSelectedP2 = 'ROBOT';
    if (st.unlockedAt) {
      if (st.unlockedAt.NEWBIE != null) {
        st.unlockedAt.ROBOT = st.unlockedAt.ROBOT != null
          ? Math.min(st.unlockedAt.ROBOT, st.unlockedAt.NEWBIE)
          : st.unlockedAt.NEWBIE;
        delete st.unlockedAt.NEWBIE;
      }
      if (st.unlockedAt.ROBOT == null) st.unlockedAt.ROBOT = 0;
    }
    return st;
  }

  // Owner R2 P0-B: a fresh Guest owns ROBOT (NEWBOT) and HUNTER. HUNTER is the
  // BOT CPU default and P2's natural pair, so it ships owned. Credits are unchanged.
  const FRESH_OWNED_FIGHTERS = Object.freeze(['ROBOT', 'HUNTER']);
  const HUNTER_OWNED_MIGRATION = 'hunter-owned-r2-20261025';
  // Additive, idempotent, once. Adds HUNTER to an existing save and records the
  // migration so it is never re-applied. Never removes or re-orders anything,
  // never touches credits, achievements, mastery, selections or other heroes.
  function migrateHunterOwnership(st) {
    if (!st || typeof st !== 'object') return st;
    if (!st.rosterMigrations || typeof st.rosterMigrations !== 'object') st.rosterMigrations = {};
    if (st.rosterMigrations[HUNTER_OWNED_MIGRATION]) return st;
    if (!Array.isArray(st.ownedFighters)) st.ownedFighters = ['ROBOT'];
    if (!st.ownedFighters.includes('HUNTER')) st.ownedFighters.push('HUNTER');
    if (st.unlockedAt && typeof st.unlockedAt === 'object' && st.unlockedAt.HUNTER == null) st.unlockedAt.HUNTER = 0;
    st.rosterMigrations[HUNTER_OWNED_MIGRATION] = 1;
    return st;
  }
  function emptyState() {
    return {
      version: 1,
      credits: START_CREDITS,
      ownedFighters: FRESH_OWNED_FIGHTERS.slice(),
      lastSelectedP1: 'ROBOT',
      lastSelectedP2: 'ROBOT',
      totalSpins: 0,
      unlockedAt: { ROBOT: 0, HUNTER: 0 },
      rosterMigrations: { [HUNTER_OWNED_MIGRATION]: 1 },
      // §D: Chamber-01 arena palette lives in THIS authority — no second
      // storage island. Null means the curated default.
      arenaPaletteId: null,
      // A1: persistent match-reward claim keys (sealed result ids). One
      // completed match pays exactly once, even across reload/retries.
      claimedMatchIds: [],
      progression: { botMatches: 0, botWins: 0, localMatches: 0, claimedIds: [] },
      mastery: emptyMastery(),
    };
  }
  function sanitize(raw) {
    const s = emptyState();
    if (!raw || typeof raw !== 'object') return s;
    s.credits = Math.max(0, raw.credits | 0);
    const owned = Array.isArray(raw.ownedFighters)
      ? raw.ownedFighters.map((id) => String(id || '').toUpperCase()).filter(Boolean) : [];
    // Historic ownership survives, even for product-locked/legacy entries.
    s.ownedFighters = Array.from(new Set(['ROBOT', ...owned]));
    s.lastSelectedP1 = String(raw.lastSelectedP1 || 'ROBOT').toUpperCase();
    s.lastSelectedP2 = String(raw.lastSelectedP2 || 'ROBOT').toUpperCase();
    s.totalSpins = Math.max(0, raw.totalSpins | 0);
    s.claimedMatchIds = Array.isArray(raw.claimedMatchIds)
      ? raw.claimedMatchIds.map((id) => String(id || '')).filter(Boolean).slice(-200) : [];
    const progress = raw.progression && typeof raw.progression === 'object' ? raw.progression : {};
    for (const key of ['botMatches','botWins','localMatches'])
      s.progression[key] = Math.max(0, Math.min(1000000, Number(progress[key]) | 0));
    s.progression.claimedIds = Array.isArray(progress.claimedIds)
      ? [...new Set(progress.claimedIds.filter(id => PROGRESSION_CATALOG.some(d => d.id === id)))]:[];
    s.mastery = sanitizeMastery(raw.mastery);
    s.unlockedAt = raw.unlockedAt && typeof raw.unlockedAt === 'object' ? { ...raw.unlockedAt } : { ROBOT: 0 };
    s.rosterMigrations = raw.rosterMigrations && typeof raw.rosterMigrations === 'object'
      ? { ...raw.rosterMigrations } : {};
    // The owner-playtest AC seed marker must survive sanitization, otherwise a
    // refresh would look "unseeded" and refill the balance.
    s.ownerPlaytestAcSeed = (raw.ownerPlaytestAcSeed && typeof raw.ownerPlaytestAcSeed === 'object')
      ? {
        revision: String(raw.ownerPlaytestAcSeed.revision || ''),
        profile: String(raw.ownerPlaytestAcSeed.profile || ''),
        at: Number(raw.ownerPlaytestAcSeed.at) || 0,
      }
      : null;
    // Legacy r44 owner playtest seeded 12,000 AC into the *real* device save.
    // Only retire an untouched, explicitly tagged demo balance. Never reset
    // an ordinary 12,000 AC wallet or a save with actual match/draw/purchase
    // history, claimed rewards or mastery progression.
    const demoMarker = s.ownerPlaytestAcSeed;
    const noGameplay = s.totalSpins === 0 &&
      s.progression.botMatches === 0 &&
      s.progression.botWins === 0 &&
      s.progression.localMatches === 0 &&
      s.progression.claimedIds.length === 0 &&
      s.claimedMatchIds.length === 0 &&
      Object.keys(s.mastery?.earned || {}).length === 0 &&
      Object.keys(s.mastery?.best || {}).length === 0 &&
      Object.keys(s.mastery?.weaponDamage || {}).length === 0 &&
      (s.mastery?.recent || []).length === 0 &&
      (s.mastery?.unseenSkinUnlocks || []).length === 0;
    const taggedDemo = ['20261005-owner-playtest-r44', OWNER_PLAYTEST_AC_SEED_REVISION]
      .includes(demoMarker?.revision) && demoMarker.profile === KEY;
    // The earlier playtest sometimes persisted exactly 12,000 AC without
    // its seed marker. Detect that *only* when it is otherwise identical to
    // an untouched starter account: zero progression, only free fighters,
    // no paid unlock timestamps and no real-purchase / reward evidence.
    // Preserve ANY wallet with activity, custom roster or other seed markers.
    const pristineUntaggedDemo = !demoMarker &&
      !raw.testSeed && !raw.adminWalletGrant &&
      s.ownedFighters.every(hero => hero === 'ROBOT' || hero === 'HUNTER') &&
      Object.entries(s.unlockedAt).every(([hero,at]) =>
        (hero === 'ROBOT' || hero === 'HUNTER') && !Number(at)) &&
      !Object.keys(s.rosterMigrations).some(key => /wallet|credit|ac-grant/i.test(key));
    const untouchedDemoWallet =
      s.credits === 12000 && noGameplay && (taggedDemo || pristineUntaggedDemo) &&
      !s.rosterMigrations['retired-owner-demo-wallet-20261028'];
    if (untouchedDemoWallet) {
      s.credits = START_CREDITS;
      s.rosterMigrations['retired-owner-demo-wallet-20261028'] = 1;
    }
    // AUDIT-E: state truth must match rendered truth — unknown/stale palette
    // ids sanitize to the canonical default representation (null => graphite-mid
    // in the palette runtime). Validated against the curated list when the
    // palette runtime is present; absent (partial boot) means default too.
    const P = window.APEX_CHAMBER_PALETTE;
    s.arenaPaletteId = (typeof raw.arenaPaletteId === 'string' && P && P.isKnown(raw.arenaPaletteId)) ? raw.arenaPaletteId : null;
    migrateNewbieToRobot(s);
    migrateHunterOwnership(s);
    // A stale historical selection is safe only when it is both owned and in
    // the current public Core Six. Locked visibility never implies selectability.
    if (!isProductPlayable(s.lastSelectedP1) || !s.ownedFighters.includes(s.lastSelectedP1)) s.lastSelectedP1 = 'ROBOT';
    if (!isProductPlayable(s.lastSelectedP2) || !s.ownedFighters.includes(s.lastSelectedP2)) s.lastSelectedP2 = 'ROBOT';
    return s;
  }
  // Owner-playtest AC seed (r44). Applied ONLY here, on load, and only when
  // the profile has no marker for THIS revision — so it fires exactly once per
  // profile/revision and an ordinary refresh never refills a spent balance.
  function applyOwnerPlaytestAcSeed(st) {
    if (!st || typeof st !== 'object') return st;
    if (!OWNER_PLAYTEST_AC_SEED) return st;
    const marker = st.ownerPlaytestAcSeed;
    if (marker && marker.revision === OWNER_PLAYTEST_AC_SEED_REVISION && marker.profile === KEY) return st;
    // Real production economy path: the single AC state, saved once.
    st.credits = OWNER_PLAYTEST_AC_SEED;
    st.ownerPlaytestAcSeed = {
      revision: OWNER_PLAYTEST_AC_SEED_REVISION,
      profile: KEY,
      at: Date.now(),
    };
    return st;
  }
  function load() {
    try {
      const raw = typeof localStorage !== 'undefined' ? localStorage.getItem(KEY) : null;
      if (!raw) return save(applyOwnerPlaytestAcSeed(emptyState()));
      const parsed = JSON.parse(raw);
      const clean = sanitize(parsed);
      // Keep the original on-device save for recovery before any legacy
      // demo balance normalization. It is never uploaded or shared.
      if (parsed?.credits === 12000 &&
          clean.rosterMigrations?.['retired-owner-demo-wallet-20261028']) {
        try {
          const backupKey = KEY + '.legacyDemoWalletBackup.20261028';
          if (localStorage.getItem(backupKey) == null)
            localStorage.setItem(backupKey, raw);
        } catch (error) { /* private storage unavailable */ }
      }
      // Migration is durable: a NEWBIE/stale selection cannot reappear after
      // the next reload, while all historic ownership and balances survive.
      const seeded = applyOwnerPlaytestAcSeed(clean);
      try { localStorage.setItem(KEY, JSON.stringify(seeded)); } catch (error) {}
      state = seeded;
      return seeded;
    } catch (e) {
      return save(applyOwnerPlaytestAcSeed(emptyState()));
    }
  }
  // The one AC/economy state. Declared before save()/load() run so the load
  // path can persist through the REAL save() mechanism (no second currency).
  let state = null;
  function save(st) {
    try {
      if (typeof localStorage !== 'undefined') localStorage.setItem(KEY, JSON.stringify(st));
    } catch (e) {}
    state = st;
    // ONE announcement for ONE economy: every balance change (spin, shop,
    // award, owner seed) travels this exact path, so any readout in any surface
    // can follow production truth instead of being told about it separately.
    try {
      if (typeof window !== 'undefined' && window.dispatchEvent) {
        window.dispatchEvent(new CustomEvent('apex:credits', { detail: { credits: st.credits } }));
      }
    } catch (e) {}
    return st;
  }
  state = load();
  const lastAward = { reasons: [], amount: 0, balance: state.credits };

  // §D palette persistence (sanitized again by the palette runtime against
  // its curated list — unknown ids simply resolve to the default there).
  function palette() { return state.arenaPaletteId || null; }
  function setPalette(id) {
    const PR = window.APEX_CHAMBER_PALETTE;
    const v = id == null ? null : String(id);
    state.arenaPaletteId = (v && PR && PR.isKnown(v)) ? v : null;
    save(state);
    if (PR && PR.refreshSelector) PR.refreshSelector();
    return state.arenaPaletteId;
  }
  function getState() { return JSON.parse(JSON.stringify(state)); }
  function credits() { return state.credits; }
  function owns(name) { return state.ownedFighters.includes(String(name).toUpperCase()); }
  function canPublicSelect(name) {
    const id = String(name || '').toUpperCase();
    if (!isProductPlayable(id)) return false;
    return owns(id) || ownerPlaytestSelectionUnlocked(id);
  }
  function poolLocked() {
    // Draw is a mutation path, so it has the Core Six legality boundary rather
    // than merely filtering whatever happens to be painted in the shop.
    return PLAYABLE_ROSTER().filter((n) => !owns(n));
  }
  function buy(name) {
    const id = String(name || '').toUpperCase();
    if (!id || !isProductPlayable(id)) return { ok: false, reason: 'unavailable' };
    if (owns(id)) return { ok: false, reason: 'owned' };
    if (state.credits < SHOP_COST) return { ok: false, reason: 'need', need: SHOP_COST - state.credits };
    state.credits -= SHOP_COST;
    state.ownedFighters.push(id);
    state.unlockedAt[id] = Date.now();
    save(state);
    return { ok: true, name: id, credits: state.credits };
  }
  function spin(rng) {
    if (spin._busy) return { ok: false, reason: 'spinning' };
    const pool = poolLocked();
    if (!pool.length) return { ok: false, reason: 'complete' };
    if (state.credits < DRAW_COST) return { ok: false, reason: 'need', need: DRAW_COST - state.credits };
    const random = typeof rng === 'function' ? rng : Math.random;
    const pick = pool[Math.floor(random() * pool.length) % pool.length];
    // One atomic localStorage snapshot: cost, draw count and ownership
    // must never split into separate persisted states.
    state.credits -= DRAW_COST;
    state.totalSpins += 1;
    state.ownedFighters.push(pick);
    state.unlockedAt[pick] = Date.now();
    save(state);
    return { ok: true, name: pick, credits: state.credits, totalSpins: state.totalSpins };
  }
  function award(reason, amount) {
    const n = Math.max(0, amount | 0);
    if (!n) return { ok: false, amount: 0, balance: state.credits };
    state.credits += n;
    save(state);
    lastAward.reasons = Array.isArray(reason) ? reason : [reason];
    lastAward.amount = n;
    lastAward.balance = state.credits;
    return { ok: true, ...lastAward };
  }
  // A1 match-reward law (single wallet commit path; telemetry stays in
  // award()/lastAward). The amount derives from the ACTUAL match mode and
  // outcome — never from winnerSide alone:
  //   BOT   P1 wins → +200 AC · P1 loses → +25 AC (provisional legacy)
  //   LOCAL valid completed match → +50 AC regardless of winner
  //   Lab / Admin Test / Quest / incomplete → 0 AC (no wallet entry at all)
  // Idempotency is two-layered: the in-memory productResultAwarded flag stops
  // duplicate callbacks, and the sealed result id (resultGold.meta.id) is
  // persisted in claimedMatchIds so a reload/retry can never pay twice.
  function masteryTestActive() {
    try { return adminTestSessionActive() || window.APEX_OWNER_TOOLS?.isPlaytestActive?.() === true || window.APEX_ARSENAL_OWNER_TEST?.active === true; }
    catch (error) { return adminTestSessionActive(); }
  }
  function ensureMastery() {
    if (!state.mastery || typeof state.mastery !== 'object' || Array.isArray(state.mastery)) state.mastery = emptyMastery();
    const mastery = state.mastery;
    if (!mastery.earned || typeof mastery.earned !== 'object' || Array.isArray(mastery.earned)) mastery.earned = {};
    if (!mastery.best || typeof mastery.best !== 'object' || Array.isArray(mastery.best)) mastery.best = {};
    if (!mastery.weaponDamage || typeof mastery.weaponDamage !== 'object' || Array.isArray(mastery.weaponDamage)) mastery.weaponDamage = {};
    if (!Array.isArray(mastery.recent)) mastery.recent = [];
    if (!Array.isArray(mastery.unseenSkinUnlocks)) mastery.unseenSkinUnlocks = [];
    return mastery;
  }
  function cloneMastery() { return JSON.parse(JSON.stringify(ensureMastery())); }
  function masteryCatalog() {
    return resultCatalog().map((def) => ({
      id: def.id,
      heroId: def.heroId || null,
      params: def.params.map((param) => ({ ...param })),
    }));
  }
  function isBetterMasteryBest(def, current, next) {
    if (!Number.isFinite(next)) return false;
    if (!Number.isFinite(current)) return true;
    return def?.params?.[0]?.compare === 'lte' ? next < current : next > current;
  }
  function updateMasteryBest(hero, def, value) {
    const cleaned = cleanMasteryNumber(value);
    if (cleaned == null) return false;
    const mastery = ensureMastery();
    const byHero = mastery.best[hero] || (mastery.best[hero] = {});
    if (!isBetterMasteryBest(def, Number(byHero[def.id]), cleaned)) return false;
    byHero[def.id] = cleaned;
    return true;
  }
  // CP4 presentation ownership. This is derived only from the event's
  // side/mode authority and is never inferred from hero identity. It is
  // attached to transient unlock/provisional payloads for UI placement and
  // copy; persisted mastery and wallet eligibility law remain unchanged.
  function masteryPresentationOwner(source) {
    const input = source && typeof source === 'object' ? source : {};
    let sideIndex = Number.isInteger(input.sideIndex) ? input.sideIndex
      : Number.isInteger(input.ownerSideIndex) ? input.ownerSideIndex : null;
    const sideText = String(input.ownerSide || input.side || '').trim().toUpperCase();
    if (sideIndex == null && (sideText === 'P1' || sideText === '1')) sideIndex = 0;
    if (sideIndex == null && (sideText === 'P2' || sideText === '2')) sideIndex = 1;
    if (sideIndex !== 0 && sideIndex !== 1) sideIndex = null;

    let battleMode = String(input.battleMode || input.mode || '').trim().toUpperCase();
    if (battleMode !== 'BOT' && battleMode !== 'LOCAL') {
      try {
        const liveMode = String(window.APEX_ARSENAL?.state?.battleMode || '').trim().toUpperCase();
        if (liveMode === 'BOT' || liveMode === 'LOCAL') battleMode = liveMode;
      } catch (error) { /* presentation owner stays unknown */ }
    }

    const ownerSide = sideIndex == null ? null : (sideIndex === 0 ? 'P1' : 'P2');
    let ownerKind = 'unknown';
    let walletEligible = false;
    if (sideIndex != null && battleMode === 'BOT') {
      ownerKind = sideIndex === 0 ? 'human' : 'bot';
      walletEligible = sideIndex === 0;
    } else if (sideIndex != null && battleMode === 'LOCAL') {
      ownerKind = sideIndex === 0 ? 'player1' : 'player2';
      walletEligible = true;
    }
    return {
      ownerSide,
      ownerSideIndex: sideIndex,
      ownerKind,
      walletEligible,
      ...(battleMode === 'BOT' || battleMode === 'LOCAL' ? { battleMode } : {}),
    };
  }

  function observeMastery(input, unlockIt, at) {
    const hero = resultHeroId(input?.heroId || input?.hero);
    const def = awardDef(input?.achievementId || input?.id);
    if (!def || (def.heroId && def.heroId !== hero)) return { unlock: null, bestChanged: false };
    let primary = input?.value;
    if (primary == null && def.params.length && input?.observedParams) primary = input.observedParams[def.params[0].key];
    if (primary == null && !def.params.length && unlockIt) primary = 1;
    const bestChanged = updateMasteryBest(hero, def, primary);
    if (!unlockIt) return { unlock: null, bestChanged };
    const mastery = ensureMastery();
    const earned = mastery.earned[hero] || (mastery.earned[hero] = {});
    if (Object.prototype.hasOwnProperty.call(earned, def.id)) return { unlock: null, bestChanged };
    earned[def.id] = at;
    const unlock = {
      achievementId: def.id,
      heroId: hero,
      at,
      value: cleanMasteryNumber(primary),
      ...masteryPresentationOwner(input),
    };
    mastery.recent = [
      { achievementId: def.id, heroId: hero, at },
      ...mastery.recent.filter((item) => !(item.heroId === hero && item.achievementId === def.id)),
    ].slice(0, 12);
    return { unlock, bestChanged };
  }
  function heroMasteryProgress(heroId) {
    const hero = resultHeroId(heroId || 'ROBOT');
    const defs = applicableAwardDefs(hero);
    const earned = ensureMastery().earned[hero] || {};
    const earnedIds = defs.filter((def) => Object.prototype.hasOwnProperty.call(earned, def.id)).map((def) => def.id);
    const missingIds = defs.filter((def) => !Object.prototype.hasOwnProperty.call(earned, def.id)).map((def) => def.id);
    return {
      heroId: hero,
      engineHeroId: engineHeroId(hero),
      earned: earnedIds.length,
      total: defs.length,
      earnedIds,
      missingIds,
      complete: defs.length > 0 && missingIds.length === 0,
    };
  }
  function skinGateFor(kind, baseId, skinId) {
    const cleanKind = String(kind || '').toLowerCase();
    const cleanBase = cleanKind === 'hero' ? engineHeroId(baseId) : String(baseId || '').trim().toUpperCase();
    const cleanSkin = String(skinId || '');
    return MASTERY_SKIN_GATES.find((gate) => gate.kind === cleanKind && gate.baseId === cleanBase && gate.skinId === cleanSkin) || null;
  }
  function skinProgress(kind, baseId, skinId) {
    const cleanSkin = String(skinId || 'default');
    const gate = skinGateFor(kind, baseId, cleanSkin);
    if (cleanSkin === 'default' || !gate) return { gated: false, entitled: true, key: null };
    if (gate.resultHeroId) {
      const progress = heroMasteryProgress(gate.resultHeroId);
      return {
        gated: true,
        entitled: progress.complete,
        key: gate.key,
        kind: gate.kind,
        baseId: gate.baseId,
        skinId: gate.skinId,
        heroId: progress.heroId,
        current: progress.earned,
        target: progress.total,
        remainingIds: progress.missingIds,
      };
    }
    const current = ensureMastery().weaponDamage[gate.weaponId] || 0;
    return {
      gated: true,
      entitled: current > gate.damageThreshold,
      key: gate.key,
      kind: gate.kind,
      baseId: gate.baseId,
      skinId: gate.skinId,
      weaponId: gate.weaponId,
      current,
      target: gate.damageThreshold,
      strictlyGreater: true,
    };
  }
  function skinEntitlement(kind, baseId, skinId) {
    return skinProgress(kind, baseId, skinId).entitled === true;
  }
  function entitledSkinKeySet() {
    return new Set(MASTERY_SKIN_GATES
      .filter((gate) => skinEntitlement(gate.kind, gate.baseId, gate.skinId))
      .map((gate) => gate.key));
  }
  function collectNewSkinUnlocks(before) {
    const after = entitledSkinKeySet();
    const mastery = ensureMastery();
    const found = [];
    for (const gate of MASTERY_SKIN_GATES) {
      if (!after.has(gate.key) || before.has(gate.key)) continue;
      found.push({ ...gate, progress: skinProgress(gate.kind, gate.baseId, gate.skinId) });
      if (!mastery.unseenSkinUnlocks.includes(gate.key)) mastery.unseenSkinUnlocks.push(gate.key);
    }
    return found;
  }
  function dispatchMasteryEvents(unlocks, skinUnlocks, source) {
    try {
      if (unlocks?.length) window.dispatchEvent(new CustomEvent('apex:mastery-unlocked', { detail: { unlocks, source } }));
      for (const skin of skinUnlocks || []) window.dispatchEvent(new CustomEvent('apex:skin-unlocked', { detail: { skin, source } }));
    } catch (error) {}
  }
  function dispatchMasteryProvisionalEvents(provisional) {
    try {
      if (provisional?.length) window.dispatchEvent(new CustomEvent('apex:mastery-provisional', {
        detail: { unlocks: provisional, provisional, source: 'live-match-provisional' },
      }));
    } catch (error) {}
  }
  // CP3.2 law: live match feedback is provisional only. This path validates
  // the ledger event against the one owner catalogue and suppresses repeats
  // for already-earned (including grandfathered) achievements, but it does
  // NOT write earned ids, bests, recent history, weapon damage, skin gates,
  // AC, or storage. Permanent mastery is committed only by
  // awardBattleResult()->foldMasteryResult() inside the valid sealed-match
  // transaction guarded by claimedMatchIds.
  function recordMasteryProvisional(events) {
    if (masteryTestActive()) return { ok: false, reason: 'admin-test', provisional: [], unlocks: [], skinUnlocks: [] };
    if (!Array.isArray(events)) return { ok: false, reason: 'invalid-events', provisional: [], unlocks: [], skinUnlocks: [] };
    const provisional = [];
    const seen = new Set();
    const at = Date.now();
    const mastery = ensureMastery();
    for (const event of events.slice(0, 64)) {
      const hero = resultHeroId(event?.heroId || event?.hero);
      const def = awardDef(event?.achievementId || event?.id);
      if (!def || (def.heroId && def.heroId !== hero)) continue;
      const owner = masteryPresentationOwner(event);
      const key = `${owner.ownerSide || 'unknown'}:${hero}:${def.id}`;
      if (seen.has(key)) continue;
      seen.add(key);
      const earned = mastery.earned[hero] || {};
      if (Object.prototype.hasOwnProperty.call(earned, def.id)) continue;
      let primary = event?.value;
      if (primary == null && def.params.length && event?.observedParams) primary = event.observedParams[def.params[0].key];
      if (primary == null && !def.params.length) primary = 1;
      provisional.push({
        achievementId: def.id,
        heroId: hero,
        at,
        value: cleanMasteryNumber(primary),
        provisional: true,
        sealRequired: true,
        ...owner,
      });
    }
    dispatchMasteryProvisionalEvents(provisional);
    return { ok: true, changed: false, provisional, unlocks: [], skinUnlocks: [], mastery: cloneMastery() };
  }
  // Backward-compatible name for the live caller. Despite the legacy name,
  // this is deliberately provisional-only under CP3.2; there is no public
  // live permanent-unlock writer.
  function recordMasteryUnlocks(events) {
    return recordMasteryProvisional(events);
  }
  function markSkinUnlockSeen(key) {
    const wanted = String(key || '');
    const mastery = ensureMastery();
    const before = mastery.unseenSkinUnlocks.length;
    mastery.unseenSkinUnlocks = mastery.unseenSkinUnlocks.filter((item) => item !== wanted);
    if (mastery.unseenSkinUnlocks.length !== before) save(state);
    return { ok: true, unseenSkinUnlocks: [...mastery.unseenSkinUnlocks] };
  }
  function foldMasteryResult(result, mode) {
    const before = entitledSkinKeySet();
    const unlocks = [];
    let changed = false;
    const at = Date.now();
    const players = Array.isArray(result?.players) ? result.players : [];
    const indexes = mode === 'BOT' ? [0] : [0, 1];
    for (const index of indexes) {
      const player = players[index];
      if (!player) continue;
      const hero = resultHeroId(player.character?.heroId || player.character?.name);
      const bests = player.achievementBests && typeof player.achievementBests === 'object' ? player.achievementBests : {};
      for (const [achievementId, rawBest] of Object.entries(bests)) {
        const best = rawBest && typeof rawBest === 'object' ? rawBest : { value: rawBest };
        const observed = observeMastery({
          heroId: hero,
          achievementId,
          value: best.value,
          observedParams: best.observedParams,
          sideIndex: index,
          battleMode: mode,
        }, false, at);
        if (observed.bestChanged) changed = true;
      }
      for (const earnedAward of Array.isArray(player.awards) ? player.awards : []) {
        const observed = observeMastery({
          heroId: hero,
          achievementId: earnedAward?.achievementId,
          value: earnedAward?.value,
          observedParams: earnedAward?.observedParams,
          sideIndex: index,
          battleMode: mode,
        }, true, at);
        if (observed.bestChanged) changed = true;
        if (observed.unlock) { unlocks.push(observed.unlock); changed = true; }
      }
      const sources = Array.isArray(player.damage?.sources) ? player.damage.sources : [];
      for (const source of sources) {
        if (source?.kind !== 'weapon') continue;
        const weaponId = String(source.weaponId || '').trim().toUpperCase();
        if (!/^[A-Z0-9_]{1,64}$/.test(weaponId)) continue;
        const damage = cleanMasteryNumber(source.damage);
        if (!(damage > 0)) continue;
        const mastery = ensureMastery();
        mastery.weaponDamage[weaponId] = Math.min(MASTERY_MAX_VALUE, (mastery.weaponDamage[weaponId] || 0) + damage);
        changed = true;
      }
    }
    const skinUnlocks = collectNewSkinUnlocks(before);
    if (skinUnlocks.length) changed = true;
    return { unlocks, skinUnlocks, changed };
  }
  const MATCH_REWARDS = Object.freeze({ BOT_WIN: 200, BOT_LOSS: 25, LOCAL_COMPLETE: 50 });
  function awardBattleResult(winnerSide, battleState) {
    const current = battleState || (window.APEX_ARSENAL && window.APEX_ARSENAL.state);
    if (!current || current.labMode || current.questStage || current.productResultAwarded) {
      return { ok: false, reason: 'not-awardable', balance: state.credits };
    }
    // Admin/owner test activity never enters the real wallet ledger.
    const ownerTest = window.APEX_ARSENAL_OWNER_TEST;
    if ((ownerTest && ownerTest.active === true) || adminTestSessionActive()) {
      return { ok: false, reason: 'admin-test', balance: state.credits };
    }
    if (winnerSide !== 'P1' && winnerSide !== 'P2') {
      return { ok: false, reason: 'invalid-winner', balance: state.credits };
    }
    const mode = String(current.battleMode || '').toUpperCase();
    if (mode !== 'BOT' && mode !== 'LOCAL') {
      // No trustworthy mode = not a valid completed product match. Fail closed.
      return { ok: false, reason: 'invalid-mode', balance: state.credits };
    }
    const claimKey = current.resultGold && current.resultGold.meta
      ? String(current.resultGold.meta.id || '') : '';
    if (!claimKey || claimKey.length > 128) {
      return { ok: false, reason: 'unsealed-match', balance: state.credits };
    }
    if (state.claimedMatchIds.includes(claimKey)) {
      current.productResultAwarded = true;
      return { ok: false, reason: 'duplicate-claim', balance: state.credits };
    }
    // Side identity is authoritative: both players may legally choose the
    // same fighter, so a fighter-name comparison cannot determine a winner.
    const p1Won = winnerSide === 'P1';
    const amount = mode === 'BOT'
      ? (p1Won ? MATCH_REWARDS.BOT_WIN : MATCH_REWARDS.BOT_LOSS)
      : MATCH_REWARDS.LOCAL_COMPLETE;
    const reasons = mode === 'BOT'
      ? (p1Won ? ['bot_complete', 'bot_winner'] : ['bot_complete'])
      : ['local_complete'];
    current.productResultAwarded = true;
    if (claimKey) {
      state.claimedMatchIds.push(claimKey);
      if (state.claimedMatchIds.length > 200) {
        state.claimedMatchIds = state.claimedMatchIds.slice(-200);
      }
    }
    // Persist progression and CP3 mastery with the exact match claim and
    // normal AC in one save. foldMasteryResult is behind the duplicate
    // claim guard above, so a retry can neither re-pay AC nor re-fold RPG
    // damage/bests. BOT folds P1 only; LOCAL folds both device players.
    if (mode === 'BOT') {
      state.progression.botMatches += 1;
      if (p1Won) state.progression.botWins += 1;
    } else state.progression.localMatches += 1;
    const masteryFold = foldMasteryResult(current.resultGold, mode);
    const paid = award(reasons, amount);
    dispatchMasteryEvents(masteryFold.unlocks, masteryFold.skinUnlocks, 'sealed-match');
    return { ...paid, mastery: { unlocks: masteryFold.unlocks, skinUnlocks: masteryFold.skinUnlocks } };
  }
  function progressionCatalog() { return PROGRESSION_CATALOG.map(d => ({ ...d })); }
  function claimProgressReward(id) {
    const def = PROGRESSION_CATALOG.find(x => x.id === id);
    if (!def) return { ok: false, reason: 'unknown-reward' };
    if (adminTestSessionActive() || window.APEX_ARSENAL_OWNER_TEST?.active === true)
      return { ok: false, reason: 'admin-test' };
    if (state.progression.claimedIds.includes(id)) return { ok: false, reason: 'already-claimed' };
    if (state.progression[def.stat] < def.target) return { ok: false, reason: 'not-complete' };
    state.progression.claimedIds.push(id);
    // One real-wallet commit makes receipt and AC award durable together.
    return award(['progression',def.id], def.ac);
  }
  function filterOwned(list) {
    const arr = list || [];
    return arr.filter((ft) => {
      const n = ft && (ft.name || ft);
      return canPublicSelect(n);
    });
  }
  function setLast(p1, p2) {
    if (p1 && canPublicSelect(p1)) state.lastSelectedP1 = String(p1).toUpperCase();
    if (p2 && canPublicSelect(p2)) state.lastSelectedP2 = String(p2).toUpperCase();
    // Sanitization makes direct compatibility callers safe too.
    if (!canPublicSelect(state.lastSelectedP1)) state.lastSelectedP1 = 'ROBOT';
    if (!canPublicSelect(state.lastSelectedP2)) state.lastSelectedP2 = 'ROBOT';
    save(state);
  }

  const PICK_ASSETS = '../assets/pick_ui_final/assets/';
  let shopSelected = state.lastSelectedP1 || 'ROBOT'; // HERO REWORK: NEWBIE retired
  let lastDrawResult = null;
  let drawBusy = false;
  let drawTimer = 0;
  let drawSpinToken = 0;

  function cancelDrawSpinAnimation() {
    drawSpinToken += 1;
    drawBusy = false;
    if (drawTimer) {
      window.clearTimeout(drawTimer);
      drawTimer = 0;
    }
  }

  function esc(v) {
    return String(v == null ? '' : v).replace(/[&<>"']/g, (ch) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'
    }[ch]));
  }
  const FIGHTER_ART = Object.freeze({
    ICE: 'ice',
    STRING: 'string',
    NOVA: 'galaxy',
  });
  function fighterInfo(name) {
    const id = String(name || 'ROBOT').toUpperCase();
    const shell = window.APEX_ARSENAL_SHELLS && window.APEX_ARSENAL_SHELLS.typeFor
      ? window.APEX_ARSENAL_SHELLS.typeFor(id) : null;
    const artId = FIGHTER_ART[id] || null;
    return {
      id,
      label: displayNameFor(id),
      color: (shell && shell.color) || '#d7bd72',
      desc: (shell && shell.desc) || 'Arsenal fighter',
      mark: (typeof window.fighterGlyph === 'function' && window.fighterGlyph(id)) || id.slice(0, 2),
      standing: artId ? `${PICK_ASSETS}standing/${artId}-standing.webp` : '',
      icon: artId ? `${PICK_ASSETS}hero-icons/${artId}-icon.webp` : '',
    };
  }
  function wireGridNav(root, selector, cols) {
    if (!root) return;
    root.addEventListener('keydown', (e) => {
      const items = Array.from(root.querySelectorAll(selector)).filter((el) => !el.disabled);
      const i = items.indexOf(document.activeElement);
      if (i < 0) return;
      let next = i;
      if (e.key === 'ArrowRight') next = Math.min(items.length - 1, i + 1);
      if (e.key === 'ArrowLeft') next = Math.max(0, i - 1);
      if (e.key === 'ArrowDown') next = Math.min(items.length - 1, i + cols);
      if (e.key === 'ArrowUp') next = Math.max(0, i - cols);
      if (next !== i) { e.preventDefault(); items[next].focus(); }
    });
  }

  const META_CSS = `
    #aq-meta-root{position:fixed;inset:0;z-index:520;display:none;pointer-events:auto;overflow:auto;overscroll-behavior:contain;background:#080b0f;color:#f4f0e6;font-family:"ApcKanit","Segoe UI",sans-serif;}
    #aq-meta-root *{box-sizing:border-box}
    #aq-meta-root button{pointer-events:auto;touch-action:manipulation;-webkit-tap-highlight-color:transparent;min-height:44px}
    #aq-meta-root button:focus-visible{outline:2px solid #f0d67e;outline-offset:3px}
    #aq-meta-root button:disabled{pointer-events:none}
    #aq-meta-stage{--aq-accent:#d7bd72;--aq-panel:#12171d;--aq-panel2:#1a2027;--aq-line:#343c45;--aq-muted:#8e99a4;position:relative;min-height:100dvh;width:100%;overflow:hidden;background:#080b0f;}
    #aq-meta-stage .aq-bg{position:fixed;inset:0;width:100%;height:100%;object-fit:cover;filter:saturate(.6) contrast(1.08) brightness(.42);pointer-events:none;}
    #aq-meta-stage .aq-veil{position:fixed;inset:0;background:radial-gradient(circle at 62% 42%,rgba(115,130,150,.12),transparent 34%),linear-gradient(180deg,rgba(4,7,10,.3),rgba(4,7,10,.78)),linear-gradient(90deg,rgba(2,4,7,.84),rgba(4,7,10,.35) 54%,rgba(2,4,7,.82));pointer-events:none;}
    .aq-ui{position:relative;z-index:2;width:100%;max-width:1920px;min-height:100dvh;margin:0 auto;padding:clamp(18px,2.2vw,38px) clamp(18px,3vw,56px) clamp(24px,3vw,50px);}
    .aq-topbar{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:20px;align-items:center;padding-bottom:16px;border-bottom:1px solid rgba(255,255,255,.1);}
    .aq-brand{display:flex;align-items:center;gap:14px;min-width:0}
    .aq-brand-copy{min-width:0}
    .aq-kicker{color:var(--aq-accent);font:800 10px/1 ui-monospace,monospace;letter-spacing:.22em;text-transform:uppercase}
    .aq-title{margin:4px 0 0;color:#f4f0e6;font-size:clamp(24px,3vw,42px);line-height:.92;font-style:italic;font-weight:900;letter-spacing:.02em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    .aq-meta-stats{display:flex;gap:10px;align-items:center;justify-content:flex-end;flex-wrap:wrap}
    .aq-stat{min-width:118px;padding:9px 12px;border:1px solid var(--aq-line);background:linear-gradient(180deg,#1a2027,#10151a);box-shadow:inset 0 1px rgba(255,255,255,.04);}
    .aq-stat span{display:block;color:var(--aq-muted);font:800 9px/1 ui-monospace,monospace;letter-spacing:.14em}
    .aq-stat b{display:block;margin-top:5px;color:#f2ead2;font:900 16px/1 "ApcKanit","Segoe UI",sans-serif}
    #aq-splatter-mode{padding:7px 12px;border:1px solid #5d6670;background:#1b242c;color:#f4e7c5;cursor:pointer;font:800 11px/1.25 "Segoe UI",sans-serif;text-align:left}
    .aq-back,.aq-exit{display:grid;place-items:center;width:44px;height:44px;flex:0 0 auto;border:1px solid #4a5057;background:linear-gradient(180deg,#2b3138,#151a20);color:#f4f0e6;cursor:pointer;font:900 18px/1 sans-serif;clip-path:polygon(7px 0,100% 0,100% calc(100% - 7px),calc(100% - 7px) 100%,0 100%,0 7px);}
    @media(hover:hover){.aq-back:hover,.aq-exit:hover{filter:brightness(1.14);transform:translateY(-1px)}}
    .aq-action{position:relative;border:1px solid var(--aq-line);background:linear-gradient(160deg,#1a2027,#0e1318 72%);color:#f4f0e6;cursor:pointer;text-align:left;overflow:hidden;box-shadow:inset 0 1px rgba(255,255,255,.035);transition:transform .14s ease,filter .14s ease,border-color .14s ease;clip-path:polygon(12px 0,100% 0,100% calc(100% - 12px),calc(100% - 12px) 100%,0 100%,0 12px);}
    .aq-action::before{content:"";position:absolute;left:0;top:0;bottom:0;width:3px;background:var(--aq-tile-accent,var(--aq-accent));opacity:.82}
    @media(hover:hover){.aq-action:hover{transform:translateY(-5px);filter:brightness(1.08);border-color:#59636d}}
    .aq-action:active{transform:translateY(0) scale(.985)}
    .aq-action-index{display:block;color:var(--aq-tile-accent,var(--aq-accent));font:800 10px/1 ui-monospace,monospace;letter-spacing:.18em}
    .aq-action-title{display:block;margin-top:14px;font-size:clamp(22px,2.1vw,34px);line-height:.92;font-style:italic;font-weight:900;letter-spacing:.01em}
    .aq-action-desc{display:block;margin-top:12px;max-width:34ch;color:#aab3bc;font:650 13px/1.4 "Segoe UI",sans-serif}
    .aq-action-meta{display:block;margin-top:15px;color:#d9c57f;font:800 11px/1.25 ui-monospace,monospace;letter-spacing:.08em}
    .aq-hub-layout{display:grid;grid-template-columns:minmax(260px,.72fr) minmax(0,1.55fr);gap:clamp(18px,2vw,28px);padding-top:clamp(22px,3vh,36px)}
    .aq-ident{min-height:min(690px,calc(100dvh - 142px));display:grid;grid-template-rows:auto minmax(190px,1fr) auto auto auto;align-items:center;padding:22px;border:1px solid #39424c;background:linear-gradient(180deg,#171d24,#0d1217);clip-path:polygon(14px 0,100% 0,100% calc(100% - 14px),calc(100% - 14px) 100%,0 100%,0 14px);}
    .aq-ident-label{justify-self:start;color:#7f8b97;font:800 9px/1 ui-monospace,monospace;letter-spacing:.18em}
    .aq-plate{position:relative;display:grid;place-items:center;width:min(82%,290px);aspect-ratio:1;justify-self:center;margin:18px 0;border:1px solid color-mix(in srgb,var(--fighter-accent) 45%,#46515d);background:radial-gradient(circle at 50% 42%,color-mix(in srgb,var(--fighter-accent) 18%,transparent),transparent 50%),linear-gradient(180deg,#222a33,#10151b);color:#f3eee1;font:900 clamp(56px,7vw,96px)/1 "ApcKanit","Segoe UI",sans-serif;font-style:italic;overflow:hidden;clip-path:polygon(16% 0,84% 0,100% 16%,100% 84%,84% 100%,16% 100%,0 84%,0 16%);}
    .aq-plate::after{content:"";position:absolute;z-index:3;left:18%;right:18%;bottom:10%;height:2px;background:var(--fighter-accent);box-shadow:0 0 16px color-mix(in srgb,var(--fighter-accent) 55%,transparent)}
    .aq-standing{position:absolute;inset:4% 2% 0;width:96%;height:96%;object-fit:contain;object-position:center bottom;filter:drop-shadow(0 18px 18px rgba(0,0,0,.48));transform:scale(1.04);transform-origin:center bottom}
    .aq-plate-mark{position:relative;z-index:2;text-shadow:0 4px 18px rgba(0,0,0,.6)}
    .aq-sel{font-size:clamp(24px,2.4vw,36px);font-weight:900;font-style:italic;line-height:.94;text-align:center;overflow-wrap:anywhere}
    .aq-tag{margin-top:7px;color:var(--fighter-accent);font:800 10px/1 ui-monospace,monospace;letter-spacing:.18em;text-align:center}
    .aq-primary-btn{min-height:48px;margin-top:18px;border:1px solid #5a5541;background:linear-gradient(180deg,#4a4024,#282312);color:#f5e8bb;cursor:pointer;font:900 13px/1 "Segoe UI",sans-serif;letter-spacing:.08em;clip-path:polygon(8px 0,100% 0,100% calc(100% - 8px),calc(100% - 8px) 100%,0 100%,0 8px);}
    @media(hover:hover){.aq-primary-btn:hover{filter:brightness(1.14)}}
    .aq-hub-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));grid-auto-rows:minmax(220px,1fr);gap:16px;min-height:min(690px,calc(100dvh - 142px));}
    .aq-hub-grid .aq-action{padding:24px 24px 22px}
    .aq-shop-layout{display:grid;grid-template-columns:minmax(0,1.65fr) minmax(280px,.7fr);gap:18px;padding-top:24px}
    .aq-shop-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;align-content:start;max-height:calc(100dvh - 152px);overflow:auto;padding-right:6px;scrollbar-width:thin;scrollbar-color:#59636d #0b0f13}
    .aq-shop-grid::-webkit-scrollbar{width:8px}.aq-shop-grid::-webkit-scrollbar-track{background:#0b0f13}.aq-shop-grid::-webkit-scrollbar-thumb{background:#4a535d;border:2px solid #0b0f13}
    .aq-fighter-card{position:relative;min-height:132px;padding:15px;border:1px solid #333c45;background:linear-gradient(180deg,#161c22,#0d1217);color:#f0ece2;cursor:pointer;text-align:left;clip-path:polygon(10px 0,100% 0,100% calc(100% - 10px),calc(100% - 10px) 100%,0 100%,0 10px);}
    .aq-fighter-card.is-selected{border-color:var(--fighter-accent);filter:brightness(1.08)}
    @media(hover:hover){.aq-fighter-card:hover{border-color:var(--fighter-accent);filter:brightness(1.08)}}
    .aq-fighter-card.is-selected{box-shadow:inset 3px 0 var(--fighter-accent)}
    .aq-fighter-card.is-locked{opacity:.62;filter:saturate(.45)}
    .aq-fighter-mark{display:grid;place-items:center;width:52px;height:52px;border:1px solid color-mix(in srgb,var(--fighter-accent) 48%,#46515d);background:#11171c;color:#f4f0e6;font:900 20px/1 "ApcKanit","Segoe UI",sans-serif;font-style:italic;overflow:hidden}
    .aq-fighter-mark img{width:100%;height:100%;object-fit:cover;object-position:center}
    .aq-fighter-name{display:block;margin-top:13px;font:900 15px/1 "ApcKanit","Segoe UI",sans-serif;font-style:italic;overflow-wrap:anywhere}
    .aq-fighter-state{display:block;margin-top:7px;color:var(--fighter-accent);font:800 9px/1 ui-monospace,monospace;letter-spacing:.08em}
    .aq-detail{align-self:start;position:sticky;top:18px;min-height:360px;padding:24px;border:1px solid #39424c;background:linear-gradient(180deg,#171d24,#0c1116);clip-path:polygon(12px 0,100% 0,100% calc(100% - 12px),calc(100% - 12px) 100%,0 100%,0 12px);}
    .aq-detail-mark{display:grid;place-items:center;width:112px;height:112px;border:1px solid var(--fighter-accent);background:radial-gradient(circle at center,color-mix(in srgb,var(--fighter-accent) 12%,transparent),#11171c 70%);color:#f4f0e6;font:900 32px/1 "ApcKanit","Segoe UI",sans-serif;font-style:italic;overflow:hidden}
    .aq-detail-mark img{width:100%;height:100%;object-fit:contain;object-position:center bottom}
    .aq-detail h2{margin:18px 0 0;font-size:clamp(24px,2.4vw,34px);line-height:.95;font-style:italic}
    .aq-detail p{margin:14px 0 0;color:#aab3bc;font:650 13px/1.55 "Segoe UI",sans-serif}
    .aq-detail-status{margin-top:20px;padding-top:14px;border-top:1px solid #2f3740;color:var(--fighter-accent);font:800 11px/1.2 ui-monospace,monospace;letter-spacing:.1em}
    .aq-detail-message{min-height:20px;margin-top:12px;color:#e7ca72;font:800 11px/1.35 ui-monospace,monospace}
    .aq-buy{width:100%;min-height:48px;margin-top:16px;border:1px solid #5a5541;background:linear-gradient(180deg,#4a4024,#282312);color:#f5e8bb;font:900 13px/1 "Segoe UI",sans-serif;cursor:pointer}
    .aq-buy:disabled{opacity:.38;cursor:default}
    .aq-draw-layout{display:grid;grid-template-columns:minmax(320px,1.25fr) minmax(280px,.75fr);gap:22px;padding-top:24px;align-items:center;min-height:calc(100dvh - 122px)}
    .aq-wheel-wrap{display:grid;place-items:center;min-height:0}
    .aq-wheel{position:relative;width:min(62vmin,610px);aspect-ratio:1;border-radius:50%;border:7px solid #5e5438;background:radial-gradient(circle at 50% 50%,#131920 0 31%,transparent 32%),conic-gradient(#493d22 0 12.5%,#182029 12.5% 25%,#5a4724 25% 37.5%,#151c24 37.5% 50%,#493d22 50% 62.5%,#182029 62.5% 75%,#5a4724 75% 87.5%,#151c24 87.5% 100%);box-shadow:0 24px 60px rgba(0,0,0,.38),inset 0 0 0 2px #17120a,inset 0 0 42px rgba(0,0,0,.55);transition:transform 4.2s cubic-bezier(.12,.74,.08,1);}
    .aq-wheel::before{content:"";position:absolute;left:50%;top:-22px;transform:translateX(-50%);width:0;height:0;border-left:13px solid transparent;border-right:13px solid transparent;border-top:0;border-bottom:26px solid #e0c877;filter:drop-shadow(0 2px 2px #000)}
    .aq-wheel-core{position:absolute;inset:31%;display:grid;place-items:center;border:1px solid #4b5560;border-radius:50%;background:#0c1116;text-align:center}
    .aq-wheel-core b{display:block;font-size:clamp(30px,5vmin,56px);line-height:.85;font-style:italic}
    .aq-wheel-core span{display:block;margin-top:8px;color:#9ba5ae;font:800 9px/1 ui-monospace,monospace;letter-spacing:.14em}
    .aq-wheel-label{position:absolute;left:50%;top:50%;width:94px;margin-left:-47px;margin-top:-8px;color:#d8d2c4;font:800 9px/1 ui-monospace,monospace;text-align:center;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;transform-origin:47px 8px}
    .aq-draw-side{padding:24px;border:1px solid #39424c;background:linear-gradient(180deg,#171d24,#0c1116)}
    .aq-draw-side h2{margin:0;font-size:clamp(26px,2.5vw,36px);line-height:.95;font-style:italic}
    .aq-draw-facts{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:18px}
    .aq-draw-fact{padding:10px;border:1px solid #303842;background:#0d1217}
    .aq-draw-fact span{display:block;color:#86919c;font:800 8px/1 ui-monospace,monospace;letter-spacing:.12em}
    .aq-draw-fact b{display:block;margin-top:5px;font-size:15px}
    .aq-draw-result{margin-top:18px;padding:16px;border:1px solid #4a4430;background:#13130e}
    .aq-draw-result strong{display:block;font-size:clamp(24px,2vw,32px);font-style:italic}
    .aq-draw-result span{display:block;margin-top:6px;color:#d7bd72;font:800 10px/1 ui-monospace,monospace;letter-spacing:.14em}
    .aq-draw-actions{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px}
    .aq-draw-actions button{min-height:42px;border:1px solid #434c56;background:#171d24;color:#f2eee5;font:800 11px/1 "Segoe UI",sans-serif;cursor:pointer}
    .aq-draw-actions button:first-child{border-color:#5a5541;background:#3d351f;color:#f2df9b}
    .aq-spin{width:100%;min-height:52px;margin-top:20px;border:1px solid #5a5541;background:linear-gradient(180deg,#4b4124,#282311);color:#f7e7ac;cursor:pointer;font:900 14px/1 "Segoe UI",sans-serif;letter-spacing:.08em}
    .aq-spin:disabled{opacity:.42;cursor:default}
    .aq-note{margin-top:12px;color:#87929c;font:650 12px/1.45 "Segoe UI",sans-serif}
    @media(min-width:1600px){
      .aq-ui{max-width:none;padding-left:clamp(42px,3.4vw,72px);padding-right:clamp(42px,3.4vw,72px)}
      .aq-hub-layout{grid-template-columns:clamp(320px,22vw,430px) minmax(0,1fr)}
      .aq-ident,.aq-hub-grid{min-height:calc(100dvh - 146px)}
      .aq-shop-grid{grid-template-columns:repeat(5,minmax(0,1fr))}
      .aq-action-title{font-size:clamp(28px,2vw,40px)}
    }
    @media(max-width:1240px){
      .aq-shop-grid{grid-template-columns:repeat(3,minmax(0,1fr))}
      .aq-hub-layout{grid-template-columns:minmax(230px,.65fr) minmax(0,1.35fr)}
    }
    @media(max-width:900px),(orientation:portrait){
      #aq-meta-root{overflow-y:auto}
      .aq-ui{min-height:100dvh;padding:16px}
      .aq-topbar{grid-template-columns:1fr}
      .aq-meta-stats{justify-content:flex-start}
      .aq-hub-layout,.aq-shop-layout,.aq-draw-layout{grid-template-columns:1fr}
      .aq-ident{min-height:auto;grid-template-columns:96px 1fr;grid-template-rows:auto auto auto;column-gap:16px;padding:16px}
      .aq-ident-label{grid-column:1/-1}
      .aq-plate{grid-row:2/4;width:92px;margin:0}
      .aq-sel,.aq-tag{text-align:left}
      .aq-primary-btn{grid-column:1/-1;margin-top:8px}
      .aq-hub-grid{min-height:auto;grid-auto-rows:minmax(156px,auto)}
      .aq-shop-grid{grid-template-columns:repeat(2,minmax(0,1fr));max-height:none}
      .aq-detail{position:relative;top:auto}
      .aq-draw-layout{min-height:auto}
      .aq-wheel{width:min(82vw,520px)}
    }
    @media(max-width:600px){
      .aq-ui{padding:12px 10px max(18px,env(safe-area-inset-bottom))}
      .aq-title{font-size:clamp(22px,8vw,32px)}
      .aq-brand{gap:9px}
      .aq-back,.aq-exit{width:44px;height:44px}
      .aq-hub-grid{grid-template-columns:1fr;gap:10px}
      .aq-hub-grid .aq-action{padding:18px}
      .aq-action-title{font-size:clamp(22px,7vw,30px)}
      .aq-action-desc{font-size:12px}
      .aq-shop-grid{grid-template-columns:1fr}
      .aq-fighter-card{min-height:110px}
      .aq-meta-stats{display:grid;grid-template-columns:1fr 1fr;width:100%}
      .aq-stat{min-width:0}
      .aq-draw-facts{grid-template-columns:1fr}
      .aq-draw-actions{grid-template-columns:1fr}
      .aq-wheel{width:min(90vw,440px)}
    }
    @media(max-height:650px) and (min-width:901px){
      .aq-ui{padding-top:12px;padding-bottom:14px}
      .aq-ident,.aq-hub-grid{min-height:calc(100dvh - 104px)}
      .aq-hub-grid{grid-auto-rows:minmax(150px,1fr)}
      .aq-hub-grid .aq-action{padding:18px}
      .aq-plate{width:min(68%,220px);margin:10px 0}
      .aq-shop-grid{max-height:calc(100dvh - 112px)}
      .aq-draw-layout{min-height:calc(100dvh - 90px)}
      .aq-wheel{width:min(56vmin,520px)}
    }
  `;

  function host() {
    return document.body;
  }
  function shell(inner) {
    return `<div id="aq-meta-stage"><img class="aq-bg" alt="" src="${PICK_ASSETS}01-select-screen-background.webp"/><div class="aq-veil"></div>${inner}</div><style>${META_CSS}</style>`;
  }
  function ensureRoot() {
    let el = document.getElementById('aq-meta-root');
    if (el) return el;
    el = document.createElement('div');
    el.id = 'aq-meta-root';
    host().appendChild(el);
    return el;
  }
  function hideMeta() {
    cancelDrawSpinAnimation();
    const el = document.getElementById('aq-meta-root');
    if (el) el.style.display = 'none';
  }
  function requestGoldNavigation(target, options) {
    const nav = window.APEX_GOLD_SHELL_NAVIGATE;
    if (typeof nav === 'function') return nav(target, options || {}) !== false;
    window.__apexPendingGoldNavigation = { target, options: options || {} };
    return false;
  }
  function returnToProductMenu() {
    hideMeta();
    requestGoldNavigation('home');
    try { window.dispatchEvent(new CustomEvent('apex:product-menu')); } catch (error) {}
  }
  function paintShop(selectedName) {
    cancelDrawSpinAnimation();
    const el = ensureRoot();
    const ids = ROSTER();
    shopSelected = String(selectedName || state.lastSelectedP1 || shopSelected || 'ROBOT').toUpperCase();
    if (!ids.includes(shopSelected)) shopSelected = 'ROBOT';
    const selected = fighterInfo(shopSelected);
    const selectedAvailable = isProductPlayable(shopSelected);
    const selectedOwned = selectedAvailable && owns(shopSelected);
    const cards = ids.map((n) => {
      const available = isProductPlayable(n);
      const owned = available && owns(n);
      const info = fighterInfo(n);
      const label = !available ? 'LOCKED' : owned ? 'OWNED' : '1000 AC';
      return `<button type="button" data-shop-card="${esc(n)}" class="aq-fighter-card ${owned ? '' : 'is-locked'} ${n === shopSelected ? 'is-selected' : ''}" style="--fighter-accent:${esc(info.color)}"><span class="aq-fighter-mark">${info.icon ? `<img src="${esc(info.icon)}" alt=""/>` : esc(info.mark)}</span><span class="aq-fighter-name">${esc(info.label)}</span><span class="aq-fighter-state">${label}</span></button>`;
    }).join('');
    el.style.display = 'block';
    el.innerHTML = shell(`
      <main class="aq-ui">
        <header class="aq-topbar">
          <div class="aq-brand"><button class="aq-back" id="aq-shop-back" type="button" aria-label="Back to Home">←</button><div class="aq-brand-copy"><div class="aq-kicker">ARSENAL · ROSTER</div><h1 class="aq-title">FIGHTER SHOP</h1></div></div>
          <div class="aq-meta-stats"><div class="aq-stat"><span>ARSENAL CREDITS</span><b>${state.credits} AC</b></div></div>
        </header>
        <section class="aq-shop-layout">
          <div class="aq-shop-grid" role="listbox" aria-label="Fighter roster">${cards}</div>
          <aside class="aq-detail" id="aq-shop-detail" style="--fighter-accent:${esc(selected.color)}">
            <div class="aq-detail-mark">${selected.standing ? `<img src="${esc(selected.standing)}" alt=""/>` : esc(selected.mark)}</div>
            <div class="aq-kicker" style="margin-top:18px">FIGHTER PROFILE</div>
            <h2>${esc(selected.label)}</h2>
            <p>${esc(selected.desc)}</p>
            <div class="aq-detail-status">${!selectedAvailable ? 'LOCKED' : selectedOwned ? 'OWNED' : 'LOCKED · 1000 AC'}</div>
            <div id="aq-shop-message" class="aq-detail-message"></div>
            <button id="aq-buy" class="aq-buy" type="button" ${(!selectedAvailable || selectedOwned) ? 'disabled' : ''}>${!selectedAvailable ? 'LOCKED' : selectedOwned ? 'OWNED' : 'UNLOCK · 1000 AC'}</button>
          </aside>
        </section>
      </main>`);
    el.querySelector('#aq-shop-back').onclick = returnToProductMenu;
    el.querySelectorAll('[data-shop-card]').forEach((b) => {
      b.onclick = () => paintShop(b.getAttribute('data-shop-card'));
    });
    const buyBtn = el.querySelector('#aq-buy');
    if (buyBtn && !buyBtn.disabled) {
      buyBtn.onclick = () => {
        const r = buy(shopSelected);
        const msg = el.querySelector('#aq-shop-message');
        if (!r.ok) {
          msg.textContent = r.reason === 'need' ? `NEED ${r.need} AC` : String(r.reason).toUpperCase();
          return;
        }
        paintShop(shopSelected);
        const nextMsg = ensureRoot().querySelector('#aq-shop-message');
        if (nextMsg) nextMsg.textContent = `${displayNameFor(shopSelected)} UNLOCKED`;
      };
    }
    wireGridNav(el.querySelector('.aq-shop-grid'), '[data-shop-card]', window.innerWidth < 860 ? 2 : 4);
    el.addEventListener('keydown', (e) => { if (e.key === 'Escape') returnToProductMenu(); }, { once: true });
  }
  function paintDraw() {
    const el = ensureRoot();
    const locked = poolLocked();
    const labels = locked.slice(0, 12).map((n, i, arr) => {
      const a = (360 / Math.max(1, arr.length)) * i;
      return `<span class="aq-wheel-label" style="transform:rotate(${a}deg) translateY(max(-25vmin,-245px)) rotate(${-a}deg)">${esc(displayNameFor(n))}</span>`;
    }).join('');
    const result = lastDrawResult
      ? `<div class="aq-draw-result"><strong>${esc(displayNameFor(lastDrawResult.name))}</strong><span>UNLOCKED</span><div class="aq-draw-actions"><button id="aq-use-now" type="button">USE NOW</button><button id="aq-spin-again" type="button">SPIN AGAIN</button></div></div>`
      : '';
    el.style.display = 'block';
    el.innerHTML = shell(`
      <main class="aq-ui">
        <header class="aq-topbar">
          <div class="aq-brand"><button class="aq-back" id="aq-draw-back" type="button" aria-label="Back to Home">←</button><div class="aq-brand-copy"><div class="aq-kicker">ARSENAL · UNLOCK</div><h1 class="aq-title">LUCKY DRAW</h1></div></div>
          <div class="aq-meta-stats"><div class="aq-stat"><span>ARSENAL CREDITS</span><b>${state.credits} AC</b></div></div>
        </header>
        <section class="aq-draw-layout">
          <div class="aq-wheel-wrap">
            <div id="aq-wheel" class="aq-wheel">${labels}<div class="aq-wheel-core"><div><b>${locked.length}</b><span>LOCKED</span></div></div></div>
          </div>
          <aside class="aq-draw-side">
            <div class="aq-kicker">NO DUPLICATES</div><h2>ONE NEW FIGHTER</h2>
            <div class="aq-draw-facts"><div class="aq-draw-fact"><span>COST</span><b>${DRAW_COST} AC</b></div><div class="aq-draw-fact"><span>POOL</span><b>${locked.length} LEFT</b></div></div>
            <p class="aq-note">The draw only contains fighters you do not own. When the pool is empty, the roster is complete.</p>
            <button id="aq-spin" class="aq-spin" type="button" ${(!locked.length || drawBusy) ? 'disabled' : ''}>${!locked.length ? 'ROSTER COMPLETE' : drawBusy ? 'SPINNING…' : `SPIN · ${DRAW_COST} AC`}</button>
            <div id="aq-draw-message" class="aq-detail-message"></div>
            ${result}
          </aside>
        </section>
      </main>`);
    el.querySelector('#aq-draw-back').onclick = () => { if (!drawBusy) { lastDrawResult = null; returnToProductMenu(); } };
    const spinBtn = el.querySelector('#aq-spin');
    if (spinBtn && !spinBtn.disabled) {
      spinBtn.onclick = () => {
        const before = locked.slice();
        const r = spin();
        const out = el.querySelector('#aq-draw-message');
        if (!r.ok) {
          out.textContent = r.reason === 'need' ? `NEED ${r.need} AC` : (r.reason === 'complete' ? 'ROSTER COMPLETE' : String(r.reason).toUpperCase());
          return;
        }
        drawBusy = true;
        lastDrawResult = null;
        spinBtn.disabled = true;
        spinBtn.textContent = 'SPINNING…';
        const wheel = el.querySelector('#aq-wheel');
        const idx = Math.max(0, before.indexOf(r.name));
        const stop = 360 * 5 + (360 - (idx * (360 / Math.max(1, before.length))));
        wheel.style.transform = `rotate(${stop}deg)`;
        const spinToken = ++drawSpinToken;
        drawTimer = window.setTimeout(() => {
          drawTimer = 0;
          if (spinToken !== drawSpinToken) return;
          drawBusy = false;
          lastDrawResult = r;
          paintDraw();
        }, 4200);
      };
    }
    el.querySelector('#aq-use-now')?.addEventListener('click', () => {
      if (!lastDrawResult) return;
      setLast(lastDrawResult.name, state.lastSelectedP2);
      lastDrawResult = null;
      openFreePick();
    });
    el.querySelector('#aq-spin-again')?.addEventListener('click', () => {
      lastDrawResult = null;
      paintDraw();
      ensureRoot().querySelector('#aq-spin')?.focus();
    });
    el.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !drawBusy) returnToProductMenu(); }, { once: true });
  }
  function openFighterPick(opts) {
    const requested = String((opts && opts.mode) || 'local').toLowerCase();
    const mode = requested === 'bot' ? 'bot' : 'local';
    window.__apexArsenalSelectionMode = mode;
    window.__apexArsenalBotBattle = mode === 'bot';
    window.__apexArsenalFreeBattle = mode === 'local';
    window.__apexArsenalSelectPending = true;
    hideMeta();
    // Fighter Pick is a Gold shell surface, not a deferred legacy runtime.
    // Real battle runtimes remain lazy until the Gold transition asks for them.
    requestGoldNavigation('fighter', { mode });
    return true;
  }
  function openFreePick() { openFighterPick({ mode: 'local' }); }
  function openBotPick() { openFighterPick({ mode: 'bot' }); }


  window.APEX_ARSENAL_META = {
    KEY, SHOP_COST, DRAW_COST, START_CREDITS,
    getState, credits, owns, canPublicSelect, buy, spin, award, awardBattleResult, progressionCatalog, claimProgressReward, filterOwned, setLast,
    getMastery: cloneMastery, masteryCatalog, heroMasteryProgress, recordMasteryUnlocks, recordMasteryProvisional,
    skinEntitlement, skinProgress, markSkinUnlockSeen, MASTERY_SKIN_GATES,
    masteryResultHeroId: resultHeroId, masteryEngineHeroId: engineHeroId,
    // A1: legacy owner-playtest exports retained for compat; the live rule
    // is the Admin-authority test session (selection only — Lucky Draw, Shop
    // and ownership keep reading production truth).
    MATCH_REWARDS,
    adminTestSessionActive, adminTestSelectionUnlocked,
    ownerPlaytestSelectionUnlocked,
    OWNER_PLAYTEST_CORE_SIX_UNLOCK,
    OWNER_PLAYTEST_CORE_SIX_UNLOCK_REVISION,
    OWNER_PLAYTEST_AC_SEED,
    OWNER_PLAYTEST_AC_SEED_REVISION,
    OWNER_PLAYTEST_REVISION,
    applyOwnerPlaytestAcSeed,
    palette, setPalette,
    load, save, emptyState, sanitize, poolLocked,
    visibleRoster: ROSTER, playableRoster: PLAYABLE_ROSTER,
    isProductVisible, isProductPlayable, displayNameFor,
    lastAward: () => lastAward,
    returnToProductMenu, hideMeta, paintShop, paintDraw, openFreePick, openBotPick, openFighterPick,
  };
  window.apexArsenalMetaRuntime = 'ready';
})();
