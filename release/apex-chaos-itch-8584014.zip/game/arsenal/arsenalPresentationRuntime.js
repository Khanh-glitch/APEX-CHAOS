// ARSENAL BATTLE — curated VFX/SFX presentation layer.
// ISOLATED presentation: no gameplay logic lives here. The weapon/spawn runtimes
// emit semantic cues through avCue(); this runtime turns them into preloaded
// image animations and bounded WebAudio playback on the EXISTING Apex audio
// graph (audioCtx / battleAudioMaster). No second engine, no engine fork.
(function apexArsenalPresentationRuntime() {
  if (window.apexArsenalPresentationRuntime === 'ready') return;
  const AQ = window.APEX_ARSENAL;
  const AV_ROOT = '../assets/arsenal/av/';
  const WEAPON_ROOT = '../assets/arsenal/weapons/';
  // Checkpoint C: per-weapon authored set (generated manifest) replaces the
  // Checkpoint A/B collage atlas. Senko-reprocessed gun family + bespoke
  // melee/shield/grenade/casing, all in one flat-fill/outline language.
  const C_SET = window.APEX_ARSENAL_C_SET || { weapons: {}, muzzleFrames: [] };
  // Original owner V4.3 equipment silhouettes (WebP, alpha intact).
  // Dimensions describe the actual uploaded images; shared sprite transform,
  // pose/ghost/pickup pipeline is unchanged.
  const V43_META={
    FLARE_GUN:{w:768,h:422},TACTICAL_CROSSBOW:{w:768,h:294},
    STEEL_BALL_LAUNCHER:{w:768,h:387},COMBAT_BOOMERANG:{w:768,h:409},
    RPG_7:{w:768,h:247},FLAMETHROWER:{w:768,h:324},
    PLASMA_SPLITTER:{w:768,h:300},SHRAPNEL_MINE_LAUNCHER:{w:768,h:341}
  };
  for(const [id,meta] of Object.entries(V43_META))meta.file='v43/'+id+'.webp';
  function weaponMeta(id) { return C_SET.weapons[id] || V43_META[id] || null; }
  function weaponAbs(meta) { return '../assets/arsenal/' + meta.file; }
  const MUZZLE_FRAMES = C_SET.muzzleFrames || []; // [{ file, w, h }] warm family
  const muzzleAbs = (f) => AV_ROOT + f.file;

  // ---------------------------------------------------------------------------
  // Asset tables — Checkpoint C bindings (AV_ASSET_MAP superseded for weapons).
  // POST-C §1 VFX transparency: smoke/spark are served from the BUILD-SANITIZED
  // copies under vfx/c/ (alpha keyed in tools/buildArsenalCAssets.mjs); the raw
  // kenney sources are 100%-opaque black-matte PNGs and must never be drawn
  // directly. The explosion atlas already carries real alpha.
  // ---------------------------------------------------------------------------
  const SMOKE = (n) => `vfx/c/smoke_${n}.webp`;
  const SPARK = (n) => `vfx/c/spark_${n}.webp`;
  const ATLAS = { file: 'vfx/explosion_pack_2/half/1.webp', cell: 256, frames: 64 };

  // Trim windows measured from the source envelopes (onset analysis):
  // cz shot @0.14s, sks repeated shots from 0.34s, mosin crack @0.43s.
  const AUDIO = {
    telegraph: [{ rel: 'sfx/scifi/forceField_001.ogg', vol: 0.18, maxVoices: 2 }],
    reveal: [
      { rel: 'sfx/rpg/metalClick.ogg', vol: 0.35, maxVoices: 3 },
      { rel: 'sfx/impact/impactGeneric_light_002.ogg', vol: 0.12, maxVoices: 3 },
    ],
    pickup: [{ rel: 'sfx/rpg/metalLatch.ogg', vol: 0.42, maxVoices: 3 }],
    pickup_pistol: [{ rel: 'sfx/feel/pickup_pistol.mp3', vol: 0.62, maxVoices: 2 }],
    pickup_smg_mac10: [{ rel: 'sfx/feel/rifle_take_05.mp3', vol: 0.58, maxVoices: 2 }],
    pickup_smg_mp5: [{ rel: 'sfx/feel/rifle_take_02.mp3', vol: 0.58, maxVoices: 2 }],
    pickup_smg_p90: [{ rel: 'sfx/feel/rifle_take_09.mp3', vol: 0.58, maxVoices: 2 }],
    pickup_rifle_ak: [{ rel: 'sfx/feel/rifle_take_01.mp3', vol: 0.62, maxVoices: 2 }],
    pickup_rifle_m16: [{ rel: 'sfx/feel/rifle_take_03.mp3', vol: 0.62, maxVoices: 2 }],
    pickup_rifle_z15: [{ rel: 'sfx/feel/rifle_take_04.mp3', vol: 0.62, maxVoices: 2 }],
    pickup_rifle_mbr: [{ rel: 'sfx/feel/rifle_take_07.mp3', vol: 0.68, maxVoices: 2 }],
    pickup_rifle_mbr2: [{ rel: 'sfx/feel/rifle_take_08.mp3', vol: 0.68, maxVoices: 2 }],
    pickup_rifle_m249: [{ rel: 'sfx/feel/rifle_take_10.mp3', vol: 0.70, maxVoices: 2 }],
    pickup_rifle_szecsei: [{ rel: 'sfx/feel/rifle_take_11.mp3', vol: 0.68, maxVoices: 2 }],
    pickup_shotgun: [{ rel: 'sfx/feel/pickup_shotgun.mp3', vol: 0.72, maxVoices: 2 }],
    pickup_sniper: [{ rel: 'sfx/feel/pickup_sniper.mp3', vol: 0.63, maxVoices: 1 }],
    pickup_sniper_lock: [{ rel: 'sfx/c-final/SNIPER/sniper_bolt_lock.mp3', vol: 0.42, maxVoices: 1 }],

    // Approved gun-fire baseline retained.
    pistol_shot: [{ rel: 'sfx/guns/cz.mp3', offset: 0.10, dur: 0.85, vol: 0.75, maxVoices: 4, fadeTail: 0.075, attack: 0.003 }],
    smg_shot: [{ rel: 'sfx/guns/sks.mp3', slices: [0.32, 2.27, 3.31, 5.98, 7.25, 9.69, 11.43, 12.70], dur: 0.24, vol: 0.5, maxVoices: 3, fadeTail: 0.035, attack: 0.002 }],
    shotgun_shot: [{ rel: 'sfx/guns/shotty.mp3', offset: 0.0, dur: 0.7, vol: 0.95, maxVoices: 2, fadeTail: 0.125, attack: 0.003 }],
    sniper_shot: [{ rel: 'sfx/guns/mosin.mp3', offset: 0.40, dur: 1.7, vol: 0.95, maxVoices: 2, fadeTail: 0.18, attack: 0.004 }],

    // Owner-approved C1 FINAL SFX LOCK.
    pistol_mech: [{ rel: 'sfx/c-final/PISTOL/pistol_mech_click.mp3', vol: 0.50, maxVoices: 2 }],
    shotgun_rack_pull: [{ rel: 'sfx/c-final/SHOTGUN/shotgun_rack_pull.mp3', vol: 0.71, maxVoices: 2 }],
    shotgun_rack_push: [{ rel: 'sfx/c-final/SHOTGUN/shotgun_rack_push.mp3', vol: 0.71, maxVoices: 2 }],
    sniper_chamber: [{ rel: 'sfx/c-final/SNIPER/sniper_chamber.mp3', vol: 0.63, maxVoices: 1 }],
    sniper_bolt_lock: [{ rel: 'sfx/c-final/SNIPER/sniper_bolt_lock.mp3', vol: 0.50, maxVoices: 1 }],

    axe_swing: [{ rel: 'sfx/c-final/BATTLE_AXE/axe_motion.mp3', vol: 0.63, maxVoices: 2 }],
    axe_hit: [
      { rel: 'sfx/c-final/BATTLE_AXE/axe_contact.mp3', vol: 1.00, maxVoices: 3 },
      { rel: 'sfx/c-final/BATTLE_AXE/axe_body.mp3', vol: 0.40, maxVoices: 3 },
    ],
    club_swing: [{ rel: 'sfx/c-final/SPIKED_CLUB/club_swing.mp3', vol: 0.79, maxVoices: 2 }],
    club_hit: [{ rel: 'sfx/c-final/SPIKED_CLUB/club_body.mp3', vol: 1.00, maxVoices: 3 }],
    dagger_swing: [{ rel: 'sfx/c-final/DAGGER/dagger_motion.mp3', vol: 0.71, maxVoices: 3 }],
    dagger_hit: [{ rel: 'sfx/c-final/DAGGER/dagger_contact.mp3', vol: 0.71, maxVoices: 3 }],
    sabre_swing: [{ rel: 'sfx/c-final/SABRE/sabre_motion.mp3', vol: 0.63, maxVoices: 3 }],
    sabre_hit: [{ rel: 'sfx/c-final/SABRE/sabre_cut.mp3', vol: 1.00, maxVoices: 3 }],
    spear_swing: [{ rel: 'sfx/c-final/SPEAR/spear_motion.mp3', vol: 0.56, maxVoices: 3 }],
    spear_hit: [{ rel: 'sfx/c-final/SPEAR/spear_impact.mp3', vol: 1.00, maxVoices: 3 }],
    swirl_block: [{ rel: 'sfx/c-final/SWIRL_SHIELD/swirl_shield_block.mp3', vol: 1.00, maxVoices: 3 }],
    tower_block: [{ rel: 'sfx/c-final/TOWER_SHIELD/tower_shield_block.mp3', vol: 1.00, maxVoices: 3 }],
    explosion: [
      { rel: 'sfx/c-final/GRENADE/grenade_core.mp3', vol: 1.00, maxVoices: 2 },
      { rel: 'sfx/c-final/GRENADE/grenade_low.mp3', vol: 0.40, maxVoices: 2 },
    ],
    casing_land: [{ rel: 'sfx/feel/casing_01.mp3', vol: 0.22, maxVoices: 4 }],
    shotgun_shell_land: [{ rel: 'sfx/feel/shell_01.mp3', vol: 0.26, maxVoices: 3 }],

    // Shared presentation: reuse the approved baseline files only.
    ricochet: [{ rel: 'sfx/impact/impactPlate_light_001.ogg', vol: 0.34, maxVoices: 3 }],

    // STORMBREAKER (red tier) — approved baseline files only, no new sourcing:
    // charge = the existing force-field bed, release = the heavy axe whoosh,
    // impact = the heavy axe contact pair (divine-weapon body strike).
    storm_windup: [{ rel: 'sfx/scifi/forceField_001.ogg', vol: 0.30, maxVoices: 1 }],
  };

  const PISTOL_READY = { PISTOL: 1, GLOCK_17: 1, TEC_9: 1, BERETTA_93R: 1, DESERT_DEAGLE: 1, MAGNUM_500: 1 };
  const SHOTGUN_READY = { SHOTGUN: 1, MOSSBERG_500: 1, SAWED_OFF: 1, JACKHAMMER: 1 };
  const GUN_READY = {
    PISTOL: 'pickup_pistol', GLOCK_17: 'pickup_pistol', TEC_9: 'pickup_pistol',
    BERETTA_93R: 'pickup_pistol', DESERT_DEAGLE: 'pickup_pistol', MAGNUM_500: 'pickup_pistol',
    MAC_10: 'pickup_smg_mac10', SMG: 'pickup_smg_mp5', P90: 'pickup_smg_p90',
    AK_47: 'pickup_rifle_ak', M16: 'pickup_rifle_m16',
    ZBROYAR_Z15: 'pickup_rifle_z15', ZBROYAR_Z15_S1: 'pickup_rifle_z15',
    ZBROYAR_Z15_S2: 'pickup_rifle_z15', ZBROYAR_Z15_S3: 'pickup_rifle_z15',
    MBR: 'pickup_rifle_mbr', MBR2: 'pickup_rifle_mbr2', M249_SAW: 'pickup_rifle_m249',
    SZECSEI_FUCHS: 'pickup_rifle_szecsei',
    SHOTGUN: 'pickup_shotgun', MOSSBERG_500: 'pickup_shotgun', SAWED_OFF: 'pickup_shotgun', JACKHAMMER: 'pickup_shotgun',
    SNIPER: 'pickup_sniper',
  };
  const CASING_VARS = [
    { rel: 'sfx/feel/casing_01.mp3', vol: 0.22, maxVoices: 4 },
    { rel: 'sfx/feel/casing_02.mp3', vol: 0.22, maxVoices: 4 },
    { rel: 'sfx/feel/casing_03.mp3', vol: 0.20, maxVoices: 4 },
    { rel: 'sfx/feel/casing_04.mp3', vol: 0.20, maxVoices: 4 },
    { rel: 'sfx/feel/casing_05.mp3', vol: 0.20, maxVoices: 4 },
  ];
  const SHELL_VARS = [
    { rel: 'sfx/feel/shell_01.mp3', vol: 0.26, maxVoices: 3 },
    { rel: 'sfx/feel/shell_02.mp3', vol: 0.24, maxVoices: 3 },
    { rel: 'sfx/feel/shell_03.mp3', vol: 0.24, maxVoices: 3 },
  ];
  let casingCursor = 0;
  let shellCursor = 0;
  const GUN_IDS = Object.assign({}, PISTOL_READY, SHOTGUN_READY, {
    MAC_10: 1, SMG: 1, P90: 1, AK_47: 1, M16: 1, ZBROYAR_Z15: 1, ZBROYAR_Z15_S1: 1,
    ZBROYAR_Z15_S2: 1, ZBROYAR_Z15_S3: 1, MBR: 1, MBR2: 1, M249_SAW: 1, SZECSEI_FUCHS: 1, SNIPER: 1,
  });

  // Checkpoint C melee contact language: weapon-specific impact transients
  // (spark/shock), never imported slash sheets. The weapon body's own motion
  // carries the swing; contact reads through these small bounded transients.
  const MELEE_CONTACT = {
    SABRE: { spark: SPARK('05'), count: 6, speed: 420, life: 0.16, tint: '#dfe9f2' },
    BATTLE_AXE: { spark: SPARK('07'), count: 10, speed: 300, life: 0.24, tint: '#ffcf7a' },
    SPEAR: { spark: SPARK('05'), count: 5, speed: 520, life: 0.14, tint: '#e8f4d8' },
    SPIKED_CLUB: { spark: SPARK('07'), count: 8, speed: 260, life: 0.22, tint: '#e6c9ff' },
    DAGGER: { spark: SPARK('05'), count: 5, speed: 460, life: 0.12, tint: '#eef6ff' },
  };

  // ---------------------------------------------------------------------------
  // Cache / stats plumbing.
  // ---------------------------------------------------------------------------
  const imageCache = new Map();
  const audioBuffers = new Map();
  const audioLoading = new Set();
  const audioFailed = new Set();
  const activeVoices = new Map();
  const vfx = [];
  const VFX_CAP = 240;
  let smgSliceCursor = 0;

  const stats = {
    cued: [],          // ring of {event, ...opts-lite} for runtime logs/tests
    scheduled: [],     // ring of every intended audio playback (even if skipped)
    throttled: {},     // per-reason throttle counters
    played: 0,
    imagesLoaded: 0,
    imagesFailed: 0,
    audioLoaded: 0,
    audioFailed: 0,
    decodeCalls: 0, // total decodeAudioData invocations (warmup only — a
                    // trigger-time increase means a latency regression)
    lastVoice: null, // {rel, vol, offset, dur, viaBufferSource} of last sound
    vfxPeak: 0,
    vfxDropped: 0,
    seqAnimsPushed: 0,
    floorSpriteDraws: 0,
    equippedSpriteDraws: 0,
  };
  function pushRing(ring, entry, cap = 600) {
    ring.push(entry);
    if (ring.length > cap) ring.splice(0, ring.length - cap);
  }
  function avLog(event, fields) {
    const line = fields ? `[AQ-AV] ${event} ${fields}` : `[AQ-AV] ${event}`;
    console.log(line);
    if (AQ && AQ.events) { AQ.events.push(line); if (AQ.events.length > 160) AQ.events.splice(0, AQ.events.length - 160); }
    return line;
  }

  // ---------------------------------------------------------------------------
  // Preload — once per mode entry, never per frame / per shot.
  // ---------------------------------------------------------------------------
  function getImg(rel) {
    let img = imageCache.get(rel);
    if (!img) {
      img = new Image();
      img.onload = () => { stats.imagesLoaded += 1; };
      img.onerror = () => { stats.imagesFailed += 1; avLog('IMG_FAIL', `file=${rel}`); };
      img.src = (rel.startsWith('/') || rel.startsWith('../')) ? rel : AV_ROOT + rel;
      imageCache.set(rel, img);
    }
    return img;
  }
  function audioCtxOf() { return typeof audioCtx !== 'undefined' ? audioCtx : null; }
  const audioPromises = new Map();
  function loadAudio(rel) {
    if (audioPromises.has(rel)) return audioPromises.get(rel);
    if (audioFailed.has(rel)) return Promise.resolve(false);
    const ctx = audioCtxOf();
    if (!ctx || typeof fetch !== 'function' || !ctx.decodeAudioData) return Promise.resolve(false);
    if (!stats.warmStartedAt) stats.warmStartedAt = (typeof performance !== 'undefined' ? performance.now() : Date.now());
    stats.decodeCalls += 1;
    const promise = fetch((rel.startsWith('/') || rel.startsWith('../')) ? rel : AV_ROOT + rel)
      .then((res) => res.arrayBuffer())
      .then((buf) => new Promise((resolve, reject) => {
        // Support both promise-form and callback-form decodeAudioData
        // (older Safari and test harness stubs use either).
        let settled = false;
        const ok = (d) => { if (!settled) { settled = true; resolve(d); } };
        const fail = (e) => { if (!settled) { settled = true; reject(e); } };
        try {
          const maybePromise = ctx.decodeAudioData(buf, ok, fail);
          if (maybePromise && typeof maybePromise.then === 'function') maybePromise.then(ok, fail);
        } catch (error) {
          fail(error);
        }
      }))
      .then((decoded) => { audioBuffers.set(rel, decoded); stats.audioLoaded += 1; return true; })
      .catch(() => { audioFailed.add(rel); stats.audioFailed += 1; avLog('SFX_FAIL', `file=${rel}`); return false; })
      .finally(() => { if (audioBuffers.size + audioFailed.size >= ALL_AUDIO.length) stats.warmDecodedAt = (typeof performance !== 'undefined' ? performance.now() : Date.now()); });
    audioPromises.set(rel, promise);
    return promise;
  }

  const ALL_IMAGES = [
    ...Object.values(C_SET.weapons).map((m) => weaponAbs(m)),
    ...Object.values(V43_META).map((m) => weaponAbs(m)),
    '../assets/arsenal/v43/BOLT.webp','../assets/arsenal/v43/STEEL_BALL.webp',
    '../assets/arsenal/v43/RPG_ROCKET.webp','../assets/arsenal/v43/SHRAPNEL_MINE.webp',
    ...MUZZLE_FRAMES.map((f) => muzzleAbs(f)),
    ATLAS.file,
    SMOKE('01'), SMOKE('03'), SPARK('05'), SPARK('07'),
  ];
  const ALL_AUDIO = Array.from(new Set([
    ...(AUDIO ? Object.values(AUDIO).flat().map((a) => a.rel) : []),
    ...CASING_VARS.map((a) => a.rel),
    ...SHELL_VARS.map((a) => a.rel),
    // POST-PLAYTEST 2026-09-29: Hunter owner SFX (hash-verified material).
    '../assets/hero-rework/hunter-v10/sfx/hunter_a1_charge_personal.mp3',
    '../assets/hero-rework/hunter-v10/sfx/hunter_a1_deploy_mechanism.mp3',
    '../assets/hero-rework/hunter-v10/sfx/hunter_a1_unfold_blade.mp3',
    '../assets/hero-rework/hunter-v10/sfx/hunter_a1_clamp.mp3',
    '../assets/hero-rework/hunter-v10/sfx/hunter_a2_pounce_sweep.mp3',
    '../assets/hero-rework/hunter-v10/sfx/hunter_a2_catch_flesh.mp3',
  ]));

  function preload(opts) {
    const noImages = !!(opts && opts.images === false);
    const noAudio = !!(opts && opts.audio === false);
    if (!noImages) for (const rel of ALL_IMAGES) getImg(rel);
    if (!noAudio) for (const rel of ALL_AUDIO) loadAudio(rel);
  }
  // CP7 (owner playtest round 4): the combat shell used to mount while this
  // runtime's async init (image fetch/decode) was still at zero — the arena
  // looked broken until loading finished. These readiness probes back the
  // gameplay-ready barrier in arsenalConfig.js.
  function imagesTotal() { return ALL_IMAGES.length; }
  function imagesSettled() { return stats.imagesLoaded + stats.imagesFailed >= ALL_IMAGES.length; }
  function whenImagesReady(timeoutMs = 8000) {
    return new Promise((resolve) => {
      const startedAt = Date.now();
      const poll = () => {
        if (imagesSettled() || Date.now() - startedAt > timeoutMs) resolve(imagesSettled());
        else setTimeout(poll, 50);
      };
      poll();
    });
  }
  // Audio 2B: promise form — resolves once every HOT-bank clip has decoded
  // (or failed). Idempotent; used by warmup integration and browser gates.
  function warmAudio() {
    preload();
    return Promise.all(ALL_AUDIO.map((rel) => loadAudio(rel)));
  }
  function audioStatus() {
    let pcmBytes = 0;
    for (const b of audioBuffers.values()) {
      pcmBytes += (b.length || 0) * (b.numberOfChannels || 1) * 4;
    }
    return {
      bankSize: ALL_AUDIO.length,
      decoded: audioBuffers.size,
      failed: audioFailed.size,
      pending: Math.max(0, ALL_AUDIO.length - audioBuffers.size - audioFailed.size),
      decodeCalls: stats.decodeCalls,
      played: stats.played,
      notReadyThrottles: stats.throttled.notReady || 0,
      pcmBytes,
      warmStartedAt: stats.warmStartedAt || null,
      warmDecodedAt: stats.warmDecodedAt || null,
      warmMs: (stats.warmStartedAt && stats.warmDecodedAt) ? stats.warmDecodedAt - stats.warmStartedAt : null,
      lastVoice: stats.lastVoice,
    };
  }
  function clear() {
    vfx.length = 0;
    resetAudioSession();
  }

  // ---------------------------------------------------------------------------
  // Audio session lifecycle (owner correction pass): every AudioBufferSourceNode
  // this runtime starts and every raw setTimeout it schedules (playLater cues,
  // voice-count releases) is tracked so a session reset can TERMINATE sound
  // for real — stop()+disconnect live sources, cancel pending cues. Decoded
  // AudioBuffers (the HOT bank) are never cleared: the cache stays warm across
  // sessions; only playback state resets.
  // ---------------------------------------------------------------------------
  const liveSources = new Set();
  const pendingTimers = new Set();
  function trackTimer(id) {
    if (id == null) return id;
    pendingTimers.add(id);
    return id;
  }
  function untrackTimer(id) {
    pendingTimers.delete(id);
  }
  function resetAudioSession() {
    for (const id of Array.from(pendingTimers)) {
      pendingTimers.delete(id);
      if (typeof clearTimeout === 'function') { try { clearTimeout(id); } catch (e) {} }
    }
    for (const src of Array.from(liveSources)) {
      liveSources.delete(src);
      try { src.onended = null; } catch (e) {}
      try { src.stop(); } catch (e) {} // already-ended sources throw — fine
      try { src.disconnect(); } catch (e) {}
    }
    activeVoices.clear();
    smgSliceCursor = 0; // per-session slice cursor
  }
  function audioSessionProbe() {
    let voices = 0;
    for (const v of activeVoices.values()) voices += v || 0;
    return {
      liveSources: liveSources.size,
      pendingTimers: pendingTimers.size,
      activeVoices: voices,
      decodedBuffers: audioBuffers.size,
    };
  }

  // ---------------------------------------------------------------------------
  // Audio playback — bounded polyphony on the existing Apex audio graph.
  // ---------------------------------------------------------------------------
  // BOT WAVE-only acoustic bus. Preserve every native source/sample; reduce
  // summation peaks with dynamic headroom and a real compressor, not random
  // gun mute/drop, time-stretch or changed shot cadence.
  // Fire events are stamped at the semantic cue source, not guessed from filenames.
  // The bus compresses gunfire ONLY; BOXE impact/guard and game cues keep their authority.
  let waveBus=null,waveBusContext=null,cluster=0,clusterAt=0;
  function waveAudioDestination(ctx,isGun){
    const dest=typeof battleAudioMaster!=='undefined'?battleAudioMaster:ctx.destination;
    if(!isGun)return dest;
    if(waveBus&&waveBusContext===ctx)return waveBus;
    if(typeof ctx.createDynamicsCompressor!=='function')return dest;
    const limiter=ctx.createDynamicsCompressor();
    limiter.threshold.value=-34;limiter.knee.value=11;limiter.ratio.value=10;
    limiter.attack.value=.003;limiter.release.value=.31;
    limiter.connect(dest);
    waveBus=limiter;waveBusContext=ctx;
    return limiter;
  }
  function playEntry(entry) {
    pushRing(stats.scheduled, { rel: entry.rel, offset: entry.offset || 0, dur: entry.dur || null, vol: entry.vol }, 900);
    const ctx = audioCtxOf();
    const buffer = audioBuffers.get(entry.rel);
    if (!ctx || !buffer) { stats.throttled.notReady = (stats.throttled.notReady || 0) + 1; return; }
    const active = activeVoices.get(entry.rel) || 0;
    const waveMix=window.APEX_BOT_WAVE_AUDIO_MIX;
    // Do not multiply native simultaneous-voice caps when 41 weapons swarm.
    const cap = entry.maxVoices||4;
    if (active >= cap) { stats.throttled[entry.rel] = (stats.throttled[entry.rel] || 0) + 1; return; }
    let offset = entry.offset || 0;
    if (entry.slices) { offset = entry.slices[smgSliceCursor++ % entry.slices.length]; }
    const dur = entry.dur || Math.max(0.05, (buffer.duration || 1) - offset);
    // Reserve the voice (harness and browser share the cap accounting); release
    // when the clip would have ended.
    activeVoices.set(entry.rel, active + 1);
    // Each voice has one owner: timeout and onended can both fire.
    let released=false;
    const release=()=>{if(released)return;released=true;
      activeVoices.set(entry.rel,Math.max(0,(activeVoices.get(entry.rel)||1)-1));};
    if (typeof setTimeout === 'function') {
      const relId = setTimeout(() => { untrackTimer(relId); release(); }, Math.ceil(dur * 1000) + 40);
      trackTimer(relId);
    }
    if (entry.fadeTail) {
      stats.fadeEnvelopes = (stats.fadeEnvelopes || 0) + 1;
      stats.lastFade = { fadeTail: entry.fadeTail, attack: entry.attack || 0, playDur: dur, stopAfterGain: true };
    }
    if (window.__apexStatsSilent) return; // harness: intent + cap accounting recorded, no sound
    if (typeof ensureBattleAudioReady === 'function') ensureBattleAudioReady();
    const src = ctx.createBufferSource();
    src.buffer = buffer;
    if (entry.playbackRate && src.playbackRate) {
      try { src.playbackRate.value = entry.playbackRate; } catch (e) {}
    }
    const gain = ctx.createGain();
    const now=ctx.currentTime;
    const isGun=!!(waveMix&&(entry.waveFire===true||/\/guns\//.test(entry.rel)));
    const isUtility=!!(waveMix&&entry.waveUtility===true);
    // Density is measured across every weapon ID, not once per clip filename.
    // Ear-safe attenuation recovers smoothly as pressure drops; never time-stretches
    // samples, changes gameplay cadence, or touches BOXE's Gold key SFX.
    if(isGun){
      cluster*=Math.exp(-Math.max(0,now-clusterAt)*4.2);
      cluster=Math.min(30,cluster+1);clusterAt=now;
    }
    const crowded=isGun?Math.max(waveMix.gunFloor||.18,
      1/Math.sqrt(1+Math.max(0,cluster-1)*.92)):1;
    const utilityFactor=isUtility?Math.max(.22,1/Math.sqrt(1+cluster*.55)):1;
    const vol=(entry.vol!=null?entry.vol:.7)*(isGun?waveMix.weapons*crowded:
      isUtility?.25*utilityFactor:1);
    if(isUtility)stats.waveUtility={source:entry.rel,
      gain:Number(vol.toFixed(4)),density:Number(cluster.toFixed(2))};
    if(isGun)stats.waveMix={density:Number(cluster.toFixed(2)),
      gain:Number(vol.toFixed(4)),factor:Number(crowded.toFixed(3)),
      nativeVoiceCap:cap,source:entry.rel};
    const attack = entry.attack != null ? entry.attack : 0;
    const fadeTail = entry.fadeTail != null ? entry.fadeTail : 0;
    const playDur = dur + (fadeTail > 0 ? 0 : 0);
    if (attack > 0) {
      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.linearRampToValueAtTime(vol, now + attack);
    } else {
      gain.gain.setValueAtTime(vol, now);
    }
    if (fadeTail > 0) {
      const tailStart = now + Math.max(attack, playDur - fadeTail);
      gain.gain.setValueAtTime(vol, tailStart);
      gain.gain.exponentialRampToValueAtTime(0.001, now + playDur);
    }
    stats.lastVoice = { rel: entry.rel, vol, offset, dur: playDur, viaBufferSource: true };
    src.connect(gain);
    gain.connect(waveMix?waveAudioDestination(ctx,isGun||isUtility):(typeof battleAudioMaster !== 'undefined'?battleAudioMaster:ctx.destination));
    src.onended = () => { liveSources.delete(src); release(); };
    try {
      src.start(now, offset, playDur);
      liveSources.add(src);
      stats.played += 1;
      if (fadeTail > 0) {
        stats.fadeEnvelopes = (stats.fadeEnvelopes || 0) + 1;
        stats.lastFade = { fadeTail, attack, playDur, stopAfterGain: true };
      }
    } catch (error) {
      release();
    }
  }
  function playAll(listName, opts) {
    const list = AUDIO[listName];
    if (!list) return;
    for (const entry of list) {
      const e = (opts && (opts.rate || opts.vol != null || opts.waveFire || opts.waveUtility))
        ? Object.assign({}, entry, {
            playbackRate: opts.rate || entry.playbackRate,
            vol: opts.vol != null ? opts.vol : entry.vol,
            waveFire: opts.waveFire === true,
            waveUtility: opts.waveUtility === true,
          })
        : entry;
      playEntry(e);
    }
  }
  function playLater(listName, delayMs, opts) {
    if (typeof setTimeout !== 'function') return;
    // Session lifecycle: the raw timeout is tracked so resetAudioSession()
    // can cancel cues that are still pending when a battle session ends.
    const id = setTimeout(() => { untrackTimer(id); playAll(listName, opts); }, Math.max(0, delayMs | 0));
    trackTimer(id);
  }

  // ---------------------------------------------------------------------------
  // VFX instances — pure value snapshots (no fighter refs retained).
  // ---------------------------------------------------------------------------
  function pushVfx(inst) {
    if (vfx.length >= VFX_CAP) { vfx.shift(); stats.vfxDropped += 1; }
    inst.t = 0;
    vfx.push(inst);
    stats.vfxPeak = Math.max(stats.vfxPeak, vfx.length);
  }

  function muzzle(x, y, angle, scale, frames, life, stretch) {
    pushVfx({ kind: 'muzzle', x, y, angle, scale, frames, life, stretch: stretch || 1 });
  }

  // ---------------------------------------------------------------------------
  // Semantic cue dispatch — the only entry point used by gameplay runtimes.
  // ---------------------------------------------------------------------------
  function cue(name, o = {}) {
    pushRing(stats.cued, Object.assign(
      { event: name, x: Math.round(o.x || 0), y: Math.round(o.y || 0) },
      o.weapon ? { weapon: o.weapon } : {},
      o.usedMeta ? { usedMeta: true } : {},
      o.vfx ? { vfx: o.vfx } : {},
      o.sfxRate ? { sfxRate: o.sfxRate } : {},
    ));
    switch (name) {
      case 'telegraph': {
        // Audio only: slash-family art must never decorate an unknown pickup.
        playAll('telegraph');
        break;
      }
      case 'reveal': {
        // Spawn runtime already supplies a neutral shockwave/particle pop.
        // Do not use slash-family art for reveal.
        playAll('reveal');
        break;
      }
      case 'pickup': {
        if(window.APEX_BOT_WAVE_NPC_EQUIP){
          stats.waveNpcEquipMuted=(stats.waveNpcEquipMuted||0)+1;
          break;
        }
        const w = o.weapon;
        const ready = GUN_READY[w];
        if (ready) {
          playAll(ready,{waveUtility:true});
          if (w === 'SNIPER') playLater('pickup_sniper_lock', 180,{waveUtility:true});
          stats.gunReady = (stats.gunReady || 0) + 1;
          stats.lastGunReady = { weapon: w, cue: ready, rel: (AUDIO[ready] && AUDIO[ready][0] && AUDIO[ready][0].rel) };
        } else {
          playAll('pickup',{waveUtility:true});
          stats.lastGunReady = { weapon: w, cue: 'pickup', rel: AUDIO.pickup[0].rel };
        }
        break;
      }
      case 'fire': {
        const w = o.weapon;
        const fam = o.family || (w === 'PISTOL' ? 'SEMI' : w === 'SMG' ? 'AUTO' : w === 'SHOTGUN' ? 'SHOTGUN' : 'SEMI');
        // SPECIAL previously had no SFX family: every new gun fired silently.
        // Reuse already-authorized material cues until a delivered pack provides
        // a dedicated key; no second audio engine or undocumented asset path.
        const specialSfx = {
          FLARE_GUN: 'pistol_shot', TACTICAL_CROSSBOW: 'spear_swing',
          STEEL_BALL_LAUNCHER: 'shotgun_shot', COMBAT_BOOMERANG: 'sabre_swing',
          RPG_7: 'sniper_shot', FLAMETHROWER: 'smg_shot',
          PLASMA_SPLITTER: 'sniper_shot', SHRAPNEL_MINE_LAUNCHER: 'shotgun_shot',
        };
        const sfx = o.sfx || specialSfx[w] || { SEMI: 'pistol_shot', AUTO: 'smg_shot', BURST: 'smg_shot', SHOTGUN: 'shotgun_shot', AUTOSHOT: 'shotgun_shot', PRECISION: 'sniper_shot' }[fam];
        const recipes = (window.APEX_ARSENAL_CONFIG && window.APEX_ARSENAL_CONFIG.VFX_RECIPES) || {};
        const rec = recipes[o.vfx] || null;
        const worldMelee=['SABRE','BATTLE_AXE','DAGGER','SPEAR','SPIKED_CLUB',
          'STORMBREAKER','COMBAT_BOOMERANG','SWIRL_SHIELD','TOWER_SHIELD'].includes(w);
        playAll(sfx, { rate: o.sfxRate || 1,
          waveFire:!worldMelee&&fam!=='MELEE'&&fam!=='SHIELD' });
        const scale = rec ? rec.scale : (fam === 'AUTO' ? 0.5 : fam === 'SHOTGUN' ? 1.5 : fam === 'AUTOSHOT' ? 1.15 : fam === 'BURST' ? 0.62 : 0.7);
        const stretch = rec ? rec.stretch : (fam === 'SHOTGUN' || fam === 'AUTOSHOT' ? 1.35 : 1);
        const frames = fam === 'AUTO' ? [2 + (smgSliceCursor % 2), 3] : (fam === 'SHOTGUN' || fam === 'AUTOSHOT') ? [4, 0] : fam === 'BURST' ? [0, 2] : [0, 1];
        // A physical throw (Boomerang) must not create a firearm muzzle.
        if (w !== 'COMBAT_BOOMERANG') muzzle(o.x, o.y, o.angle, scale, frames, rec ? 0.08 + (rec.smokeLife || 0) * 0.15 : 0.09, stretch);
        if (rec ? rec.smoke > 0.05 : (fam === 'SHOTGUN' || fam === 'AUTOSHOT')) {
          const smokeScale = rec ? (0.7 + rec.smoke * 0.6) : 1.1;
          pushVfx({ kind: 'smoke', x: o.x, y: o.y, angle: o.angle, scale: smokeScale, life: rec ? rec.smokeLife : 0.5, file: SMOKE('01') });
        }
        break;
      }
      case 'melee_throw': {
        // POST-C §5: the thrown sprite is the primary read; swing-family SFX
        // punctuates the release.
        if (o.weapon === 'SABRE') playAll('sabre_swing');
        else if (o.weapon === 'BATTLE_AXE') playAll('axe_swing');
        else if (o.weapon === 'DAGGER') playAll('dagger_swing');
        else if (o.weapon === 'SPEAR') playAll('spear_swing');
        else if (o.weapon === 'SPIKED_CLUB') playAll('club_swing');
        break;
      }
      case 'ricochet': {
        // Readable wall bounce: small metal tick + the runtime spark particles.
        playAll('ricochet');
        break;
      }
      case 'casing': {
        pushVfx({ kind: 'casing', x: o.x, y: o.y, vx: o.vx || 0, vy: o.vy || -120, rot: o.rot || 0, vrot: o.vrot || 11, life: 0.9, landed: false, hull: !!o.hull, shotgun: !!o.shotgun, weapon: o.weapon });
        break;
      }
      case 'casing_land':
      case 'hull_land': {
        const shotgun = !!(o.shotgun || SHOTGUN_READY[o.weapon]);
        const list = shotgun ? SHELL_VARS : CASING_VARS;
        const entry = list[(shotgun ? shellCursor++ : casingCursor++) % list.length];
        const e = (o.vol != null) ? Object.assign({}, entry, { vol: o.vol }) : entry;
        playEntry(window.APEX_BOT_WAVE_AUDIO_MIX?{...e,waveUtility:true}:e);
        const key = shotgun ? 'shotgun_shell_land' : 'casing_land';
        stats.casingLands = (stats.casingLands || 0) + 1;
        stats.lastCasingLand = { key, rel: entry.rel, shotgun: !!shotgun };
        break;
      }
      case 'sniper_aim': {
        // Readiness identity moved to pickup; do not duplicate chamber here.
        break;
      }
      case 'sniper_bolt_lock': {
        break;
      }
      case 'shotgun_rack': {
        playAll('shotgun_rack_pull',{waveUtility:true});
        playLater('shotgun_rack_push', 170,{waveUtility:true});
        break;
      }
      case 'sniper_shot': {
        playAll('sniper_shot',{waveFire:true});
        // Long stretched transient — the near-hitscan punctuation (C §5.3).
        muzzle(o.x, o.y, o.angle, 1.9, [5, 4], 0.16, 2.1);
        pushVfx({ kind: 'smoke', x: o.x, y: o.y, angle: o.angle, scale: 0.9, life: 0.55, file: SMOKE('03') });
        break;
      }
      case 'grenade_throw': {
        // The grenade projectile itself communicates the throw; no slash trail.
        break;
      }
      case 'explosion': {
        // The AOE and its single gameplay hit receipt already occurred.
        // Cosmetic presentation may replace BOTH visual layers, never the
        // original SFX or blast damage. Grenade / default rocket remain Gold.
        playAll('explosion');
        if (!window.APEX_COSMETICS?.suppressDefaultBlast?.(o.cosmetic)) {
          stats.atlasCued = (stats.atlasCued || 0) + 1;
          pushVfx({ kind: 'atlas', x: o.x, y: o.y, life: 64 / 34, fps: 34, size: 400 });
        }
        break;
      }
      case 'storm_windup': {
        // Red-tier charge: existing force-field bed (no new audio sourcing).
        playAll('storm_windup');
        break;
      }
      case 'storm_throw': {
        // Heavy committed release — approved heavy whoosh.
        playAll('axe_swing');
        break;
      }
      case 'storm_impact': {
        // Confirmed red-tier impact — approved heavy contact pair.
        playAll('axe_hit');
        break;
      }
      case 'melee_swing': {
        // V2 §A4: imported slash/swipe sequences are disabled in normal
        // gameplay. The weapon sprite's own motion communicates the attack;
        // swing SFX remain.
        if (o.weapon === 'SABRE') playAll('sabre_swing');
        else if (o.weapon === 'BATTLE_AXE') playAll('axe_swing');
        else if (o.weapon === 'DAGGER') playAll('dagger_swing');
        else if (o.weapon === 'SPEAR') playAll('spear_swing');
        else if (o.weapon === 'SPIKED_CLUB') playAll('club_swing');
        break;
      }
      case 'melee_hit': {
        if (o.weapon === 'BATTLE_AXE') playAll('axe_hit');
        else if (o.weapon === 'SPIKED_CLUB') playAll('club_hit');
        else if (o.weapon === 'SPEAR') playAll('spear_hit');
        else if (o.weapon === 'SABRE') playAll('sabre_hit');
        else if (o.weapon === 'DAGGER') playAll('dagger_hit');
        const contact = MELEE_CONTACT[o.weapon];
        if (contact) pushVfx({ kind: 'contact', x: o.x, y: o.y, angle: o.angle != null ? o.angle : Math.random() * 6.28, conf: contact, life: contact.life });
        break;
      }
      case 'shield_activate': {
        // Final-lock shield identity is reserved for actual contact.
        break;
      }
      case 'reflect': {
        // V2 §A4: no blue slash art on shield events; audio + the runtime's
        // native shockwave/particles already communicate the reflect.
        playAll('swirl_block');
        break;
      }
      case 'tower_block': {
        playAll('tower_block');
        break;
      }
      default:
        break;
    }
  }

  // ---------------------------------------------------------------------------
  // Tick / draw.
  // ---------------------------------------------------------------------------
  function tick(dt) {
    for (let i = vfx.length - 1; i >= 0; i--) {
      const v = vfx[i];
      v.t += dt;
      if (v.spin && v.angle !== undefined) v.angle += v.spin * dt;
      if (v.kind === 'casing') {
        // Bounded brass physics: arc, spin, fall, settle.
        if (v.floorY == null) v.floorY = v.y + 46;
        v.vy += 1500 * dt;
        v.x += v.vx * dt;
        v.y += v.vy * dt;
        v.rot += v.vrot * dt;
        if (v.vy > 0 && v.y > v.floorY) {
          if (!v.landed) {
            v.landed = true;
            const speed = Math.hypot(v.vx, v.vy);
            const vol = Math.min(0.28, 0.08 + speed / 2400);
            cue(v.hull ? 'hull_land' : 'casing_land', { x: v.x, y: v.y, vol, shotgun: !!v.shotgun, weapon: v.weapon });
          }
          v.y = v.floorY; v.vy *= -0.3; v.vx *= 0.6; v.vrot *= 0.5;
        }
      }
      if (v.t >= v.life) vfx.splice(i, 1);
    }
  }

  // Checkpoint C sprite draw: per-weapon authored PNG. Guns are authored
  // muzzle-right; when the aim faces left the sprite is mirrored across its
  // own axis so the weapon never renders upside-down.
  function drawWeaponSprite(ctx, weaponId, x, y, options = {}) {
    const meta = weaponMeta(weaponId);
    if (!meta) return false;
    const img = getImg(weaponAbs(meta));
    if (!img || !img.complete || !img.width) return false;

    let dw;
    let dh;
    if (options.useWorld && meta.worldW && meta.worldH) {
      dw = meta.worldW * (options.scaleMul || 1);
      dh = meta.worldH * (options.scaleMul || 1);
    } else {
      const longSide = Math.max(meta.w, meta.h) || 1;
      const scale = (options.targetLongSide || 120) / longSide;
      dw = meta.w * scale;
      dh = meta.h * scale;
    }

    ctx.save();
    ctx.translate(x || 0, y || 0);
    if (options.angle) ctx.rotate(options.angle);
    if (options.keepUpright && Math.cos(options.angle || 0) < 0) ctx.scale(1, -1);
    // B6/correction: the STORMBREAKER asset is portrait — its LONG axis is
    // local Y (image top = blade/head, confirmed by pixel mass analysis of
    // the real webp: top 30% carries the head, the rest is the shaft).
    // A mirror ACROSS the long axis therefore flips the WIDTH axis only:
    // scale(-1, 1). scale(1, -1) would flip the long axis itself, swapping
    // blade and handle ends so the blade faces AWAY from the target.
    // Pure presentation: world angle, aim, physics, and collision are set
    // before this transform and are not affected by it.
    if (options.mirrorLocal) ctx.scale(-1, 1);
    ctx.globalAlpha *= options.alpha == null ? 1 : options.alpha;
    if (options.glow) {
      ctx.shadowColor = options.glow;
      ctx.shadowBlur = options.shadowBlur || 14;
    }
    // A held skin may REPLACE only these pixels, inside the same authored
    // muzzle/pose transform. Gold physics, dimensions and socket do not change.
    if (!window.APEX_COSMETICS?.render?.('weapon',ctx,options.cosmetic,
      { x:0,y:0,width:dw,height:dh,kind:weaponId }))
      ctx.drawImage(img, 0, 0, meta.w, meta.h, -dw / 2, -dh / 2, dw, dh);
    ctx.restore();

    if (options.mode === 'equipped') stats.equippedSpriteDraws += 1;
    else stats.floorSpriteDraws += 1;
    return true;
  }
  function weaponImage(weaponId) {
    const meta = weaponMeta(weaponId);
    if (!meta) return null;
    const img = getImg(weaponAbs(meta));
    return (img && img.complete && img.width) ? { img, w: meta.w, h: meta.h } : null;
  }

  // Shared per-weapon draw parameters (base pose, before Checkpoint B pose
  // state is applied). Melee/shield sprites are authored upright: their -Y
  // long axis is rotated onto the weapon aim direction.
  function weaponDrawParams(weaponId, category, radius) {
    let drawOffset = Math.PI / 2; // extra rotation for upright-authored sprites
    let targetLongSide = 138;
    let offset = radius * 0.72;
    let mirrorLocal = false;
    if (category === 'melee') {
      if (weaponId === 'STORMBREAKER') {
        const st = (window.APEX_ARSENAL_CONFIG && window.APEX_ARSENAL_CONFIG.STORMBREAKER) || {};
        targetLongSide = st.heldLongSide || 206;
        // B6: held presentation is a mirror reflection (local negative scale
        // across the weapon long axis) — never a +pi rotation.
        mirrorLocal = st.mirrorLocal === true;
      }
      else targetLongSide = weaponId === 'SPEAR' ? 190 : weaponId === 'BATTLE_AXE' ? 155 : 145;
    } else if (category === 'defense') {
      targetLongSide = weaponId === 'TOWER_SHIELD' ? 145 : 128;
      offset = radius * 0.82;
    } else {
      drawOffset = 0;
      const meta = weaponMeta(weaponId);
      if (weaponId === 'GRENADE') {
        targetLongSide = 56;
      } else {
        const table = (window.APEX_ARSENAL_CONFIG && window.APEX_ARSENAL_CONFIG.FIREARM_LONG_SIDE) || {};
        targetLongSide = table[weaponId] || 145;
      }
      offset = radius * 0.78;
    }
    const gunTable = (window.APEX_ARSENAL_CONFIG && window.APEX_ARSENAL_CONFIG.FIREARM_LONG_SIDE) || {};
    const isGun = !!gunTable[weaponId];
    return { drawOffset, targetLongSide, offset, mirrorLocal, useWorld: !isGun && !!(weaponMeta(weaponId) && weaponMeta(weaponId).worldW && category !== 'melee' && category !== 'defense' && weaponId !== 'GRENADE') };
  }

  // Checkpoint B (B-handoff PART 2): the weapon sprite transform consumes the
  // independent weaponPose state — recoil along aim, rotational kick, local
  // offsets, flourish spin, scale. The fighter body is never touched here.
  function drawWeaponWithPose(ctx, fighter, weaponId, category, aimAngle, pose, alpha) {
    if (!weaponMeta(weaponId)) return false;
    const params = weaponDrawParams(weaponId, category, fighter.radius || 75);
    const p = pose || {};
    // Q3u presentation-only grip: Gold V12 Scout/Bulwark/T.O.T bodies were
    // resized, but Arsenal held-gun artwork still used the unscaled Fighter
    // radius. Scale the gun IMAGE and its rendered hand offset together.
    // Physics/muzzle/worldAnchor, pickup, gun ownership and AI are untouched.
    const questRigScale = window.APEX_ARSENAL?.state?.questMultiActor &&
      fighter.questVisualId ? window.APEX_QUEST_V12_RIG?.inspect?.(fighter)?.scaleFactor : null;
    const artScale = Number.isFinite(questRigScale) && questRigScale >= 0.5 &&
      questRigScale <= 1 ? questRigScale : 1;
    const offset = (params.offset + (p.localX || 0) - (p.recoil || 0)) * artScale;
    const lateral = (p.localY || 0) * artScale;
    const drawAngle = aimAngle + params.drawOffset + (p.rotKick || 0) + (p.flourish || 0);
    const x = fighter.x + Math.cos(aimAngle) * offset + Math.cos(aimAngle + Math.PI / 2) * lateral;
    const y = fighter.y + Math.sin(aimAngle) * offset + Math.sin(aimAngle + Math.PI / 2) * lateral;
    return drawWeaponSprite(ctx, weaponId, x, y, {
      mode: 'equipped',
      cosmetic:window.APEX_COSMETICS?.capture?.(
        window.APEX_COSMETICS?.sideOf?.(fighter,window),'weapon',weaponId)||null,
      useWorld: params.useWorld,
      scaleMul: (p.scaleX || 1) * artScale,
      targetLongSide: params.targetLongSide * (p.scaleX || 1) * artScale,
      angle: drawAngle,
      alpha: alpha == null ? 0.98 : alpha,
      glow: category === 'defense' ? '#9fe8ff' : null,
      shadowBlur: 10,
      keepUpright: category === 'ranged' && weaponId !== 'GRENADE',
      mirrorLocal: params.mirrorLocal === true,
    });
  }

  // V4.3 Gold authored muzzle: compute from the ACTUAL held-art transform,
  // not a second approximation from the Fighter center. Shares the exact
  // weaponDrawParams, Q3u artScale, pose, angle and left-facing flip used by
  // drawWeaponWithPose, then applies the owner's per-weapon calibrated UV/dx/dy.
  function weaponMuzzleWorld(fighter, holder, aimAngle) {
    const id=holder?.weaponId, c=window.APEX_ARSENAL_CONFIG?.V43_WEAPONS?.[id];
    const meta=weaponMeta(id);
    if(!fighter||!c||!meta)return null;
    const params=weaponDrawParams(id,'ranged',fighter.radius||75);
    const p=holder?.meta?.pose||{};
    const questRigScale=window.APEX_ARSENAL?.state?.questMultiActor&&fighter.questVisualId
      ?window.APEX_QUEST_V12_RIG?.inspect?.(fighter)?.scaleFactor:null;
    const artScale=Number.isFinite(questRigScale)&&questRigScale>=.5&&questRigScale<=1?questRigScale:1;
    const offset=(params.offset+(p.localX||0)-(p.recoil||0))*artScale;
    const lateral=(p.localY||0)*artScale;
    const theta=aimAngle+params.drawOffset+(p.rotKick||0)+(p.flourish||0);
    // ROBOT has its own Gold held-weapon socket; the generic Arsenal grip
    // is not where its override renders the gun. Sharing the robot socket
    // here keeps charge VFX, launch point and held art on the same origin.
    const robot=window.APEX_ROBOT_PRESENTATION;
    const robotSocket=robot?.isRobotFighter?.(fighter)
      ?robot.getRobotWeaponSocketWorld?.(fighter):null;
    const cx=robotSocket?.x??(fighter.x+Math.cos(aimAngle)*offset-Math.sin(aimAngle)*lateral);
    const cy=robotSocket?.y??(fighter.y+Math.sin(aimAngle)*offset+Math.cos(aimAngle)*lateral);
    const width=params.targetLongSide*(p.scaleX||1)*artScale;
    const height=width*meta.h/meta.w;
    const localX=(c.muzzleU-.5)*width+(c.muzzleDx||0);
    // drawWeaponSprite uses keepUpright scale(1,-1) after rotate when left.
    const orientation=Math.cos(theta)<0?-1:1;
    const localY=((c.muzzleV-.5)*height+(c.muzzleDy||0))*orientation;
    const sourceX=cx+Math.cos(theta)*localX-Math.sin(theta)*localY;
    const sourceY=cy+Math.sin(theta)*localX+Math.cos(theta)*localY;
    // Plasma requires ~104px of Gold glow/ring/mote overhang. A world-edge
    // actor must not crop half the charging core. Both rendering and the
    // projectile launcher consume this ONE corrected world-space anchor.
    // Only the plasma charge changes origin; other weapon calibration stays
    // bit-for-bit intact. Preserve raw source for an energy-tether cue.
    const margin=id==='PLASMA_SPLITTER'?c.chargeClipMargin||0:0;
    const bound=window.GAME_SIZE||1000;
    const x=margin?Math.max(margin,Math.min(bound-margin,sourceX)):sourceX;
    const y=margin?Math.max(margin,Math.min(bound-margin,sourceY)):sourceY;
    return {x,y,sourceX,sourceY,centerX:cx,centerY:cy,width,height,theta};
  }

  // Direct V4.3 Gold Lab charge authoring: radial compression,
  // four rotating elliptical rings and thirteen converging motes.
  function drawV43GoldPlasmaCharge(ctx,fighter,holder,aimAngle) {
    const m=weaponMuzzleWorld(fighter,holder,aimAngle);
    if(!m)return;
    const wait=holder.meta?.v43Wait||.5;
    const t=Math.max(0,Math.min(1,(holder.meta?.v43Time||0)/wait));
    const compress=Math.max(0,Math.min(1,(t-.72)/.28));
    const outerR=(31+t*13)*(1-.42*compress);
    const clock=holder.elapsed||0;
    ctx.save();ctx.globalCompositeOperation='lighter';
    // If an edge would crop the charge, a thin umbilical arc visibly connects
    // the weapon's true barrel to the inset core, avoiding a floating effect.
    if(Math.hypot(m.x-m.sourceX,m.y-m.sourceY)>1){
      ctx.save();ctx.strokeStyle='#ca84fc';ctx.lineWidth=4.2;
      ctx.globalAlpha=.28+t*.52;ctx.shadowColor='#c781ff';ctx.shadowBlur=16;
      ctx.beginPath();ctx.moveTo(m.sourceX,m.sourceY);
      ctx.quadraticCurveTo((m.sourceX+m.x)/2,(m.sourceY+m.y)/2-13*t,m.x,m.y);
      ctx.stroke();ctx.restore();
    }
    ctx.translate(m.x,m.y);
    const glow=ctx.createRadialGradient(0,0,0,0,0,55*(1-.18*compress));
    glow.addColorStop(0,'rgba(255,255,255,'+(.25+t*.45)+')');
    glow.addColorStop(.14,'rgba(223,176,255,'+(.3+t*.4)+')');
    glow.addColorStop(.46,'rgba(139,57,236,'+(.16+t*.16)+')');
    glow.addColorStop(1,'rgba(74,13,118,0)');
    ctx.fillStyle=glow;ctx.beginPath();ctx.arc(0,0,60,0,TAU);ctx.fill();
    for(let k=0;k<4;k++){
      const rot=clock*(1.9+k*.3)+k*TAU/4;
      ctx.save();ctx.rotate(rot);
      ctx.strokeStyle=['#a45afb','#ddafff','#7c33d4','#f8eaff'][k];
      ctx.globalAlpha=.36+t*.18;ctx.lineWidth=2.7-k*.35;
      ctx.setLineDash([outerR*.9,outerR*.42]);
      ctx.beginPath();ctx.ellipse(0,0,Math.max(2,outerR-k*4),
        Math.max(2,outerR*.55-k*2),0,0,TAU);ctx.stroke();ctx.restore();
    }
    for(let k=0;k<13;k++){
      const rad=k*TAU/13+clock*.74,rr=69*(1-t)+5;
      const r=Math.max(2.5,1.5+2*(1-t)),sx=Math.cos(rad)*rr,sy=Math.sin(rad)*rr;
      ctx.globalAlpha=.35+t*.57;ctx.strokeStyle='#dba5ff';ctx.lineWidth=1.3;
      ctx.beginPath();ctx.moveTo(sx*1.13,sy*1.13);
      ctx.lineTo(sx*.67,sy*.67);ctx.stroke();
      ctx.fillStyle=k%3===0?'#fff4ff':'#c084ff';
      ctx.beginPath();ctx.arc(sx,sy,r,0,TAU);ctx.fill();
    }
    ctx.globalAlpha=.7+t*.3;ctx.fillStyle='#f8edff';
    ctx.shadowBlur=22;ctx.shadowColor='#dca4ff';
    ctx.beginPath();ctx.arc(0,0,5+t*9,0,TAU);ctx.fill();ctx.restore();
  }

  // CP13 — the ONE presentation-only seam for specialised hero held-rigs.
  // Registration is page-lifetime and idempotent. Each provider is ordered
  // deterministically and must RETURN TRUE only if it painted the entire
  // equipped weapon. Physics/ownership/aim/recoil remain Arsenal/hero-owned.
  // Shared late-world presentation channel for persistent VFX surviving a
  // Fighter death or transform. Pure render callbacks only; the emitter
  // never owns world HP, collision or any gameplay update.
  const worldVisualRenderers = new Map();
  function registerWorldVisualRenderer(id,paint){
    const key=String(id||'');
    if(!/^[a-z][a-z0-9-]{1,79}$/.test(key)||typeof paint!=='function')
      throw Error('Invalid world visual presentation provider');
    if(worldVisualRenderers.has(key)&&worldVisualRenderers.get(key)!==paint)
      throw Error('Duplicate world visual provider '+key);
    worldVisualRenderers.set(key,paint);
    return ()=>{if(worldVisualRenderers.get(key)===paint)worldVisualRenderers.delete(key);};
  }
  const equippedWeaponRenderers = new Map();
  function registerEquippedWeaponRenderer(id, paint) {
    const key=String(id||'');
    if(!/^[a-z][a-z0-9-]{1,79}$/.test(key)||typeof paint!=='function')
      throw new Error('Invalid equipped weapon presentation provider');
    const previous=equippedWeaponRenderers.get(key);
    if(previous && previous!==paint)
      throw new Error('Duplicate equipped weapon presentation provider: '+key);
    equippedWeaponRenderers.set(key,paint);
    return ()=>{
      if(equippedWeaponRenderers.get(key)===paint)equippedWeaponRenderers.delete(key);
    };
  }

  function drawEquippedWeapon(ctx, fighter, holder) {
    if (!fighter || !holder || !holder.weaponId) return false;
    // BEFORE generic art just as the old Robot wrapper was. Providers that
    // do not own this fighter MUST return false; ORIGINAL art is unchanged.
    for(const [id,paint] of equippedWeaponRenderers) {
      try {
        const handled=paint(ctx,fighter,holder);
        if(handled&&typeof handled.then==='function')
          throw new Error('Async equipped weapon renderer forbidden: '+id);
        if(handled===true)return true;
      }catch(error){console.warn('[arsenal-av] equipped renderer failed: '+id,error);}
    }
    // TRUE = handled by this renderer. Returning false made the host fallback
    // paint the weapon again even while the thrown projectile owned the art.
    if (holder.weaponId === 'COMBAT_BOOMERANG' && holder.phase === 'IN_FLIGHT') return true;
    // V2 §A2: equipped weapons continuously face the opponent through the
    // independent aim angle — never through the fighter movement direction.
    const angle = (holder.meta && holder.meta.aimAngle != null)
      ? holder.meta.aimAngle
      : Math.atan2(fighter.dir?.y || 0, fighter.dir?.x || 1);
    const drawn=drawWeaponWithPose(ctx, fighter, holder.weaponId, holder.def?.category || '', angle, holder.meta && holder.meta.pose, 0.98);
    // Charge VFX is drawn by the ONE foreground pass, *after* every
    // hero-specific held-art override (including ROBOT). Do not draw it here:
    // ROBOT's override returns before this function can run at all.
    return drawn;
  }

  // Pose ghost (Checkpoint C §3.2): the consumed weapon exits PHYSICALLY —
  // drop / rotation / shield retract driven by advancePoseGhost — and alpha is
  // used only in the final ~15% of that already-physical exit.
  function drawPoseGhost(ctx, fighter, ghost) {
    if (!fighter || !ghost || !ghost.weaponId) return false;
    const u = Math.max(0, Math.min(1, ghost.t / (ghost.maxLife || 0.38)));
    const alpha = u < 0.85 ? 0.95 : Math.max(0, 0.95 * (1 - (u - 0.85) / 0.15));
    ctx.save();
    ctx.translate(0, ghost.drop || 0);
    const ok = drawWeaponWithPose(ctx, fighter, ghost.weaponId, ghost.category || '', ghost.aimAngle || 0, ghost.pose, alpha);
    ctx.restore();
    return ok;
  }

  function drawDetachedWeapon(ctx, d) {
    if (!d || !d.weaponId) return false;
    const u = Math.max(0, Math.min(1, d.t / (d.maxLife || 0.5)));
    const alpha = u < 0.85 ? 1 : Math.max(0, 1 - (u - 0.85) / 0.15);
    const table = (window.APEX_ARSENAL_CONFIG && window.APEX_ARSENAL_CONFIG.FIREARM_LONG_SIDE) || {};
    const mul = (window.APEX_ARSENAL_CONFIG && window.APEX_ARSENAL_CONFIG.FIREARM_DISPLAY_MODE && window.APEX_ARSENAL_CONFIG.FIREARM_DISPLAY_MODE.exit) || 0.96;
    const long = table[d.weaponId] ? table[d.weaponId] * mul : undefined;
    return drawWeaponSprite(ctx, d.weaponId, d.x, d.y, {
      mode: 'equipped',
      useWorld: !table[d.weaponId],
      targetLongSide: long || 140,
      angle: d.rot,
      alpha,
      keepUpright: true,
    });
  }

  function draw(ctx) {
    for(const [id,paint] of worldVisualRenderers){
      try{
        const result=paint(ctx);
        if(result&&typeof result.then==='function')
          throw Error('Async world visual renderer forbidden: '+id);
      }catch(error){console.warn('[arsenal-av] world visual renderer failed: '+id,error);}
    }
    for (const v of vfx) {
      if (v.kind === 'muzzle') {
        const n = v.frames.length;
        const frame = MUZZLE_FRAMES[v.frames[Math.min(n - 1, Math.floor((v.t / v.life) * n))]];
        const img = frame ? getImg(muzzleAbs(frame)) : null;
        if (!img || !img.complete || !img.width) continue;
        const fade = 1 - v.t / v.life;
        ctx.save();
        ctx.translate(v.x, v.y);
        ctx.rotate(v.angle || 0);
        ctx.globalAlpha = Math.min(1, 1.35 * fade + 0.2);
        ctx.globalCompositeOperation = 'lighter';
        const s = v.scale || 1;
        const st = v.stretch || 1;
        // Authored muzzle-right; anchor just behind the flash base.
        ctx.drawImage(img, 0, 0, frame.w, frame.h, -16 * s, -38 * s, 96 * s * st, 76 * s);
        ctx.restore();
      } else if (v.kind === 'smoke') {
        const img = getImg(v.file);
        if (!img || !img.complete || !img.width) continue;
        const u = v.t / v.life;
        ctx.save();
        ctx.translate(v.x, v.y);
        ctx.rotate(v.angle || 0);
        ctx.globalAlpha = 0.22 * (1 - u);
        const s = (v.scale || 1) * (1 + u * 1.6);
        ctx.drawImage(img, -32 * s, -32 * s, 64 * s, 64 * s);
        ctx.restore();
      } else if (v.kind === 'contact') {
        // Melee contact transient: additive spark + short streaks (C §5.4).
        const c = v.conf;
        const img = getImg(c.spark);
        const u = v.t / v.life;
        ctx.save();
        ctx.translate(v.x, v.y);
        ctx.globalCompositeOperation = 'lighter';
        if (img && img.complete && img.width) {
          ctx.save();
          ctx.rotate(v.angle || 0);
          ctx.globalAlpha = 0.8 * (1 - u);
          const s = 0.7 + u * 0.5;
          ctx.drawImage(img, -24 * s, -24 * s, 48 * s, 48 * s);
          ctx.restore();
        }
        ctx.globalAlpha = 0.7 * (1 - u);
        ctx.strokeStyle = c.tint;
        ctx.lineWidth = 3;
        for (let i = 0; i < 4; i++) {
          const a = (v.angle || 0) + (i - 1.5) * 0.5;
          const r0 = 6 + u * c.speed * 0.16;
          const r1 = r0 + 14 * (1 - u) + 6;
          ctx.beginPath();
          ctx.moveTo(Math.cos(a) * r0, Math.sin(a) * r0);
          ctx.lineTo(Math.cos(a) * r1, Math.sin(a) * r1);
          ctx.stroke();
        }
        ctx.restore();
      } else if (v.kind === 'casing') {
        const w = weaponImage('CASING');
        if (!w) continue;
        const u = v.t / v.life;
        const alpha = u < 0.85 ? 1 : Math.max(0, 1 - (u - 0.85) / 0.15);
        ctx.save();
        ctx.translate(v.x, v.y);
        ctx.rotate(v.rot);
        ctx.globalAlpha = alpha;
        const s = 0.9;
        ctx.drawImage(w.img, 0, 0, w.w, w.h, -14 * s, -7 * s, 28 * s, 14 * s);
        ctx.restore();
      } else if (v.kind === 'atlas') {
        const img = getImg(ATLAS.file);
        if (!img || !img.complete || !img.width) continue;
        const frame = Math.min(ATLAS.frames - 1, Math.floor(v.t * v.fps));
        const sx = (frame % 8) * ATLAS.cell;
        const sy = Math.floor(frame / 8) * ATLAS.cell;
        const grow = 0.9 + 0.3 * Math.min(1, v.t * 2.6);
        const size = v.size * grow;
        ctx.save();
        ctx.translate(v.x, v.y);
        ctx.globalAlpha = frame > 52 ? Math.max(0, 1 - (frame - 52) / 12) : 1;
        ctx.globalCompositeOperation = 'lighter';
        ctx.drawImage(img, sx, sy, ATLAS.cell, ATLAS.cell, -size / 2, -size / 2, size, size);
        ctx.restore();
      }
    }
  }

  // POST-PLAYTEST 2026-09-29: Hunter owner SFX through the existing battle-audio
  // bank (no second AudioContext). Event edges in the presentation runtime own
  // the semantic dispatch; this layer only loads/plays with bounded polyphony.
  const hunterSfxLog = [];
  function playHunter(rel, opts) {
    if (typeof rel !== 'string' || !rel.startsWith('../assets/hero-rework/hunter-v10/sfx/')) return false;
    hunterSfxLog.push({ rel, t: (typeof performance !== 'undefined' ? performance.now() : Date.now()) });
    if (hunterSfxLog.length > 120) hunterSfxLog.shift();
    if (audioBuffers.has(rel)) {
      playEntry(Object.assign({ rel, maxVoices: 3 }, opts || {}));
    } else {
      // Deferred first decode stays session-scoped: the cue token invalidates
      // it if the battle session ends before the buffer arrives.
      loadAudio(rel);
      const e = Object.assign({ rel, maxVoices: 3 }, opts || {});
      if (typeof window.apexBattleAudioScheduleCue === 'function') window.apexBattleAudioScheduleCue(() => playEntry(e), 0);
    }
    return true;
  }

  window.APEX_ARSENAL_AV = {
    cue,
    tick,
    draw,
    preload,
    imagesTotal,
    imagesSettled,
    whenImagesReady,
    warmAudio,
    audioStatus,
    clear,
    resetAudioSession,
    audioSessionProbe,
    playLater,
    playHunter,
    hunterSfxLog,
    stats,
    audioReady: () => stats.audioLoaded,
    // CP7: a true predicate — audioReady() returns a COUNT (the headless
    // harness compares it against the total); callers that need "all clips
    // settled" must use audioSettled() instead of truthiness, which was
    // true as soon as ONE clip decoded.
    audioSettled: () => (stats.audioLoaded + (stats.audioFailed || 0)) >= ALL_AUDIO.length,
    imagesReady: () => stats.imagesLoaded,
    activeVfx: () => vfx.length,
    drawWeaponSprite,
    weaponDrawParams,
    weaponMuzzleWorld,
    registerWorldVisualRenderer,
    worldVisualRendererIds:()=>Object.freeze([...worldVisualRenderers.keys()]),
    registerEquippedWeaponRenderer,
    equippedWeaponRendererIds:()=>Object.freeze([...equippedWeaponRenderers.keys()]),
    drawEquippedWeapon,
    drawV43GoldPlasmaCharge,
    drawPoseGhost,
    drawDetachedWeapon,
    weaponImage,
    weaponMeta,
    imageByPath: (p)=>getImg(p),
      describe: () => ({
      root: AV_ROOT,
      weaponSet: Object.fromEntries(Object.entries(C_SET.weapons).map(([k, m]) => [k, m.file])),
      muzzleFrames: MUZZLE_FRAMES.map((f) => f.file),
      explosionAtlas: ATLAS.file,
      melee: Object.fromEntries(Object.entries(MELEE_CONTACT).map(([k, v]) => [k, v.spark])),
      audio: Object.fromEntries(Object.entries(AUDIO).map(([k, list]) => [k, list.map((a) => a.rel)])),
      allImages: ALL_IMAGES,
      allAudio: ALL_AUDIO,
    }),
  };
  window.apexArsenalPresentationRuntime = 'ready';
})();
