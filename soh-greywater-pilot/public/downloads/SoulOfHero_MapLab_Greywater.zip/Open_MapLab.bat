@echo off
rem Soul of Hero - Map Lab Studio + Greywater POI detail layer (offline)
start "" "%~dp0SoulOfHero_MapLab.html"
