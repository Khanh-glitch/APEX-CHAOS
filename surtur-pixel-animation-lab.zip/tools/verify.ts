import { writeFileSync, mkdirSync } from 'fs';
import { Buf } from '../src/surtur/engine/buf';
import { encodePNG } from '../src/surtur/engine/png';
import { DIRS } from '../src/surtur/engine/rig';
import { ACTION_MAP } from '../src/surtur/engine/actions';
import { hex } from '../src/surtur/engine/palette';
import { newProject, getFrame, compositeFX, compositeCell } from '../src/surtur/engine/render';
import { FX_W, FX_H } from '../src/surtur/engine/fx';
import { runValidation } from '../src/surtur/engine/validate';
import { buildLegacyZip, buildFullZip } from '../src/surtur/engine/export';

const scale = (b: Buf, s: number) => { const o = new Buf(b.w * s, b.h * s); for (let y = 0; y < o.h; y++) for (let x = 0; x < o.w; x++) o.set(x, y, b.get((x / s) | 0, (y / s) | 0)); return o; };
const p = newProject();
mkdirSync('tools/out/export', { recursive: true });
const args = process.argv.slice(2);
const tag = Date.now() % 100000;
if (args[0] === 'sheet') {
  const sc = Number(args[2] ?? 3), fx = !args.includes('--novfx'), frames = args[3] && !args[3].startsWith('--') ? args[3].split(',').map(Number) : null;
  for (const name of args[1].split(',')) {
    const def = ACTION_MAP[name];
    const idx = frames ?? Array.from({ length: def.frames }, (_, i) => i);
    const W = fx ? FX_W : 64, H = fx ? FX_H : 64;
    const b = new Buf(idx.length * W, 4 * H);
    for (let y = 0; y < b.h; y++) for (let x = 0; x < b.w; x++) b.set(x, y, hex(((x >> 3) + (y >> 3)) % 2 ? '#3a3e49' : '#434854'));
    DIRS.forEach((d, r) => idx.forEach((i, k) => { const fr = getFrame(p, name, d, i); b.blit(fx ? compositeFX(fr) : compositeCell(fr, false), k * W, r * H); }));
    const f = `tools/out/${name}${fx ? '' : '_novfx'}_${tag}.png`;
    writeFileSync(f, encodePNG(scale(b, sc)));
    console.log(f);
  }
} else {
  const res = runValidation(p, (s) => { if (!s.startsWith('PASS')) console.log(s); });
  const fail = res.filter((r) => !r.pass);
  console.log(`\n${res.length} checks, ${res.length - fail.length} pass, ${fail.length} fail`);
  writeFileSync('tools/out/export/Surtur_Legacy_RockBoss.zip', buildLegacyZip(p));
  writeFileSync('tools/out/export/Surtur_Full.zip', buildFullZip(p));
  writeFileSync('tools/out/export/validation.json', JSON.stringify(res, null, 1));
}
