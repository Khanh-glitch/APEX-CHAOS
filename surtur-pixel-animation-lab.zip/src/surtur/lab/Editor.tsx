import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Buf } from '../engine/buf';
import { ACTION_MAP } from '../engine/actions';
import { CELL } from '../engine/rig';
import { FX_OFF_X, FX_OFF_Y } from '../engine/fx';
import { getFrame, generateFrame, compositeCell, okey, layerSize, isCharLayer, ALL_LAYERS, serializeProject, deserializeProject, type Project, type LayerName } from '../engine/render';
import { ALL_PALETTE, CHARACTER_PALETTE, VFX_PALETTE, toHex, hex, type RGBA } from '../engine/palette';
import { Btn, Panel, PixelView, drawBuf, download } from './canvas';
import type { useSelection } from './Stage';

type Tool = 'pencil' | 'eraser' | 'fill' | 'eyedropper' | 'anchor';
interface Undo { key: string; before: Buf | undefined; after: Buf | undefined }

export function Editor({ project, rev, touch, sel }: { project: Project; rev: number; touch: (p?: Project) => void; sel: ReturnType<typeof useSelection> }) {
  const def = ACTION_MAP[sel.action];
  const [frame, setFrame] = useState(0);
  const [layer, setLayer] = useState<LayerName>('character');
  const [tool, setTool] = useState<Tool>('pencil');
  const [color, setColor] = useState<RGBA>(CHARACTER_PALETTE[5]);
  const [onion, setOnion] = useState(true);
  const [grid, setGrid] = useState(true);
  const [anchorName, setAnchorName] = useState('swordTip');
  const [vis, setVis] = useState<Record<LayerName, boolean>>(() => Object.fromEntries(ALL_LAYERS.map((l) => [l, isCharLayer(l)])) as Record<LayerName, boolean>);
  const [opac, setOpac] = useState<Record<LayerName, number>>(() => Object.fromEntries(ALL_LAYERS.map((l) => [l, 1])) as Record<LayerName, number>);
  const [clip, setClip] = useState<Buf | null>(null);
  const undo = useRef<Undo[]>([]), redo = useRef<Undo[]>([]);
  const stroke = useRef<{ key: string; before: Buf | undefined } | null>(null);
  const f = Math.min(frame, def.frames - 1);
  useEffect(() => setFrame(0), [sel.action]);

  const fr = getFrame(project, sel.action, sel.dir, f);
  const size = layerSize(layer);
  const zoom = isCharLayer(layer) ? 9 : 5;
  const key = okey(sel.action, sel.dir, f, layer);

  const editable = (): Buf => {
    let b = project.overrides[key];
    if (!b) { b = fr.layers[layer].clone(); project.overrides[key] = b; }
    return b;
  };
  const commit = (u: Undo) => { undo.current.push(u); if (undo.current.length > 100) undo.current.shift(); redo.current = []; };
  const apply = (k: string, b: Buf | undefined) => { if (b) project.overrides[k] = b.clone(); else delete project.overrides[k]; touch(); };
  const doUndo = useCallback(() => { const u = undo.current.pop(); if (!u) return; redo.current.push(u); apply(u.key, u.before); }, [project]);
  const doRedo = useCallback(() => { const u = redo.current.pop(); if (!u) return; undo.current.push(u); apply(u.key, u.after); }, [project]);
  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement)?.tagName === 'INPUT') return;
      if ((e.ctrlKey || e.metaKey) && e.code === 'KeyZ') { e.preventDefault(); e.shiftKey ? doRedo() : doUndo(); }
      else if ((e.ctrlKey || e.metaKey) && e.code === 'KeyY') { e.preventDefault(); doRedo(); }
      else if (!e.ctrlKey && !e.metaKey) {
        const m: Record<string, Tool> = { KeyB: 'pencil', KeyE: 'eraser', KeyG: 'fill', KeyI: 'eyedropper', KeyA: 'anchor' };
        if (m[e.code]) setTool(m[e.code]);
        if (e.code === 'ArrowRight') setFrame((x) => (x + 1) % def.frames);
        if (e.code === 'ArrowLeft') setFrame((x) => (x - 1 + def.frames) % def.frames);
      }
    };
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  }, [doUndo, doRedo, def.frames]);

  const onPointer = (x: number, y: number, e: React.PointerEvent) => {
    if (tool === 'eyedropper') { const c = fr.layers[layer].get(x, y); if (c & 255) setColor(c); return; }
    if (tool === 'anchor') {
      const ak = `${sel.action}|${sel.dir}|${f}`;
      const cx = x + size.ox, cy = y + size.oy; // to cell space
      project.anchors[ak] = { ...(project.anchors[ak] ?? {}), [anchorName]: [cx, cy] };
      touch(); return;
    }
    if (e.type === 'pointerdown' || !stroke.current) stroke.current = { key, before: project.overrides[key]?.clone() };
    const b = editable();
    if (tool === 'pencil') b.set(x, y, color);
    else if (tool === 'eraser') b.clearPx(x, y);
    else if (tool === 'fill' && e.type === 'pointerdown') {
      const target = b.get(x, y); if (target === color) return;
      const st = [[x, y]];
      while (st.length) { const [px, py] = st.pop()!; if (!b.inb(px, py) || b.get(px, py) !== target) continue; b.set(px, py, color); st.push([px + 1, py], [px - 1, py], [px, py + 1], [px, py - 1]); }
    }
    touch();
  };
  const endStroke = () => { if (stroke.current) { commit({ key: stroke.current.key, before: stroke.current.before, after: project.overrides[stroke.current.key]?.clone() }); stroke.current = null; } };

  // composite for editing view, in active layer's space
  const view = useMemo(() => {
    const out = new Buf(size.w, size.h);
    const toLocal = (l: LayerName) => { const s = layerSize(l); return { x: s.ox - size.ox, y: s.oy - size.oy }; };
    if (onion) {
      for (const [df, tint] of [[-1, 0.28], [1, 0.16]] as const) {
        const nf = (f + df + def.frames) % def.frames;
        const o = getFrame(project, sel.action, sel.dir, nf);
        const ghost = compositeCell(o, false);
        const tinted = new Buf(ghost.w, ghost.h);
        for (let yy = 0; yy < ghost.h; yy++) for (let xx = 0; xx < ghost.w; xx++) if (ghost.a(xx, yy)) tinted.set(xx, yy, df < 0 ? 0xff5050ff : 0x50a0ffff);
        const p = toLocal('character'); out.blit(tinted, p.x, p.y, tint);
      }
    }
    for (const l of ALL_LAYERS) if (vis[l] || l === layer) { const p = toLocal(l); out.blit(fr.layers[l], p.x, p.y, l === layer ? 1 : opac[l] * 0.9); }
    return out;
  }, [fr, vis, opac, layer, onion, rev, f]);

  const overlay = useCallback((ctx: CanvasRenderingContext2D, s: number) => {
    if (grid) { ctx.strokeStyle = 'rgba(255,255,255,0.07)'; ctx.lineWidth = 1; for (let x = 0; x <= size.w; x++) { ctx.beginPath(); ctx.moveTo(x * s + 0.5, 0); ctx.lineTo(x * s + 0.5, size.h * s); ctx.stroke(); } for (let y = 0; y <= size.h; y++) { ctx.beginPath(); ctx.moveTo(0, y * s + 0.5); ctx.lineTo(size.w * s, y * s + 0.5); ctx.stroke(); } }
    if (!isCharLayer(layer)) { ctx.strokeStyle = 'rgba(255,220,0,0.6)'; ctx.strokeRect(FX_OFF_X * s, FX_OFF_Y * s, CELL * s, CELL * s); }
    for (const [k, [x, y]] of Object.entries(fr.anchors)) { const lx = x - size.ox, ly = y - size.oy; ctx.strokeStyle = k === anchorName ? '#f0f' : k.startsWith('foot') ? '#4ade80' : k === 'root' ? '#22d3ee' : '#facc15'; ctx.lineWidth = 2; ctx.strokeRect(lx * s + 1, ly * s + 1, s - 2, s - 2); }
    ctx.strokeStyle = 'rgba(34,211,238,0.6)'; ctx.beginPath(); ctx.moveTo(0, (55 - size.oy) * s + s); ctx.lineTo(size.w * s, (55 - size.oy) * s + s); ctx.stroke();
  }, [grid, size, layer, fr, anchorName]);

  const thumbs = useMemo(() => Array.from({ length: def.frames }, (_, i) => compositeCell(getFrame(project, sel.action, sel.dir, i), true)), [def, sel.dir, project, rev]);
  const fileRef = useRef<HTMLInputElement>(null);

  return (
    <div className="grid gap-3 xl:grid-cols-[1fr_330px]">
      <div className="space-y-3">
        <Panel title={`Frame timeline · ${def.label} · ${sel.dir}`}>
          <div className="flex gap-1 overflow-x-auto pb-1">
            {thumbs.map((t, i) => (
              <div key={i} className={`flex-none rounded border p-1 ${i === f ? 'border-orange-500 bg-orange-950/30' : 'border-zinc-800'}`}>
                <button onClick={() => setFrame(i)} className="block"><ThumbCanvas buf={t} /></button>
                <div className="mt-1 flex items-center gap-1">
                  <span className="font-mono text-[9px] text-zinc-500">{i + 1}</span>
                  <input type="number" className="w-12 rounded bg-zinc-800 px-1 text-[10px]" value={project.timing[`${sel.action}|${i}`] ?? def.durations[i]} min={16} max={2000}
                    onChange={(e) => { project.timing[`${sel.action}|${i}`] = Math.max(16, +e.target.value || 16); touch(); }} />
                </div>
                <div className="text-[9px] text-zinc-500">{def.phases[i]}{ALL_LAYERS.some((l) => project.overrides[okey(sel.action, sel.dir, i, l)]) ? ' ✎' : ''}</div>
              </div>
            ))}
          </div>
        </Panel>
        <Panel title={`Pixel editor · layer "${layer}" · ${size.w}×${size.h}`} right={<span className="text-[10px] text-zinc-500">B pencil · E eraser · G fill · I pick · A anchor · Ctrl+Z / Ctrl+Y · ←/→ frame</span>}>
          <div className="overflow-auto" onPointerUp={endStroke} onPointerLeave={endStroke}>
            <PixelView buf={view} scale={zoom} bg="checker" overlay={overlay} onPointer={onPointer} cursor="crosshair" className="rounded border border-zinc-700" />
          </div>
          <div className="mt-2 flex flex-wrap gap-1">
            {(['pencil', 'eraser', 'fill', 'eyedropper', 'anchor'] as Tool[]).map((t) => <Btn key={t} on={tool === t} onClick={() => setTool(t)}>{t}</Btn>)}
            <span className="mx-1 h-5 w-px bg-zinc-700" />
            <Btn onClick={doUndo}>↶ Undo</Btn><Btn onClick={doRedo}>↷ Redo</Btn>
            <Btn on={onion} onClick={() => setOnion(!onion)}>Onion skin</Btn><Btn on={grid} onClick={() => setGrid(!grid)}>Grid</Btn>
            <Btn onClick={() => setClip(fr.layers[layer].clone())}>Copy layer</Btn>
            <Btn onClick={() => { if (!clip || clip.w !== size.w) return; commit({ key, before: project.overrides[key]?.clone(), after: clip.clone() }); project.overrides[key] = clip.clone(); touch(); }}>Paste layer{clip ? '' : ' (empty)'}</Btn>
            <Btn onClick={() => { commit({ key, before: project.overrides[key]?.clone(), after: undefined }); delete project.overrides[key]; touch(); }}>Reset to generated</Btn>
          </div>
        </Panel>
      </div>
      <div className="space-y-3">
        <Panel title="Layers">
          <div className="space-y-1">
            {ALL_LAYERS.map((l) => (
              <div key={l} className={`flex items-center gap-2 rounded px-1 py-0.5 ${l === layer ? 'bg-orange-900/30' : ''}`}>
                <input type="checkbox" checked={vis[l]} onChange={() => setVis({ ...vis, [l]: !vis[l] })} />
                <button className={`flex-1 text-left text-xs ${l === layer ? 'text-orange-200' : 'text-zinc-300'}`} onClick={() => setLayer(l)}>{l}{project.overrides[okey(sel.action, sel.dir, f, l)] ? ' ✎' : ''}</button>
                <input type="range" min={0} max={1} step={0.05} value={opac[l]} onChange={(e) => setOpac({ ...opac, [l]: +e.target.value })} className="w-20" />
              </div>
            ))}
          </div>
        </Panel>
        <Panel title="Palette" right={<span className="font-mono text-[10px] text-zinc-400">{toHex(color)}</span>}>
          <div className="mb-1 text-[10px] text-zinc-500">Character ramps ({CHARACTER_PALETTE.length})</div>
          <Swatches list={CHARACTER_PALETTE} color={color} setColor={setColor} />
          <div className="mb-1 mt-2 text-[10px] text-zinc-500">VFX ramps ({VFX_PALETTE.length})</div>
          <Swatches list={VFX_PALETTE} color={color} setColor={setColor} />
          <label className="mt-2 flex items-center gap-2 text-xs text-zinc-400">custom <input type="color" value={toHex(color)} onChange={(e) => setColor(hex(e.target.value))} /></label>
          <p className="mt-1 text-[10px] text-zinc-500">Total distinct lab colours: {ALL_PALETTE.length}</p>
        </Panel>
        <Panel title="Anchors (cell space)">
          <div className="grid grid-cols-2 gap-1">
            {Object.entries(fr.anchors).map(([k, v]) => <Btn key={k} on={anchorName === k} onClick={() => { setAnchorName(k); setTool('anchor'); }}>{k} {v.join(',')}</Btn>)}
          </div>
          <Btn className="mt-2" onClick={() => { delete project.anchors[`${sel.action}|${sel.dir}|${f}`]; touch(); }}>Reset frame anchors</Btn>
        </Panel>
        <Panel title="Project file">
          <div className="flex flex-wrap gap-1">
            <Btn onClick={() => download('surtur.surtur.json', serializeProject(project), 'application/json')}>Save project</Btn>
            <Btn onClick={() => fileRef.current?.click()}>Load project</Btn>
            <Btn onClick={() => { if (confirm('Discard all edits?')) touch({ ...project, overrides: {}, anchors: {}, timing: {} }); }}>Clear edits</Btn>
          </div>
          <input ref={fileRef} type="file" accept=".json" className="hidden" onChange={async (e) => { const file = e.target.files?.[0]; if (!file) return; try { touch(deserializeProject(await file.text())); } catch (err) { alert(String(err)); } }} />
          <p className="mt-2 text-[10px] text-zinc-500">Edits: {Object.keys(project.overrides).length} layers · {Object.keys(project.anchors).length} anchor sets · {Object.keys(project.timing).length} timings. Autosaved to localStorage; exports use edited pixels.</p>
          <p className="mt-1 text-[10px] text-zinc-500">Generated baseline: {generateFrame(sel.action, sel.dir, f).layers[layer].opaqueCount()} px on this layer.</p>
        </Panel>
      </div>
    </div>
  );
}

function Swatches({ list, color, setColor }: { list: RGBA[]; color: RGBA; setColor: (c: RGBA) => void }) {
  return <div className="flex flex-wrap gap-[3px]">{list.map((c, i) => <button key={i} onClick={() => setColor(c)} title={toHex(c)} className={`h-5 w-5 rounded-sm border ${c === color ? 'border-white' : 'border-black/40'}`} style={{ background: toHex(c) }} />)}</div>;
}
function ThumbCanvas({ buf }: { buf: Buf }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => { const c = ref.current!; c.width = 64; c.height = 64; const ctx = c.getContext('2d')!; ctx.fillStyle = '#26242c'; ctx.fillRect(0, 0, 64, 64); drawBuf(ctx, buf, 0, 0, 1); }, [buf]);
  return <canvas ref={ref} style={{ imageRendering: 'pixelated', width: 64, height: 64 }} />;
}
