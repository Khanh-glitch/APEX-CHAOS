import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ACTIONS, ACTION_MAP } from '../engine/actions';
import { DIRS, CELL, type Dir } from '../engine/rig';
import { FX_W, FX_H, FX_OFF_X, FX_OFF_Y, FX_LAYERS } from '../engine/fx';
import { getFrame, compositeFX, coreCell, CHAR_LAYERS, ALL_LAYERS, type Project, type LayerName } from '../engine/render';
import { PixelView, Btn, Panel, silhouette, drawBuf, paintBg, type BgMode } from './canvas';
import { usePlayback, durationsOf, type PlayMode } from './state';

export function useSelection() {
  const [action, setAction] = useState('idle');
  const [dir, setDir] = useState<Dir>('front');
  return { action, setAction, dir, setDir };
}

export function ActionPicker({ action, setAction, dir, setDir }: ReturnType<typeof useSelection>) {
  return (
    <div className="flex flex-wrap items-center gap-1.5">
      {ACTIONS.map((a) => <Btn key={a.name} on={a.name === action} onClick={() => setAction(a.name)} title={`${a.frames} frames${a.legacy ? ' · legacy' : ''}`}>{a.label}<span className="ml-1 text-[10px] opacity-60">{a.frames}</span></Btn>)}
      <span className="mx-2 h-5 w-px bg-zinc-700" />
      {DIRS.map((d, i) => <Btn key={d} on={d === dir} onClick={() => setDir(d)} title={`key ${i + 1}`}>{d}</Btn>)}
      <span className="ml-1 rounded border border-zinc-800 px-2 py-1 text-[10px] text-zinc-500" title="Diagonals are not authored yet; they will NOT be faked by rotating cardinal views.">8-dir: locked (diagonals unauthored)</span>
    </div>
  );
}

export function Stage({ project, rev, sel, reference }: { project: Project; rev: number; sel: ReturnType<typeof useSelection>; reference: string | null }) {
  const def = ACTION_MAP[sel.action];
  const durations = useMemo(() => durationsOf(project, def), [project, def, rev]);
  const [playing, setPlaying] = useState(true);
  const [speed, setSpeed] = useState(1);
  const [reverse, setReverse] = useState(false);
  const [mode, setMode] = useState<PlayMode>('auto');
  const [zoom, setZoom] = useState(4);
  const [bg, setBg] = useState<BgMode>('arena');
  const [showChar, setShowChar] = useState(true);
  const [showFx, setShowFx] = useState(true);
  const [showBg, setShowBg] = useState(true);
  const [sil, setSil] = useState(true);
  const [dbg, setDbg] = useState({ anchors: false, root: true, bounds: false, hitbox: true });
  const [layerVis, setLayerVis] = useState<Record<LayerName, boolean>>(() => Object.fromEntries(ALL_LAYERS.map((l) => [l, true])) as Record<LayerName, boolean>);
  const [frame, setFrame] = usePlayback(def, durations, { playing, speed, reverse, mode });
  const fr = getFrame(project, sel.action, sel.dir, Math.min(frame, def.frames - 1));

  const visible = useMemo(() => {
    const v: Partial<Record<LayerName, boolean>> = {};
    for (const l of ALL_LAYERS) v[l] = layerVis[l] && ((CHAR_LAYERS as readonly string[]).includes(l) ? showChar : showFx);
    return v;
  }, [layerVis, showChar, showFx]);
  const comp = useMemo(() => compositeFX(fr, { visible }), [fr, visible, rev]);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = canvasRef.current; if (!c) return;
    const s = zoom;
    c.width = FX_W * s; c.height = FX_H * s;
    const ctx = c.getContext('2d')!;
    if (showBg) paintBg(ctx, c.width, c.height, bg, s, (FX_OFF_Y + 55) * s); else ctx.clearRect(0, 0, c.width, c.height);
    drawBuf(ctx, comp, 0, 0, s);
    const ox = FX_OFF_X * s, oy = FX_OFF_Y * s;
    if (dbg.root) { ctx.fillStyle = 'rgba(80,220,255,0.7)'; ctx.fillRect(0, oy + 55 * s, c.width, Math.max(1, s / 4)); ctx.fillRect(ox + 32 * s, oy + 50 * s, Math.max(1, s / 4), 10 * s); }
    if (dbg.bounds) { const b = coreCell(fr).bounds(); ctx.strokeStyle = 'rgba(255,255,0,0.8)'; ctx.lineWidth = 1; ctx.strokeRect(ox, oy, CELL * s, CELL * s); if (b) { ctx.strokeStyle = 'rgba(0,255,120,0.9)'; ctx.strokeRect(ox + b.x0 * s, oy + b.y0 * s, (b.x1 - b.x0 + 1) * s, (b.y1 - b.y0 + 1) * s); } }
    if (dbg.anchors) for (const [k, [x, y]] of Object.entries(fr.anchors)) { ctx.fillStyle = k.startsWith('foot') ? '#4ade80' : k === 'swordTip' ? '#f43f5e' : k === 'root' ? '#22d3ee' : '#facc15'; ctx.fillRect(ox + x * s, oy + y * s, s, s); ctx.font = '10px monospace'; ctx.fillText(k, ox + x * s + s + 2, oy + y * s + 8); }
    if (dbg.hitbox) for (const h of def.hitboxes.filter((h) => h.frame === frame)) {
      ctx.strokeStyle = h.kind === 'hit' ? 'rgba(255,60,60,0.9)' : 'rgba(80,160,255,0.9)'; ctx.setLineDash([4, 3]);
      const facing = { front: [0, 1, -1, 0], back: [0, -1, 1, 0], left: [-1, 0, 0, -1], right: [1, 0, 0, 1] }[sel.dir];
      const gx = h.f * facing[0] + h.r * facing[2], gy = h.f * facing[1] + h.r * facing[3];
      const cx = ox + (32 + gx) * s, cy = oy + (55 + gy * 0.45) * s;
      ctx.beginPath();
      if (h.shape === 'circle') ctx.ellipse(cx, cy, h.radius! * s, h.radius! * 0.45 * s, 0, 0, Math.PI * 2);
      else { const w = (sel.dir === 'left' || sel.dir === 'right' ? h.d! : h.w!) * s, d = (sel.dir === 'left' || sel.dir === 'right' ? h.w! : h.d!) * 0.45 * s; ctx.rect(cx - w / 2, cy - d / 2, w, d); }
      ctx.stroke(); ctx.setLineDash([]);
    }
  }, [comp, zoom, bg, showBg, dbg, fr, def, frame, sel.dir]);

  const step = useCallback((d: number) => { setPlaying(false); setFrame(frame + d); }, [frame, setFrame]);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement)?.tagName === 'INPUT' || (e.target as HTMLElement)?.tagName === 'SELECT') return;
      if (e.code === 'Space') { e.preventDefault(); setPlaying((p) => !p); }
      else if (e.code === 'ArrowRight' || e.code === 'Period') step(1);
      else if (e.code === 'ArrowLeft' || e.code === 'Comma') step(-1);
      else if (e.code === 'KeyR') setReverse((r) => !r);
      else if (e.code === 'Home' || e.code === 'KeyT') { setFrame(0); setPlaying(true); }
      else if (e.code === 'KeyS') setSpeed((s) => (s === 0.25 ? 1 : 0.25));
      else if (e.code === 'BracketLeft') setSpeed((s) => Math.max(0.1, +(s - 0.1).toFixed(2)));
      else if (e.code === 'BracketRight') setSpeed((s) => Math.min(3, +(s + 0.1).toFixed(2)));
      else if (/^Digit[1-4]$/.test(e.code)) sel.setDir(DIRS[+e.code.slice(5) - 1]);
      else if (e.code === 'KeyV') setShowFx((v) => !v);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [step, setFrame, sel]);

  const silBuf = useMemo(() => silhouette(coreCell(fr), 0x0c0c10ff), [fr]);
  const hitFrames = def.events.filter((e) => e.type === 'hit').map((e) => e.frame);

  return (
    <div className="grid gap-3 xl:grid-cols-[1fr_320px]">
      <div className="space-y-3">
        <Panel title="Live stage" right={<span className="font-mono text-[11px] text-zinc-400">{def.label} · {sel.dir} · frame {frame + 1}/{def.frames} · {durations[frame]}ms · {def.phases[frame]}{hitFrames.includes(frame) ? ' · ◆HIT' : ''}{fr.edited.length ? ' · edited' : ''}</span>}>
          <div className="flex flex-wrap items-start gap-4 overflow-auto">
            <canvas ref={canvasRef} className="max-w-full rounded border border-zinc-800" style={{ imageRendering: 'pixelated' }} />
            {sil && (
              <div className="space-y-2">
                <div className="text-[10px] uppercase tracking-wider text-zinc-500">Silhouette (no VFX)</div>
                <PixelView buf={silBuf} scale={Math.max(2, Math.min(4, zoom))} bg="light" className="rounded border border-zinc-700" />
                <div className="text-[10px] uppercase tracking-wider text-zinc-500">Gameplay 1x / 2x</div>
                <div className="flex items-end gap-2"><PixelView buf={compositeFX(fr)} scale={1} bg="arena" /><PixelView buf={coreCell(fr)} scale={2} bg="dark" /></div>
              </div>
            )}
          </div>
          <div className="mt-3 flex flex-wrap items-center gap-1.5">
            <Btn on={!playing} onClick={() => setPlaying(!playing)} title="Space">{playing ? '❚❚ Pause' : '▶ Play'}</Btn>
            <Btn onClick={() => step(-1)} title="← / ,">◀ Step</Btn>
            <Btn onClick={() => step(1)} title="→ / .">Step ▶</Btn>
            <Btn on={reverse} onClick={() => setReverse(!reverse)} title="R">⇄ Reverse</Btn>
            <Btn onClick={() => { setFrame(0); setPlaying(true); }} title="Home / T">⟲ Restart</Btn>
            <Btn on={speed === 0.25} onClick={() => setSpeed(speed === 0.25 ? 1 : 0.25)} title="S">Slow-mo</Btn>
            <label className="ml-2 flex items-center gap-1 text-xs text-zinc-400">speed ×<input type="range" min={0.1} max={3} step={0.05} value={speed} onChange={(e) => setSpeed(+e.target.value)} /><span className="w-10 font-mono">{speed.toFixed(2)}</span></label>
            <select value={mode} onChange={(e) => setMode(e.target.value as PlayMode)} className="rounded border border-zinc-700 bg-zinc-800 px-1 py-1 text-xs">
              <option value="auto">auto ({def.loop})</option><option value="loop">loop</option><option value="pingpong">ping-pong</option><option value="once">once</option>
            </select>
          </div>
          <div className="mt-2 flex items-center gap-2">
            <input type="range" className="w-full" min={0} max={def.frames - 1} value={frame} onChange={(e) => { setPlaying(false); setFrame(+e.target.value); }} />
          </div>
          <div className="mt-1 flex gap-[2px]">
            {Array.from({ length: def.frames }, (_, i) => (
              <button key={i} onClick={() => { setPlaying(false); setFrame(i); }} className={`h-5 flex-1 rounded-sm text-[9px] font-mono ${i === frame ? 'ring-1 ring-white' : ''} ${{ loop: 'bg-zinc-700', anticipation: 'bg-sky-800', active: 'bg-amber-700', hit: 'bg-red-600', recovery: 'bg-emerald-800', hold: 'bg-violet-800' }[def.phases[i]]}`} title={`${def.phases[i]} ${durations[i]}ms`}>{i + 1}</button>
            ))}
          </div>
          <div className="mt-1 flex gap-3 text-[10px] text-zinc-500"><span className="text-sky-400">■ anticipation</span><span className="text-amber-500">■ active</span><span className="text-red-400">■ hit</span><span className="text-emerald-500">■ recovery</span><span className="text-violet-400">■ hold</span></div>
        </Panel>
      </div>
      <div className="space-y-3">
        <Panel title="View">
          <div className="flex flex-wrap gap-1">{[1, 2, 4, 8].map((z) => <Btn key={z} on={zoom === z} onClick={() => setZoom(z)}>{z}x</Btn>)}</div>
          <div className="mt-2 flex flex-wrap gap-1">{(['arena', 'dark', 'light', 'checker'] as BgMode[]).map((b) => <Btn key={b} on={bg === b} onClick={() => setBg(b)}>{b}</Btn>)}</div>
          <div className="mt-2 flex flex-wrap gap-1">
            <Btn on={showChar} onClick={() => setShowChar(!showChar)}>Character</Btn>
            <Btn on={showFx} onClick={() => setShowFx(!showFx)} title="V">FX</Btn>
            <Btn on={showBg} onClick={() => setShowBg(!showBg)}>Background</Btn>
            <Btn on={sil} onClick={() => setSil(!sil)}>Silhouette</Btn>
          </div>
          <div className="mt-2 flex flex-wrap gap-1">
            {(Object.keys(dbg) as (keyof typeof dbg)[]).map((k) => <Btn key={k} on={dbg[k]} onClick={() => setDbg({ ...dbg, [k]: !dbg[k] })}>{k}</Btn>)}
          </div>
        </Panel>
        <Panel title="Layers">
          <div className="grid grid-cols-2 gap-1">
            {ALL_LAYERS.map((l) => <Btn key={l} on={layerVis[l]} onClick={() => setLayerVis({ ...layerVis, [l]: !layerVis[l] })}>{l}</Btn>)}
          </div>
          <p className="mt-2 text-[10px] text-zinc-500">Character layers: {CHAR_LAYERS.join(', ')} (64×64). FX layers: {FX_LAYERS.length} × {FX_W}×{FX_H}, cell at ({FX_OFF_X},{FX_OFF_Y}).</p>
        </Panel>
        <Panel title="Timeline events">
          <ul className="space-y-0.5 font-mono text-[11px] text-zinc-300">
            {def.events.map((e, i) => <li key={i} className={e.frame === frame ? 'text-orange-300' : ''}>f{e.frame + 1} · {e.type}{e.data ? ' ' + JSON.stringify(e.data) : ''}</li>)}
            {def.hitboxes.map((h, i) => <li key={'h' + i} className="text-zinc-500">f{h.frame + 1} · {h.kind}box {h.shape} {h.shape === 'circle' ? `r${h.radius}` : `${h.w}×${h.d}`} @({h.f},{h.r})</li>)}
            <li className="text-zinc-500">root motion: {def.rootMotion[frame].join(', ')} px/frame</li>
          </ul>
        </Panel>
        <Panel title="Keys"><p className="text-[11px] leading-relaxed text-zinc-400">Space play · ←/→ step · R reverse · T restart · S slow-mo · [ ] speed · 1–4 facing · V toggle FX</p></Panel>
        {reference && <Panel title="Concept reference"><img src={reference} alt="Surtur reference" className="w-full rounded" /></Panel>}
      </div>
    </div>
  );
}
