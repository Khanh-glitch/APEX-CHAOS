import { useMemo, useState } from 'react';
import { Buf } from '../engine/buf';
import { ACTION_MAP, ACTIONS } from '../engine/actions';
import { DIRS, CELL, ROOT_Y } from '../engine/rig';
import { getFrame, compositeCell, coreCell, type Project } from '../engine/render';
import { PixelView, Panel, Btn, silhouette } from './canvas';
import type { useSelection } from './Stage';

export function Diagnose({ project, rev, sel, reference, setReference }: { project: Project; rev: number; sel: ReturnType<typeof useSelection>; reference: string | null; setReference: (s: string | null) => void }) {
  const def = ACTION_MAP[sel.action];
  const [frame, setFrame] = useState(0);
  const [vfx, setVfx] = useState(true);
  const [mode, setMode] = useState<'normal' | 'silhouette'>('normal');
  const f = Math.min(frame, def.frames - 1);

  const contact = useMemo(() => {
    const b = new Buf(def.frames * CELL, 4 * CELL);
    DIRS.forEach((d, r) => { for (let i = 0; i < def.frames; i++) { const fr = getFrame(project, sel.action, d, i); const c = vfx ? compositeCell(fr, true) : coreCell(fr); b.blit(mode === 'silhouette' ? silhouette(coreCell(fr)) : c, i * CELL, r * CELL); } });
    return b;
  }, [def, project, rev, vfx, mode, sel.action]);

  const diff = useMemo(() => {
    const a = coreCell(getFrame(project, sel.action, sel.dir, (f - 1 + def.frames) % def.frames)), b = coreCell(getFrame(project, sel.action, sel.dir, f));
    const o = new Buf(CELL, CELL); let changed = 0;
    for (let y = 0; y < CELL; y++) for (let x = 0; x < CELL; x++) {
      const pa = a.get(x, y), pb = b.get(x, y);
      if (pa === pb) { if (pb & 255) o.set(x, y, 0x2a2a30ff); continue; }
      changed++;
      o.set(x, y, !(pa & 255) ? 0x40ff80ff : !(pb & 255) ? 0xff4060ff : 0xffd040ff);
    }
    return { o, changed };
  }, [project, rev, sel, f, def]);

  const onion = useMemo(() => {
    const o = new Buf(CELL, CELL);
    for (let i = 0; i < def.frames; i++) { const s = silhouette(coreCell(getFrame(project, sel.action, sel.dir, i)), i === f ? 0xffffffff : 0xff7a2aff); o.blit(s, 0, 0, i === f ? 1 : 0.12); }
    return o;
  }, [project, rev, sel, f, def]);

  const stats = useMemo(() => ACTIONS.map((a) => {
    const rows = DIRS.map((d) => {
      let minM = 99, hTot = 0, feetVar = new Set<string>();
      for (let i = 0; i < a.frames; i++) {
        const fr = getFrame(project, a.name, d, i);
        const bb = coreCell(fr).bounds();
        if (bb) { minM = Math.min(minM, bb.x0, bb.y0, CELL - 1 - bb.x1, CELL - 1 - bb.y1); hTot += bb.y1 - bb.y0 + 1; }
        if (a.name === 'idle') feetVar.add(JSON.stringify([fr.anchors.footL, fr.anchors.footR]));
      }
      return { d, minM, avgH: (hTot / a.frames).toFixed(1), feet: feetVar.size };
    });
    return { a, rows };
  }), [project, rev]);

  const fr = getFrame(project, sel.action, sel.dir, f);
  const bb = coreCell(fr).bounds();

  return (
    <div className="grid gap-3 xl:grid-cols-[1fr_340px]">
      <div className="space-y-3">
        <Panel title={`Four-direction contact sheet · ${def.label} (rows: ${DIRS.join(' / ')})`} right={<div className="flex gap-1"><Btn on={vfx} onClick={() => setVfx(!vfx)}>VFX {vfx ? 'on' : 'off'}</Btn><Btn on={mode === 'silhouette'} onClick={() => setMode(mode === 'normal' ? 'silhouette' : 'normal')}>silhouette</Btn></div>}>
          <div className="overflow-auto"><PixelView buf={contact} scale={2} bg={mode === 'silhouette' ? 'light' : 'checker'} className="rounded" onPointer={(x, y) => { setFrame(Math.floor(x / CELL)); sel.setDir(DIRS[Math.floor(y / CELL)]); }} /></div>
          <div className="mt-2 text-[10px] text-zinc-500">Gameplay scale (1x):</div>
          <div className="overflow-auto"><PixelView buf={contact} scale={1} bg="arena" /></div>
        </Panel>
        <div className="grid gap-3 md:grid-cols-3">
          <Panel title={`Diff f${((f - 1 + def.frames) % def.frames) + 1}→f${f + 1}`}><PixelView buf={diff.o} scale={4} bg="dark" /><p className="mt-1 text-[10px] text-zinc-400">{diff.changed} px changed · <span className="text-emerald-400">added</span> · <span className="text-rose-400">removed</span> · <span className="text-amber-300">recoloured</span></p></Panel>
          <Panel title="Onion ghosting (all frames)"><PixelView buf={onion} scale={4} bg="dark" overlay={(ctx, s) => { ctx.fillStyle = 'rgba(34,211,238,.8)'; ctx.fillRect(0, (ROOT_Y + 1) * s, CELL * s, 1); }} /><p className="mt-1 text-[10px] text-zinc-400">Spread = motion range; root line cyan.</p></Panel>
          <Panel title="Alpha bounds / alignment"><PixelView buf={coreCell(fr)} scale={4} bg="checker" overlay={(ctx, s) => { if (!bb) return; ctx.strokeStyle = '#0f0'; ctx.strokeRect(bb.x0 * s, bb.y0 * s, (bb.x1 - bb.x0 + 1) * s, (bb.y1 - bb.y0 + 1) * s); ctx.fillStyle = 'rgba(34,211,238,.8)'; ctx.fillRect(0, (ROOT_Y + 1) * s, CELL * s, 1); ctx.fillRect(32 * s, 0, 1, CELL * s); }} /><p className="mt-1 font-mono text-[10px] text-zinc-400">{bb ? `x ${bb.x0}–${bb.x1} y ${bb.y0}–${bb.y1} · ${bb.x1 - bb.x0 + 1}×${bb.y1 - bb.y0 + 1}px` : 'empty'}</p></Panel>
        </div>
        <input type="range" min={0} max={def.frames - 1} value={f} onChange={(e) => setFrame(+e.target.value)} className="w-full" />
      </div>
      <div className="space-y-3">
        <Panel title="Concept reference (identity only)">
          {reference ? <img src={reference} alt="reference" className="w-full rounded" /> : <p className="text-[11px] text-zinc-400">Load <i>Surtur_Pixel_Art_Style_Reference.png</i> to compare side-by-side. (It was not present in this build environment, so it is not bundled.)</p>}
          <div className="mt-2 flex gap-1">
            <label className="cursor-pointer rounded border border-zinc-700 bg-zinc-800 px-2 py-1 text-xs">Load image<input type="file" accept="image/*" className="hidden" onChange={(e) => { const file = e.target.files?.[0]; if (!file) return; const r = new FileReader(); r.onload = () => setReference(String(r.result)); r.readAsDataURL(file); }} /></label>
            {reference && <Btn onClick={() => setReference(null)}>Clear</Btn>}
          </div>
          <div className="mt-2 flex items-end gap-2"><PixelView buf={coreCell(getFrame(project, 'idle', 'front', 0))} scale={1} bg="dark" /><PixelView buf={coreCell(getFrame(project, 'idle', 'front', 0))} scale={3} bg="dark" /></div>
        </Panel>
        <Panel title="Diagnostics table">
          <div className="max-h-[480px] overflow-auto">
            <table className="w-full font-mono text-[10px]">
              <thead className="text-zinc-500"><tr><th className="text-left">action</th><th>dir</th><th>min margin</th><th>avg h</th><th>idle feet</th></tr></thead>
              <tbody>{stats.flatMap(({ a, rows }) => rows.map((r) => (
                <tr key={a.name + r.d} className="border-t border-zinc-800">
                  <td>{a.name}</td><td className="text-center">{r.d}</td>
                  <td className={`text-center ${r.minM < 1 ? 'text-red-400' : r.minM < 2 ? 'text-amber-300' : 'text-emerald-400'}`}>{r.minM}px</td>
                  <td className="text-center">{r.avgH}</td><td className="text-center">{a.name === 'idle' ? (r.feet === 1 ? '✓ fixed' : `✗ ${r.feet}`) : '–'}</td>
                </tr>)))}</tbody>
            </table>
          </div>
        </Panel>
      </div>
    </div>
  );
}
