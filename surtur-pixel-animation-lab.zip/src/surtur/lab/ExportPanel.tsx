import { useState } from 'react';
import { buildLegacyZip, buildFullZip, auditRockBossZip, LEGACY, type AuditReport } from '../engine/export';
import { runValidation, type Check } from '../engine/validate';
import { ACTIONS } from '../engine/actions';
import { serializeProject, type Project } from '../engine/render';
import { Btn, Panel, download } from './canvas';

export function ExportPanel({ project }: { project: Project }) {
  const [bake, setBake] = useState(true);
  const [frames, setFrames] = useState(true);
  const [busy, setBusy] = useState('');
  const [checks, setChecks] = useState<Check[] | null>(null);
  const [audit, setAudit] = useState<AuditReport | null>(null);
  const [auditErr, setAuditErr] = useState('');
  const later = (label: string, fn: () => void) => { setBusy(label); setTimeout(() => { try { fn(); } finally { setBusy(''); } }, 30); };

  const groups = checks ? Array.from(new Set(checks.map((c) => c.group))) : [];
  const fails = checks?.filter((c) => !c.pass).length ?? 0;

  return (
    <div className="grid gap-3 xl:grid-cols-2">
      <div className="space-y-3">
        <Panel title="Exports">
          <div className="space-y-3 text-xs text-zinc-300">
            <div>
              <div className="font-semibold text-orange-200">1 · Legacy RockBoss-compatible ZIP</div>
              <p className="text-[11px] text-zinc-400">idle/walk/stomp/swipe folders, BossEnemy_*.png masters + original row file names, action-specific row order, exact 64×64 RGBA cells, frame counts 7/10/13/10. Every pixel is newly authored Surtur art.</p>
              <label className="mt-1 flex items-center gap-2"><input type="checkbox" checked={bake} onChange={() => setBake(!bake)} /> bake in-cell VFX (flames/embers clipped to cell; core character is never clipped)</label>
              <Btn className="mt-1" onClick={() => later('legacy', () => download('Surtur_Legacy_RockBoss.zip', buildLegacyZip(project, bake), 'application/zip'))}>Download legacy ZIP</Btn>
            </div>
            <div>
              <div className="font-semibold text-orange-200">2 · Full Surtur animation ZIP</div>
              <p className="text-[11px] text-zinc-400">sheets (all actions × 4 directions), per-layer sheets (character, weapon, emissive + 7 FX layers at 128×112 with offsets), FX composites, contact sheets, manifest.json (durations, events with timestamps, phases, root motion, anchors, hitboxes, version), editable project, offline preview.html.</p>
              <label className="mt-1 flex items-center gap-2"><input type="checkbox" checked={frames} onChange={() => setFrames(!frames)} /> include individual frame PNGs</label>
              <Btn className="mt-1" onClick={() => later('full', () => download('Surtur_Full.zip', buildFullZip(project, { frames }), 'application/zip'))}>Download full ZIP</Btn>
            </div>
            <div>
              <div className="font-semibold text-orange-200">3 · Editable project</div>
              <Btn onClick={() => download('surtur.surtur.json', serializeProject(project), 'application/json')}>Download project JSON</Btn>
              <span className="ml-2 text-[11px] text-zinc-500">also autosaved to localStorage (survives reload)</span>
            </div>
            {busy && <div className="text-amber-300">Building {busy}… (rasterising every frame)</div>}
          </div>
        </Panel>
        <Panel title="Phase 1 · RockBoss ZIP audit (format reference only)">
          <p className="text-[11px] text-zinc-400">Drop <i>TopDown_RockBoss_EBrosAssets.zip</i>. It is parsed locally: __MACOSX / ._* ignored, PNG dimensions / colour type / alpha / 64-px divisibility / non-empty cells per row measured, and each directional row file is pixel-matched against the master rows to derive the real row order. Direction <i>semantics</i> (which row is "front") cannot be proven from pixels alone and come from the brief. RockBoss art is never copied into exports.</p>
          <label className="mt-2 inline-block cursor-pointer rounded border border-zinc-700 bg-zinc-800 px-2 py-1 text-xs">Choose ZIP<input type="file" accept=".zip" className="hidden" onChange={async (e) => { const file = e.target.files?.[0]; if (!file) return; try { setAuditErr(''); setAudit(auditRockBossZip(new Uint8Array(await file.arrayBuffer()))); } catch (err) { setAuditErr(String(err)); } }} /></label>
          {auditErr && <p className="mt-2 text-xs text-red-400">{auditErr}</p>}
          {audit && (
            <div className="mt-2 space-y-2 font-mono text-[10px]">
              {Object.entries(audit.actions).map(([a, r]) => (
                <div key={a} className={`rounded border p-2 ${r.ok ? 'border-emerald-800' : 'border-red-800'}`}>
                  <div className={r.ok ? 'text-emerald-300' : 'text-red-300'}>{a}: {r.ok ? 'matches schema' : 'MISMATCH'} · master {r.master ? `${r.master.width}x${r.master.height} ct${r.master.colorType}` : 'missing'} · {r.framesPerDir} frames/dir</div>
                  <div className="text-zinc-400">row file → master row: {Object.entries(r.rowMatches).map(([d, m]) => `${d}=${LEGACY[a].rowFiles[d as 'front']}→${m ?? '?'}`).join(' · ')}</div>
                  {r.master?.nonEmptyCells && <div className="text-zinc-500">non-empty cells per row: {r.master.nonEmptyCells.join(', ')}</div>}
                  {r.notes.map((n, i) => <div key={i} className="text-amber-300">{n}</div>)}
                </div>
              ))}
              <details><summary className="cursor-pointer text-zinc-400">{audit.files.length} PNGs · {audit.ignored.length} ignored entries</summary>
                {audit.files.map((f) => <div key={f.path} className="text-zinc-500">{f.path} {f.width}x{f.height} ct{f.colorType} {f.divisible ? '÷64' : 'NOT ÷64'} alpha:{String(f.alphaUsed)} {f.error ?? ''}</div>)}
              </details>
            </div>
          )}
          {!audit && (
            <table className="mt-2 w-full font-mono text-[10px] text-zinc-400"><thead><tr className="text-zinc-500"><th className="text-left">action</th><th>frames</th><th>rows (top→bottom)</th></tr></thead>
              <tbody>{Object.entries(LEGACY).map(([a, s]) => <tr key={a}><td>{s.master}</td><td className="text-center">{s.frames}</td><td>{s.rows.map((d) => `${d}:${s.rowFiles[d]}`).join(' ')}</td></tr>)}</tbody></table>
          )}
        </Panel>
      </div>
      <Panel title="Automated validation" right={<Btn onClick={() => later('validation', () => setChecks(runValidation(project)))}>Run test suite</Btn>}>
        {!checks && <p className="text-xs text-zinc-400">Runs: action/frame-count coverage, per-frame clipping, root/foot anchors, planted-foot vs root-motion, duplicate-frame padding, left≠mirror(right), hit events ↔ hitboxes, input map, legacy ZIP (files, dims, RGBA, row mapping pixel-identical to authored frames), full ZIP re-decode roundtrip, timing serialisation, preview presence, project save→load→export with a real pixel edit. Takes ~10–20 s.</p>}
        {checks && (
          <div>
            <div className={`mb-2 text-sm font-semibold ${fails ? 'text-red-300' : 'text-emerald-300'}`}>{checks.length} checks · {checks.length - fails} pass · {fails} fail · {checks.filter((c) => c.warn).length} warnings</div>
            <div className="max-h-[640px] space-y-2 overflow-auto">
              {groups.map((g) => (
                <div key={g}><div className="text-[10px] font-bold uppercase tracking-wider text-zinc-500">{g}</div>
                  {checks.filter((c) => c.group === g).map((c) => <div key={c.id} className="flex gap-2 font-mono text-[10px]"><span className={!c.pass ? 'text-red-400' : c.warn ? 'text-amber-300' : 'text-emerald-400'}>{!c.pass ? 'FAIL' : c.warn ? 'WARN' : 'PASS'}</span><span className="text-zinc-300">{c.id}</span><span className="text-zinc-500">{c.detail}</span></div>)}
                </div>
              ))}
            </div>
          </div>
        )}
        <div className="mt-3 border-t border-zinc-800 pt-2 text-[10px] text-zinc-500">Actions: {ACTIONS.map((a) => `${a.name}(${a.frames}${a.bonus ? ', bonus' : ''})`).join(' · ')}</div>
      </Panel>
    </div>
  );
}
