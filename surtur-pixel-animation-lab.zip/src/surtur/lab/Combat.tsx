import { useEffect, useRef, useState } from 'react';
import { Buf } from '../engine/buf';
import { ACTION_MAP } from '../engine/actions';
import { DEPTH_Y, type Dir } from '../engine/rig';
import { FX_RX, FX_RY, FX_OFF_X, FX_OFF_Y } from '../engine/fx';
import { getFrame, compositeFX, type Project } from '../engine/render';
import { KEYMAP } from '../engine/validate';
import { hex, ROCK, OUTLINE, FIRE } from '../engine/palette';
import { Btn, Panel, drawBuf, paintBg } from './canvas';
import { durationsOf } from './state';

const W = 320, H = 190;
const FACE: Record<Dir, [number, number, number, number]> = { front: [0, 1, -1, 0], back: [0, -1, 1, 0], left: [-1, 0, 0, -1], right: [1, 0, 0, 1] };

// small authored raster target dummy (basalt pillar)
const DUMMY = (() => {
  const rows = ['..ooooo..', '.ohhlmmo.', 'oohlmmdoo', 'ohlmmmddo', 'olmmrmddo', 'olmmmmddo', 'olmrmmddo', 'olmmmmddo', 'oklmmmdko', 'ooooooooo'];
  const pal: Record<string, number> = { o: OUTLINE, h: ROCK[4], l: ROCK[3], m: ROCK[2], d: ROCK[1], k: ROCK[0], r: FIRE[4] };
  const b = new Buf(9, rows.length);
  rows.forEach((r, y) => [...r].forEach((c, x) => c !== '.' && b.set(x, y, pal[c])));
  return b;
})();

interface Dummy { x: number; y: number; hp: number; flash: number; kx: number; ky: number }

export function Combat({ project, rev }: { project: Project; rev: number }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const [scale, setScale] = useState(3);
  const [debug, setDebug] = useState({ hitbox: true, anchors: true, events: true });
  const [log, setLog] = useState<string[]>([]);
  const [hud, setHud] = useState('');
  const dbgRef = useRef(debug); dbgRef.current = debug;
  const scaleRef = useRef(scale); scaleRef.current = scale;

  useEffect(() => {
    const keys = new Set<string>();
    const s = { x: 160, y: 120, dir: 'front' as Dir, action: 'idle', frame: 0, t: 0, hitstop: 0, shake: 0, downed: false, recovering: false, firedFrame: -1 };
    const dummies: Dummy[] = [{ x: 210, y: 122, hp: 100, flash: 0, kx: 0, ky: 0 }, { x: 160, y: 160, hp: 100, flash: 0, kx: 0, ky: 0 }, { x: 105, y: 110, hp: 100, flash: 0, kx: 0, ky: 0 }, { x: 160, y: 78, hp: 100, flash: 0, kx: 0, ky: 0 }];
    const push = (m: string) => setLog((l) => [m, ...l].slice(0, 9));
    const start = (a: string) => { s.action = a; s.frame = 0; s.t = 0; s.firedFrame = -1; push(`▶ ${a} (${s.dir})`); };
    const locked = () => { const d = ACTION_MAP[s.action]; return d.loop === 'once' && !(s.action === 'collapse' && s.downed); };
    const kd = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement)?.tagName === 'INPUT') return;
      if (['KeyW', 'KeyA', 'KeyS', 'KeyD', 'Space'].includes(e.code)) e.preventDefault();
      if (keys.has(e.code)) return;
      keys.add(e.code);
      if (e.code === 'KeyR' && s.downed) { s.downed = false; s.recovering = true; s.action = 'collapse'; s.frame = ACTION_MAP.collapse.frames - 1; s.t = 0; push('⟲ recover (collapse played in reverse, explicit toggle)'); return; }
      const a = KEYMAP[e.code];
      if (a && !s.downed && !s.recovering && (!locked() || s.action === 'charge')) start(a);
    };
    const ku = (e: KeyboardEvent) => { keys.delete(e.code); if (e.code === 'KeyL' && s.action === 'charge') { push('charge released'); start('idle'); } };
    window.addEventListener('keydown', kd); window.addEventListener('keyup', ku);

    let raf = 0, last = performance.now();
    const loop = (now: number) => {
      const dt = Math.min(50, now - last); last = now;
      const c = ref.current; if (!c) { raf = requestAnimationFrame(loop); return; }
      const sc = scaleRef.current, dbg = dbgRef.current;
      // ---- input → locomotion
      const mv = { x: (keys.has('KeyD') ? 1 : 0) - (keys.has('KeyA') ? 1 : 0), y: (keys.has('KeyS') ? 1 : 0) - (keys.has('KeyW') ? 1 : 0) };
      const busy = locked() || s.downed || s.recovering || s.action === 'charge';
      if (!busy) {
        if (mv.x || mv.y) {
          s.dir = Math.abs(mv.x) >= Math.abs(mv.y) && mv.x ? (mv.x > 0 ? 'right' : 'left') : mv.y > 0 ? 'front' : 'back';
          const want = keys.has('ShiftLeft') || keys.has('ShiftRight') ? 'run' : 'walk';
          if (s.action !== want) { s.action = want; s.frame = 0; s.t = 0; }
        } else if (s.action !== 'idle') { s.action = 'idle'; s.frame = 0; s.t = 0; }
      }
      const def = ACTION_MAP[s.action];
      const dur = durationsOf(project, def);
      // ---- advance with hit-stop (freeze on the impact frame, no sprite stretching)
      if (s.hitstop > 0) s.hitstop -= dt;
      else {
        s.t += dt;
        const rm = def.rootMotion[s.frame];
        const v = (rm[0] / dur[s.frame]) * dt, vr = (rm[1] / dur[s.frame]) * dt;
        const f = FACE[s.dir];
        s.x += (f[0] * v + f[2] * vr); s.y += (f[1] * v + f[3] * vr) * DEPTH_Y;
        s.x = Math.max(30, Math.min(W - 30, s.x)); s.y = Math.max(60, Math.min(H - 10, s.y));
        while (s.t >= dur[s.frame]) {
          s.t -= dur[s.frame];
          if (s.recovering) { s.frame--; if (s.frame < 0) { s.recovering = false; s.frame = 0; s.action = 'idle'; push('standing'); break; } continue; }
          s.frame++;
          if (s.frame >= def.frames) {
            if (def.loop === 'loop') s.frame = 0;
            else if (def.loop === 'hold') s.frame = def.frames - 2;
            else if (s.action === 'collapse') { s.frame = def.frames - 1; if (!s.downed) { s.downed = true; push('downed — press R to recover'); } }
            else { s.action = 'idle'; s.frame = 0; break; }
          }
        }
      }
      const cur = ACTION_MAP[s.action];
      const fi = Math.min(s.frame, cur.frames - 1);
      // ---- events on frame entry
      if (s.firedFrame !== fi && !s.recovering) {
        s.firedFrame = fi;
        for (const ev of cur.events.filter((e) => e.frame === fi)) {
          if (ev.type === 'hit') {
            s.hitstop = Number(ev.data?.hitstop ?? 80); s.shake = s.action === 'stomp' ? 4 : 2;
            let hits = 0;
            for (const hb of cur.hitboxes.filter((h) => h.frame === fi && h.kind === 'hit')) {
              const f = FACE[s.dir];
              const gx = s.x + hb.f * f[0] + hb.r * f[2], gy = s.y / DEPTH_Y + hb.f * f[1] + hb.r * f[3];
              for (const d of dummies) {
                const dx = d.x - gx, dy = d.y / DEPTH_Y - gy;
                const inside = hb.shape === 'circle' ? Math.hypot(dx, dy) <= hb.radius! : (() => { const side = s.dir === 'left' || s.dir === 'right'; const w = side ? hb.d! : hb.w!, h = side ? hb.w! : hb.d!; return Math.abs(dx) <= w / 2 + 4 && Math.abs(dy) <= h / 2 + 4; })();
                if (inside) { d.hp = Math.max(0, d.hp - (hb.damage ?? 0)); d.flash = 160; const n = Math.hypot(dx, dy) || 1; d.kx = (dx / n) * 3; d.ky = (dy / n) * 1.5; hits++; }
              }
            }
            push(`◆ HIT ${s.action} f${fi + 1}: ${hits} target(s), hit-stop ${s.hitstop}ms`);
          } else if (dbg.events) push(`· ${ev.type} f${fi + 1}`);
        }
      }
      // ---- render
      c.width = W * sc; c.height = H * sc;
      const ctx = c.getContext('2d')!;
      const shx = s.shake > 0 ? ((now / 30) | 0) % 2 ? sc : -sc : 0;
      if (s.shake > 0 && s.hitstop <= 0) s.shake -= dt / 40;
      ctx.save(); ctx.translate(Math.round(shx), 0);
      paintBg(ctx, c.width, c.height, 'arena', sc);
      const fr = getFrame(project, s.action, s.dir, fi);
      const sprite = compositeFX(fr);
      const items: { y: number; draw: () => void }[] = dummies.map((d) => ({ y: d.y, draw: () => {
        if (d.flash > 0) d.flash -= dt;
        d.x += d.kx * 0.2; d.kx *= 0.8; d.y += d.ky * 0.2; d.ky *= 0.8;
        const b = d.flash > 0 ? (() => { const o = DUMMY.clone(); for (let i = 0; i < o.d.length; i += 4) if (o.d[i + 3]) { o.d[i] = 255; o.d[i + 1] = 230; o.d[i + 2] = 180; } return o; })() : DUMMY;
        drawBuf(ctx, b, Math.round(d.x - 4) * sc, Math.round(d.y - 9) * sc, sc);
        ctx.fillStyle = '#300'; ctx.fillRect(Math.round(d.x - 6) * sc, Math.round(d.y + 2) * sc, 12 * sc, sc);
        ctx.fillStyle = '#e44'; ctx.fillRect(Math.round(d.x - 6) * sc, Math.round(d.y + 2) * sc, Math.round((12 * d.hp) / 100) * sc, sc);
      } }));
      const ox = Math.round(s.x) - FX_RX, oy = Math.round(s.y) - FX_RY;
      items.push({ y: s.y, draw: () => drawBuf(ctx, sprite, ox * sc, oy * sc, sc) });
      items.sort((a, b) => a.y - b.y).forEach((i) => i.draw());
      if (dbg.hitbox) for (const hb of cur.hitboxes.filter((h) => h.frame === fi)) {
        const f = FACE[s.dir];
        const gx = s.x + hb.f * f[0] + hb.r * f[2], gy = s.y + (hb.f * f[1] + hb.r * f[3]) * DEPTH_Y;
        ctx.strokeStyle = hb.kind === 'hit' ? '#ff4040' : '#4aa3ff'; ctx.setLineDash([3, 3]); ctx.beginPath();
        if (hb.shape === 'circle') ctx.ellipse(gx * sc, gy * sc, hb.radius! * sc, hb.radius! * DEPTH_Y * sc, 0, 0, Math.PI * 2);
        else { const side = s.dir === 'left' || s.dir === 'right'; const w = (side ? hb.d! : hb.w!) * sc, h = (side ? hb.w! : hb.d!) * DEPTH_Y * sc; ctx.rect(gx * sc - w / 2, gy * sc - h / 2, w, h); }
        ctx.stroke(); ctx.setLineDash([]);
      }
      if (dbg.anchors) {
        const cx = ox + FX_OFF_X, cy = oy + FX_OFF_Y;
        for (const [k, [ax, ay]] of Object.entries(fr.anchors)) if (['footR', 'footL', 'swordTip', 'root'].includes(k)) { ctx.fillStyle = k === 'swordTip' ? '#f43f5e' : k === 'root' ? '#22d3ee' : '#4ade80'; ctx.fillRect((cx + ax) * sc, (cy + ay) * sc, sc, sc); }
      }
      ctx.restore();
      if (s.hitstop > 0) { ctx.fillStyle = '#fff'; ctx.font = `${4 * sc}px monospace`; ctx.fillText('HIT-STOP', 6 * sc, 10 * sc); }
      setHud(`${s.action} · ${s.dir} · f${fi + 1}/${cur.frames} · ${cur.phases[fi]}${cur.events.some((e) => e.frame === fi && e.type === 'hit') ? ' ◆' : ''}${s.downed ? ' · DOWNED (R)' : ''}`);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => { cancelAnimationFrame(raf); window.removeEventListener('keydown', kd); window.removeEventListener('keyup', ku); };
  }, [project, rev]);

  return (
    <div className="grid gap-3 xl:grid-cols-[1fr_300px]">
      <Panel title="Combat test arena" right={<span className="font-mono text-[11px] text-orange-200">{hud}</span>}>
        <canvas ref={ref} tabIndex={0} className="max-w-full rounded border border-zinc-800 outline-none" style={{ imageRendering: 'pixelated' }} />
        <p className="mt-2 text-[11px] text-zinc-500">Click the arena if keys don't respond. Hit-stop freezes the impact frame for its authored duration; screen shake is an integer-pixel camera offset (sprites are never stretched or blurred).</p>
      </Panel>
      <div className="space-y-3">
        <Panel title="Controls">
          <ul className="space-y-0.5 text-[11px] text-zinc-300">
            <li><b>WASD</b> walk (facing follows input)</li><li><b>Shift</b>+WASD run</li><li><b>J</b> slash · <b>K</b> stomp · <b>L</b> charge (hold)</li><li><b>U</b> summon · <b>C</b> collapse · <b>R</b> recover · <b>H</b> hurt</li>
          </ul>
          <div className="mt-2 flex flex-wrap gap-1">{[2, 3, 4].map((z) => <Btn key={z} on={scale === z} onClick={() => setScale(z)}>{z}x</Btn>)}</div>
          <div className="mt-2 flex flex-wrap gap-1">{(Object.keys(debug) as (keyof typeof debug)[]).map((k) => <Btn key={k} on={debug[k]} onClick={() => setDebug({ ...debug, [k]: !debug[k] })}>{k}</Btn>)}</div>
        </Panel>
        <Panel title="Event log"><ul className="space-y-0.5 font-mono text-[10px] text-zinc-400">{log.map((l, i) => <li key={i} className={l.startsWith('◆') ? 'text-red-300' : ''}>{l}</li>)}</ul></Panel>
      </div>
    </div>
  );
}
export const _unused = hex;
