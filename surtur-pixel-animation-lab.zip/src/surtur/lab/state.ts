import { useCallback, useEffect, useRef, useState } from 'react';
import { ACTIONS, ACTION_MAP, type ActionDef } from '../engine/actions';
import { newProject, serializeProject, deserializeProject, type Project, type LayerName } from '../engine/render';
import type { Dir } from '../engine/rig';

const LS_KEY = 'surtur-lab-project-v1';

export function loadStoredProject(): Project {
  try { const s = localStorage.getItem(LS_KEY); if (s) return deserializeProject(s); } catch { /* corrupted → fresh */ }
  return newProject();
}

export function useProject() {
  const [project, setProject] = useState<Project>(() => loadStoredProject());
  const [rev, setRev] = useState(0);
  const [saved, setSaved] = useState<string>('');
  const timer = useRef<number | undefined>(undefined);
  const touch = useCallback((p?: Project) => {
    if (p) setProject(p);
    setRev((r) => r + 1);
  }, []);
  useEffect(() => {
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => {
      try { localStorage.setItem(LS_KEY, serializeProject(project)); setSaved(new Date().toLocaleTimeString()); }
      catch (e) { setSaved('save failed: ' + String(e)); }
    }, 400);
  }, [project, rev]);
  return { project, rev, touch, saved };
}

export type PlayMode = 'auto' | 'loop' | 'pingpong' | 'once';

export function durationsOf(p: Project, def: ActionDef) {
  return Array.from({ length: def.frames }, (_, i) => p.timing[`${def.name}|${i}`] ?? def.durations[i]);
}

/** Frame-accurate playback honouring per-frame durations, speed multiplier, reverse and loop modes. */
export function usePlayback(def: ActionDef, durations: number[], opts: { playing: boolean; speed: number; reverse: boolean; mode: PlayMode }) {
  const [frame, setFrame] = useState(0);
  const st = useRef({ t: 0, dirSign: 1, frame: 0 });
  st.current.frame = frame;
  useEffect(() => { setFrame(0); st.current.t = 0; st.current.dirSign = 1; }, [def.name]);
  useEffect(() => {
    if (!opts.playing) return;
    let raf = 0, last = performance.now();
    const loopMode = opts.mode === 'auto' ? (def.loop === 'loop' ? 'loop' : def.loop === 'hold' ? 'hold' : 'once') : opts.mode;
    const tick = (now: number) => {
      const dt = (now - last) * opts.speed; last = now;
      const s = st.current;
      s.t += dt;
      let f = s.frame;
      let guard = 0;
      while (s.t >= durations[f] && guard++ < 50) {
        s.t -= durations[f];
        const step = (opts.reverse ? -1 : 1) * s.dirSign;
        let nf = f + step;
        const n = def.frames;
        if (nf >= n || nf < 0) {
          if (loopMode === 'loop') nf = (nf + n) % n;
          else if (loopMode === 'pingpong') { s.dirSign *= -1; nf = f - step; }
          else if (loopMode === 'hold') nf = opts.reverse ? 0 : n - 2; // release-ready hold cycles the last two frames
          else { nf = f; s.t = 0; }
        }
        f = Math.max(0, Math.min(n - 1, nf));
      }
      if (f !== s.frame) setFrame(f);
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [opts.playing, opts.speed, opts.reverse, opts.mode, def, durations]);
  const set = useCallback((f: number) => { st.current.t = 0; setFrame(((f % def.frames) + def.frames) % def.frames); }, [def.frames]);
  return [frame, set] as const;
}

export interface LabSel { action: string; dir: Dir }
export const defaultVisible = (): Record<LayerName, boolean> => ({ character: true, weapon: true, emissive: true, ground_impact: true, shockwave: true, smoke: true, trail: true, flames: true, embers: true, summoned_entity: true });
export { ACTIONS, ACTION_MAP };
