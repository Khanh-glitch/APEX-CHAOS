import { useEffect, useRef } from 'react';
import { Buf } from '../engine/buf';

export type BgMode = 'dark' | 'light' | 'checker' | 'arena';

const scratch = typeof document !== 'undefined' ? document.createElement('canvas') : null;
/** Blit a pixel buffer with nearest-neighbour integer scaling. Never bilinear. */
export function drawBuf(ctx: CanvasRenderingContext2D, b: Buf, x: number, y: number, s: number, alpha = 1) {
  if (!scratch) return;
  scratch.width = b.w; scratch.height = b.h;
  const sctx = scratch.getContext('2d')!;
  sctx.putImageData(new ImageData(new Uint8ClampedArray(b.d), b.w, b.h), 0, 0);
  ctx.imageSmoothingEnabled = false;
  ctx.globalAlpha = alpha;
  ctx.drawImage(scratch, 0, 0, b.w, b.h, Math.round(x), Math.round(y), b.w * s, b.h * s);
  ctx.globalAlpha = 1;
}

export function paintBg(ctx: CanvasRenderingContext2D, w: number, h: number, mode: BgMode, s: number, groundY?: number) {
  if (mode === 'dark') { ctx.fillStyle = '#16151b'; ctx.fillRect(0, 0, w, h); }
  else if (mode === 'light') { ctx.fillStyle = '#d9d6cf'; ctx.fillRect(0, 0, w, h); }
  else if (mode === 'checker') {
    const c = 8 * s;
    for (let y = 0; y < h; y += c) for (let x = 0; x < w; x += c) { ctx.fillStyle = ((x + y) / c) % 2 ? '#3a3d47' : '#454956'; ctx.fillRect(x, y, c, c); }
  } else {
    // minimal raster test arena: basalt flagstones in pixel blocks
    ctx.fillStyle = '#1b1820'; ctx.fillRect(0, 0, w, h);
    const tile = 16 * s;
    for (let y = 0; y < h; y += tile) for (let x = 0; x < w; x += tile) {
      const k = ((x / tile) * 7 + (y / tile) * 13) % 5;
      ctx.fillStyle = ['#221e27', '#25212b', '#1f1b24', '#28232d', '#231f28'][k];
      ctx.fillRect(x + s, y + s, tile - 2 * s, tile - 2 * s);
    }
    if (groundY !== undefined) { ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.fillRect(0, groundY, w, s); }
  }
}

export function silhouette(b: Buf, color = 0x101014ff) {
  const o = new Buf(b.w, b.h);
  for (let y = 0; y < b.h; y++) for (let x = 0; x < b.w; x++) if (b.a(x, y) > 0) o.set(x, y, color);
  return o;
}

export function PixelView({ buf, scale, bg = 'checker', className, overlay, onPointer, cursor }: {
  buf: Buf; scale: number; bg?: BgMode; className?: string;
  overlay?: (ctx: CanvasRenderingContext2D, s: number) => void;
  onPointer?: (x: number, y: number, e: React.PointerEvent) => void; cursor?: string;
}) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current; if (!c) return;
    c.width = buf.w * scale; c.height = buf.h * scale;
    const ctx = c.getContext('2d')!;
    paintBg(ctx, c.width, c.height, bg, scale);
    drawBuf(ctx, buf, 0, 0, scale);
    overlay?.(ctx, scale);
  }, [buf, scale, bg, overlay]);
  const handle = (e: React.PointerEvent) => {
    if (!onPointer) return;
    const r = (e.target as HTMLCanvasElement).getBoundingClientRect();
    onPointer(Math.floor(((e.clientX - r.left) / r.width) * buf.w), Math.floor(((e.clientY - r.top) / r.height) * buf.h), e);
  };
  return <canvas ref={ref} className={className} style={{ imageRendering: 'pixelated', cursor }} onPointerDown={handle} onPointerMove={(e) => e.buttons && handle(e)} />;
}

export const Btn = ({ on, children, onClick, title, className = '' }: { on?: boolean; children: React.ReactNode; onClick?: () => void; title?: string; className?: string }) => (
  <button title={title} onClick={onClick} className={`rounded border px-2 py-1 text-xs font-medium transition ${on ? 'border-orange-500 bg-orange-600/30 text-orange-100' : 'border-zinc-700 bg-zinc-800/80 text-zinc-300 hover:border-zinc-500 hover:text-white'} ${className}`}>{children}</button>
);
export const Panel = ({ title, children, right, className = '' }: { title: string; children: React.ReactNode; right?: React.ReactNode; className?: string }) => (
  <section className={`rounded-lg border border-zinc-800 bg-zinc-900/70 ${className}`}>
    <header className="flex items-center justify-between border-b border-zinc-800 px-3 py-1.5"><h3 className="text-[11px] font-bold uppercase tracking-widest text-orange-300/90">{title}</h3>{right}</header>
    <div className="p-3">{children}</div>
  </section>
);
export function download(name: string, data: Uint8Array | string, type = 'application/octet-stream') {
  const blob = new Blob([typeof data === 'string' ? data : new Uint8Array(data)], { type });
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}
