// Minimal, dependency-light PNG codec (8-bit RGBA encode; decode types 0/2/3/4/6 @ 8-bit, non-interlaced).
// Pure TS so the exact same bytes are produced in the browser and in the Node test-runner.
import { zlibSync, unzlibSync } from 'fflate';
import { Buf } from './buf';

const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();
export function crc32(data: Uint8Array, crc = 0xffffffff) {
  for (let i = 0; i < data.length; i++) crc = CRC_TABLE[(crc ^ data[i]) & 255] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}
const u32 = (n: number) => [(n >>> 24) & 255, (n >>> 16) & 255, (n >>> 8) & 255, n & 255];

function chunk(type: string, data: Uint8Array) {
  const out = new Uint8Array(12 + data.length);
  out.set(u32(data.length), 0);
  const td = new Uint8Array(4 + data.length);
  for (let i = 0; i < 4; i++) td[i] = type.charCodeAt(i);
  td.set(data, 4);
  out.set(td, 4);
  out.set(u32(crc32(td)), 8 + data.length);
  return out;
}

export function encodePNG(b: Buf): Uint8Array {
  const raw = new Uint8Array((b.w * 4 + 1) * b.h);
  for (let y = 0; y < b.h; y++) {
    raw[y * (b.w * 4 + 1)] = 0;
    raw.set(b.d.subarray(y * b.w * 4, (y + 1) * b.w * 4), y * (b.w * 4 + 1) + 1);
  }
  const ihdr = new Uint8Array([...u32(b.w), ...u32(b.h), 8, 6, 0, 0, 0]);
  const parts = [
    new Uint8Array([137, 80, 78, 71, 13, 10, 26, 10]),
    chunk('IHDR', ihdr),
    chunk('IDAT', zlibSync(raw, { level: 9 })),
    chunk('IEND', new Uint8Array(0)),
  ];
  const len = parts.reduce((s, p) => s + p.length, 0);
  const out = new Uint8Array(len);
  let o = 0;
  for (const p of parts) (out.set(p, o), (o += p.length));
  return out;
}

export interface PNGInfo { width: number; height: number; colorType: number; bitDepth: number; interlace: number; hasAlphaChannel: boolean }

export function readPNGHeader(bytes: Uint8Array): PNGInfo | null {
  if (bytes.length < 33 || bytes[0] !== 137 || bytes[1] !== 80) return null;
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const colorType = bytes[25];
  return { width: dv.getUint32(16), height: dv.getUint32(20), bitDepth: bytes[24], colorType, interlace: bytes[28], hasAlphaChannel: colorType === 4 || colorType === 6 };
}

export function decodePNG(bytes: Uint8Array): Buf {
  const info = readPNGHeader(bytes);
  if (!info) throw new Error('Not a PNG');
  if (info.bitDepth !== 8 || info.interlace !== 0) throw new Error(`Unsupported PNG (depth ${info.bitDepth}, interlace ${info.interlace})`);
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  let p = 8;
  const idat: Uint8Array[] = [];
  let plte: Uint8Array | null = null, trns: Uint8Array | null = null;
  while (p < bytes.length) {
    const len = dv.getUint32(p);
    const type = String.fromCharCode(bytes[p + 4], bytes[p + 5], bytes[p + 6], bytes[p + 7]);
    const data = bytes.subarray(p + 8, p + 8 + len);
    if (type === 'IDAT') idat.push(data);
    else if (type === 'PLTE') plte = data;
    else if (type === 'tRNS') trns = data;
    else if (type === 'IEND') break;
    p += 12 + len;
  }
  const total = idat.reduce((s, d) => s + d.length, 0);
  const cat = new Uint8Array(total);
  let o = 0;
  for (const d of idat) (cat.set(d, o), (o += d.length));
  const raw = unzlibSync(cat);
  const bpp = { 0: 1, 2: 3, 3: 1, 4: 2, 6: 4 }[info.colorType as 0 | 2 | 3 | 4 | 6];
  if (!bpp) throw new Error('Unsupported colour type ' + info.colorType);
  const { width: w, height: h } = info;
  const stride = w * bpp;
  const px = new Uint8Array(stride * h);
  let prev = new Uint8Array(stride);
  for (let y = 0; y < h; y++) {
    const f = raw[y * (stride + 1)];
    const line = raw.subarray(y * (stride + 1) + 1, (y + 1) * (stride + 1));
    const cur = new Uint8Array(stride);
    for (let x = 0; x < stride; x++) {
      const a = x >= bpp ? cur[x - bpp] : 0, b = prev[x], c = x >= bpp ? prev[x - bpp] : 0;
      let v = line[x];
      if (f === 1) v += a;
      else if (f === 2) v += b;
      else if (f === 3) v += (a + b) >> 1;
      else if (f === 4) {
        const pp = a + b - c, pa = Math.abs(pp - a), pb = Math.abs(pp - b), pc = Math.abs(pp - c);
        v += pa <= pb && pa <= pc ? a : pb <= pc ? b : c;
      }
      cur[x] = v & 255;
    }
    px.set(cur, y * stride);
    prev = cur;
  }
  const out = new Buf(w, h);
  for (let i = 0; i < w * h; i++) {
    const t = i * 4;
    if (info.colorType === 6) { out.d[t] = px[i * 4]; out.d[t + 1] = px[i * 4 + 1]; out.d[t + 2] = px[i * 4 + 2]; out.d[t + 3] = px[i * 4 + 3]; }
    else if (info.colorType === 2) { out.d[t] = px[i * 3]; out.d[t + 1] = px[i * 3 + 1]; out.d[t + 2] = px[i * 3 + 2]; out.d[t + 3] = 255; }
    else if (info.colorType === 0) { out.d[t] = out.d[t + 1] = out.d[t + 2] = px[i]; out.d[t + 3] = 255; }
    else if (info.colorType === 4) { out.d[t] = out.d[t + 1] = out.d[t + 2] = px[i * 2]; out.d[t + 3] = px[i * 2 + 1]; }
    else if (info.colorType === 3 && plte) {
      const k = px[i];
      out.d[t] = plte[k * 3]; out.d[t + 1] = plte[k * 3 + 1]; out.d[t + 2] = plte[k * 3 + 2];
      out.d[t + 3] = trns && k < trns.length ? trns[k] : 255;
    }
  }
  return out;
}
