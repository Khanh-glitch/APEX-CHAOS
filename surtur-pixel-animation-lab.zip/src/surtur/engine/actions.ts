// Authored key poses + combat timelines. Each action: keyed poses at frame indices, interpolated into in-betweens
// (sword interpolated in yaw/pitch so swings travel real arcs), then rasterised per facing.
import type { Pose, V3 } from './rig';

export type Phase = 'loop' | 'anticipation' | 'active' | 'hit' | 'recovery' | 'hold';
export type LoopMode = 'loop' | 'once' | 'hold' | 'pingpong';
export interface GameEvent { frame: number; type: string; data?: Record<string, number | string> }
export interface HitBox { frame: number; kind: 'hit' | 'hurt'; shape: 'box' | 'circle'; f: number; r: number; w?: number; d?: number; radius?: number; damage?: number }
export interface ActionDef {
  name: string;
  label: string;
  frames: number;
  loop: LoopMode;
  durations: number[]; // ms per frame
  phases: Phase[];
  events: GameEvent[];
  rootMotion: [number, number][]; // per frame body-local [forward, right] px
  hitboxes: HitBox[];
  keys: { at: number; pose: Partial<Pose>; ease?: 'linear' | 'in' | 'out' | 'inout' }[];
  legacy?: boolean;
  bonus?: boolean;
  status: 'complete' | 'partial';
}

export const BASE: Pose = {
  pel: [0, 0, 0], lean: 0.08, side: 0, twist: 0, head: [0, 0],
  hR: [4.5, 11.5, 16], hL: [3.5, -11.5, 16], fR: [2.5, 6, 2], fL: [-2.5, -6, 2],
  sw: [42, -36], glow: 0, shrug: 0, swFree: 0, swPos: [0, 0, 0],
};
const P = (o: Partial<Pose>): Partial<Pose> => o;
const fill = <T,>(n: number, v: T): T[] => Array.from({ length: n }, () => v);
const phases = (spec: [Phase, number][]) => spec.flatMap(([p, n]) => fill(n, p));

// ---------------- walk / run cycles (authored contact/down/pass/up tables) -----------------
function walkKeys() {
  const keys: ActionDef['keys'] = [];
  const S = 4.5, N = 10, half = 5;
  const bob = [-0.5, -1.5, -0.6, 0.6, 0.3];
  const lift = [0, 2.2, 3.4, 2.4, 0.8];
  for (let i = 0; i < N; i++) {
    const footAt = (ph: number): V3 => {
      // ph 0..10 ; planted for 0..5 moving back linearly, swing 5..10
      if (ph < half) return [S - (2 * S * ph) / half, 0, 2];
      const s = (ph - half) / half;
      return [-S + 2 * S * s, 0, 2 + lift[Math.round(s * 4)]];
    };
    const r = footAt(i), l = footAt((i + half) % N);
    const k = i % half;
    const sideW = i < half ? 1 : -1;
    const swing = Math.cos((i / N) * Math.PI * 2);
    keys.push({
      at: i,
      pose: P({
        fR: [r[0], 6, r[2]], fL: [l[0], -6, l[2]],
        pel: [0.4, 0.8 * sideW * (k < 3 ? 1 : 0.4), bob[k]],
        lean: 0.12, twist: 0.12 * swing,
        hL: [2 + 4 * swing, -11.5, 16.5 + Math.max(0, swing) * 1.5],
        hR: [3 - 2 * swing, 11.5, 16 - Math.abs(swing) * 0.5],
        sw: [42 - 6 * swing, -34 + 3 * swing], glow: k === 0 ? 1 : k === 1 ? 0.5 : 0,
        shrug: bob[k] * -0.3, head: [0.3, bob[k] * 0.3],
      }),
    });
  }
  return keys;
}
function runKeys() {
  const keys: ActionDef['keys'] = [];
  const N = 8, S = 7;
  for (let i = 0; i < N; i++) {
    const footAt = (p: number): V3 => {
      if (p < 3) return [S - (2 * S * p) / 3, 0, 2]; // planted / push
      const s = (p - 3) / 5; // swing incl. flight: kick back-up then reach
      const u = 2 + [3.5, 7, 6, 3.5, 1.2][Math.min(4, Math.floor(s * 5))];
      const f = s < 0.3 ? -S - 1.5 * (s / 0.3) : -S - 1.5 + (2 * S + 1.5) * ((s - 0.3) / 0.7);
      return [f, 0, u];
    };
    const r = footAt(i), l = footAt((i + 4) % N);
    const k = i % 4;
    const swing = Math.cos((i / N) * Math.PI * 2);
    keys.push({
      at: i,
      pose: P({
        fR: [r[0], 5.5, r[2]], fL: [l[0], -5.5, l[2]],
        pel: [2, 0.6 * (i < 4 ? 1 : -1), [-1.5, -2.6, -0.5, 1.4][k]],
        lean: 0.4, twist: 0.2 * swing, head: [1.4, -0.5],
        hL: [3 + 6 * swing, -10.5, 19 + 4 * Math.max(0, swing)],
        hR: [-5 - 1.5 * swing, 11, 14.5],
        sw: [158 - 6 * swing, -22], glow: k === 0 ? 1.5 : 1, shrug: 0.3,
      }),
    });
  }
  return keys;
}

export const ACTIONS: ActionDef[] = [
  {
    name: 'idle', label: 'Idle', frames: 7, loop: 'loop', legacy: true, status: 'complete',
    durations: [180, 140, 160, 200, 150, 140, 170], phases: fill(7, 'loop'),
    events: [{ frame: 2, type: 'breath_in' }, { frame: 5, type: 'breath_out' }],
    rootMotion: fill(7, [0, 0]), hitboxes: [],
    keys: [
      { at: 0, pose: P({}) },
      { at: 1, pose: P({ pel: [0, 0, -0.5], shrug: -0.3, glow: 0.5, sw: [41, -36] }) },
      { at: 2, pose: P({ pel: [0, 0, -1], shrug: -0.7, lean: 0.11, hL: [2, -11.5, 15.5], glow: 1, sw: [40, -37] }) },
      { at: 3, pose: P({ pel: [0, 0, -1.1], shrug: -0.6, lean: 0.11, hL: [3.5, -10.5, 17], glow: 1.2, sw: [40, -37] }) },
      { at: 4, pose: P({ pel: [0, 0, -0.5], shrug: -0.2, hL: [3.5, -10.5, 17], glow: 0.4, sw: [41, -36] }) },
      { at: 5, pose: P({ pel: [0, 0, 0.2], shrug: 0.5, lean: 0.06, glow: -0.4, sw: [43, -35], head: [0, 0.4] }) },
      { at: 6, pose: P({ pel: [0, 0, 0.2], shrug: 0.4, glow: 0, sw: [43, -35], head: [0, 0.3] }) },
    ],
  },
  {
    name: 'walk', label: 'Walk', frames: 10, loop: 'loop', legacy: true, status: 'complete',
    durations: fill(10, 95), phases: fill(10, 'loop'),
    events: [{ frame: 0, type: 'footstep', data: { foot: 'R' } }, { frame: 5, type: 'footstep', data: { foot: 'L' } }],
    rootMotion: fill(10, [1.8, 0]), hitboxes: [], keys: walkKeys(),
  },
  {
    name: 'run', label: 'Run', frames: 8, loop: 'loop', status: 'complete',
    durations: fill(8, 75), phases: fill(8, 'loop'),
    events: [{ frame: 0, type: 'footstep', data: { foot: 'R' } }, { frame: 4, type: 'footstep', data: { foot: 'L' } }],
    rootMotion: fill(8, [4.67, 0]), hitboxes: [], keys: runKeys(),
  },
  {
    name: 'charge', label: 'Charge (gồng)', frames: 14, loop: 'hold', status: 'complete',
    durations: [120, 110, 110, 130, 110, 110, 100, 100, 90, 90, 90, 200, 140, 140],
    phases: phases([['anticipation', 6], ['active', 5], ['hit', 1], ['hold', 2]]),
    events: [{ frame: 2, type: 'footplant', data: { foot: 'R' } }, { frame: 3, type: 'footplant', data: { foot: 'L' } }, { frame: 6, type: 'ignite' }, { frame: 11, type: 'charge_peak' }, { frame: 12, type: 'release_ready' }],
    rootMotion: fill(14, [0, 0]), hitboxes: [{ frame: 11, kind: 'hurt', shape: 'circle', f: 0, r: 0, radius: 12 }],
    keys: [
      { at: 0, pose: P({}) },
      { at: 1, pose: P({ pel: [0, 0.8, -1], fR: [0.5, 7.5, 4], lean: 0.14, glow: 0.3 }) },
      { at: 2, pose: P({ pel: [0, -0.6, -1.6], fR: [0.5, 8.5, 2], fL: [-0.5, -7.5, 3.6], lean: 0.17, glow: 0.6 }) },
      { at: 3, pose: P({ pel: [0, 0, -2.6], fR: [0.5, 8.5, 2], fL: [-0.5, -8.5, 2], lean: 0.2, hR: [5, 6, 19], hL: [4, -6, 18], sw: [25, -55], glow: 1 }) },
      { at: 4, pose: P({ pel: [0, 0, -2.8], fR: [0.5, 8.5, 2], fL: [-0.5, -8.5, 2], lean: 0.2, hR: [5, 1.5, 20], hL: [5, -1.5, 19], sw: [6, -78], glow: 1.4 }) },
      { at: 6, pose: P({ pel: [0, 0, -2.4], fR: [0.5, 8.5, 2], fL: [-0.5, -8.5, 2], lean: 0.15, hR: [5, 1.5, 20], hL: [5, -1.5, 19], sw: [6, -79], glow: 2.2, shrug: 0.5 }) },
      { at: 8, pose: P({ pel: [0, 0.4, -2.0], fR: [0.5, 8.5, 2], fL: [-0.5, -8.5, 2], lean: 0.1, hR: [5, 1.5, 20.5], hL: [5, -1.5, 19.5], sw: [6, -79], glow: 3, shrug: 1, head: [0, 0.5] }) },
      { at: 9, pose: P({ pel: [0, -0.4, -2.0], fR: [0.5, 8.5, 2], fL: [-0.5, -8.5, 2], lean: 0.08, hR: [5, 1.5, 20.5], hL: [5, -1.5, 19.5], sw: [6, -79], glow: 3.4, shrug: 1.1, head: [0, 0.6] }) },
      { at: 10, pose: P({ pel: [0, 0.4, -1.8], fR: [0.5, 8.5, 2], fL: [-0.5, -8.5, 2], lean: 0.05, hR: [5, 1.5, 21], hL: [5, -1.5, 20], sw: [6, -80], glow: 3.8, shrug: 1.3, head: [0, 0.8] }) },
      { at: 11, pose: P({ pel: [0, 0, -1.2], fR: [0.5, 8.5, 2], fL: [-0.5, -8.5, 2], lean: -0.04, hR: [5, 2, 21.5], hL: [5, -2.5, 20.5], sw: [6, -80], glow: 5, shrug: 1.8, head: [-0.3, 1.2] }) },
      { at: 12, pose: P({ pel: [0, 0, -1.8], fR: [0.5, 8.5, 2], fL: [-0.5, -8.5, 2], lean: 0.06, hR: [5, 1.5, 21], hL: [5, -1.5, 20], sw: [6, -80], glow: 4.2, shrug: 1.2, head: [0, 0.8] }) },
      { at: 13, pose: P({ pel: [0, 0, -1.9], fR: [0.5, 8.5, 2], fL: [-0.5, -8.5, 2], lean: 0.07, hR: [5, 1.5, 21], hL: [5, -1.5, 20], sw: [6, -80], glow: 4.6, shrug: 1.1, head: [0, 0.8] }) },
    ],
  },
  {
    name: 'swipe', label: 'Swipe / Slash', frames: 10, loop: 'once', legacy: true, status: 'complete',
    durations: [90, 110, 160, 60, 50, 110, 70, 90, 110, 120],
    phases: ['anticipation', 'anticipation', 'anticipation', 'active', 'hit', 'hit', 'recovery', 'recovery', 'recovery', 'recovery'],
    events: [{ frame: 3, type: 'footplant', data: { foot: 'L' } }, { frame: 4, type: 'hit', data: { damage: 30, hitstop: 90 } }, { frame: 5, type: 'impact_hold' }],
    rootMotion: [[0, 0], [0, 0], [0, 0], [1.5, 0], [1.5, 0], [0, 0], [0, 0], [0, 0], [0, 0], [0, 0]],
    hitboxes: [
      { frame: 3, kind: 'hit', shape: 'box', f: 14, r: 10, w: 16, d: 14, damage: 0 },
      { frame: 4, kind: 'hit', shape: 'box', f: 16, r: 0, w: 34, d: 18, damage: 30 },
      { frame: 5, kind: 'hit', shape: 'box', f: 15, r: -8, w: 24, d: 16, damage: 0 },
    ],
    keys: [
      { at: 0, pose: P({ hR: [5, 10, 17], sw: [35, -25] }) },
      { at: 1, pose: P({ twist: 0.45, lean: 0.02, pel: [0, 1, -1], hR: [-3, 12, 24], sw: [140, 28], hL: [6, -6, 20], glow: 0.5 }), ease: 'out' },
      { at: 2, pose: P({ twist: 0.58, lean: 0, pel: [-0.5, 1.2, -1.6], hR: [-4.5, 11, 26.5], sw: [162, 40], hL: [7, -5, 21], glow: 1, head: [-0.3, 0] }) },
      { at: 3, pose: P({ twist: 0.25, lean: 0.15, pel: [1.2, 0.3, -1.5], fL: [2.5, -6, 4], hR: [1, 10, 23], sw: [100, 30], hL: [5, -8, 19], glow: 1.5 }) },
      { at: 4, pose: P({ twist: -0.2, lean: 0.27, pel: [2.2, -0.4, -2.4], fL: [5, -6, 2], hR: [7.5, 4, 18], sw: [12, -6], hL: [1, -11, 18], glow: 2 }) },
      { at: 5, pose: P({ twist: -0.3, lean: 0.29, pel: [2.4, -0.5, -2.6], fL: [5, -6, 2], hR: [7.5, 0, 17], sw: [-12, -9], hL: [0, -11.5, 17.5], glow: 2.5 }) },
      { at: 6, pose: P({ twist: -0.5, lean: 0.3, pel: [2, -0.8, -2.2], fL: [5, -6, 2], hR: [5, -7, 15.5], sw: [-72, -18], hL: [-3, -11, 17], glow: 1.5 }) },
      { at: 7, pose: P({ twist: -0.55, lean: 0.28, pel: [1.8, -0.8, -2], fL: [5, -6, 2], hR: [3, -9.5, 14.5], sw: [-96, -26], hL: [-3.5, -11, 16.5], glow: 1 }) },
      { at: 8, pose: P({ twist: -0.2, lean: 0.18, pel: [1, -0.3, -1], fL: [2.2, -6, 4.2], hR: [5, 4, 15], sw: [-15, -32], glow: 0.5 }) },
      { at: 9, pose: P({ twist: 0, lean: 0.1, pel: [0.2, 0, -0.2], fL: [-2.5, -6, 2], hR: [4, 10, 16], sw: [36, -30] }) },
    ],
  },
  {
    name: 'stomp', label: 'Stomp', frames: 13, loop: 'once', legacy: true, status: 'complete',
    durations: [80, 90, 110, 90, 90, 160, 50, 60, 120, 100, 100, 100, 120],
    phases: phases([['anticipation', 6], ['active', 1], ['hit', 2], ['recovery', 4]]),
    events: [{ frame: 7, type: 'hit', data: { damage: 40, hitstop: 110, radius: 26 } }, { frame: 7, type: 'shockwave' }, { frame: 12, type: 'footplant', data: { foot: 'R' } }],
    rootMotion: fill(13, [0, 0]),
    hitboxes: [
      { frame: 7, kind: 'hit', shape: 'circle', f: 4.5, r: 5.5, radius: 26, damage: 40 },
      { frame: 8, kind: 'hit', shape: 'circle', f: 4.5, r: 5.5, radius: 32, damage: 10 },
    ],
    keys: [
      { at: 0, pose: P({}) },
      { at: 1, pose: P({ pel: [0, 0, -2.5], lean: 0.2, hR: [5, 11, 15], hL: [4, -11, 15], glow: 0.5 }), ease: 'out' },
      { at: 2, pose: P({ pel: [0, 0, -3.5], lean: 0.26, shrug: -0.5, hR: [5, 11, 14], hL: [4, -11, 14], glow: 0.8 }) },
      { at: 3, pose: P({ pel: [0, -1.5, -0.6], lean: -0.04, fR: [3, 5.5, 8], hR: [2, 12, 23], sw: [62, 40], hL: [3, -12, 23], shrug: 1, glow: 1.2 }) },
      { at: 4, pose: P({ pel: [0, -1.6, 0.4], lean: -0.1, fR: [4, 5.5, 11.5], hR: [1.5, 12, 26], sw: [68, 55], hL: [2.5, -12, 26], shrug: 1.4, glow: 1.8 }) },
      { at: 5, pose: P({ pel: [0, -1.6, 0.8], lean: -0.12, fR: [4.5, 5.5, 12.5], hR: [1, 12, 27], sw: [70, 60], hL: [2, -12, 27], shrug: 1.6, glow: 2.5, head: [-0.3, 0.5] }) },
      { at: 6, pose: P({ pel: [0, -0.8, -1.5], lean: 0.18, fR: [4.5, 5.5, 5], hR: [4, 12, 19], sw: [55, 5], hL: [4, -12, 19], shrug: 0.4, glow: 3 }), ease: 'in' },
      { at: 7, pose: P({ pel: [0, 0.3, -4], lean: 0.3, fR: [4.5, 5.5, 2], hR: [6, 11, 14], sw: [40, -35], hL: [6, -10, 14], shrug: -1, glow: 4 }) },
      { at: 8, pose: P({ pel: [0, 0.3, -4.5], lean: 0.32, fR: [4.5, 5.5, 2], hR: [6, 11, 13.5], sw: [40, -36], hL: [6, -10, 13.5], shrug: -1.2, glow: 3.5 }) },
      { at: 9, pose: P({ pel: [0, 0.2, -2.6], lean: 0.18, fR: [4.5, 5.5, 2], hR: [5, 11.5, 15], sw: [41, -36], hL: [4, -11, 15], glow: 2 }) },
      { at: 10, pose: P({ pel: [0, 0, -1], lean: 0.1, fR: [4.5, 5.5, 2], glow: 1 }) },
      { at: 11, pose: P({ pel: [0, -0.5, -0.4], lean: 0.08, fR: [2.6, 5.8, 4.2], glow: 0.5 }) },
      { at: 12, pose: P({ fR: [2.5, 6, 2] }) },
    ],
  },
  {
    name: 'summon', label: 'Summon', frames: 16, loop: 'once', status: 'complete',
    durations: [90, 100, 110, 160, 70, 60, 140, 110, 110, 100, 100, 100, 110, 120, 140, 160],
    phases: phases([['anticipation', 5], ['active', 1], ['active', 6], ['hit', 2], ['recovery', 2]]),
    events: [{ frame: 5, type: 'sword_plant' }, { frame: 6, type: 'sigils_begin' }, { frame: 9, type: 'eruption' }, { frame: 13, type: 'summon_spawn', data: { f: 20, r: -10 } }],
    rootMotion: fill(16, [0, 0]),
    hitboxes: [{ frame: 9, kind: 'hit', shape: 'circle', f: 20, r: -10, radius: 12, damage: 15 }],
    keys: [
      { at: 0, pose: P({}) },
      { at: 1, pose: P({ pel: [0, 0, -0.5], hR: [3, 10, 22], sw: [60, 40], hL: [3, -11, 17], glow: 0.4 }) },
      { at: 2, pose: P({ hR: [2, 6, 28], sw: [12, 80], hL: [3, -10, 20], shrug: 1, lean: -0.08, head: [0, 0.5], glow: 0.8 }) },
      { at: 3, pose: P({ hR: [2, 5, 28.5], sw: [6, 84], hL: [3, -10, 21], shrug: 1.2, lean: -0.1, head: [-0.3, 0.7], glow: 1.2 }) },
      { at: 4, pose: P({ hR: [5.5, 4, 25], sw: [8, 20], hL: [4, -6, 21], shrug: 0.5, lean: 0.1, glow: 1.4 }), ease: 'in' },
      { at: 5, pose: P({ pel: [0, 0, -2], hR: [5, 2.5, 19], sw: [5, -80], hL: [5, -1, 18.5], lean: 0.25, shrug: -0.4, glow: 1.6 }) },
      { at: 6, pose: P({ pel: [0, 0, -2.5], hR: [5, 2.5, 19], sw: [5, -80], hL: [5, -1, 18.5], lean: 0.27, shrug: -0.5, glow: 2 }) },
      { at: 7, pose: P({ pel: [0, 0, -2], hR: [5, 2.5, 19], sw: [5, -80], hL: [8.5, -8, 21.5], lean: 0.17, glow: 2.4 }) },
      { at: 8, pose: P({ pel: [0, 0, -1.8], hR: [5, 2.5, 19], sw: [5, -80], hL: [9.5, -7.5, 24], lean: 0.12, shrug: 0.5, glow: 2.8 }) },
      { at: 10, pose: P({ pel: [0, 0, -2.1], hR: [5, 2.5, 19], sw: [5, -80], hL: [10, -6.5, 26.5], lean: 0.1, shrug: 0.8, head: [0, 0.4], glow: 3.4 }) },
      { at: 12, pose: P({ pel: [0, 0, -1.6], hR: [5, 2.5, 19], sw: [5, -80], hL: [10, -6, 27.5], lean: 0.06, shrug: 1, head: [0, 0.7], glow: 4 }) },
      { at: 13, pose: P({ pel: [0, 0, -2.2], hR: [5, 2.5, 19], sw: [5, -80], hL: [10.5, -7, 25], lean: 0.12, shrug: 0.6, head: [0.3, 0.3], glow: 4.4 }) },
      { at: 15, pose: P({ pel: [0, 0, -1.4], hR: [5, 2.5, 19], sw: [5, -80], hL: [8, -8.5, 21], lean: 0.1, shrug: 0.2, glow: 3 }) },
    ],
  },
  {
    name: 'collapse', label: 'Collapse (gục)', frames: 14, loop: 'once', status: 'complete',
    durations: [110, 110, 130, 100, 100, 110, 90, 150, 130, 90, 120, 140, 200, 400],
    phases: phases([['active', 3], ['active', 8], ['hold', 3]]),
    events: [{ frame: 2, type: 'footplant', data: { foot: 'L' } }, { frame: 6, type: 'knee_impact' }, { frame: 9, type: 'sword_drop' }, { frame: 11, type: 'body_drop' }, { frame: 13, type: 'downed' }],
    rootMotion: [[-1, 0], [-1, 0], [-0.5, 0], ...fill(11, [0, 0] as [number, number])],
    hitboxes: [],
    keys: [
      { at: 0, pose: P({ pel: [-1.5, 0, 0], lean: -0.15, head: [-0.4, 0.5], hR: [2, 12, 18], sw: [60, -12], glow: -0.5 }) },
      { at: 1, pose: P({ pel: [-2, 0, -0.3], lean: -0.2, fL: [-3, -6, 3.6], head: [-0.5, 0.4], hR: [2, 12.5, 18], sw: [65, -8], hL: [0, -12.5, 18], glow: -0.8 }) },
      { at: 2, pose: P({ pel: [-2, 0, -1.5], lean: -0.02, fL: [-3.5, -6.5, 2], hR: [3, 12, 16], sw: [55, -25], glow: -1 }) },
      { at: 3, pose: P({ pel: [-1, 0, -4], lean: 0.25, fL: [-3.5, -6.5, 2], hR: [5, 9.5, 13], sw: [35, -55], hL: [3, -11, 13], glow: -1.2 }) },
      { at: 4, pose: P({ pel: [-0.5, 0, -6], lean: 0.35, fL: [-3.5, -6.5, 2], hR: [6, 10, 10.5], sw: [30, -60], hL: [4, -11, 11], glow: -1.5 }) },
      { at: 5, pose: P({ pel: [-0.5, 0, -7], lean: 0.4, fL: [-3.5, -6.5, 2], hR: [6.5, 9, 9], sw: [22, -68], hL: [5, -11, 9], glow: -1.7 }) },
      { at: 6, pose: P({ pel: [-0.8, 0, -8], lean: 0.42, fR: [-6, 6, 1.6], fL: [-3.5, -6.5, 2], hR: [7, 9, 8.5], sw: [20, -70], hL: [5, -11, 9], head: [0.3, -0.5], glow: -2 }) },
      { at: 7, pose: P({ pel: [-0.8, 0, -8.5], lean: 0.46, fR: [-6, 6, 1.6], fL: [-3.5, -6.5, 2], hR: [7, 9, 8], sw: [20, -70], hL: [5.5, -11, 8.5], head: [0.6, -1], glow: -2 }) },
      { at: 8, pose: P({ pel: [-0.8, 0, -8.6], lean: 0.5, fR: [-6, 6, 1.6], fL: [-3.5, -6.5, 2], hR: [8, 8.5, 6.5], sw: [18, -48], hL: [6, -10.5, 7], head: [0.7, -1], glow: -2.2 }) },
      { at: 9, pose: P({ pel: [-0.8, 0, -8.8], lean: 0.56, fR: [-6, 6, 1.6], fL: [-3.5, -6.5, 2], hR: [8, 8.5, 5], sw: [-28, -2], swFree: 1, swPos: [-3, 11, 0.8], hL: [6.5, -10, 5.5], head: [0.8, -1.2], glow: -2.4 }) },
      { at: 10, pose: P({ pel: [-0.8, 0, -9.2], lean: 0.68, fR: [-6, 6, 1.6], fL: [-3.5, -6.5, 2], hR: [7.5, 8.5, 2.5], sw: [-28, -2], swFree: 1, swPos: [-3, 11, 0.8], hL: [7, -9.5, 2.5], head: [1, -1.6], glow: -2.8 }) },
      { at: 11, pose: P({ pel: [-1.2, 0, -10.2], lean: 0.8, fR: [-6, 6, 1.6], fL: [-6.5, -6, 1.6], hR: [7.5, 8.5, 2.2], sw: [-28, -2], swFree: 1, swPos: [-3, 11, 0.8], hL: [7.5, -9, 2.2], head: [1.4, -2], glow: -3.2 }) },
      { at: 12, pose: P({ pel: [-1.2, 0, -10.6], lean: 0.83, fR: [-6, 6, 1.6], fL: [-6.5, -6, 1.6], hR: [7.5, 8.5, 2], sw: [-28, -2], swFree: 1, swPos: [-3, 11, 0.8], hL: [7.5, -9, 2], head: [1.6, -2.3], glow: -3.6 }) },
      { at: 13, pose: P({ pel: [-1.2, 0, -10.7], lean: 0.84, fR: [-6, 6, 1.6], fL: [-6.5, -6, 1.6], hR: [7.5, 8.5, 2], sw: [-28, -2], swFree: 1, swPos: [-3, 11, 0.8], hL: [7.5, -9, 2], head: [1.6, -2.4], glow: -3.8 }) },
    ],
  },
  {
    name: 'hurt', label: 'Hurt (bonus)', frames: 5, loop: 'once', bonus: true, status: 'complete',
    durations: [60, 90, 110, 110, 120], phases: ['hit', 'hit', 'recovery', 'recovery', 'recovery'],
    events: [{ frame: 0, type: 'damaged' }], rootMotion: [[-1.5, 0], [-1, 0], [0, 0], [0, 0], [0, 0]], hitboxes: [],
    keys: [
      { at: 0, pose: P({ pel: [-1, 0, -0.5], lean: -0.18, head: [-0.6, 0.4], hR: [1, 12.5, 18], hL: [0, -12.5, 18], sw: [55, -22], glow: 2.5 }) },
      { at: 1, pose: P({ pel: [-1.6, 0, -1.4], lean: -0.26, head: [-0.8, 0.2], hR: [0, 13, 19], hL: [-1, -13, 19], sw: [62, -14], glow: 1.5, shrug: 1 }) },
      { at: 2, pose: P({ pel: [-0.8, 0, -1.6], lean: 0.05, hR: [2.5, 12, 16.5], sw: [48, -30], glow: 0.5 }) },
      { at: 3, pose: P({ pel: [-0.3, 0, -0.8], lean: 0.12, glow: 0.2 }) },
      { at: 4, pose: P({}) },
    ],
  },
];

export const ACTION_MAP: Record<string, ActionDef> = Object.fromEntries(ACTIONS.map((a) => [a.name, a]));
export const MANDATORY = ['idle', 'walk', 'run', 'charge', 'swipe', 'stomp', 'summon', 'collapse'];

const ease = (t: number, e?: string) => (e === 'in' ? t * t : e === 'out' ? 1 - (1 - t) * (1 - t) : e === 'inout' ? t * t * (3 - 2 * t) : t);
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const full = (p: Partial<Pose>): Pose => ({ ...BASE, ...p }) as Pose;

/** Pose at a (possibly fractional) frame time. Loops wrap between last and first key. */
export function poseAt(def: ActionDef, t: number): Pose {
  const n = def.frames;
  const keys = def.keys;
  if (def.loop === 'loop') t = ((t % n) + n) % n;
  else t = Math.max(0, Math.min(n - 1, t));
  let k0 = keys[0], k1 = keys[0];
  for (let i = 0; i < keys.length; i++) {
    if (keys[i].at <= t) { k0 = keys[i]; k1 = keys[i + 1] ?? (def.loop === 'loop' ? { ...keys[0], at: n } : keys[i]); }
  }
  const span = k1.at - k0.at;
  const u = span > 0 ? ease((t - k0.at) / span, k0.ease) : 0;
  const a = full(k0.pose), b = full(k1.pose);
  const out: Pose = { ...a };
  for (const key of Object.keys(a) as (keyof Pose)[]) {
    const va = a[key] as unknown, vb = b[key] as unknown;
    if (key === 'swFree') { (out as unknown as Record<string, unknown>)[key] = u < 1 ? a.swFree : b.swFree; continue; }
    if (key === 'swPos') { out.swPos = (u >= 1 ? b.swPos : a.swPos); continue; }
    if (Array.isArray(va)) (out as unknown as Record<string, unknown>)[key] = (va as number[]).map((x, i) => lerp(x, (vb as number[])[i], u));
    else if (typeof va === 'number') (out as unknown as Record<string, unknown>)[key] = lerp(va, vb as number, u);
  }
  return out;
}
