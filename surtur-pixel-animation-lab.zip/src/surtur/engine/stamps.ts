// Hand-authored native-resolution pixel stamps for Surtur's rigid armour parts.
// Legend: . transparent | o outline | i inner contour | k d m l h w obsidian ramp (dark→spec)
//         c n N M warm charcoal/horn | q b B burgundy | r R e a A y W emissive (glow levels 2..8)
// Character's RIGHT horn is the big hooked horn; the LEFT horn is short and chipped.
// Every facing has its own drawn head so the asymmetric horns stay on the correct side.

export interface Stamp { w: number; h: number; rows: string[]; ax: number; ay: number }

function S(rows: string[], ax: number, ay: number): Stamp {
  const w = Math.max(...rows.map((r) => r.length));
  return { w, h: rows.length, rows: rows.map((r) => r.padEnd(w, '.')), ax, ay };
}

export const HEAD = {
  front: S([
    '...oo............',
    '..oyeo...........',
    '.oaeoo...........',
    '.oRo.........o...',
    'oRNo........oao..',
    'oNno........oRro.',
    'oNno.........oNo.',
    'onNo...ooo...oNo.',
    '.oNnoomhwhmoonNo.',
    '.onNmlhhhhhlmNno.',
    '..onmllhhhllmno..',
    '..oommllllllmoo..',
    '...odbooooobdo...',
    '...odoyAoAyodo...',
    '...okdorRrodko...',
    '....okkdddkko....',
    '.....ooooooo.....',
  ], 8, 16),
  back: S([
    '............oo...',
    '...........oeyo..',
    '...........ooeao.',
    '...o.........oRo.',
    '..oao........oNRo',
    '.orRo........onNo',
    '.oNo.........onNo',
    '.oNo...ooo...oNno',
    '.oNnoomlhlmoonNo.',
    '.onNmllhwhllmNno.',
    '..onmlmhhhmlmno..',
    '..oommlhhhlmmoo..',
    '...odmmlhlmmdo...',
    '...odmrlhlmmdo...',
    '...okdmRrmmdko...',
    '....okkdddkko....',
    '.....ooooooo.....',
  ], 8, 16),
  right: S([
    '.....oo..........',
    '....oyeo.........',
    '...oaeoo.........',
    '..oRo.......oo...',
    '..oRo......oaeo..',
    '.oNo.......oRo...',
    '.oNno.....onNo...',
    '.onNo.ooooonNo...',
    '..onNomlhhhlmo...',
    '..oonmlhhwhhlmo..',
    '...onmllhhhllmo..',
    '....ommllllllmo..',
    '....odmmdboooodo.',
    '....odmmdoyAoko..',
    '....okdmmdorRo...',
    '.....okkdddkko...',
    '......ooooooo....',
  ], 8, 16),
  left: S([
    '..........oo.....',
    '.........oeyo....',
    '..........oeao...',
    '...oo.......oRo..',
    '..oaeo......oNo..',
    '...oRro.....oNo..',
    '....oNo....onNo..',
    '....oNoooooNno...',
    '...omlhhhlmnNo...',
    '..omlhhwhhlmNo...',
    '..omllhhhllmno...',
    '..omllllllmmo....',
    '.odooooobdmmdo...',
    '..okoAyodmmdo....',
    '...oRrodmmdko....',
    '...okkdddkko.....',
    '....ooooooo......',
  ], 8, 16),
};

export const CHEST = {
  front: S([
    '...ooooooooooooo...',
    '..omhhhwhlhwhhhmo..',
    '.omlhhlllklllhhlmo.',
    'odmllllmRkRmllllmdo',
    'odmmllmrmamrmllmmdo',
    'odkmmlmbaWabmlmmkdo',
    'odkmmmrmeyemrmmmkdo',
    '.odkmmmkbabkmmmkdo.',
    '.odkdmmmkrkmmmdkdo.',
    '..odkdmmmmmmmdkdo..',
    '...odkddmmmddkdo...',
    '....ooooooooooo....',
  ], 9, 6),
  back: S([
    '...ooooooooooooo...',
    '..omhhhhhwhhhhhmo..',
    '.omlhhhllhllhhhlmo.',
    'odmllllmlhlmllllmdo',
    'odmmlllmkrkmlllmmdo',
    'odkmmllmdRdmllmmkdo',
    'odkmmmmkmrmkmmmmkdo',
    '.odkmmmmkrkmmmmkdo.',
    '.odkdmmmdkdmmmdkdo.',
    '..odkdmmmmmmmdkdo..',
    '...odkddmmmddkdo...',
    '....ooooooooooo....',
  ], 9, 6),
  right: S([
    '..oooooooooo...',
    '.omhhhhhhhhmo..',
    'omlhhhhlllllhmo',
    'odmlllllllmrlmo',
    'odmmllllmmraAeo',
    'odkmrlmmmmbyWao',
    'odkmmrmmmmreaRo',
    'odkkmmmmmmmbrmo',
    '.odkmmmmmmmmmdo',
    '.odkdmmmmmmmdo.',
    '..odkdddmmmdo..',
    '...ooooooooo...',
  ], 7, 6),
};

export const WAIST = {
  front: S([
    '.ooooooooooo.',
    'odkkdBbBdkkdo',
    'odmlmkrkmlmdo',
    '.odmlmkmlmdo.',
    '.odkmo.omkdo.',
    '..ooo...ooo..',
  ], 6, 2),
  back: S([
    '.ooooooooooo.',
    'odkkdbbbdkkdo',
    'odmlmkmkmlmdo',
    '.odmlmkmlmdo.',
    '.odkmo.omkdo.',
    '..ooo...ooo..',
  ], 6, 2),
  right: S([
    '.ooooooo.',
    'odkdBbkdo',
    'odmlmmldo',
    '.odmlmdo.',
    '.odkmko..',
    '..oooo...',
  ], 4, 2),
};

// Right pauldron: big, double-spiked. Left pauldron: lower, one chipped spike.
export const PAULDRON_R = S([
  '..o....o...',
  '.oeo..oro..',
  '.oNo..oNo..',
  '.oNNooNNoo.',
  'omhhhhhhhmo',
  'omlhwhhllmo',
  'odmllllmmdo',
  'okdmmmmmdko',
  '.okdrkkdko.',
  '..ooooooo..',
], 5, 6);
export const PAULDRON_L = S([
  '......o...',
  '.....oNo..',
  '..oooonNo.',
  '.omhhhhhmo',
  'omlhhwhlmo',
  'odmlllmmdo',
  'okdmmmmdko',
  '.okkdkkko.',
  '..oooooo..',
], 5, 5);

export const GAUNTLET = S([
  'oooo...',
  'ohhmooo',
  'olhlmmo',
  'omllmdo',
  'odmrdko',
  '.ooooo.',
], 3, 3);
export const GAUNTLET_FRONT = S([
  '.oooo.',
  'omhhmo',
  'olhlmo',
  'omlmdo',
  'okrdko',
  '.oooo.',
], 3, 3);

export const BOOT = {
  front: S([
    '.oooooo.',
    'omhlhhmo',
    'omllllmo',
    'odmrmmdo',
    'okkddkko',
    '.oooooo.',
  ], 4, 5),
  back: S([
    '.oooooo.',
    'omhhhhmo',
    'odmllmdo',
    'odmmmmdo',
    'okdddkko',
    '.oooooo.',
  ], 4, 5),
  right: S([
    '.ooooo....',
    'omhhhmooo.',
    'omlllhhhmo',
    'odmmmlllmo',
    'okkdddrdko',
    '.oooooooo.',
  ], 3, 5),
};

export const KNEE = S([
  '.ooo.',
  'ohhmo',
  'omldo',
  '.oko.',
  '..o..',
], 2, 2);

// Summoned flame-being authored stages (stage 1 = ember seed handled procedurally; 2..4 here).
// Uses fire chars: Y white-core, A amber, a orange, e ember, r red, s smoke-dark core, o outline-dark.
export const BEING = {
  pillar: S([
    '.....r.....',
    '....rer....',
    '...reaer...',
    '...eaAae...',
    '..raAYAar..',
    '..eaAYAae..',
    '..eaAYAae..',
    '.reaAYAaer.',
    '.eaAYYYAae.',
    'reaAYYYAaer',
    'eaAAYYYAAae',
  ], 5, 10),
  form: S([
    '......r.r......',
    '.....rerer.....',
    '....reaAaer....',
    '....eaAsAae....',
    '...r.eaAae.r...',
    '..re.eaaae.er..',
    '..ea.raAar.ae..',
    '.rea.eaYae.aer.',
    '.ea..eAYAe..ae.',
    '.r...eaYae...r.',
    '.....raAar.....',
    '....reaAaer....',
    '...reaAYAaer...',
    '..reaAYYYAaer..',
  ], 7, 13),
  full: S([
    '.r.........r...',
    'rer.......rer..',
    '.ea.......ae...',
    '.eae.rrr.eae...',
    '..eaeaAaeae....',
    '...eaAsAae.....',
    '...eAsYsAe.....',
    '..reaAYAaer....',
    '.reaaAYAaaer...',
    'rea.eAYAe.aer..',
    'ea..eaYae..ae..',
    'eAr.eAYAe.rAe..',
    '.r..reaear..r..',
    '....ea.ae......',
    '...rea.aer.....',
    '..reaA.Aaer....',
    '.reaAY.YAaer...',
  ], 7, 16),
};

// Ground sigils — 5x5 runes, authored, appear one by one around the ritual circle.
export const RUNES: Stamp[] = [
  S(['a...a', '.a.a.', '..A..', '.a.a.', 'a...a'], 2, 2),
  S(['.aaa.', 'a.A..', 'aaAaa', '..A.a', '.aaa.'], 2, 2),
  S(['A....', 'aa...', 'a.a..', 'a..a.', 'aaaaA'], 2, 2),
  S(['..a..', '.aAa.', 'a.A.a', '..a..', '.a.a.'], 2, 2),
  S(['aa.aa', 'a...a', '..A..', 'a...a', 'aa.aa'], 2, 2),
  S(['.a.a.', 'aAaAa', '.a.a.', '..a..', '.aaa.'], 2, 2),
];
