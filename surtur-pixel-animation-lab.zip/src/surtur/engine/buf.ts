import type { RGBA } from './palette';

/** Plain RGBA pixel buffer — the only image primitive in the engine. No smoothing anywhere. */
export class Buf {
  w: number;
  h: number;
  d: Uint8ClampedArray;
  constructor(w: number, h: number, d?: Uint8ClampedArray) {
    this.w = w;
    this.h = h;
    this.d = d ?? new Uint8ClampedArray(w * h * 4);
  }
  inb(x: number, y: number) {
    return x >= 0 && y >= 0 && x < this.w && y < this.h;
  }
  set(x: number, y: number, c: RGBA) {
    x |= 0;
    y |= 0;
    if (!this.inb(x, y)) return;
    const i = (y * this.w + x) * 4;
    this.d[i] = (c >>> 24) & 255;
    this.d[i + 1] = (c >>> 16) & 255;
    this.d[i + 2] = (c >>> 8) & 255;
    this.d[i + 3] = c & 255;
  }
  get(x: number, y: number): RGBA {
    if (!this.inb(x, y)) return 0;
    const i = (y * this.w + x) * 4;
    return ((this.d[i] << 24) | (this.d[i + 1] << 16) | (this.d[i + 2] << 8) | this.d[i + 3]) >>> 0;
  }
  a(x: number, y: number) {
    if (!this.inb(x, y)) return 0;
    return this.d[(y * this.w + x) * 4 + 3];
  }
  clearPx(x: number, y: number) {
    if (!this.inb(x, y)) return;
    const i = (y * this.w + x) * 4;
    this.d[i] = this.d[i + 1] = this.d[i + 2] = this.d[i + 3] = 0;
  }
  clone() {
    return new Buf(this.w, this.h, new Uint8ClampedArray(this.d));
  }
  /** Alpha-over blit with integer offset. Pixel art uses binary alpha; partial alpha is composited for layer opacity only. */
  blit(src: Buf, dx: number, dy: number, opacity = 1) {
    dx |= 0;
    dy |= 0;
    for (let y = 0; y < src.h; y++) {
      const ty = y + dy;
      if (ty < 0 || ty >= this.h) continue;
      for (let x = 0; x < src.w; x++) {
        const tx = x + dx;
        if (tx < 0 || tx >= this.w) continue;
        const si = (y * src.w + x) * 4;
        const sa = (src.d[si + 3] / 255) * opacity;
        if (sa <= 0) continue;
        const ti = (ty * this.w + tx) * 4;
        if (sa >= 1) {
          this.d[ti] = src.d[si];
          this.d[ti + 1] = src.d[si + 1];
          this.d[ti + 2] = src.d[si + 2];
          this.d[ti + 3] = 255;
        } else {
          const ta = this.d[ti + 3] / 255;
          const oa = sa + ta * (1 - sa);
          for (let k = 0; k < 3; k++) this.d[ti + k] = (src.d[si + k] * sa + this.d[ti + k] * ta * (1 - sa)) / (oa || 1);
          this.d[ti + 3] = oa * 255;
        }
      }
    }
  }
  bounds(): { x0: number; y0: number; x1: number; y1: number } | null {
    let x0 = this.w, y0 = this.h, x1 = -1, y1 = -1;
    for (let y = 0; y < this.h; y++)
      for (let x = 0; x < this.w; x++)
        if (this.d[(y * this.w + x) * 4 + 3] > 0) {
          if (x < x0) x0 = x;
          if (x > x1) x1 = x;
          if (y < y0) y0 = y;
          if (y > y1) y1 = y;
        }
    return x1 < 0 ? null : { x0, y0, x1, y1 };
  }
  opaqueCount() {
    let n = 0;
    for (let i = 3; i < this.d.length; i += 4) if (this.d[i] > 0) n++;
    return n;
  }
  crop(x: number, y: number, w: number, h: number) {
    const o = new Buf(w, h);
    for (let yy = 0; yy < h; yy++)
      for (let xx = 0; xx < w; xx++) {
        if (!this.inb(x + xx, y + yy)) continue;
        const si = ((y + yy) * this.w + x + xx) * 4, ti = (yy * w + xx) * 4;
        o.d[ti] = this.d[si]; o.d[ti + 1] = this.d[si + 1]; o.d[ti + 2] = this.d[si + 2]; o.d[ti + 3] = this.d[si + 3];
      }
    return o;
  }
  equals(o: Buf) {
    if (o.w !== this.w || o.h !== this.h) return false;
    for (let i = 0; i < this.d.length; i++) if (this.d[i] !== o.d[i]) return false;
    return true;
  }
}

/** Deterministic RNG (mulberry32). */
export function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
export function hash(...n: (number | string)[]) {
  let h = 2166136261;
  for (const v of n) {
    const s = String(v);
    for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619);
    h = Math.imul(h ^ 124, 16777619);
  }
  return h >>> 0;
}
export const noise2 = (x: number, y: number, s: number) => (hash(x | 0, y | 0, s) % 1000) / 1000;
