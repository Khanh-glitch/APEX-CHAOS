// Directed raster VFX. All effects live in world space (f,r,u), are projected per facing (so trail, shockwave
// perspective and ground decals change with direction) and are baked to discrete pixels. Deterministic by seed.
import { Buf, rng, hash, noise2 } from './buf';
import { FIRE, ASH, SMOKE, ROCK, CRACK, SIGIL, type RGBA } from './palette';
import { project, solve, type Dir, type V3, type Pose, ROOT_X, ROOT_Y } from './rig';
import { BEING, RUNES, type Stamp } from './stamps';
import type { ActionDef } from './actions';
import { poseAt } from './actions';

export const FX_W = 128, FX_H = 112, FX_RX = 64, FX_RY = 84;
export const FX_OFF_X = FX_RX - ROOT_X, FX_OFF_Y = FX_RY - ROOT_Y; // cell origin inside the FX canvas
export const FX_LAYERS = ['ground_impact', 'shockwave', 'smoke', 'trail', 'flames', 'embers', 'summoned_entity'] as const;
export type FxLayer = (typeof FX_LAYERS)[number];

const P = (v: V3, dir: Dir) => project(v, dir, FX_RX, FX_RY);
const put = (b: Buf, x: number, y: number, c: RGBA) => b.set(Math.round(x), Math.round(y), c);
const lifeCol = (k: number, ramp: RGBA[] = FIRE) => ramp[Math.min(ramp.length - 1, Math.max(0, Math.floor(k * ramp.length)))];

function line(b: Buf, x0: number, y0: number, x1: number, y1: number, c: RGBA | ((t: number) => RGBA | 0)) {
  x0 = Math.round(x0); y0 = Math.round(y0); x1 = Math.round(x1); y1 = Math.round(y1);
  const n = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0), 1);
  for (let i = 0; i <= n; i++) {
    const t = i / n;
    const col = typeof c === 'function' ? c(t) : c;
    if (col) b.set(Math.round(x0 + (x1 - x0) * t), Math.round(y0 + (y1 - y0) * t), col);
  }
}

/** Turbulent flame tongue: hot core, orange body, sparse red breakup, detached cooling ash. */
export function flame(b: Buf, x: number, y: number, H: number, W: number, drift: { x: number; y: number }, seed: number, frame: number) {
  if (H < 1) return;
  const sway = Math.sin(frame * 1.7 + seed) * 0.9;
  for (let j = 0; j < H; j++) {
    const k = j / H;
    const cx = x + drift.x * Math.pow(k, 1.4) + sway * k + (noise2(j, frame, seed) - 0.5) * 1.1 * k;
    const cy = y - j + drift.y * Math.pow(k, 1.4);
    const w = Math.max(0, W * Math.pow(1 - k, 0.85) + (noise2(j + 9, frame, seed) - 0.5) * 0.8);
    const half = w / 2;
    for (let xx = Math.floor(cx - half); xx <= Math.ceil(cx + half - 0.5); xx++) {
      const e = Math.abs(xx + 0.5 - cx) / Math.max(half, 0.5);
      if (k > 0.55 && noise2(xx, j * 31 + frame, seed) < k * 0.55) continue; // breakup
      let idx = k < 0.25 && e < 0.45 ? 0 : k < 0.45 && e < 0.6 ? 1 : k < 0.7 ? (e < 0.5 ? 2 : 3) : e < 0.4 ? 3 : 4;
      if (k > 0.85) idx = 5;
      b.set(xx, Math.round(cy), FIRE[idx]);
    }
  }
  // detached licks / ash
  const r = rng(hash(seed, frame));
  if (r() < 0.75) put(b, x + drift.x + sway + (r() - 0.5) * 2, y - H - 1 - r() * 2 + drift.y, FIRE[r() < 0.5 ? 4 : 5]);
  if (r() < 0.4) put(b, x + drift.x * 1.2 + (r() - 0.5) * 3, y - H - 3 - r() * 2 + drift.y, ASH[1]);
}

function blob(b: Buf, x: number, y: number, size: number, ramp: RGBA[], fade: number, seed: number) {
  const shapes = [
    ['.#.', '###'],
    ['.##.', '####', '.##.'],
    ['..##.', '.####', '#####', '.###.'],
  ];
  const s = shapes[Math.min(2, Math.max(0, size))];
  const ox = Math.round(x - s[0].length / 2), oy = Math.round(y - s.length / 2);
  s.forEach((row, j) => [...row].forEach((ch, i) => {
    if (ch !== '#') return;
    if (fade > 0 && ((i + j + seed) % 2 === 0 ? fade > 0.3 : fade > 0.75)) return; // ordered dither dissolve
    b.set(ox + i, oy + j, ramp[j === 0 ? 0 : j === s.length - 1 ? ramp.length - 1 : Math.min(1, ramp.length - 1)]);
  }));
}

function stampFire(b: Buf, s: Stamp, x: number, y: number, frame: number, seed: number) {
  const map: Record<string, RGBA> = { Y: FIRE[0], A: FIRE[1], a: FIRE[2], e: FIRE[3], r: FIRE[4], s: SMOKE[2] };
  const ox = Math.round(x) - s.ax, oy = Math.round(y) - s.ay;
  for (let j = 0; j < s.h; j++) for (let i = 0; i < s.w; i++) {
    const ch = s.rows[j][i];
    if (ch === '.') continue;
    if (ch === 'r' && noise2(i, j + frame * 7, seed) < 0.3) continue;
    let c = map[ch] ?? FIRE[3];
    if ((ch === 'a' || ch === 'e') && noise2(i * 3, j + frame, seed) < 0.18) c = map[ch === 'a' ? 'A' : 'a'];
    b.set(ox + i, oy + j, c);
  }
  // sparse dark-red rim on the lower half so the being reads against the ground
  for (let j = s.h >> 1; j < s.h; j++) for (let i = 0; i < s.w; i++) {
    if (s.rows[j][i] !== '.') continue;
    const nb = (s.rows[j][i - 1] ?? '.') !== '.' || (s.rows[j][i + 1] ?? '.') !== '.';
    if (nb && (i + j) % 2 === 0) b.set(ox + i, oy + j, FIRE[6]);
  }
}

function fillQuad(b: Buf, q: { x: number; y: number }[], col: (x: number, y: number) => RGBA | 0) {
  const minx = Math.floor(Math.min(...q.map((p) => p.x))), maxx = Math.ceil(Math.max(...q.map((p) => p.x)));
  const miny = Math.floor(Math.min(...q.map((p) => p.y))), maxy = Math.ceil(Math.max(...q.map((p) => p.y)));
  for (let y = miny; y <= maxy; y++) for (let x = minx; x <= maxx; x++) {
    const px = x + 0.5, py = y + 0.5;
    let pos = 0, neg = 0;
    for (let i = 0; i < q.length; i++) {
      const a = q[i], c = q[(i + 1) % q.length];
      const cr = (c.x - a.x) * (py - a.y) - (c.y - a.y) * (px - a.x);
      if (cr > 0.01) pos++; else if (cr < -0.01) neg++;
    }
    if (pos && neg) continue;
    const cc = col(x, y);
    if (cc) b.set(x, y, cc);
  }
}

interface Particle { s: number; life: number; o: V3; v: V3; g: number; kind: 'ember' | 'lava' | 'rock' | 'smoke' | 'dust' }
function simulate(p: Particle, age: number): V3 {
  const pos: V3 = [p.o[0] + p.v[0] * age, p.o[1] + p.v[1] * age, p.o[2] + p.v[2] * age - 0.5 * p.g * age * age];
  if (pos[2] < 0) pos[2] = 0;
  return pos;
}
function drawParticle(L: Record<FxLayer, Buf>, p: Particle, age: number, dir: Dir, seed: number) {
  const k = age / p.life;
  const pos = simulate(p, age), prev = simulate(p, Math.max(0, age - 0.45));
  const a = P(pos, dir), b = P(prev, dir);
  if (p.kind === 'ember') {
    put(L.embers, a.x, a.y, lifeCol(k * 0.95));
    if (Math.hypot(a.x - b.x, a.y - b.y) > 1.2 && k < 0.6) put(L.embers, b.x, b.y, lifeCol(Math.min(0.99, k + 0.35)));
  } else if (p.kind === 'lava') {
    const grounded = pos[2] <= 0;
    put(L.embers, a.x, a.y, grounded ? lifeCol(0.55 + k * 0.4) : lifeCol(k * 0.7));
    if (!grounded) put(L.embers, b.x, b.y, lifeCol(Math.min(0.99, k * 0.7 + 0.3)));
    else put(L.ground_impact, a.x + 1, a.y, FIRE[5]);
  } else if (p.kind === 'rock') {
    const big = seed % 3 === 0;
    put(L.embers, a.x, a.y, ROCK[3]); put(L.embers, a.x + 1, a.y, ROCK[2]);
    put(L.embers, a.x, a.y + 1, ROCK[1]); put(L.embers, a.x + 1, a.y + 1, ROCK[0]);
    if (big) { put(L.embers, a.x + 2, a.y + 1, ROCK[1]); put(L.embers, a.x - 1, a.y, ROCK[2]); }
    if (k < 0.4) put(L.embers, a.x, a.y - 1, FIRE[3]); // hot fleck
  } else if (p.kind === 'smoke') {
    blob(L.smoke, a.x, a.y, Math.min(2, Math.floor(k * 3)), SMOKE, Math.max(0, (k - 0.55) / 0.45), seed);
  } else if (p.kind === 'dust') {
    blob(L.shockwave, a.x, a.y, k < 0.5 ? 1 : 0, ASH.slice(1), Math.max(0, (k - 0.4) / 0.6), seed);
  }
}

function particles(seed: number, n: number, gen: (r: () => number, i: number) => Particle | null): Particle[] {
  const out: Particle[] = [];
  for (let i = 0; i < n; i++) { const p = gen(rng(hash(seed, i)), i); if (p) out.push(p); }
  return out;
}

function crackPaths(seed: number, n: number, minL: number, maxL: number) {
  const paths: { pts: [number, number][]; L: number }[] = [];
  for (let i = 0; i < n; i++) {
    const r = rng(hash(seed, 'crack', i));
    let a = (i / n) * Math.PI * 2 + (r() - 0.5) * 0.6;
    const L = minL + r() * (maxL - minL);
    const pts: [number, number][] = [[0, 0]];
    let x = 0, y = 0;
    for (let d = 0; d < L; d += 2) { a += (r() - 0.5) * 0.9; x += Math.cos(a) * 2; y += Math.sin(a) * 2; pts.push([x, y]); }
    paths.push({ pts, L });
  }
  return paths;
}
function drawCracks(b: Buf, dir: Dir, c: V3, paths: { pts: [number, number][]; L: number }[], grow: number, heat: number, rot = 0) {
  for (const path of paths) {
    const visible = Math.floor(path.pts.length * Math.min(1, grow));
    for (let i = 1; i < visible; i++) {
      const [ax, ay] = path.pts[i - 1], [bx, by] = path.pts[i];
      const ra = rot ? [ax * Math.cos(rot) - ay * Math.sin(rot), ax * Math.sin(rot) + ay * Math.cos(rot)] : [ax, ay];
      const rb = rot ? [bx * Math.cos(rot) - by * Math.sin(rot), bx * Math.sin(rot) + by * Math.cos(rot)] : [bx, by];
      const A = P([c[0] + ra[0], c[1] + ra[1], 0], dir), B = P([c[0] + rb[0], c[1] + rb[1], 0], dir);
      const t = i / path.pts.length;
      line(b, A.x, A.y + 1, B.x, B.y + 1, CRACK);
      const h = heat * (1 - t * 0.7);
      line(b, A.x, A.y, B.x, B.y, h > 0.75 ? FIRE[1] : h > 0.5 ? FIRE[2] : h > 0.3 ? FIRE[3] : h > 0.12 ? FIRE[4] : CRACK);
    }
  }
}

function emptyLayers(): Record<FxLayer, Buf> {
  return Object.fromEntries(FX_LAYERS.map((l) => [l, new Buf(FX_W, FX_H)])) as Record<FxLayer, Buf>;
}

export interface FxMeta { summonBehind: boolean; trailBehind: boolean }

export function renderFX(def: ActionDef, dir: Dir, frame: number, pose: Pose, emitters: { x: number; y: number; kind: string }[]): { layers: Record<FxLayer, Buf>; meta: FxMeta } {
  const L = emptyLayers();
  const n = def.frames;
  const seed = hash(def.name);
  const speed = def.rootMotion[frame]?.[0] ?? 0;
  const w0 = P([0, 0, 0], dir), wv = P([-1.2 - speed * 1.3, 0, 0], dir);
  const drift = { x: wv.x - w0.x, y: wv.y - w0.y - 0.5 };
  const meta: FxMeta = { summonBehind: false, trailBehind: dir === 'back' };

  // --- character-bound flames: horns + shoulder spikes, scaled by heat --------------------
  const heat = pose.glow;
  for (const e of emitters) {
    const x = e.x + FX_OFF_X, y = e.y + FX_OFF_Y;
    const s = hash(seed, e.kind, e.x & 3);
    if (e.kind === 'horn') {
      const H = Math.round(1.5 + heat * 0.6 + (def.name === 'run' ? 1.5 : 0) + (noise2(frame, e.x, 3) > 0.5 ? 1 : 0));
      if (H >= 2) flame(L.flames, x, y - 1, Math.min(H, 5), 1.6 + Math.max(0, heat * 0.15), drift, s, frame);
      else if (frame % 2 === 0) put(L.smoke, x, y - 2 - (frame % 3), SMOKE[0]);
    } else if (e.kind === 'shoulder') {
      const H = Math.round(2 + heat * 0.7 + (def.name === 'run' ? 2.5 : 0) + noise2(frame, e.y, 5) * 1.5);
      // shoulder licks lean outward/back so they never stack over the horns
      if (H >= 2) flame(L.flames, x, y + 1, Math.min(H, 7), 2.2 + Math.max(0, heat * 0.2), { x: drift.x + (e.x < 32 ? -1.5 : 1.5), y: drift.y }, s, frame);
    }
  }
  // --- ambient embers / smoke (loop-safe) --------------------------------------------------
  const amb = particles(hash(seed, 'amb'), 9 + Math.max(0, Math.round(heat * 3)), (r) => ({
    s: r() * n, life: 3 + r() * 3, o: [r() * 6 - 3, (r() < 0.5 ? -1 : 1) * (6 + r() * 5), 24 + r() * 8], v: [(r() - 0.5) * 0.5 - speed * 0.4, (r() - 0.5) * 0.7, 1.4 + r() * 1.3], g: -0.05, kind: 'ember',
  }));
  for (const p of amb) {
    const age = def.loop === 'loop' ? (frame - p.s + n) % n : frame - p.s;
    if (age >= 0 && age < p.life) drawParticle(L, p, age, dir, 1);
  }
  const smk = particles(hash(seed, 'smk'), 4, (r) => ({ s: r() * n, life: 4 + r() * 3, o: [-3 + r() * 2, (r() - 0.5) * 14, 30], v: [-0.6 - speed * 0.5, (r() - 0.5) * 0.4, 1.3], g: 0, kind: 'smoke' }));
  for (const p of smk) { const age = def.loop === 'loop' ? (frame - p.s + n) % n : frame - p.s; if (age >= 0 && age < p.life) drawParticle(L, p, age, dir, 2); }

  // --- per-action bespoke effects -----------------------------------------------------------
  const footFx = (ev: number, foot: 'R' | 'L', strong: boolean) => {
    const age = frame - ev;
    if (age < 0 || age > 3) return;
    const pz = poseAt(def, ev);
    const f = foot === 'R' ? pz.fR : pz.fL;
    const dust = particles(hash(seed, 'dust', ev), strong ? 6 : 3, (r) => ({ s: 0, life: 3.5, o: [f[0], f[1], 0.5], v: [(r() - 0.7) * (strong ? 2 : 1), (r() - 0.5) * 2, 0.4 + r() * 0.5], g: 0.1, kind: 'dust' }));
    dust.forEach((p, i) => drawParticle(L, p, age, dir, i));
    if (strong) particles(hash(seed, 'kick', ev), 3, (r) => ({ s: 0, life: 3, o: [f[0], f[1], 1], v: [-1 - r(), (r() - 0.5), 1.5 + r()], g: 0.6, kind: 'ember' })).forEach((p) => drawParticle(L, p, age, dir, 0));
  };
  if (def.name === 'walk' || def.name === 'run') {
    for (const ev of def.events.filter((e) => e.type === 'footstep')) {
      for (const off of [0, n]) footFx(ev.frame - off, ev.data!.foot as 'R' | 'L', def.name === 'run');
    }
  }

  if (def.name === 'swipe') trail(L, def, dir, frame, 2.6, 7);

  if (def.name === 'stomp') {
    const hit = 7, C: V3 = [4.5, 5.5, 0];
    const age = frame - hit;
    if (age >= 0) {
      drawCracks(L.ground_impact, dir, C, crackPaths(seed, 9, 12, 26), (age + 1) / 3, Math.max(0, 1 - age / 6));
      // scorched crater: irregular rock lip
      for (let a = 0; a < 40; a++) {
        const ang = (a / 40) * Math.PI * 2, rr = 4 + noise2(a, 0, seed) * 2.5;
        const q = P([C[0] + Math.cos(ang) * rr, C[1] + Math.sin(ang) * rr, 0], dir);
        put(L.ground_impact, q.x, q.y, a % 3 === 0 ? ROCK[3] : ROCK[1]);
      }
      const q0 = P(C, dir);
      for (let j = -1; j <= 1; j++) for (let i = -3; i <= 3; i++) if (Math.abs(i) + Math.abs(j) * 2 < 4) put(L.ground_impact, q0.x + i, q0.y + j, age < 3 ? FIRE[2 + Math.abs(i) % 2] : age < 5 ? FIRE[4] : ROCK[0]);
    }
    if (age >= 0 && age <= 4) {
      // broken dust/heat front on the ground plane — not a clean ring
      const R = 6 + age * 7;
      for (let a = 0; a < 64; a++) {
        if (noise2(a >> 2, 1, seed) < 0.28 + age * 0.12) continue;
        const ang = (a / 64) * Math.PI * 2, rr = R + noise2(a, age, seed) * 3;
        const q = P([C[0] + Math.cos(ang) * rr, C[1] + Math.sin(ang) * rr, 0], dir);
        put(L.shockwave, q.x, q.y, age < 2 && a % 2 ? FIRE[3] : ASH[age < 2 ? 0 : 1]);
        put(L.shockwave, q.x + 1, q.y, ASH[2]);
        if (age < 2 && a % 5 === 0) put(L.shockwave, q.x, q.y - 1, FIRE[2]);
      }
    }
    const ej = particles(hash(seed, 'ej'), 26, (r, i) => {
      const ang = r() * Math.PI * 2, sp = 1 + r() * 1.8;
      const kind = i < 10 ? 'rock' : i < 22 ? 'lava' : 'smoke';
      return { s: hit + (kind === 'smoke' ? 1 + r() * 2 : r() * 1.2), life: kind === 'smoke' ? 4 + r() * 2 : 4 + r() * 2, o: [C[0] + Math.cos(ang) * 3, C[1] + Math.sin(ang) * 3, 1], v: [Math.cos(ang) * sp, Math.sin(ang) * sp, kind === 'smoke' ? 0.9 : 2.5 + r() * 2.5], g: kind === 'rock' ? 1.2 : kind === 'lava' ? 1 : 0, kind } as Particle;
    });
    ej.forEach((p, i) => { const a = frame - p.s; if (a >= 0 && (a < p.life || p.kind === 'rock')) drawParticle(L, p, p.kind === 'rock' ? Math.min(a, p.life) : a, dir, i); });
  }

  if (def.name === 'charge') {
    const lvl = Math.max(0, (frame - 3) / 8);
    const core = solve(pose).chest;
    const conv = particles(hash(seed, 'conv'), 34, (r) => {
      const ang = r() * Math.PI * 2, rad = 14 + r() * 8;
      return { s: 3 + r() * 9, life: 3, o: [Math.cos(ang) * rad, Math.sin(ang) * rad, r() * 4], v: [0, 0, 0], g: 0, kind: 'ember' };
    });
    conv.forEach((p) => {
      const a = frame - p.s; if (a < 0 || a >= p.life) return;
      const k = a / p.life, kk = k * k;
      const pos: V3 = [p.o[0] + (core[0] - p.o[0]) * kk, p.o[1] + (core[1] - p.o[1]) * kk, p.o[2] + (core[2] - p.o[2]) * k];
      const q = P(pos, dir), q2 = P([pos[0] * 1.15, pos[1] * 1.15, pos[2] - 1.5], dir);
      put(L.embers, q.x, q.y, FIRE[k > 0.6 ? 1 : 2]); put(L.embers, q2.x, q2.y, FIRE[4]);
    });
    if (frame >= 3) {
      drawCracks(L.ground_impact, dir, [0.5, 8.5, 0], crackPaths(hash(seed, 'r'), 3, 3, 3 + lvl * 6), 1, 0.3 + lvl * 0.6);
      drawCracks(L.ground_impact, dir, [-0.5, -8.5, 0], crackPaths(hash(seed, 'l'), 3, 3, 3 + lvl * 6), 1, 0.3 + lvl * 0.6, 1);
    }
    if (frame >= 11) {
      // contained peak: radial flame spikes from the core (streaks, not a ring)
      const q = P(core, dir);
      const spikes = frame === 11 ? 10 : 6;
      for (let i = 0; i < spikes; i++) {
        const ang = (i / spikes) * Math.PI * 2 + noise2(i, frame, seed) * 0.5;
        const len = (frame === 11 ? 7 : 4) + noise2(i, 2, seed) * 4;
        line(L.flames, q.x + Math.cos(ang) * 4, q.y + Math.sin(ang) * 3, q.x + Math.cos(ang) * (4 + len), q.y + Math.sin(ang) * (3 + len * 0.75), (t) => (t > 0.8 && i % 2 ? 0 : FIRE[Math.min(5, Math.floor(t * 5))]));
      }
    }
  }

  if (def.name === 'summon') summonFx(L, def, dir, frame, seed, meta);

  if (def.name === 'collapse') {
    const evs: [number, V3, number][] = [[6, [-6, 6, 0], 5], [9, [12, 12, 0], 4], [11, [4, 0, 0], 8]];
    for (const [ev, c, count] of evs) {
      const age = frame - ev;
      if (age < 0 || age > 4) continue;
      particles(hash(seed, ev), count, (r) => { const a = r() * Math.PI * 2; return { s: 0, life: 4, o: [c[0], c[1], 0.5], v: [Math.cos(a) * 1.6, Math.sin(a) * 1.6, 0.3], g: 0, kind: 'dust' }; }).forEach((p, i) => drawParticle(L, p, age, dir, i));
      if (ev === 9) particles(hash(seed, 'spark'), 6, (r) => ({ s: 0, life: 3, o: c, v: [(r() - 0.5) * 3, (r() - 0.5) * 3, 1.5 + r() * 2], g: 1, kind: 'ember' })).forEach((p) => drawParticle(L, p, age, dir, 0));
    }
    const sm = particles(hash(seed, 'csm'), 10, (r) => ({ s: 4 + r() * 9, life: 5, o: [2 + r() * 4, (r() - 0.5) * 14, 14 + r() * 8], v: [-0.3, (r() - 0.5) * 0.5, 1.1], g: 0, kind: 'smoke' }));
    sm.forEach((p, i) => { const a = frame - p.s; if (a >= 0 && a < p.life) drawParticle(L, p, a, dir, i); });
  }

  if (def.name === 'hurt' && frame <= 2) {
    const core = solve(pose).chest;
    particles(hash(seed, 'hs'), 9, (r) => ({ s: 0, life: 3, o: core, v: [-1 - r() * 2, (r() - 0.5) * 4, (r() - 0.3) * 3], g: 0.6, kind: 'ember' })).forEach((p) => drawParticle(L, p, frame, dir, 0));
  }
  return { layers: L, meta };
}

/** Fiery blade trail swept from the physical blade path (sub-frame pose sampling). */
function trail(L: Record<FxLayer, Buf>, def: ActionDef, dir: Dir, frame: number, from: number, to: number) {
  if (frame < from + 0.5 || frame > to) return;
  const span = 1.9;
  const t1 = frame, t0 = Math.max(from, frame - span);
  const steps = 14;
  const seg = (t: number, along: number) => { const sk = solve(poseAt(def, t)); const p: V3 = [sk.grip[0] + (sk.tip[0] - sk.grip[0]) * along, sk.grip[1] + (sk.tip[1] - sk.grip[1]) * along, sk.grip[2] + (sk.tip[2] - sk.grip[2]) * along]; return P(p, dir); };
  const fadeOut = frame > 5 ? (frame - 5) / 2.5 : 0;
  for (let i = 0; i < steps; i++) {
    const ta = t0 + ((t1 - t0) * i) / steps, tb = t0 + ((t1 - t0) * (i + 1)) / steps;
    const age = 1 - (i + 1) / steps; // 0 = newest
    const q = [seg(ta, 0.4), seg(ta, 1.05), seg(tb, 1.05), seg(tb, 0.4)];
    fillQuad(L.trail, q, (x, y) => {
      if (noise2(x, y, frame) < age * 0.75 + fadeOut * 0.6) return 0;
      const k = age + fadeOut * 0.4;
      return FIRE[Math.min(6, Math.floor(k * 6.5))];
    });
    // hot leading rim near the blade edge
    const a = seg(ta, 1.05), b = seg(tb, 1.05);
    if (age < 0.5 && fadeOut < 0.6) line(L.trail, a.x, a.y, b.x, b.y, FIRE[age < 0.2 ? 0 : 1]);
  }
  // sparks shed from the trail tail
  const r = rng(hash('trail', frame, dir));
  for (let i = 0; i < 5; i++) { const p = seg(t0 + r() * 0.4, 0.6 + r() * 0.45); put(L.embers, p.x + (r() - 0.5) * 4, p.y + r() * 3, FIRE[3 + (i % 3)]); }
}

function summonFx(L: Record<FxLayer, Buf>, def: ActionDef, dir: Dir, frame: number, seed: number, meta: FxMeta) {
  const S: V3 = [20, -10, 0];
  const sp = P(S, dir);
  meta.summonBehind = sp.z < 0;
  const plant = solve(poseAt(def, 5)).tip;
  const T: V3 = [plant[0], plant[1], 0];
  if (frame >= 5) {
    // crack line from sword point to the ritual site
    const age = frame - 5;
    const pts: V3[] = [];
    const r = rng(hash(seed, 'link'));
    for (let i = 0; i <= 10; i++) { const t = i / 10; pts.push([T[0] + (S[0] - T[0]) * t + (r() - 0.5) * 2.5, T[1] + (S[1] - T[1]) * t + (r() - 0.5) * 2.5, 0]); }
    const vis = Math.min(10, Math.floor(age * 3.5));
    for (let i = 1; i <= vis; i++) {
      const a = P(pts[i - 1], dir), b = P(pts[i], dir);
      line(L.ground_impact, a.x, a.y + 1, b.x, b.y + 1, CRACK);
      line(L.ground_impact, a.x, a.y, b.x, b.y, FIRE[(i + frame) % 3 === 0 ? 1 : 3]);
    }
    drawCracks(L.ground_impact, dir, T, crackPaths(hash(seed, 'plant'), 5, 4, 9), (age + 1) / 2, Math.max(0.25, 1 - age / 8));
  }
  // runes appear one per frame around the ritual site
  for (let i = 0; i < 6; i++) {
    const appear = 6 + i;
    if (frame < appear) continue;
    const ang = (i / 6) * Math.PI * 2 + 0.3;
    const q = P([S[0] + Math.cos(ang) * 10, S[1] + Math.sin(ang) * 10, 0], dir);
    const rune = RUNES[i];
    const hot = frame - appear < 2 ? 0 : 1 + ((frame + i) % 2);
    const ox = Math.round(q.x) - rune.ax, oy = Math.round(q.y) - 1;
    for (let j = 0; j < rune.h; j++) for (let k = 0; k < rune.w; k++) {
      const ch = rune.rows[j][k];
      if (ch === '.') continue;
      // runes lie on the ground: squash rows 2:1 following ground-plane perspective
      if (j % 2 === 1 && j !== 2) continue;
      L.ground_impact.set(ox + k, oy + (j >> 1), ch === 'A' ? SIGIL[hot] : SIGIL[Math.min(4, hot + 1)]);
    }
  }
  // magma pool
  if (frame >= 8) {
    const g = Math.min(1, (frame - 7) / 3);
    for (let a = -8; a <= 8; a++) for (let b = -8; b <= 8; b++) {
      const d = Math.hypot(a, b) / (6.5 * g + 0.5) + (noise2(a, b, seed) - 0.5) * 0.35;
      if (d > 1) continue;
      const q = P([S[0] + a, S[1] + b, 0], dir);
      const c = d > 0.85 ? ROCK[1] : d > 0.65 ? FIRE[5] : noise2(a + frame, b, 7) < 0.2 ? ROCK[2] : d > 0.4 ? FIRE[3] : FIRE[2];
      put(L.ground_impact, q.x, q.y, c);
    }
  }
  if (frame >= 9) {
    particles(hash(seed, 'erupt'), 22, (r) => { const a = r() * Math.PI * 2; return { s: 9 + r() * 6, life: 3 + r() * 2, o: [S[0] + Math.cos(a) * 2, S[1] + Math.sin(a) * 2, 1], v: [Math.cos(a) * (0.6 + r()), Math.sin(a) * (0.6 + r()), 3 + r() * 3], g: 1.1, kind: 'lava' }; })
      .forEach((p, i) => { const a = frame - p.s; if (a >= 0 && a < p.life) drawParticle(L, p, a, dir, i); });
  }
  // channel stream: embers travel from the open left hand to the site
  if (frame >= 7) {
    const sk = solve(poseAt(def, frame));
    const H = sk.haL;
    for (let i = 0; i < 9; i++) {
      const t = ((frame * 0.37 + i / 9) % 1);
      const wob = Math.sin(t * 9 + i) * 1.5;
      const pos: V3 = [H[0] + (S[0] - H[0]) * t, H[1] + (S[1] - H[1]) * t + wob, H[2] + (6 - H[2]) * t + Math.sin(t * Math.PI) * 4];
      const q = P(pos, dir);
      put(L.embers, q.x, q.y, FIRE[t < 0.3 ? 1 : t < 0.7 ? 2 : 3]);
    }
  }
  // summoned flame-being: seed → pillar → forming humanoid → full horned being
  const B = L.summoned_entity;
  if (frame >= 9 && frame <= 10) flame(B, sp.x, sp.y, 5 + (frame - 9) * 4, 3 + (frame - 9), { x: 0, y: 0 }, seed, frame);
  else if (frame >= 11 && frame <= 12) { stampFire(B, BEING.pillar, sp.x, sp.y, frame, seed); flame(B, sp.x, sp.y - 10, 4, 3, { x: 0, y: 0 }, seed + 1, frame); }
  else if (frame === 13) { stampFire(B, BEING.form, sp.x, sp.y, frame, seed); flame(B, sp.x, sp.y - 13, 4, 3, { x: 0, y: 0 }, seed + 2, frame); }
  else if (frame >= 14) {
    stampFire(B, BEING.full, sp.x, sp.y, frame, seed);
    flame(B, sp.x - 6, sp.y - 16, 3, 2, { x: 0, y: 0 }, seed + 3, frame);
    flame(B, sp.x + 4, sp.y - 16, 3, 2, { x: 0, y: 0 }, seed + 4, frame);
  }
}
