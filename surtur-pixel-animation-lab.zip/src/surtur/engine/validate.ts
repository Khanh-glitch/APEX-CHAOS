import { unzipSync, strFromU8 } from 'fflate';
import { Buf } from './buf';
import { decodePNG, readPNGHeader } from './png';
import { ACTIONS, ACTION_MAP, MANDATORY } from './actions';
import { DIRS, CELL, ROOT_X, ROOT_Y } from './rig';
import { FX_W, FX_H } from './fx';
import { getFrame, compositeCell, compositeFX, coreCell, serializeProject, deserializeProject, newProject, okey, type Project } from './render';
import { LEGACY, rowFilePath, buildLegacyZip, buildFullZip } from './export';

export interface Check { id: string; group: string; pass: boolean; warn?: boolean; detail: string }

export const KEYMAP: Record<string, string> = { KeyJ: 'swipe', KeyK: 'stomp', KeyL: 'charge', KeyU: 'summon', KeyC: 'collapse', KeyH: 'hurt' };
export const TARGET_COUNTS: Record<string, [number, number]> = { idle: [7, 7], walk: [10, 10], swipe: [10, 10], stomp: [13, 13], run: [8, 10], charge: [12, 16], summon: [14, 18], collapse: [12, 16] };

export function runValidation(p: Project, log: (s: string) => void = () => {}): Check[] {
  const out: Check[] = [];
  const add = (group: string, id: string, pass: boolean, detail: string, warn = false) => { out.push({ group, id, pass, detail, warn }); log(`${pass ? (warn ? 'WARN' : 'PASS') : 'FAIL'} [${group}] ${id}: ${detail}`); };

  // ---- action set
  for (const name of MANDATORY) {
    const def = ACTION_MAP[name];
    const [lo, hi] = TARGET_COUNTS[name];
    add('actions', `${name}.present`, !!def, def ? `${def.frames} frames` : 'missing');
    if (def) {
      add('actions', `${name}.frameCount`, def.frames >= lo && def.frames <= hi, `${def.frames} (target ${lo}${hi !== lo ? '–' + hi : ''})`);
      add('actions', `${name}.timeline`, def.durations.length === def.frames && def.phases.length === def.frames && def.rootMotion.length === def.frames, 'durations/phases/rootMotion arrays sized to frame count');
    }
  }
  // ---- per-frame art checks
  let clipped = 0, rootBad = 0, dupes: string[] = [], noSword = 0; const hidden: string[] = [];
  for (const def of ACTIONS) for (const dir of DIRS) {
    let prev: Buf | null = null;
    for (let i = 0; i < def.frames; i++) {
      const fr = getFrame(p, def.name, dir, i);
      const core = coreCell(fr);
      const bb = core.bounds();
      if (!bb || bb.x0 <= 0 || bb.y0 <= 0 || bb.x1 >= CELL - 1 || bb.y1 >= CELL - 1) { clipped++; if (clipped < 6) log(`  clip ${def.name}/${dir}/${i} ${JSON.stringify(bb)}`); }
      if (fr.anchors.root[0] !== ROOT_X || fr.anchors.root[1] !== ROOT_Y) rootBad++;
      if (fr.layers.weapon.opaqueCount() < 6) { noSword++; hidden.push(`${def.name}/${dir}/${i}`); }
      if (prev && prev.equals(core) && def.phases[i] !== 'hold') dupes.push(`${def.name}/${dir}/${i}`);
      prev = core;
    }
  }
  add('art', 'noClippedCoreCharacter', clipped === 0, clipped ? `${clipped} frames touch the 64x64 cell edge` : 'core character (body+weapon+emissive) inside every 64x64 cell with ≥1px margin');
  add('art', 'rootAnchorConstant', rootBad === 0, `root anchor fixed at (${ROOT_X},${ROOT_Y}) in all frames`);
  add('art', 'swordVisibility', noSword <= 8, noSword ? `${noSword} frames with sword fully occluded by the body (expected for back-view frontal holds): ${hidden.join(', ')}` : 'weapon visible in every frame', noSword > 0);
  add('art', 'noDuplicatePaddingFrames', dupes.length === 0, dupes.length ? `identical consecutive frames: ${dupes.slice(0, 8).join(', ')}` : 'no consecutive identical frames outside authored holds');
  // planted-foot consistency: idle feet must not move; walk planted foot must move at root speed
  for (const dir of DIRS) {
    const fx = new Set<string>();
    for (let i = 0; i < 7; i++) fx.add(JSON.stringify([getFrame(p, 'idle', dir, i).anchors.footR, getFrame(p, 'idle', dir, i).anchors.footL]));
    add('anchors', `idle.${dir}.feetPlanted`, fx.size === 1, fx.size === 1 ? 'feet anchors identical across idle' : `${fx.size} distinct foot positions`);
  }
  const walkSlide = (() => { const def = ACTION_MAP.walk; let worst = 0; for (let i = 0; i < 4; i++) { const a = getFrame(p, 'walk', 'right', i).anchors.footR[0], b = getFrame(p, 'walk', 'right', i + 1).anchors.footR[0]; worst = Math.max(worst, Math.abs((a - b) - def.rootMotion[i][0])); } return worst; })();
  add('anchors', 'walk.plantedFootMatchesRootMotion', walkSlide <= 1.01, `max planted-foot vs root-motion error ${walkSlide.toFixed(2)}px (≤1px rounding allowed)`);
  // directional distinctness (not mirrored/rotated copies)
  for (const def of ACTIONS) {
    const L = compositeCell(getFrame(p, def.name, 'left', 0), false), R = compositeCell(getFrame(p, def.name, 'right', 0), false);
    const mirrored = new Buf(CELL, CELL); for (let y = 0; y < CELL; y++) for (let x = 0; x < CELL; x++) mirrored.set(CELL - 1 - x, y, R.get(x, y));
    const F = compositeCell(getFrame(p, def.name, 'front', 0), false), B = compositeCell(getFrame(p, def.name, 'back', 0), false);
    add('directions', `${def.name}.leftNotMirrorOfRight`, !mirrored.equals(L) && !F.equals(B), 'left≠mirror(right), front≠back');
  }
  // events / hitboxes / input map
  for (const def of ACTIONS) {
    for (const e of def.events) if (e.frame < 0 || e.frame >= def.frames) add('events', `${def.name}.${e.type}`, false, `event frame ${e.frame} out of range`);
    for (const e of def.events.filter((e) => e.type === 'hit')) add('events', `${def.name}.hitHasHitbox`, def.hitboxes.some((h) => h.frame === e.frame && h.kind === 'hit'), `hit event frame ${e.frame} has authored hitbox; phase=${def.phases[e.frame]}`);
  }
  for (const [k, a] of Object.entries(KEYMAP)) add('input', `${k}->${a}`, !!ACTION_MAP[a], `key ${k} triggers ${a}`);
  add('input', 'Shift+WASD->run, WASD->walk', !!ACTION_MAP.run && !!ACTION_MAP.walk, 'locomotion actions exist');

  // ---- legacy export roundtrip
  const legacy = unzipSync(buildLegacyZip(p, true));
  for (const [action, spec] of Object.entries(LEGACY)) {
    const m = legacy[spec.master];
    const h = m && readPNGHeader(m);
    add('legacy', `${action}.master`, !!h && h.width === spec.frames * 64 && h.height === 256 && h.colorType === 6, h ? `${spec.master} ${h.width}x${h.height} colorType ${h.colorType} (expect ${spec.frames * 64}x256 RGBA)` : 'missing');
    if (!m) continue;
    const mb = decodePNG(m);
    spec.rows.forEach((dir, r) => {
      const rf = legacy[rowFilePath(action, dir)];
      const rb = rf && decodePNG(rf);
      const expect = new Buf(spec.frames * CELL, CELL);
      for (let i = 0; i < spec.frames; i++) expect.blit(compositeCell(getFrame(p, action, dir, i), true), i * CELL, 0);
      const ok = !!rb && rb.w === spec.frames * 64 && rb.h === 64 && rb.equals(mb.crop(0, r * 64, mb.w, 64)) && rb.equals(expect);
      add('legacy', `${action}.row${r}.${dir}`, ok, `${rowFilePath(action, dir)} = master row ${r} = authored ${dir} frames`);
    });
    let hasAlpha = false; for (let i = 3; i < mb.d.length; i += 4) if (mb.d[i] === 0) { hasAlpha = true; break; }
    add('legacy', `${action}.transparent`, hasAlpha, 'transparent background pixels present');
  }
  add('legacy', 'noExtraFiles', Object.keys(legacy).length === 20, `${Object.keys(legacy).length} files (4 masters + 16 row files)`);

  // ---- full export roundtrip
  const full = unzipSync(buildFullZip(p, { frames: false }));
  const man = JSON.parse(strFromU8(full['surtur/manifest.json']));
  add('full', 'manifest', man.format === 'surtur-animation' && !!man.version, `manifest v${man.version}`);
  for (const def of ACTIONS) {
    const a = man.animations[def.name];
    const durOk = a && JSON.stringify(a.durationsMs) === JSON.stringify(Array.from({ length: def.frames }, (_, i) => p.timing[`${def.name}|${i}`] ?? def.durations[i]));
    add('full', `${def.name}.timings`, !!durOk, 'durations serialised exactly');
    const sheet = full[`surtur/sheets/${def.name}.png`];
    const sb = sheet && decodePNG(sheet);
    let match = !!sb && sb.w === def.frames * 64 && sb.h === 256;
    if (sb && match) DIRS.forEach((dir, r) => { for (let i = 0; i < def.frames && match; i++) match = sb.crop(i * 64, r * 64, 64, 64).equals(compositeCell(getFrame(p, def.name, dir, i), true)); });
    add('full', `${def.name}.sheetRoundtrip`, match, `sheet ${sb?.w}x${sb?.h} re-decoded == authored frames (4 dirs)`);
    const fxs = full[`surtur/fx/${def.name}_fx.png`];
    const fb = fxs && decodePNG(fxs);
    add('full', `${def.name}.fxSheet`, !!fb && fb.w === def.frames * FX_W && fb.h === 4 * FX_H && fb.crop(0, 0, FX_W, FX_H).equals(compositeFX(getFrame(p, def.name, 'front', 0))), `${FX_W}x${FX_H} FX cells`);
    for (const dir of DIRS) if (!a?.frames?.[dir]?.length) add('full', `${def.name}.${dir}.missing`, false, 'missing direction in manifest');
  }
  add('full', 'preview.html', !!full['surtur/preview.html'] && strFromU8(full['surtur/preview.html']).includes('data:image/png;base64'), 'self-contained offline preview');

  // ---- project roundtrip with an actual edit
  const test: Project = { ...newProject(), overrides: { ...p.overrides }, anchors: { ...p.anchors }, timing: { ...p.timing, 'idle|0': 222 } };
  const ed = getFrame(test, 'idle', 'front', 0).layers.character.clone();
  ed.set(5, 5, 0xff00ffff);
  test.overrides[okey('idle', 'front', 0, 'character')] = ed;
  const re = deserializeProject(serializeProject(test));
  const back = getFrame(re, 'idle', 'front', 0);
  add('project', 'saveLoadRoundtrip', back.layers.character.get(5, 5) === 0xff00ffff && back.durationMs === 222, 'edited pixel + timing survive serialise→parse');
  const reZip = unzipSync(buildFullZip(re, { frames: false }));
  const s2 = decodePNG(reZip['surtur/sheets/idle.png']);
  add('project', 'editAffectsExport', s2.get(5, 5) === 0xff00ffff, 'pixel edit visible in exported sheet');
  return out;
}
