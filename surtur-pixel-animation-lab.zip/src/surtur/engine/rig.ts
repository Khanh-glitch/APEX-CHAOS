// Surtur rig → raster. Key poses are authored as 3D body-local joint targets (f=forward, r=character-right, u=up, 1 unit = 1 px).
// Each facing is projected with its own camera mapping (top-down 3/4) and composited from hand-drawn stamps for
// that facing; limbs are pixel-plotted armour segments with ramp shading. No whole-sprite rotation / scaling / mirroring.
import { Buf } from './buf';
import { CHAR_COLORS, GLOW_CHARS, GLOW, OUTLINE, OUTLINE_IN, OBSIDIAN, glowAt, type RGBA } from './palette';
import { HEAD, CHEST, WAIST, PAULDRON_R, PAULDRON_L, GAUNTLET, GAUNTLET_FRONT, BOOT, KNEE, type Stamp } from './stamps';

export type Dir = 'front' | 'back' | 'left' | 'right';
export const DIRS: Dir[] = ['front', 'back', 'left', 'right'];
export type V3 = [number, number, number];

export interface Pose {
  pel: V3;
  lean: number;
  side: number;
  twist: number;
  head: [number, number];
  hR: V3;
  hL: V3;
  fR: V3;
  fL: V3;
  sw: [number, number]; // yaw deg (0 fwd, +90 char-right), pitch deg (+up)
  glow: number;
  shrug: number;
  swFree: number; // >=0.5 → sword detached, grip at swPos
  swPos: V3;
}

export const CELL = 64;
export const ROOT_X = 32;
export const ROOT_Y = 55;
export const DEPTH_Y = 0.45; // top-down 3/4 ground foreshortening
export const BLADE_LEN = 19;
export const POMMEL_LEN = 3;

const add = (a: V3, b: V3): V3 => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const sub = (a: V3, b: V3): V3 => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const mul = (a: V3, s: number): V3 => [a[0] * s, a[1] * s, a[2] * s];
const dot = (a: V3, b: V3) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const len = (a: V3) => Math.hypot(a[0], a[1], a[2]);
const norm = (a: V3): V3 => { const l = len(a) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };

export function ik(a: V3, t: V3, l1: number, l2: number, pole: V3): V3 {
  const dv = sub(t, a);
  const d = Math.min(Math.max(len(dv), 0.01), l1 + l2 - 0.05);
  const dir = norm(dv);
  const x = (l1 * l1 - l2 * l2 + d * d) / (2 * d);
  const h = Math.sqrt(Math.max(0, l1 * l1 - x * x));
  let p = sub(pole, mul(dir, dot(pole, dir)));
  p = norm(p);
  return add(add(a, mul(dir, x)), mul(p, h));
}

export interface Skeleton {
  pelvis: V3; waist: V3; chest: V3; neck: V3;
  shR: V3; shL: V3; elR: V3; elL: V3; haR: V3; haL: V3;
  hipR: V3; hipL: V3; knR: V3; knL: V3; ftR: V3; ftL: V3;
  grip: V3; tip: V3; pommel: V3; swordDir: V3;
}

export function swordVec(yawDeg: number, pitchDeg: number): V3 {
  const y = (yawDeg * Math.PI) / 180, p = (pitchDeg * Math.PI) / 180;
  return [Math.cos(p) * Math.cos(y), Math.cos(p) * Math.sin(y), Math.sin(p)];
}

export function solve(p: Pose): Skeleton {
  const pelvis: V3 = [p.pel[0], p.pel[1], 15 + p.pel[2]];
  const upT = norm([Math.sin(p.lean) * Math.cos(p.side), Math.sin(p.side), Math.cos(p.lean) * Math.cos(p.side)]);
  const rightT: V3 = [-Math.sin(p.twist), Math.cos(p.twist), 0];
  const waist = add(pelvis, mul(upT, 2));
  const chest = add(pelvis, mul(upT, 11));
  const neck = add(add(pelvis, mul(upT, 17)), [p.head[0], 0, p.head[1]]);
  const shBase = add(chest, mul(upT, 2.5 + p.shrug));
  const shR = add(shBase, mul(rightT, 9));
  const shL = add(shBase, mul(rightT, -9));
  const hipTw = p.twist * 0.3;
  const hipR = add(pelvis, [-Math.sin(hipTw) * 4.5, Math.cos(hipTw) * 4.5, 0]);
  const hipL = add(pelvis, [Math.sin(hipTw) * 4.5, -Math.cos(hipTw) * 4.5, 0]);
  const elR = ik(shR, p.hR, 7, 7.5, [-1, 0.9, -0.2]);
  const elL = ik(shL, p.hL, 7, 7.5, [-1, -0.9, -0.2]);
  const haR = add(elR, mul(norm(sub(p.hR, elR)), Math.min(7.5, len(sub(p.hR, elR)))));
  const haL = add(elL, mul(norm(sub(p.hL, elL)), Math.min(7.5, len(sub(p.hL, elL)))));
  const knR = ik(hipR, p.fR, 7.5, 7, [1, 0.3, 0]);
  const knL = ik(hipL, p.fL, 7.5, 7, [1, -0.3, 0]);
  // knees rest on the floor instead of passing through it when kneeling
  if (knR[2] < 1.5) knR[2] = 1.5;
  if (knL[2] < 1.5) knL[2] = 1.5;
  const ftR = add(knR, mul(norm(sub(p.fR, knR)), Math.min(7, len(sub(p.fR, knR)))));
  const ftL = add(knL, mul(norm(sub(p.fL, knL)), Math.min(7, len(sub(p.fL, knL)))));
  const swordDir = swordVec(p.sw[0], p.sw[1]);
  const grip = p.swFree >= 0.5 ? p.swPos : haR;
  const tip = add(grip, mul(swordDir, BLADE_LEN));
  const pommel = add(grip, mul(swordDir, -POMMEL_LEN));
  return { pelvis, waist, chest, neck, shR, shL, elR, elL, haR, haL, hipR, hipL, knR, knL, ftR, ftL, grip, tip, pommel, swordDir };
}

/** Facing-specific camera mapping. z = toward camera (used for depth sort and ground foreshortening). */
export function project(p: V3, dir: Dir, ox = ROOT_X, oy = ROOT_Y) {
  let x = 0, z = 0;
  switch (dir) {
    case 'front': x = -p[1]; z = p[0]; break;
    case 'back': x = p[1]; z = -p[0]; break;
    case 'left': x = -p[0]; z = -p[1]; break;
    case 'right': x = p[0]; z = p[1]; break;
  }
  return { x: ox + x, y: oy - p[2] + z * DEPTH_Y, z };
}
/** Screen-space facing sign: +1 = forward is screen-right. */
export const facingX: Record<Dir, number> = { front: 0, back: 0, left: -1, right: 1 };

// --------------------------------------------------------------------------------------------
// Part buffers: colour + emissive level + outline flags. One reusable scratch set.
class Part {
  c = new Buf(CELL, CELL);
  g = new Int8Array(CELL * CELL).fill(-1);
  o = new Uint8Array(CELL * CELL);
  touched: number[] = [];
  reset() {
    for (const i of this.touched) { this.c.d[i * 4 + 3] = 0; this.g[i] = -1; this.o[i] = 0; }
    this.touched.length = 0;
  }
  put(x: number, y: number, col: RGBA, glow = -1, outline = 0) {
    x = Math.round(x); y = Math.round(y);
    if (x < 0 || y < 0 || x >= CELL || y >= CELL) return;
    const i = y * CELL + x;
    if (this.c.d[i * 4 + 3] === 0) this.touched.push(i);
    this.c.set(x, y, col);
    this.g[i] = glow;
    this.o[i] = outline;
  }
  filled(x: number, y: number) { return x >= 0 && y >= 0 && x < CELL && y < CELL && this.c.d[(y * CELL + x) * 4 + 3] > 0 && !this.o[y * CELL + x]; }
  /** 4-neighbour outline ring around current fill. */
  ring() {
    const add: number[] = [];
    for (const i of [...this.touched]) {
      if (this.o[i]) continue;
      const x = i % CELL, y = (i / CELL) | 0;
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const nx = x + dx, ny = y + dy;
        if (nx < 0 || ny < 0 || nx >= CELL || ny >= CELL) continue;
        if (this.c.d[(ny * CELL + nx) * 4 + 3] === 0) add.push(nx, ny);
      }
    }
    for (let k = 0; k < add.length; k += 2) if (this.c.a(add[k], add[k + 1]) === 0) this.put(add[k], add[k + 1], OUTLINE, -1, 1);
  }
}

export function drawStamp(part: Part, s: Stamp, x: number, y: number, mirror = false) {
  const ox = Math.round(x) - (mirror ? s.w - 1 - s.ax : s.ax), oy = Math.round(y) - s.ay;
  for (let j = 0; j < s.h; j++)
    for (let i = 0; i < s.w; i++) {
      const ch = s.rows[j][mirror ? s.w - 1 - i : i];
      if (ch === '.') continue;
      if (ch === 'o') part.put(ox + i, oy + j, OUTLINE, -1, 1);
      else if (GLOW_CHARS[ch] !== undefined) part.put(ox + i, oy + j, GLOW[0], GLOW_CHARS[ch]);
      else part.put(ox + i, oy + j, CHAR_COLORS[ch] ?? OBSIDIAN[2]);
    }
}

type P2 = { x: number; y: number };
const LIGHT = { x: -0.55, y: -0.83 };

/** Pixel-plotted armour segment with radius profile, ramp shading, plate seams and crack pixels. */
function drawLimb(part: Part, a: P2, b: P2, ra: number, rb: number, seams: number[], cracks: [number, number][], bulge = 0) {
  const minx = Math.floor(Math.min(a.x, b.x) - Math.max(ra, rb) - 2), maxx = Math.ceil(Math.max(a.x, b.x) + Math.max(ra, rb) + 2);
  const miny = Math.floor(Math.min(a.y, b.y) - Math.max(ra, rb) - 2), maxy = Math.ceil(Math.max(a.y, b.y) + Math.max(ra, rb) + 2);
  const vx = b.x - a.x, vy = b.y - a.y, L2 = vx * vx + vy * vy || 0.0001, L = Math.sqrt(L2);
  for (let y = miny; y <= maxy; y++)
    for (let x = minx; x <= maxx; x++) {
      const px = x + 0.5 - a.x, py = y + 0.5 - a.y;
      let t = (px * vx + py * vy) / L2;
      t = Math.max(0, Math.min(1, t));
      const cx = a.x + vx * t, cy = a.y + vy * t;
      const dx = x + 0.5 - cx, dy = y + 0.5 - cy;
      const dist = Math.hypot(dx, dy);
      const r = ra + (rb - ra) * t + bulge * Math.sin(Math.PI * t);
      if (dist > r) continue;
      const k = dist / (r || 1);
      const nx = dist > 0.01 ? dx / dist : 0, ny = dist > 0.01 ? dy / dist : 0;
      const shade = -(nx * LIGHT.x + ny * LIGHT.y) * k + 0.1 * (1 - k);
      let col = shade > 0.5 ? OBSIDIAN[4] : shade > 0.12 ? OBSIDIAN[3] : shade > -0.32 ? OBSIDIAN[2] : shade > -0.7 ? OBSIDIAN[1] : OBSIDIAN[0];
      for (const s of seams) if (Math.abs(t - s) * L < 0.6) col = OBSIDIAN[1];
      part.put(x, y, col);
    }
  // Authored crack pixels (fixed along-limb positions so they never shimmer).
  const px = -vy / L, py = vx / L;
  for (const [t, s] of cracks) {
    const r = ra + (rb - ra) * t;
    const x = a.x + vx * t + px * s * r * 0.6, y = a.y + vy * t + py * s * r * 0.6;
    part.put(Math.floor(x), Math.floor(y), GLOW[0], 4);
    part.put(Math.floor(x + vx / L), Math.floor(y + vy / L), GLOW[0], 2);
  }
  part.ring();
}

/** Jagged molten greatsword, rasterised along its projected axis. */
function drawSword(part: Part, grip: P2, tip: P2, pommel: P2, cut = 1) {
  const vx = tip.x - grip.x, vy = tip.y - grip.y;
  const L = Math.hypot(vx, vy);
  const ux = L > 0.01 ? vx / L : 0, uy = L > 0.01 ? vy / L : 1;
  const nx = -uy, ny = ux;
  // grip & pommel
  const steps = Math.ceil(Math.hypot(pommel.x - grip.x, pommel.y - grip.y) * 2) + 1;
  for (let s = 0; s <= steps; s++) {
    const t = s / steps;
    part.put(Math.floor(grip.x + (pommel.x - grip.x) * t), Math.floor(grip.y + (pommel.y - grip.y) * t), CHAR_COLORS.n);
  }
  part.put(Math.floor(pommel.x), Math.floor(pommel.y), GLOW[0], 5);
  // blade
  const minx = Math.floor(Math.min(grip.x, tip.x) - 5), maxx = Math.ceil(Math.max(grip.x, tip.x) + 5);
  const miny = Math.floor(Math.min(grip.y, tip.y) - 5), maxy = Math.ceil(Math.max(grip.y, tip.y) + 5);
  const fore = Math.max(L, 8); // end-on blades keep a minimum readable foreshortened mass
  for (let y = miny; y <= maxy; y++)
    for (let x = minx; x <= maxx; x++) {
      const px = x + 0.5 - grip.x, py = y + 0.5 - grip.y;
      const along = px * ux + py * uy, across = px * nx + py * ny;
      if (along < 0.8 || along > fore + 0.5 || along > fore * cut + 0.3) continue;
      const t = along / fore;
      let hw = t < 0.82 ? 2.9 - t * 0.9 : (2.9 - 0.82 * 0.9) * (1 - (t - 0.82) / 0.2) + 0.35;
      // serrated back edge (across < 0): three teeth
      const tooth = across < 0 && [0.22, 0.46, 0.7].some((c) => t > c - 0.06 && t < c + 0.03) ? 1.3 : 0;
      if (across > hw || across < -(hw + tooth)) continue;
      const rel = across / hw;
      if (tooth && across < -hw) { part.put(x, y, OBSIDIAN[2]); continue; }
      if (Math.abs(rel) < 0.34 && t < 0.97) part.put(x, y, GLOW[0], t < 0.15 ? 7 : t < 0.6 ? 6 : 5);
      else if (rel > 0.34) part.put(x, y, GLOW[0], t < 0.5 ? 4 : 3);
      else part.put(x, y, rel < -0.75 ? OBSIDIAN[1] : OBSIDIAN[3]);
    }
  // crossguard
  for (let s = -3; s <= 3; s++) {
    const gx = grip.x + ux * 1.2 + nx * s, gy = grip.y + uy * 1.2 + ny * s;
    part.put(Math.floor(gx), Math.floor(gy), Math.abs(s) === 3 ? CHAR_COLORS.N : CHAR_COLORS.M);
  }
  part.ring();
}

export interface CharLayers {
  character: Buf; weapon: Buf; emissive: Buf;
  anchors: Record<string, [number, number]>;
  emitters: { x: number; y: number; kind: 'horn' | 'shoulder' | 'blade' | 'core' }[];
  glowLevels: Int8Array;
}

// horn / spike tip pixels in stamp-local coords per facing (for flame emitters)
const HORN_TIPS: Record<Dir, [number, number][]> = {
  front: [[3, 0], [13, 3]], back: [[13, 0], [3, 3]], right: [[5, 0], [12, 3]], left: [[11, 0], [3, 3]],
};

export function renderCharacter(pose: Pose, dir: Dir, frameSeed: number): CharLayers {
  const sk = solve(pose);
  const P = (v: V3) => project(v, dir);
  const character = new Buf(CELL, CELL), weapon = new Buf(CELL, CELL), emissive = new Buf(CELL, CELL);
  const glow = new Int8Array(CELL * CELL).fill(-1);
  const wGlow = new Uint8Array(CELL * CELL);
  const part = new Part();
  const side = dir === 'left' || dir === 'right';
  const mirrorSide = dir === 'left';
  const emitters: CharLayers['emitters'] = [];

  type Item = { z: number; weapon?: boolean; draw: () => void };
  const items: Item[] = [];
  const pr = (v: V3) => { const q = P(v); return { x: q.x, y: q.y }; };

  // Legs
  for (const s of ['R', 'L'] as const) {
    const hip = s === 'R' ? sk.hipR : sk.hipL, kn = s === 'R' ? sk.knR : sk.knL, ft = s === 'R' ? sk.ftR : sk.ftL;
    const zLeg = (P(hip).z + P(kn).z + P(ft).z) / 3;
    items.push({ z: zLeg, draw: () => drawLimb(part, pr(hip), pr(kn), 3.1, 2.6, [0.55], s === 'R' ? [[0.4, 0.5]] : [[0.6, -0.4]], 0.4) });
    items.push({ z: zLeg + 0.05, draw: () => drawLimb(part, pr(kn), pr(ft), 2.6, 2.1, [0.5], s === 'L' ? [[0.35, 0.3]] : []) });
    items.push({ z: zLeg + 0.15, draw: () => { const k = P(kn); drawStamp(part, KNEE, k.x, k.y); } });
    items.push({
      z: P(ft).z + 0.3, draw: () => {
        const f = P([ft[0], ft[1], ft[2] - 2]);
        if (side) drawStamp(part, BOOT.right, f.x, f.y, mirrorSide);
        else drawStamp(part, dir === 'front' ? BOOT.front : BOOT.back, f.x, f.y, s === 'L');
      },
    });
  }
  // Torso
  const zc = P(sk.chest).z;
  items.push({ z: P(sk.waist).z + (dir === 'front' ? 0.4 : 0.2), draw: () => { const w = P(sk.waist); drawStamp(part, side ? WAIST.right : dir === 'front' ? WAIST.front : WAIST.back, w.x, w.y, mirrorSide); } });
  items.push({ z: zc + 0.5, draw: () => { const c = P(sk.chest); drawStamp(part, side ? CHEST.right : dir === 'front' ? CHEST.front : CHEST.back, c.x, c.y, mirrorSide); } });
  // Head
  let headOrigin = { x: 0, y: 0 };
  items.push({
    z: zc + 3.2, draw: () => {
      const n = P(sk.neck);
      const st = HEAD[dir];
      drawStamp(part, st, n.x, n.y);
      headOrigin = { x: Math.round(n.x) - st.ax, y: Math.round(n.y) - st.ay };
    },
  });
  // Arms
  for (const s of ['R', 'L'] as const) {
    const sh = s === 'R' ? sk.shR : sk.shL, el = s === 'R' ? sk.elR : sk.elL, ha = s === 'R' ? sk.haR : sk.haL;
    const zArm = (P(sh).z + P(el).z) / 2;
    const zFore = (P(el).z + P(ha).z) / 2;
    items.push({ z: zArm + 0.6, draw: () => drawLimb(part, pr(sh), pr(el), 2.7, 2.3, [0.5], s === 'R' ? [[0.6, 0.3]] : []) });
    items.push({ z: zFore + 0.7, draw: () => drawLimb(part, pr(el), pr(ha), 2.3, 2.9, [0.35], s === 'L' ? [[0.55, -0.3]] : [[0.7, 0.4]]) });
    items.push({
      z: P(ha).z + 0.95, draw: () => {
        const h = P(ha);
        if (side) drawStamp(part, GAUNTLET, h.x, h.y, mirrorSide);
        else drawStamp(part, GAUNTLET_FRONT, h.x, h.y, (dir === 'front') === (s === 'L'));
      },
    });
    items.push({
      z: P(sh).z + 2.4, draw: () => {
        const q = P(sh);
        const st = s === 'R' ? PAULDRON_R : PAULDRON_L;
        // spikes point away from the body centre on screen
        const outwardRight = q.x >= ROOT_X + (P(sk.chest).x - ROOT_X);
        const mir = side ? mirrorSide : !outwardRight;
        drawStamp(part, st, q.x + (side ? 0 : outwardRight ? 1 : -1), q.y - 1, mir);
        const tipX = mir ? st.w - 1 - 2 : 2;
        emitters.push({ x: Math.round(q.x + (side ? 0 : outwardRight ? 1 : -1)) - (mir ? st.w - 1 - st.ax : st.ax) + tipX, y: Math.round(q.y - 1) - st.ay, kind: 'shoulder' });
      },
    });
  }
  // Sword
  const zSword = pose.swFree >= 0.5 ? (P(sk.grip).z + P(sk.tip).z) / 2 + 3 : P(sk.haR).z + 0.85;
  // blade below the ground plane is buried (planted / leaning) — clip it in 3D instead of letting it leave the cell
  const cut = sk.tip[2] < 0.3 && sk.grip[2] > 0.3 ? (sk.grip[2] - 0.3) / (sk.grip[2] - sk.tip[2]) : 1;
  items.push({ z: zSword, weapon: true, draw: () => drawSword(part, pr(sk.grip), pr(sk.tip), pr(sk.pommel), cut) });

  items.sort((a, b) => a.z - b.z);
  for (const it of items) {
    part.reset();
    it.draw();
    for (const i of part.touched) {
      const x = i % CELL, y = (i / CELL) | 0;
      const occupied = character.d[i * 4 + 3] > 0 || weapon.d[i * 4 + 3] > 0;
      let col = part.c.get(x, y);
      if (part.o[i]) col = occupied ? OUTLINE_IN : OUTLINE; // selective interior contour
      if (it.weapon) weapon.set(x, y, col);
      else { character.set(x, y, col); weapon.clearPx(x, y); }
      glow[i] = part.o[i] ? -1 : part.g[i];
      wGlow[i] = it.weapon ? 1 : 0;
    }
  }
  // emissive layer from levels, modulated by pose glow + deterministic flicker
  for (let i = 0; i < glow.length; i++) {
    if (glow[i] < 0) continue;
    const x = i % CELL, y = (i / CELL) | 0;
    const flick = ((x * 7 + y * 13 + frameSeed * 5) % 9) === 0 ? 1 : 0;
    // the blade is already near white-hot: heat boosts it only partially so it keeps its ramp
    const lvl = glow[i] + (wGlow[i] ? Math.min(1, pose.glow * 0.3) : pose.glow) + flick;
    if (lvl >= 1.5) emissive.set(x, y, glowAt(lvl));
  }
  if (headOrigin) for (const [hx, hy] of HORN_TIPS[dir]) emitters.push({ x: headOrigin.x + hx, y: headOrigin.y + hy, kind: 'horn' });
  const c = P(sk.chest);
  emitters.push({ x: Math.round(c.x), y: Math.round(c.y), kind: 'core' });
  const tp = P(sk.tip);
  emitters.push({ x: Math.round(tp.x), y: Math.round(tp.y), kind: 'blade' });

  const A = (v: V3): [number, number] => { const q = P(v); return [Math.round(q.x), Math.round(q.y)]; };
  const anchors: Record<string, [number, number]> = {
    root: [ROOT_X, ROOT_Y],
    footR: A([sk.ftR[0], sk.ftR[1], 0]), footL: A([sk.ftL[0], sk.ftL[1], 0]),
    handR: A(sk.haR), handL: A(sk.haL), swordTip: A(sk.tip), grip: A(sk.grip),
    chest: A(sk.chest), head: A(sk.neck),
  };
  return { character, weapon, emissive, anchors, emitters, glowLevels: glow };
}
