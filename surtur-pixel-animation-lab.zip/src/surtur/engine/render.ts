import { Buf } from './buf';
import { zlibSync, unzlibSync, strToU8, strFromU8 } from 'fflate';
import { ACTIONS, ACTION_MAP, poseAt, type ActionDef, type Phase } from './actions';
import { renderCharacter, type Dir, DIRS, CELL } from './rig';
import { renderFX, FX_LAYERS, FX_W, FX_H, FX_OFF_X, FX_OFF_Y, type FxLayer, type FxMeta } from './fx';

export const CHAR_LAYERS = ['character', 'weapon', 'emissive'] as const;
export type CharLayer = (typeof CHAR_LAYERS)[number];
export type LayerName = CharLayer | FxLayer;
export const ALL_LAYERS: LayerName[] = [...CHAR_LAYERS, ...FX_LAYERS];
export const isCharLayer = (l: LayerName) => (CHAR_LAYERS as readonly string[]).includes(l);
export const layerSize = (l: LayerName) => (isCharLayer(l) ? { w: CELL, h: CELL, ox: 0, oy: 0 } : { w: FX_W, h: FX_H, ox: -FX_OFF_X, oy: -FX_OFF_Y });

export interface FrameData {
  action: string; dir: Dir; index: number;
  layers: Record<LayerName, Buf>;
  anchors: Record<string, [number, number]>;
  durationMs: number; phase: Phase; meta: FxMeta;
  edited: LayerName[];
}

export interface Project {
  version: number;
  name: string;
  overrides: Record<string, Buf>; // `${action}|${dir}|${frame}|${layer}`
  anchors: Record<string, Record<string, [number, number]>>; // `${action}|${dir}|${frame}`
  timing: Record<string, number>; // `${action}|${frame}`
}
export const newProject = (): Project => ({ version: 1, name: 'Surtur', overrides: {}, anchors: {}, timing: {} });
export const okey = (a: string, d: Dir, f: number, l: LayerName) => `${a}|${d}|${f}|${l}`;

const cache = new Map<string, Omit<FrameData, 'edited'>>();

export function generateFrame(action: string, dir: Dir, index: number): Omit<FrameData, 'edited'> {
  const key = `${action}|${dir}|${index}`;
  const hit = cache.get(key);
  if (hit) return hit;
  const def = ACTION_MAP[action];
  const pose = poseAt(def, index);
  const c = renderCharacter(pose, dir, index);
  const fx = renderFX(def, dir, index, pose, c.emitters);
  const out = {
    action, dir, index,
    layers: { character: c.character, weapon: c.weapon, emissive: c.emissive, ...fx.layers } as Record<LayerName, Buf>,
    anchors: c.anchors, durationMs: def.durations[index], phase: def.phases[index], meta: fx.meta,
  };
  cache.set(key, out);
  return out;
}

export function getFrame(p: Project, action: string, dir: Dir, index: number): FrameData {
  const g = generateFrame(action, dir, index);
  const layers = { ...g.layers };
  const edited: LayerName[] = [];
  for (const l of ALL_LAYERS) {
    const o = p.overrides[okey(action, dir, index, l)];
    if (o) { layers[l] = o; edited.push(l); }
  }
  const anchors = { ...g.anchors, ...(p.anchors[`${action}|${dir}|${index}`] ?? {}) };
  const durationMs = p.timing[`${action}|${index}`] ?? g.durationMs;
  return { ...g, layers, anchors, durationMs, edited };
}

export interface CompositeOpts { visible?: Partial<Record<LayerName, boolean>>; opacity?: Partial<Record<LayerName, number>> }

/** Composite in FX space (128x112). Layer order respects per-facing depth flags. */
export function compositeFX(fr: FrameData, o: CompositeOpts = {}): Buf {
  const out = new Buf(FX_W, FX_H);
  const vis = (l: LayerName) => o.visible?.[l] !== false;
  const op = (l: LayerName) => o.opacity?.[l] ?? 1;
  const draw = (l: LayerName) => {
    if (!vis(l)) return;
    const s = layerSize(l);
    out.blit(fr.layers[l], s.ox + FX_OFF_X, s.oy + FX_OFF_Y, op(l));
  };
  draw('ground_impact'); draw('shockwave'); draw('smoke');
  if (fr.meta.summonBehind) draw('summoned_entity');
  if (fr.meta.trailBehind) draw('trail');
  draw('character');
  if (!fr.meta.trailBehind) draw('trail');
  draw('weapon'); draw('emissive'); draw('flames'); draw('embers');
  if (!fr.meta.summonBehind) draw('summoned_entity');
  return out;
}
export function compositeCell(fr: FrameData, includeFx: boolean): Buf {
  const visible: Partial<Record<LayerName, boolean>> = {};
  if (!includeFx) for (const l of FX_LAYERS) visible[l] = false;
  return compositeFX(fr, { visible }).crop(FX_OFF_X, FX_OFF_Y, CELL, CELL);
}
/** Core character only (character+weapon+emissive) in the 64 cell — used for clipping checks. */
export function coreCell(fr: FrameData): Buf {
  const b = new Buf(CELL, CELL);
  b.blit(fr.layers.character, 0, 0); b.blit(fr.layers.weapon, 0, 0); b.blit(fr.layers.emissive, 0, 0);
  return b;
}

export function allFrames(p: Project, def: ActionDef, dir: Dir) {
  return Array.from({ length: def.frames }, (_, i) => getFrame(p, def.name, dir, i));
}
export { ACTIONS, DIRS };

// ------------------------------- project (de)serialisation -------------------------------
const b64 = (u: Uint8Array) => {
  let s = '';
  for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode(...u.subarray(i, i + 0x8000));
  return typeof btoa === 'function' ? btoa(s) : Buffer.from(u).toString('base64');
};
const unb64 = (s: string) => {
  if (typeof atob !== 'function') return new Uint8Array(Buffer.from(s, 'base64'));
  const bin = atob(s);
  const u = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
  return u;
};
export function serializeProject(p: Project): string {
  const overrides: Record<string, { w: number; h: number; z: string }> = {};
  for (const [k, b] of Object.entries(p.overrides)) overrides[k] = { w: b.w, h: b.h, z: b64(zlibSync(new Uint8Array(b.d.buffer.slice(0)))) };
  return JSON.stringify({ format: 'surtur-lab-project', version: p.version, name: p.name, overrides, anchors: p.anchors, timing: p.timing });
}
export function deserializeProject(s: string): Project {
  const j = JSON.parse(s);
  if (j.format !== 'surtur-lab-project') throw new Error('Not a Surtur lab project');
  const overrides: Record<string, Buf> = {};
  for (const [k, v] of Object.entries(j.overrides as Record<string, { w: number; h: number; z: string }>)) overrides[k] = new Buf(v.w, v.h, new Uint8ClampedArray(unzlibSync(unb64(v.z))));
  return { version: j.version, name: j.name, overrides, anchors: j.anchors ?? {}, timing: j.timing ?? {} };
}
export { strToU8, strFromU8 };
