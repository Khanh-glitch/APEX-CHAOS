import { zipSync, unzipSync, strToU8, strFromU8 } from 'fflate';
import { Buf } from './buf';
import { encodePNG, decodePNG, readPNGHeader } from './png';
import { ACTIONS, ACTION_MAP } from './actions';
import { DIRS, CELL, ROOT_X, ROOT_Y, type Dir } from './rig';
import { FX_W, FX_H, FX_OFF_X, FX_OFF_Y, FX_LAYERS } from './fx';
import { getFrame, compositeCell, compositeFX, coreCell, layerSize, ALL_LAYERS, serializeProject, type Project, type LayerName } from './render';
import { hex } from './palette';

export const VERSION = '1.0.0';

/** RockBoss legacy schema (verified against the brief; re-verify with the in-lab ZIP auditor). */
export const LEGACY: Record<string, { master: string; frames: number; rows: Dir[]; rowFiles: Record<Dir, string> }> = {
  idle: { master: 'idle/BossEnemy_idle.png', frames: 7, rows: ['front', 'back', 'left', 'right'], rowFiles: { front: 'spritesheet-5.png', back: 'spritesheet-6.png', left: 'spritesheet-7.png', right: 'spritesheet-8.png' } },
  walk: { master: 'walk/BossEnemy_walk.png', frames: 10, rows: ['back', 'left', 'right', 'front'], rowFiles: { back: 'spritesheet-2.png', left: 'spritesheet-3.png', right: 'spritesheet-4.png', front: 'spritesheet.png' } },
  stomp: { master: 'stomp/BossEnemy_stomp.png', frames: 13, rows: ['back', 'left', 'right', 'front'], rowFiles: { back: 'spritesheet-10.png', left: 'spritesheet-11.png', right: 'spritesheet-12.png', front: 'spritesheet-9.png' } },
  swipe: { master: 'swipe/BossEnemy_swipe.png', frames: 10, rows: ['front', 'back', 'left', 'right'], rowFiles: { front: 'spritesheet-13.png', back: 'spritesheet-14.png', left: 'spritesheet-15.png', right: 'spritesheet-16.png' } },
};
export const rowFilePath = (action: string, dir: Dir) => `${action}/${LEGACY[action].rowFiles[dir]}`;

export function stripFor(p: Project, action: string, dir: Dir, fx: boolean) {
  const def = ACTION_MAP[action];
  const b = new Buf(def.frames * CELL, CELL);
  for (let i = 0; i < def.frames; i++) b.blit(compositeCell(getFrame(p, action, dir, i), fx), i * CELL, 0);
  return b;
}

export function buildLegacyZip(p: Project, bakeFx = true): Uint8Array {
  const files: Record<string, Uint8Array> = {};
  for (const [action, spec] of Object.entries(LEGACY)) {
    const master = new Buf(spec.frames * CELL, 4 * CELL);
    spec.rows.forEach((dir, row) => {
      const strip = stripFor(p, action, dir, bakeFx);
      master.blit(strip, 0, row * CELL);
      files[rowFilePath(action, dir)] = encodePNG(strip);
    });
    files[spec.master] = encodePNG(master);
  }
  return zipSync(files, { level: 6 });
}

export function buildManifest(p: Project) {
  const animations: Record<string, unknown> = {};
  for (const def of ACTIONS) {
    const frames: Record<string, unknown[]> = {};
    for (const dir of DIRS) {
      frames[dir] = Array.from({ length: def.frames }, (_, i) => {
        const fr = getFrame(p, def.name, dir, i);
        const bb = coreCell(fr).bounds();
        return { index: i, durationMs: fr.durationMs, phase: fr.phase, anchors: fr.anchors, coreBounds: bb, file: `frames/${def.name}/${dir}/${String(i).padStart(2, '0')}.png`, editedLayers: fr.edited };
      });
    }
    const durations = Array.from({ length: def.frames }, (_, i) => p.timing[`${def.name}|${i}`] ?? def.durations[i]);
    const t0 = durations.map((_, i) => durations.slice(0, i).reduce((s, v) => s + v, 0));
    animations[def.name] = {
      label: def.label, frameCount: def.frames, loop: def.loop, status: def.status, bonus: !!def.bonus, legacy: !!def.legacy,
      durationsMs: durations, totalMs: durations.reduce((s, v) => s + v, 0), phases: def.phases,
      events: def.events.map((e) => ({ ...e, timeMs: t0[e.frame] })),
      rootMotion: def.rootMotion, hitboxes: def.hitboxes,
      sheets: { composite: `sheets/${def.name}.png`, rows: DIRS, perDirection: Object.fromEntries(DIRS.map((d) => [d, `sheets/${def.name}_${d}.png`])), fxComposite: `fx/${def.name}_fx.png` },
      layers: Object.fromEntries(ALL_LAYERS.map((l) => [l, `layers/${def.name}/${l}.png`])),
      frames,
    };
  }
  return {
    format: 'surtur-animation', version: VERSION, generator: 'Surtur Pixel Animation Lab',
    cell: { w: CELL, h: CELL }, root: { x: ROOT_X, y: ROOT_Y },
    fxCell: { w: FX_W, h: FX_H, offsetFromCell: { x: -FX_OFF_X, y: -FX_OFF_Y } },
    directions: DIRS, rowOrder: DIRS, coordinateSystem: 'pixels, y-down, anchors in 64x64 cell space',
    layers: ALL_LAYERS.map((l) => ({ name: l, ...layerSize(l) })),
    layerOrder: ['ground_impact', 'shockwave', 'smoke', 'summoned_entity(if behind)', 'trail(if back)', 'character', 'trail', 'weapon', 'emissive', 'flames', 'embers', 'summoned_entity(if front)'],
    legacy: LEGACY, animations,
  };
}

function scaleNN(b: Buf, s: number) {
  const o = new Buf(b.w * s, b.h * s);
  for (let y = 0; y < o.h; y++) for (let x = 0; x < o.w; x++) o.set(x, y, b.get((x / s) | 0, (y / s) | 0));
  return o;
}
function contact(p: Project, action: string) {
  const def = ACTION_MAP[action];
  const b = new Buf(def.frames * CELL, 4 * CELL);
  for (let y = 0; y < b.h; y++) for (let x = 0; x < b.w; x++) b.set(x, y, hex(((x >> 3) + (y >> 3)) % 2 ? '#2a2d36' : '#323641'));
  DIRS.forEach((d, r) => { for (let i = 0; i < def.frames; i++) b.blit(compositeCell(getFrame(p, action, d, i), true), i * CELL, r * CELL); });
  return scaleNN(b, 2);
}

const b64 = (u: Uint8Array) => { let s = ''; for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode(...u.subarray(i, i + 0x8000)); return typeof btoa === 'function' ? btoa(s) : Buffer.from(u).toString('base64'); };

export function buildPreviewHTML(fxSheets: Record<string, Uint8Array>, manifest: ReturnType<typeof buildManifest>) {
  const sheets = Object.fromEntries(Object.entries(fxSheets).map(([k, v]) => [k, 'data:image/png;base64,' + b64(v)]));
  const anims = Object.fromEntries(Object.entries(manifest.animations).map(([k, v]) => [k, { d: (v as { durationsMs: number[] }).durationsMs, loop: (v as { loop: string }).loop }]));
  return `<!doctype html><html><head><meta charset="utf-8"><title>Surtur preview</title><style>body{background:#121117;color:#ddd;font:13px monospace;margin:20px}canvas{image-rendering:pixelated;background:#24222b;border:1px solid #444}button,select{background:#2a2830;color:#eee;border:1px solid #555;padding:4px 8px;margin:2px}</style></head><body>
<h3>Surtur — offline playable preview (v${manifest.version})</h3><div><select id=a></select><select id=d>${DIRS.map((d) => `<option>${d}</option>`).join('')}</select><select id=z><option>2</option><option selected>4</option><option>6</option></select><button id=p>pause</button> <span id=l></span></div><canvas id=c></canvas>
<script>const S=${JSON.stringify(sheets)},A=${JSON.stringify(anims)},D=${JSON.stringify(DIRS)},W=${FX_W},H=${FX_H};const a=document.getElementById('a'),d=document.getElementById('d'),z=document.getElementById('z'),c=document.getElementById('c'),x=c.getContext('2d'),l=document.getElementById('l');Object.keys(A).forEach(k=>a.add(new Option(k)));const I={};for(const k in S){I[k]=new Image();I[k].src=S[k]}let f=0,t=0,run=true,last=performance.now();document.getElementById('p').onclick=e=>{run=!run;e.target.textContent=run?'pause':'play'};a.onchange=()=>{f=0;t=0};function loop(n){const an=A[a.value],dt=n-last;last=n;if(run){t+=dt;while(t>an.d[f]){t-=an.d[f];f++;if(f>=an.d.length)f=an.loop==='loop'?0:an.d.length-1;if(f===an.d.length-1&&an.loop!=='loop'){t=0;break}}}const s=+z.value;c.width=W*s;c.height=H*s;x.imageSmoothingEnabled=false;const r=D.indexOf(d.value);x.drawImage(I[a.value],f*W,r*H,W,H,0,0,W*s,H*s);l.textContent=a.value+' '+d.value+' frame '+(f+1)+'/'+an.d.length+' '+an.d[f]+'ms';requestAnimationFrame(loop)}requestAnimationFrame(loop);</script></body></html>`;
}

export function buildFullZip(p: Project, opts: { frames?: boolean } = { frames: true }): Uint8Array {
  const files: Record<string, Uint8Array> = {};
  const R = 'surtur/';
  const manifest = buildManifest(p);
  const fxSheets: Record<string, Uint8Array> = {};
  for (const def of ACTIONS) {
    const sheet = new Buf(def.frames * CELL, 4 * CELL);
    const fxSheet = new Buf(def.frames * FX_W, 4 * FX_H);
    const layerSheets = Object.fromEntries(ALL_LAYERS.map((l) => { const s = layerSize(l); return [l, new Buf(def.frames * s.w, 4 * s.h)]; })) as Record<LayerName, Buf>;
    DIRS.forEach((dir, row) => {
      const strip = new Buf(def.frames * CELL, CELL);
      for (let i = 0; i < def.frames; i++) {
        const fr = getFrame(p, def.name, dir, i);
        const cell = compositeCell(fr, true);
        strip.blit(cell, i * CELL, 0);
        fxSheet.blit(compositeFX(fr), i * FX_W, row * FX_H);
        for (const l of ALL_LAYERS) { const s = layerSize(l); layerSheets[l].blit(fr.layers[l], i * s.w, row * s.h); }
        if (opts.frames) files[`${R}frames/${def.name}/${dir}/${String(i).padStart(2, '0')}.png`] = encodePNG(cell);
      }
      sheet.blit(strip, 0, row * CELL);
      files[`${R}sheets/${def.name}_${dir}.png`] = encodePNG(strip);
    });
    files[`${R}sheets/${def.name}.png`] = encodePNG(sheet);
    fxSheets[def.name] = encodePNG(fxSheet);
    files[`${R}fx/${def.name}_fx.png`] = fxSheets[def.name];
    for (const l of ALL_LAYERS) files[`${R}layers/${def.name}/${l}.png`] = encodePNG(layerSheets[l]);
    files[`${R}contact/contact_${def.name}.png`] = encodePNG(contact(p, def.name));
  }
  files[`${R}manifest.json`] = strToU8(JSON.stringify(manifest, null, 1));
  files[`${R}project.surtur.json`] = strToU8(serializeProject(p));
  files[`${R}preview.html`] = strToU8(buildPreviewHTML(fxSheets, manifest));
  files[`${R}README.txt`] = strToU8(`Surtur animation export v${VERSION}\nCells 64x64 RGBA, root anchor (${ROOT_X},${ROOT_Y}). FX layers are ${FX_W}x${FX_H} with the 64 cell placed at (${FX_OFF_X},${FX_OFF_Y}).\nRows in every sheet: ${DIRS.join(', ')}. Timings/events/anchors in manifest.json. Open preview.html offline.\nFX layers: ${FX_LAYERS.join(', ')}.\n`);
  return zipSync(files, { level: 6 });
}

// ------------------------------------ RockBoss ZIP audit ------------------------------------
export interface AuditFile { path: string; width: number; height: number; colorType: number; rgba: boolean; cellsX: number; cellsY: number; divisible: boolean; nonEmptyCells?: number[]; alphaUsed?: boolean; error?: string }
export interface AuditReport { files: AuditFile[]; ignored: string[]; actions: Record<string, { master?: AuditFile; rowMatches: Record<string, number | null>; expectedRows: Dir[]; framesPerDir: number; ok: boolean; notes: string[] }> }

export function auditRockBossZip(bytes: Uint8Array): AuditReport {
  const all = unzipSync(bytes);
  const ignored: string[] = [];
  const pngs: Record<string, Uint8Array> = {};
  for (const [path, data] of Object.entries(all)) {
    if (path.includes('__MACOSX') || path.split('/').pop()!.startsWith('._') || path.endsWith('/')) { ignored.push(path); continue; }
    if (path.toLowerCase().endsWith('.png')) pngs[path] = data; else ignored.push(path);
  }
  const decoded: Record<string, Buf> = {};
  const files: AuditFile[] = Object.entries(pngs).map(([path, data]) => {
    const h = readPNGHeader(data)!;
    const f: AuditFile = { path, width: h.width, height: h.height, colorType: h.colorType, rgba: h.colorType === 6, cellsX: h.width / 64, cellsY: h.height / 64, divisible: h.width % 64 === 0 && h.height % 64 === 0 };
    try {
      const b = decodePNG(data);
      decoded[path] = b;
      f.alphaUsed = false;
      for (let i = 3; i < b.d.length; i += 4) if (b.d[i] < 255) { f.alphaUsed = true; break; }
      f.nonEmptyCells = [];
      for (let cy = 0; cy < Math.floor(h.height / 64); cy++) { let n = 0; for (let cx = 0; cx < Math.floor(h.width / 64); cx++) if (b.crop(cx * 64, cy * 64, 64, 64).opaqueCount() > 0) n++; f.nonEmptyCells.push(n); }
    } catch (e) { f.error = String(e); }
    return f;
  });
  const actions: AuditReport['actions'] = {};
  for (const [action, spec] of Object.entries(LEGACY)) {
    const masterPath = Object.keys(pngs).find((p) => p.endsWith(spec.master));
    const master = files.find((f) => f.path === masterPath);
    const notes: string[] = [];
    const rowMatches: Record<string, number | null> = {};
    if (!master) notes.push('master missing');
    else {
      if (master.width !== spec.frames * 64 || master.height !== 256) notes.push(`master is ${master.width}x${master.height}, expected ${spec.frames * 64}x256`);
      const mb = decoded[masterPath!];
      for (const dir of DIRS) {
        const rp = Object.keys(pngs).find((p) => p.endsWith(`${action}/${spec.rowFiles[dir]}`) || (p.split('/').pop() === spec.rowFiles[dir] && p.includes(action)));
        if (!rp || !decoded[rp] || !mb) { rowMatches[dir] = null; notes.push(`${dir}: row file ${spec.rowFiles[dir]} missing`); continue; }
        // which master row is pixel-identical to this row file? (derives mapping instead of trusting suffixes)
        let found: number | null = null;
        for (let r = 0; r < 4; r++) if (mb.crop(0, r * 64, mb.w, 64).equals(decoded[rp])) found = r;
        rowMatches[dir] = found;
        if (found !== spec.rows.indexOf(dir)) notes.push(`${dir}: row file matches master row ${found}, brief says ${spec.rows.indexOf(dir)}`);
      }
    }
    actions[action] = { master, rowMatches, expectedRows: spec.rows, framesPerDir: spec.frames, ok: notes.length === 0, notes };
  }
  return { files, ignored, actions };
}

export { unzipSync, strFromU8, decodePNG };
