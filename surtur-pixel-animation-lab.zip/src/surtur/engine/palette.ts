// Surtur palette — designed as ramps, not per-pixel noise.
// Character ramps (~30 functional colours) + separately controlled VFX ramps.

export type RGBA = number; // packed 0xRRGGBBAA (unsigned)

export const hex = (h: string, a = 255): RGBA => ((parseInt(h.slice(1), 16) << 8) | a) >>> 0;
export const toHex = (c: RGBA) => '#' + ((c >>> 8) & 0xffffff).toString(16).padStart(6, '0');

// --- Character ramps -------------------------------------------------------
export const OUTLINE = hex('#0b0910'); // deep blue-black contour
export const OUTLINE_IN = hex('#171522'); // selective interior contour
export const OBSIDIAN = ['#141420', '#1f1d2b', '#2c2836', '#3d3644', '#544a58', '#7a6c78'].map((h) => hex(h));
export const CHARCOAL = ['#22161a', '#33201f', '#4a2e2a', '#5f3d33'].map((h) => hex(h)); // warm charcoal / horn
export const BURGUNDY = ['#2e1219', '#461a20', '#6a2228'].map((h) => hex(h));
// Glow ramp index: 0 cooled .. 8 white-hot. Emissive levels address this ramp.
export const GLOW = ['#461a20', '#6a2228', '#a02a1c', '#d8451a', '#ff7418', '#ffa22c', '#ffcc4a', '#fff0a0', '#fffbea'].map((h) => hex(h));

// Stamp character map. Glow chars carry an emissive level instead of a flat colour.
export const CHAR_COLORS: Record<string, RGBA> = {
  o: OUTLINE,
  i: OUTLINE_IN,
  k: OBSIDIAN[0],
  d: OBSIDIAN[1],
  m: OBSIDIAN[2],
  l: OBSIDIAN[3],
  h: OBSIDIAN[4],
  w: OBSIDIAN[5],
  c: CHARCOAL[0],
  n: CHARCOAL[1],
  N: CHARCOAL[2],
  M: CHARCOAL[3],
  q: BURGUNDY[0],
  b: BURGUNDY[1],
  B: BURGUNDY[2],
};
export const GLOW_CHARS: Record<string, number> = { r: 2, R: 3, e: 4, a: 5, A: 6, y: 7, W: 8 };

// --- VFX ramps (independent from character palette) ------------------------
export const FIRE = ['#fffbe0', '#ffe27a', '#ffb02e', '#ff7a1a', '#e2421a', '#a8231c', '#5e1a1e'].map((h) => hex(h));
export const ASH = ['#6a5d62', '#4b4148', '#342c34', '#241e26'].map((h) => hex(h));
export const SMOKE = ['#3a3038', '#2b2329', '#1f191f'].map((h) => hex(h));
export const ROCK = ['#0d0a0e', '#1c1820', '#2f2932', '#4a4048', '#665a62'].map((h) => hex(h));
export const CRACK = hex('#0e080b');
export const SIGIL = ['#fff3b0', '#ffc340', '#ff7a1a', '#b8301c', '#5a1a1e'].map((h) => hex(h));

export const CHARACTER_PALETTE: RGBA[] = [OUTLINE, OUTLINE_IN, ...OBSIDIAN, ...CHARCOAL, ...BURGUNDY, ...GLOW];
export const VFX_PALETTE: RGBA[] = [...FIRE, ...ASH, ...SMOKE, ...ROCK, CRACK, ...SIGIL];
export const ALL_PALETTE: RGBA[] = Array.from(new Set([...CHARACTER_PALETTE, ...VFX_PALETTE]));

export const glowAt = (level: number): RGBA => GLOW[Math.max(0, Math.min(GLOW.length - 1, Math.round(level)))];
