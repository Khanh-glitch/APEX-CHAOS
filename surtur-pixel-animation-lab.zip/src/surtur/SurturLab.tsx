import { useEffect, useState } from 'react';
import { useProject } from './lab/state';
import { Stage, ActionPicker, useSelection } from './lab/Stage';
import { Editor } from './lab/Editor';
import { Combat } from './lab/Combat';
import { Diagnose } from './lab/Diagnose';
import { ExportPanel } from './lab/ExportPanel';
import { Panel } from './lab/canvas';
import { ACTIONS, MANDATORY } from './engine/actions';

const TABS = ['stage', 'editor', 'combat', 'diagnose', 'export', 'status'] as const;
type Tab = (typeof TABS)[number];
const LABELS: Record<Tab, string> = { stage: 'Stage & Browser', editor: 'Frame Editor', combat: 'Combat Test', diagnose: 'Compare & Diagnose', export: 'Export & Validate', status: 'Status / Integration' };

/** Self-contained lab. Mount anywhere: <SurturLab /> — owns no global state except localStorage keys `surtur-lab-*`. */
export default function SurturLab() {
  const { project, rev, touch, saved } = useProject();
  const sel = useSelection();
  const [tab, setTab] = useState<Tab>(() => (TABS as readonly string[]).includes(location.hash.split('/')[2] ?? '') ? (location.hash.split('/')[2] as Tab) : 'stage');
  const [reference, setRef] = useState<string | null>(() => { try { return localStorage.getItem('surtur-lab-reference'); } catch { return null; } });
  const setReference = (s: string | null) => { setRef(s); try { s ? localStorage.setItem('surtur-lab-reference', s) : localStorage.removeItem('surtur-lab-reference'); } catch { /* quota */ } };
  useEffect(() => { history.replaceState(null, '', `#/surtur-lab/${tab}`); }, [tab]);

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        {TABS.map((t) => (
          <button key={t} onClick={() => setTab(t)} className={`rounded-md px-3 py-1.5 text-xs font-semibold tracking-wide ${tab === t ? 'bg-gradient-to-b from-orange-500 to-red-700 text-white shadow shadow-red-900/50' : 'bg-zinc-900 text-zinc-400 hover:text-zinc-100'}`}>{LABELS[t]}</button>
        ))}
        <span className="ml-auto text-[10px] text-zinc-500">project autosaved {saved || '—'}</span>
      </div>
      {tab !== 'combat' && tab !== 'export' && tab !== 'status' && <ActionPicker {...sel} />}
      {tab === 'stage' && <Stage project={project} rev={rev} sel={sel} reference={reference} />}
      {tab === 'editor' && <Editor project={project} rev={rev} touch={touch} sel={sel} />}
      {tab === 'combat' && <Combat project={project} rev={rev} />}
      {tab === 'diagnose' && <Diagnose project={project} rev={rev} sel={sel} reference={reference} setReference={setReference} />}
      {tab === 'export' && <ExportPanel project={project} />}
      {tab === 'status' && <Status />}
    </div>
  );
}

function Status() {
  return (
    <div className="grid gap-3 lg:grid-cols-2">
      <Panel title="Animation status (honest)">
        <table className="w-full text-[11px]">
          <thead className="text-zinc-500"><tr><th className="text-left">action</th><th>frames/dir</th><th>dirs</th><th>status</th></tr></thead>
          <tbody>{ACTIONS.map((a) => <tr key={a.name} className="border-t border-zinc-800"><td>{a.label}{MANDATORY.includes(a.name) ? '' : ' (bonus)'}</td><td className="text-center">{a.frames}</td><td className="text-center">4 cardinal</td><td className="text-center text-emerald-400">{a.status}</td></tr>)}</tbody>
        </table>
        <ul className="mt-3 list-disc space-y-1 pl-4 text-[11px] text-zinc-400">
          <li>Diagonal (8-direction) views are <b>not authored</b> and are locked. They will not be faked by rotating or reusing cardinal images.</li>
          <li>Bonus set: only <b>hurt</b> is implemented. death / recover / victory / second special are <b>not done</b>. (In combat, "recover" plays collapse in reverse when you press R. It is not a separately authored animation.)</li>
          <li>Side views (left/right) are leaner than front/back. Their torso/pauldron mass is smaller than the concept's bulk. That is the main remaining art refinement.</li>
          <li>When the blade points straight at the camera, it gets a minimum foreshortened length so it stays readable. When it goes below the ground plane, the buried part is clipped. A few back/left frames hide the sword behind the body, as real occlusion would (the validator reports these as warnings).</li>
          <li>The RockBoss ZIP and concept PNG were <b>not available</b> in the build environment. Use the in-lab auditor and the reference loader to verify against your copies.</li>
        </ul>
      </Panel>
      <Panel title="Integration path into AI Arena Battle">
        <ol className="list-decimal space-y-1.5 pl-4 text-[11px] text-zinc-300">
          <li>Copy <code className="text-orange-200">src/surtur/</code> into the game repo. The engine is pure TS with one dependency, <code>fflate</code>, and no DOM. The lab UI is React + Tailwind.</li>
          <li>Add a route or tab that renders <code className="text-orange-200">&lt;SurturLab /&gt;</code> (it self-routes under <code>#/surtur-lab/*</code>). Nothing else in the game is touched.</li>
          <li>Game runtime: load <code>surtur/manifest.json</code> + <code>sheets/*.png</code> from the Full ZIP. For each animation use <code>durationsMs</code>, <code>events</code> (hit / footstep / summon_spawn), <code>rootMotion</code>, <code>hitboxes</code> and per-frame <code>anchors</code>. Draw FX sheets at <code>fxCell.offsetFromCell</code>.</li>
          <li>Legacy path: drop the Legacy ZIP contents in place of the RockBoss folders. Names, row order and cell sizes match, so existing RockBoss loaders work unchanged.</li>
          <li>CI: <code>npx esbuild tools/verify.ts --bundle --platform=node --outfile=v.cjs &amp;&amp; node v.cjs</code> runs the same validation suite headless and writes both ZIPs.</li>
        </ol>
      </Panel>
    </div>
  );
}
