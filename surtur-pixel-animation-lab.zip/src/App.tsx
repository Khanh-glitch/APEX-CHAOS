import SurturLab from './surtur/SurturLab';

export default function App() {
  return (
    <div className="min-h-screen bg-[#0e0d12] text-zinc-200">
      <header className="border-b border-zinc-800 bg-gradient-to-r from-[#1a0f10] via-[#121016] to-[#0e0d12]">
        <div className="mx-auto flex max-w-[1500px] items-center gap-4 px-4 py-3">
          <div className="flex h-9 w-9 items-center justify-center rounded bg-gradient-to-b from-orange-500 to-red-800 font-black text-black">AI</div>
          <div>
            <div className="text-[10px] font-semibold uppercase tracking-[0.25em] text-zinc-500">AI Arena Battle · tools</div>
            <h1 className="text-lg font-bold tracking-tight text-orange-100">Surtur Pixel Animation Lab</h1>
          </div>
          <span className="ml-auto max-w-md text-right text-[10px] leading-snug text-zinc-500">Standalone build: the AI Arena Battle game source wasn't in this workspace. The lab is isolated in <code>src/surtur/</code>. See Status / Integration for how to mount it as a route.</span>
        </div>
      </header>
      <main className="mx-auto max-w-[1500px] px-4 py-4">
        <SurturLab />
      </main>
    </div>
  );
}
